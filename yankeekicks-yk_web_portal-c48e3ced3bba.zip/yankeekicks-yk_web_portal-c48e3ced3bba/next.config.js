/** @type {import('next').NextConfig} */
const path = require('path');
const nextConfig = {
  reactStrictMode: false,
  swcMinify: false, //TODO: make true in future when kiosk code will seperate make this false because of react-idle-timer is getting error in production mode
  sassOptions: {
    includePaths: [path.join(__dirname, 'styles')],
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'cdn.shopify.com',
      },
      {
        protocol: 'https',
        hostname: 'yankeekics-dev.s3.amazonaws.com',
      },
      {
        protocol: 'https',
        hostname: 'images.stockx.com',
      },
    ],
  },
};

module.exports = nextConfig;
