import { WARE_HOUSE_TABLE_TAB_QUERY_STATUS } from 'components/warehouse/constants';
// warehouse table query
export const getWareHouseData = (
  type: string = 'All',
  filterInput: any = {},
  userOffset: Number,
  searchData: string,
  storeId: any,
  inDateRange: any,
  locationId: any
) => {
  let filterValue: any = [];
  const obj = {
    member: '',
    operator: 'contains',
    values: [],
  };
  filterValue.push(
    {
      ...obj,
      member: 'WarehouseProductList.storeId',
      operator: 'equals',
      values: [storeId],
    },
    {
      ...obj,
      member: 'WarehouseProductList.locationId',
      operator: 'equals',
      values: [locationId],
    }
  );
  if (type) {
    if (type.includes('All')) {
      filterValue.push(
        {
          ...obj,
          member: 'WarehouseProductList.eventType',
          values: [
            WARE_HOUSE_TABLE_TAB_QUERY_STATUS.CHECK_IN,
            WARE_HOUSE_TABLE_TAB_QUERY_STATUS.CHECK_OUT,
            WARE_HOUSE_TABLE_TAB_QUERY_STATUS.PENDING,
            WARE_HOUSE_TABLE_TAB_QUERY_STATUS.SOLD,
            WARE_HOUSE_TABLE_TAB_QUERY_STATUS.MISSING,
          ],
        },
        {
          ...obj,
          member: 'WarehouseProductList.storeId',
          operator: 'equals',
          values: [storeId],
        },
        {
          ...obj,
          member: 'WarehouseProductList.eventTime',
          operator: 'inDateRange',
          values: [inDateRange],
        }
      );
    }
    if (type.includes('Pending')) {
      filterValue.push(
        {
          ...obj,
          member: 'WarehouseProductList.eventType',
          values: [WARE_HOUSE_TABLE_TAB_QUERY_STATUS.PENDING],
        },
        {
          ...obj,
          member: 'WarehouseProductList.eventTime',
          operator: 'inDateRange',
          values: [inDateRange],
        }
      );
    }
    if (type.includes('Checked In')) {
      filterValue.push(
        {
          ...obj,
          member: 'WarehouseProductList.eventType',
          values: [WARE_HOUSE_TABLE_TAB_QUERY_STATUS.CHECK_IN],
        },
        {
          ...obj,
          member: 'WarehouseProductList.eventTime',
          operator: 'inDateRange',
          values: [inDateRange],
        }
      );
    }
    if (type.includes('Checked Out')) {
      filterValue.push(
        {
          ...obj,
          member: 'WarehouseProductList.eventType',
          values: [WARE_HOUSE_TABLE_TAB_QUERY_STATUS.CHECK_OUT],
        },
        {
          ...obj,
          member: 'WarehouseProductList.eventTime',
          operator: 'inDateRange',
          values: [inDateRange],
        }
      );
    }
  }

  if (filterInput && filterInput?.bin?.length > 0) {
    filterValue.push({
      ...obj,
      member: 'WarehouseProductList.itemName',
      operator: 'contains',
      values: filterInput.bin,
    });
  }

  if (filterInput && filterInput?.size?.length > 0) {
    filterValue.push({
      ...obj,
      member: 'WarehouseProductList.size',
      operator: 'contains',
      values: filterInput.size,
    });
  }

  if (filterInput && filterInput?.requestBy?.length > 0) {
    filterValue.push({
      ...obj,
      member: 'WarehouseProductList.user_name',
      operator: 'equals',
      values: filterInput?.requestBy,
    });
  }

  if (searchData) {
    filterValue.push({
      or: [
        {
          member: 'WarehouseProductList.RequestNumber',
          operator: 'contains',
          values: [searchData],
        },
        {
          member: 'WarehouseProductList.inventory_sku',
          operator: 'contains',
          values: [searchData],
        },
        {
          member: 'WarehouseProductList.itemName',
          operator: 'contains',
          values: [searchData],
        },
        {
          member: 'WarehouseProductList.size',
          operator: 'contains',
          values: [searchData],
        },
        {
          member: 'WarehouseProductList.userName',
          operator: 'contains',
          values: [searchData],
        },
      ],
    });
  }
  const currentTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  return {
    order: {
      'WarehouseProductList.eventTime': 'desc',
    },
    dimensions: [
      'WarehouseProductList.inventory_sku',
      'WarehouseProductList.itemName',
      'WarehouseProductList.imageUrl',
      'WarehouseProductList.size',
      'WarehouseProductList.eventType',
      'WarehouseProductList.eventTime.second',
      'WarehouseProductList.bin',
      'WarehouseProductList.rack',
      'WarehouseProductList.RequestNumber',
      'WarehouseProductList.request_count',
      'WarehouseProductList.userName',
      'WarehouseProductList.variantId',
      'WarehouseProductList.Barcode',
      'WarehouseProductList.consignorName',
      'WarehouseProductList.Brand',
    ],
    filters: filterValue,
    limit: 8,
    offset: userOffset,
    timezone: currentTimezone,
    timeDimensions: [
      {
        dimension: 'WarehouseProductList.eventTime',
        granularity: 'second',
      },
    ],
  };
};

export const getBrandsQuery = () => {
  return {
    dimensions: ['Brand.brandName', 'Brand.brandImageUrl'],
    order: {
      'Brand.brandName': 'asc',
    },
  };
};

export const getSearchQuery = (
  input: any,
  userOffset: Number,
  sortType: string,
  filterInput: any,
  limitForQuery: Number
) => {
  const filterPayload = [];
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };

  const splitInput = input.split(' ');

  let appliedFiltersPayload = splitInput.map((item: any) => {
    return {
      or: [
        {
          member: 'InventoryLineItem.name',
          operator: 'contains',
          values: [item],
        },
        {
          member: 'Catalogue.colorway',
          operator: 'contains',
          values: [item],
        },
        {
          member: 'Brand.brandName',
          operator: 'contains',
          values: [item],
        },
      ],
    };
  });

  if (filterInput?.brands?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'Brand.brandName',
      operator: 'contains',
      values: filterInput.brands,
    });
  }

  if (filterInput?.sizes?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'InventoryLineSize.inventorySize',
      operator: 'equals',
      values: filterInput.sizes,
    });
  }

  if (filterInput?.colorway?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'Catalogue.colorway',
      operator: 'contains',
      values: filterInput.colorway,
    });
  }

  if (filterInput?.releaseYear?.length > 0) {
    const yearsInString = filterInput?.releaseYear.map(String);
    filterPayload.push({
      ...filterObj,
      member: 'Catalogue.releaseYear',
      operator: 'equals',
      values: yearsInString,
    });
  }

  if (filterInput?.sizeTypes?.length > 0) {
    const sizeTypePayload = [];
    const sizeTypeObj = { member: '', operator: '', values: [] };

    if (filterInput?.sizeTypes?.includes('Him')) {
      sizeTypePayload.push({
        ...sizeTypeObj,
        member: 'Catalogue.men',
        operator: 'equals',
        values: ['true'],
      });
    }
    if (filterInput?.sizeTypes?.includes('Her')) {
      sizeTypePayload.push({
        ...sizeTypeObj,
        member: 'Catalogue.women',
        operator: 'equals',
        values: ['true'],
      });
    }
    if (filterInput?.sizeTypes?.includes('Infant')) {
      sizeTypePayload.push({
        ...sizeTypeObj,
        member: 'Catalogue.infant',
        operator: 'equals',
        values: ['true'],
      });
    }
    if (filterInput?.sizeTypes?.includes('Preschool')) {
      sizeTypePayload.push({
        ...sizeTypeObj,
        member: 'Catalogue.preschool',
        operator: 'equals',
        values: ['true'],
      });
    }
    if (filterInput?.sizeTypes?.includes('Toddler')) {
      sizeTypePayload.push({
        ...sizeTypeObj,
        member: 'Catalogue.toddler',
        operator: 'equals',
        values: ['true'],
      });
    }

    filterPayload.push({
      or: sizeTypePayload,
    });
  }

  if (filterPayload.length > 0) {
    appliedFiltersPayload.push({
      and: filterPayload,
    });
  }

  const payloadForFilter = [{ and: appliedFiltersPayload }];

  return {
    dimensions: [
      'Brand.brandName',
      'InventoryLineItem.name',
      'CatalogueImages.imageUrl',
      'InventoryLineItem.sku',
      'Brand.brandName',
      'Catalogue.colorway',
      'Catalogue.releaseYear',
      'Catalogue.releaseDate',
    ],
    filters: payloadForFilter,
    order: [
      ['Catalogue.releaseDate', sortType],
      ['InventoryLineItem.inventoryId', 'asc'],
    ],
    limit: limitForQuery,
    offset: userOffset,
  };
};

export const getColorwaysQuery = (input: any, filterInput: any) => {
  const filterPayload = [];
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };

  const splitInput = input.split(' ');

  let appliedFiltersPayload = splitInput.map((item: any) => {
    return {
      or: [
        {
          member: 'InventoryLineItem.name',
          operator: 'contains',
          values: [item],
        },
        {
          member: 'Catalogue.colorway',
          operator: 'contains',
          values: [item],
        },
        {
          member: 'Brand.brandName',
          operator: 'contains',
          values: [item],
        },
      ],
    };
  });

  if (filterInput?.brands?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'Brand.brandName',
      operator: 'contains',
      values: filterInput.brands,
    });
  }

  if (filterPayload.length > 0) {
    appliedFiltersPayload.push({
      and: filterPayload,
    });
  }

  const payloadForFilter = [{ and: appliedFiltersPayload }];

  return {
    dimensions: ['Catalogue.colorway'],
    filters: payloadForFilter,
  };
};

export const getProductNames = (input: any) => {
  return {
    dimensions: ['InventoryLineItem.name'],
    timeDimensions: [],
    order: {
      'InventoryLineItem.name': 'asc',
    },
    filters: [
      {
        member: 'InventoryLineItem.name',
        operator: 'contains',
        values: [input],
      },
    ],
  };
};

export const getIndividualProduct = (input: any) => {
  return {
    dimensions: [
      'SKUBasedItems.sellingPrice_D',
      'SKUBasedItems.inventoryId',
      'SKUBasedItems.inventorySize',
      'SKUBasedItems.name',
      'SKUBasedItems.inventory_sku',
      'SKUBasedItems.imageUrl',
      'SKUBasedItems.colorway',
      'SKUBasedItems.availableFlag',
    ],
    order: {
      'SKUBasedItems.eventType': 'asc',
    },
    filters: [
      {
        member: 'SKUBasedItems.inventory_sku',
        operator: 'contains',
        values: [input],
      },
      {
        member: 'SKUBasedItems.storeId',
        operator: 'equals',
        values: ['1'],
      },
    ],
  };
};

export const getProductInfo = (input: any) => {
  return {
    dimensions: [
      'ProductInfo.itemName',
      'ProductInfo.inventorySize',
      'ProductInfo.colorway',
      'ProductInfo.style',
      'ProductInfo.retailPrice_D',
      'ProductInfo.imageUrl',
    ],
    order: {
      'ProductInfo.inventorySize': 'asc',
    },
    filters: [
      {
        member: 'ProductInfo.style',
        operator: 'contains',
        values: [input],
      },
    ],
  };
};

//warehouse -Sales Associate KPI query
export const getShoesizeWarehouseKPIQuery = (
  storeId: any,
  locationId: any,
  startDate: any,
  endDate: any,
  userId: any = ''
) => {
  let kpiFilterValue: any = [];
  kpiFilterValue.push(
    {
      member: 'WarehouseKPICount.eventTime',
      operator: 'inDateRange',
      values: [startDate, endDate],
    },
    {
      member: 'WarehouseKPICount.storeId',
      operator: 'equals',
      values: [storeId],
    },
    {
      member: 'WarehouseKPICount.locationId',
      operator: 'equals',
      values: [locationId],
    }
  );
  if (userId && userId?.length > 0) {
    kpiFilterValue.push({
      member: 'WarehouseKPICount.UserId',
      operator: 'equals',
      values: [userId],
    });
  }
  return {
    measures: [
      'WarehouseKPICount.checkinCount',
      'WarehouseKPICount.checkoutCount',
      'WarehouseKPICount.pendingCount',
      'WarehouseKPICount.soldCount',
      'WarehouseKPICount.checkinPendingCount',
      'WarehouseKPICount.checkoutPendingCount',
    ],
    filters: kpiFilterValue,
  };
};

export const getAllShoeSizesKPI = () => {
  return {
    dimensions: ['InventoryLineSize.inventorySize'],
    timeDimensions: [],
    order: {
      'InventoryLineSize.inventorySize': 'asc',
    },
  };
};

export const getAllBrandsAPI = () => {
  return {
    dimensions: ['Brand.brandName'],
    timeDimensions: [],
    order: {
      'Brand.brandName': 'asc',
    },
  };
};

//warehouse pagination count query
export const getPaginationCount = (
  type: string = 'All',
  filterInput: any = {},
  userInput: string,
  storeId: any,
  inDateRange: any,
  locationId: any
) => {
  let filterValue: any = [];
  const obj = {
    member: '',
    operator: 'contains',
    values: [],
  };
  filterValue.push(
    {
      ...obj,
      member: 'WarehouseProductList.storeId',
      operator: 'equals',
      values: [storeId],
    },
    {
      ...obj,
      member: 'WarehouseProductList.locationId',
      operator: 'equals',
      values: [locationId],
    }
  );
  if (type) {
    if (type.includes('All')) {
      filterValue.push(
        {
          ...obj,
          member: 'WarehouseProductList.eventType',
          values: [
            WARE_HOUSE_TABLE_TAB_QUERY_STATUS.CHECK_IN,
            WARE_HOUSE_TABLE_TAB_QUERY_STATUS.CHECK_OUT,
            WARE_HOUSE_TABLE_TAB_QUERY_STATUS.PENDING,
            WARE_HOUSE_TABLE_TAB_QUERY_STATUS.MISSING,
          ],
        },
        {
          ...obj,
          member: 'WarehouseProductList.eventTime',
          operator: 'inDateRange',
          values: [inDateRange],
        }
      );
    }
    if (type.includes('Pending')) {
      filterValue.push(
        {
          ...obj,
          member: 'WarehouseProductList.eventType',
          values: [WARE_HOUSE_TABLE_TAB_QUERY_STATUS.PENDING],
        },
        {
          ...obj,
          member: 'WarehouseProductList.eventTime',
          operator: 'inDateRange',
          values: [inDateRange],
        }
      );
    }
    if (type.includes('Checked In')) {
      filterValue.push(
        {
          ...obj,
          member: 'WarehouseProductList.eventType',
          values: [WARE_HOUSE_TABLE_TAB_QUERY_STATUS.CHECK_IN],
        },
        {
          ...obj,
          member: 'WarehouseProductList.eventTime',
          operator: 'inDateRange',
          values: [inDateRange],
        }
      );
    }
    if (type.includes('Checked Out')) {
      filterValue.push(
        {
          ...obj,
          member: 'WarehouseProductList.eventType',
          values: [WARE_HOUSE_TABLE_TAB_QUERY_STATUS.CHECK_OUT],
        },
        {
          ...obj,
          member: 'WarehouseProductList.eventTime',
          operator: 'inDateRange',
          values: [inDateRange],
        }
      );
    }
  }

  if (filterInput && filterInput?.bin?.length > 0) {
    filterValue.push({
      ...obj,
      member: 'WarehouseProductList.bin',
      operator: 'contains',
      values: filterInput?.bin,
    });
  }

  if (filterInput && filterInput?.size?.length > 0) {
    filterValue.push({
      ...obj,
      member: 'WarehouseProductList.size',
      operator: 'contains',
      values: filterInput?.size,
    });
  }

  if (filterInput && filterInput?.requestBy?.length > 0) {
    filterValue.push({
      ...obj,
      member: 'WarehouseProductList.user_name',
      operator: 'contains',
      values: filterInput?.requestBy,
    });
  }

  if (userInput) {
    const searchFilter = {
      or: [
        {
          member: 'WarehouseProductList.RequestNumber',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'WarehouseProductList.inventory_sku',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'WarehouseProductList.itemName',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'WarehouseProductList.size',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'WarehouseProductList.userName',
          operator: 'contains',
          values: [userInput],
        },
      ],
    };
    filterValue.push(searchFilter);
  }

  return {
    order: {
      'WarehouseProductList.RequestNumber': 'desc',
    },
    measures: ['WarehouseProductList.count'],
    filters: filterValue,
  };
};

export const getCountQuery = (userInput: any, filterInput: any) => {
  const filterPayload = [];
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };

  const splitInput = userInput.split(' ');

  let appliedFiltersPayload = splitInput.map((item: any) => {
    return {
      or: [
        {
          member: 'InventoryLineItem.name',
          operator: 'contains',
          values: [item],
        },
        {
          member: 'Catalogue.colorway',
          operator: 'contains',
          values: [item],
        },
        {
          member: 'Brand.brandName',
          operator: 'contains',
          values: [item],
        },
      ],
    };
  });

  if (filterInput?.brands?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'Brand.brandName',
      operator: 'contains',
      values: filterInput.brands,
    });
  }

  if (filterInput?.sizes?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'InventoryLineSize.inventorySize',
      operator: 'equals',
      values: filterInput.sizes,
    });
  }

  if (filterInput?.colorway?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'Catalogue.colorway',
      operator: 'contains',
      values: filterInput.colorway,
    });
  }

  if (filterInput?.releaseYear?.length > 0) {
    const yearsInString = filterInput?.releaseYear.map(String);
    filterPayload.push({
      ...filterObj,
      member: 'Catalogue.releaseYear',
      operator: 'equals',
      values: yearsInString,
    });
  }

  if (filterInput?.sizeTypes?.length > 0) {
    const sizeTypePayload = [];
    const sizeTypeObj = { member: '', operator: '', values: [] };

    if (filterInput?.sizeTypes?.includes('Him')) {
      sizeTypePayload.push({
        ...sizeTypeObj,
        member: 'Catalogue.men',
        operator: 'equals',
        values: ['true'],
      });
    }
    if (filterInput?.sizeTypes?.includes('Her')) {
      sizeTypePayload.push({
        ...sizeTypeObj,
        member: 'Catalogue.women',
        operator: 'equals',
        values: ['true'],
      });
    }
    if (filterInput?.sizeTypes?.includes('Infant')) {
      sizeTypePayload.push({
        ...sizeTypeObj,
        member: 'Catalogue.infant',
        operator: 'equals',
        values: ['true'],
      });
    }
    if (filterInput?.sizeTypes?.includes('Preschool')) {
      sizeTypePayload.push({
        ...sizeTypeObj,
        member: 'Catalogue.preschool',
        operator: 'equals',
        values: ['true'],
      });
    }
    if (filterInput?.sizeTypes?.includes('Toddler')) {
      sizeTypePayload.push({
        ...sizeTypeObj,
        member: 'Catalogue.toddler',
        operator: 'equals',
        values: ['true'],
      });
    }

    filterPayload.push({
      or: sizeTypePayload,
    });
  }

  if (filterPayload.length > 0) {
    appliedFiltersPayload.push({
      and: filterPayload,
    });
  }

  const payloadForFilter = [{ and: appliedFiltersPayload }];

  return {
    measures: ['InventoryLineItem.count'],
    filters: payloadForFilter,
    order: [
      ['CatalogueImages.imageUrl', 'asc'],
      ['InventoryLineItem.name', 'asc'],
      ['InventoryLineItem.sku', 'asc'],
      ['Brand.brandName', 'asc'],
    ],
  };
};

//Sales Associate Pending Tab query
export const getPendingStatusTabQuery = (
  storeId: any,
  inDateRange: any,
  locationId: any,
  userId: any
) => {
  return {
    dimensions: [
      'StoreTab.imageUrl',
      'StoreTab.itemName',
      'StoreTab.inventoryItemId',
      'StoreTab.option1',
      'StoreTab.price',
      'StoreTab.barcode',
      'StoreTab.requestNumber',
    ],
    order: {
      'StoreTab.imageUrl': 'asc',
    },
    filters: [
      {
        member: 'StoreTab.storeId',
        operator: 'equals',
        values: [storeId],
      },
      {
        member: 'StoreTab.locationId',
        operator: 'equals',
        values: [locationId],
      },
      {
        member: 'StoreTab.eventTime',
        operator: 'inDateRange',
        values: [inDateRange],
      },
      {
        member: 'StoreTab.status',
        operator: 'contains',
        values: ['Pending'],
      },
      {
        member: 'StoreTab.UserId',
        operator: 'equals',
        values: [userId],
      },
    ],
    timeDimensions: [
      {
        dimension: 'StoreTab.eventTime',
        granularity: 'day',
      },
    ],
  };
};

//Sales Associate Checked Out Tab query
export const getCheckedOutStatusTabQuery = (
  storeId: any,
  inDateRange: any,
  locationId: any,
  userId: any
) => {
  return {
    dimensions: [
      'StoreTab.imageUrl',
      'StoreTab.itemName',
      'StoreTab.inventoryItemId',
      'StoreTab.option1',
      'StoreTab.price',
      'StoreTab.variantId',
      'StoreTab.productId',
      'StoreTab.barcode',
      'StoreTab.requestNumber',
    ],
    order: {
      'StoreTab.imageUrl': 'asc',
    },
    filters: [
      {
        member: 'StoreTab.storeId',
        operator: 'equals',
        values: [storeId],
      },
      {
        member: 'StoreTab.locationId',
        operator: 'equals',
        values: [locationId],
      },
      {
        member: 'StoreTab.status',
        operator: 'contains',
        values: ['CheckOut'],
      },
      {
        member: 'StoreTab.eventTime',
        operator: 'inDateRange',
        values: [inDateRange],
      },
      {
        member: 'StoreTab.UserId',
        operator: 'equals',
        values: [userId],
      },
    ],
    timeDimensions: [
      {
        dimension: 'StoreTab.eventTime',
        granularity: 'day',
      },
    ],
  };
};

//warehouse request details page query
export const getRequestInfo = (
  requestId: string,
  storeId: any,
  locationId: any
) => {
  const currentTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  return {
    order: {
      'WarehouseTab.RequestNumber': 'desc',
    },
    dimensions: [
      'WarehouseTab.sku',
      'WarehouseTab.itemName',
      'WarehouseTab.imageUrl',
      'WarehouseTab.Option1',
      'WarehouseTab.status',
      'WarehouseTab.bin',
      'WarehouseTab.rack',
      'WarehouseTab.userName',
      'WarehouseTab.requestNumber',
      'WarehouseTab.compartment',
      'WarehouseTab.colorway',
      'WarehouseTab.releaseDate',
      'WarehouseTab.description',
      'WarehouseTab.Price',
      'WarehouseTab.variantId',
      'WarehouseTab.brand',
      'WarehouseTab.productDescription',
      'WarehouseTab.barcode',
      'WarehouseTab.consignorName',
    ],
    filters: [
      {
        member: 'WarehouseTab.requestNumber',
        operator: 'equals',
        values: [requestId],
      },
      {
        member: 'WarehouseTab.storeId',
        operator: 'equals',
        values: [storeId],
      },
      {
        member: 'WarehouseTab.locationId',
        operator: 'equals',
        values: [locationId],
      },
    ],
    timezone: currentTimezone,
    timeDimensions: [
      { dimension: 'WarehouseTab.eventTime', granularity: 'second' },
    ],
  };
};

export const getInventoryProductDetails = (input: any) => {
  const numericId = input.split('/').pop('');
  return {
    order: {
      'InventoryDetailsPopup.inventoryId': 'asc',
    },
    dimensions: [
      'InventoryDetailsPopup.bin',
      'InventoryDetailsPopup.rack',
      'InventoryDetailsPopup.brandName',
      'InventoryDetailsPopup.inventory_sku',
      'InventoryDetailsPopup.colorway',
      'InventoryDetailsPopup.releaseDate',
      'InventoryDetailsPopup.retailPrice_D',
      'InventoryDetailsPopup.Size',
      'InventoryDetailsPopup.Name',
      'InventoryDetailsPopup.imageUrl',
      'InventoryDetailsPopup.Compartment',
      'InventoryDetailsPopup.description',
      'InventoryDetailsPopup.inventoryId',
      'InventoryDetailsPopup.RequestNumber_D',
      'InventoryDetailsPopup.eventTime',
      'InventoryDetailsPopup.ProductId',
      'InventoryDetailsPopup.variantId',
    ],
    filters: [
      {
        member: 'InventoryDetailsPopup.variantId',
        operator: 'equals',
        values: [numericId],
      },
    ],
  };
};

export const getAllBins = () => {
  return {
    dimensions: ['InventoryLineItem.bin'],
    timeDimensions: [],
    order: {
      'InventoryLineItem.bin': 'asc',
    },
  };
};

export const getAvailableLocations = (inventoryItemId: any) => {
  return {
    dimensions: ['AvailableLocations.Name', 'AvailableLocations.location'],
    order: {
      'AvailableLocations.Name': 'asc',
    },
    filters: [
      {
        member: 'AvailableLocations.InventoryItemId',
        operator: 'equals',
        values: [inventoryItemId.toString()],
      },
    ],
  };
};

export const getKioskInventory = (
  filterTypes: any,
  locationId: any,
  selectedSort: any,
  limitToFetch: any,
  currentOffset: any
) => {
  let filterPayload = [];

  const specialChars = ['@', '$', '&', '_', '(', ')'];
  let modifiedUserInput = filterTypes?.title;

  specialChars?.map((item: any) => {
    if (modifiedUserInput?.includes(item)) {
      modifiedUserInput = modifiedUserInput?.replaceAll(item, `\\${item}`);
    }
  });

  let splitUserInput = modifiedUserInput?.trim();
  splitUserInput = splitUserInput?.split(' ');
  let payloadForTitle: any = [];

  splitUserInput?.map((word: any) => {
    payloadForTitle?.push({
      or: [
        {
          member: 'KioskInventory.title',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.brand',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.sku',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.colorway',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.tags',
          operator: 'contains',
          values: [word],
        },
      ],
    });
  });

  filterPayload.push({ and: payloadForTitle });
  filterPayload.push({
    member: 'KioskInventory.locationId',
    operator: 'contains',
    values: [locationId],
  });
  if (filterTypes?.type?.length > 0) {
    const types = [
      { userType: 'men / women', member: 'KioskInventory.men' },
      { userType: 'men / women', member: 'KioskInventory.women' },
      { userType: 'grade school', member: 'KioskInventory.child' },
      { userType: 'toddler', member: 'KioskInventory.infant' },
      { userType: 'pre school', member: 'KioskInventory.preschool' },
      { userType: 'toddler', member: 'KioskInventory.toddler' },
    ];
    let userTypesArray: any = [];
    types?.map((item: any) => {
      if (filterTypes?.type?.includes(item?.userType)) {
        return userTypesArray?.push({
          member: item?.member,
          operator: 'equals',
          values: ['true'],
        });
      }
    });
    const userTypeObj = { or: userTypesArray };
    filterPayload.push(userTypeObj);
  }
  if (filterTypes?.brand?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.brand',
      operator: 'contains',
      values: filterTypes?.brand,
    });
  }
  if (filterTypes?.size?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.option1',
      operator: 'equals',
      values: filterTypes?.size,
    });
  }
  if (filterTypes?.color?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.colorway',
      operator: 'contains',
      values: filterTypes?.color,
    });
  }
  if (filterTypes?.date?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.releaseYear',
      operator: 'contains',
      values: filterTypes?.date,
    });
  }
  if (filterTypes?.availability?.length > 0) {
    const availabilityCriteria = [
      { criteria: 'in stock', operator: 'gt' },
      { criteria: 'out of stock', operator: 'lte' },
    ];
    let availabilityArray: any = [];
    availabilityCriteria?.map((item: any) => {
      if (filterTypes?.availability?.includes(item?.criteria)) {
        return availabilityArray?.push({
          member: 'KioskInventory.availableQuantity',
          operator: item?.operator,
          values: ['0'],
        });
      }
    });
    const availabilityObj = { or: availabilityArray };
    filterPayload?.push(availabilityObj);
  }
  if (filterTypes?.model?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.Model',
      operator: 'contains',
      values: filterTypes?.model,
    });
  }
  if (
    filterTypes?.price?.length > 0 &&
    filterTypes?.price[0] >= 0 &&
    filterTypes?.price[1] > 0
  ) {
    filterPayload?.push({
      and: [
        {
          member: 'KioskInventory.shopifyPrice',
          operator: 'gte',
          values: [`${filterTypes?.price[0]}`],
        },
        {
          member: 'KioskInventory.shopifyPrice',
          operator: 'lte',
          values: [`${filterTypes?.price[1]}`],
        },
      ],
    });
  }
  const orderFlow = selectedSort === 'newest' ? 'desc' : 'asc';

  return {
    dimensions: [
      'KioskInventory.productId',
      'KioskInventory.productType',
      'KioskInventory.tags',
      'KioskInventory.title',
      'KioskInventory.vendor',
      'KioskInventory.imageUrl',
      'KioskInventory.locationId',
      'KioskInventory.releaseYear',
      'KioskInventory.sku',
      'KioskInventory.colorway',
      'KioskInventory.brand',
      'KioskInventory.releaseDate', // to display in inspect mode
    ],
    order: [['KioskInventory.releaseDate', orderFlow]],
    filters: filterPayload,
    limit: limitToFetch,
    offset: currentOffset,
  };
};

export const getKioskInventoryTotalCount = (
  filterTypes: any,
  locationId: any,
  currentOffset: any
) => {
  let filterPayload = [];

  const specialChars = ['@', '$', '&', '_', '(', ')'];
  let modifiedUserInput = filterTypes?.title;

  specialChars?.map((item: any) => {
    if (modifiedUserInput?.includes(item)) {
      modifiedUserInput = modifiedUserInput?.replaceAll(item, `\\${item}`);
    }
  });

  let splitUserInput = modifiedUserInput?.trim();
  splitUserInput = splitUserInput?.split(' ');
  let payloadForTitle: any = [];

  splitUserInput?.map((word: any) => {
    payloadForTitle?.push({
      or: [
        {
          member: 'KioskInventory.title',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.brand',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.sku',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.colorway',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.tags',
          operator: 'contains',
          values: [word],
        },
      ],
    });
  });

  filterPayload.push({ and: payloadForTitle });

  filterPayload.push({
    member: 'KioskInventory.locationId',
    operator: 'contains',
    values: [locationId],
  });
  if (filterTypes?.type?.length > 0) {
    const types = [
      { userType: 'men / women', member: 'KioskInventory.men' },
      { userType: 'men / women', member: 'KioskInventory.women' },
      { userType: 'grade school', member: 'KioskInventory.child' },
      { userType: 'toddler', member: 'KioskInventory.infant' },
      { userType: 'pre school', member: 'KioskInventory.preschool' },
      { userType: 'toddler', member: 'KioskInventory.toddler' },
    ];
    let userTypesArray: any = [];
    types?.map((item: any) => {
      if (filterTypes?.type?.includes(item?.userType)) {
        return userTypesArray?.push({
          member: item?.member,
          operator: 'equals',
          values: ['true'],
        });
      }
    });
    const userTypeObj = { or: userTypesArray };
    filterPayload.push(userTypeObj);
  }
  if (filterTypes?.brand?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.brand',
      operator: 'contains',
      values: filterTypes?.brand,
    });
  }
  if (filterTypes?.size?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.option1',
      operator: 'equals',
      values: filterTypes?.size,
    });
  }
  if (filterTypes?.color?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.colorway',
      operator: 'contains',
      values: filterTypes?.color,
    });
  }
  if (filterTypes?.date?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.releaseYear',
      operator: 'contains',
      values: filterTypes?.date,
    });
  }
  if (filterTypes?.availability?.length > 0) {
    const availabilityCriteria = [
      { criteria: 'in stock', operator: 'gt' },
      { criteria: 'out of stock', operator: 'lte' },
    ];
    let availabilityArray: any = [];
    availabilityCriteria?.map((item: any) => {
      if (filterTypes?.availability?.includes(item?.criteria)) {
        return availabilityArray?.push({
          member: 'KioskInventory.availableQuantity',
          operator: item?.operator,
          values: ['0'],
        });
      }
    });
    const availabilityObj = { or: availabilityArray };
    filterPayload?.push(availabilityObj);
  }
  if (filterTypes?.model?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.Model',
      operator: 'contains',
      values: filterTypes?.model,
    });
  }
  if (
    filterTypes?.price?.length > 0 &&
    filterTypes?.price[0] >= 0 &&
    filterTypes?.price[1] > 0
  ) {
    filterPayload?.push({
      and: [
        {
          member: 'KioskInventory.shopifyPrice',
          operator: 'gte',
          values: [`${filterTypes?.price[0]}`],
        },
        {
          member: 'KioskInventory.shopifyPrice',
          operator: 'lte',
          values: [`${filterTypes?.price[1]}`],
        },
      ],
    });
  }

  return {
    measures: ['KioskInventory.rowCount'],
    filters: filterPayload,
  };
};

export const getKioskInventoryWithSizes = (
  filterTypes: any,
  locationId: any,
  selectedSort: any,
  limitToFetch: any,
  currentOffset: any
) => {
  let filterPayload = [];

  const specialChars = ['@', '$', '&', '_', '(', ')'];
  let modifiedUserInput = filterTypes?.title;

  specialChars?.map((item: any) => {
    if (modifiedUserInput?.includes(item)) {
      modifiedUserInput = modifiedUserInput?.replaceAll(item, `\\${item}`);
    }
  });

  let splitUserInput = modifiedUserInput?.trim();
  splitUserInput = splitUserInput?.split(' ');
  let payloadForTitle: any = [];

  splitUserInput?.map((word: any) => {
    payloadForTitle.push({
      or: [
        {
          member: 'KioskInventory.title',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.brand',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.sku',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.colorway',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.tags',
          operator: 'contains',
          values: [word],
        },
      ],
    });
  });

  filterPayload.push({ and: payloadForTitle });
  filterPayload.push({
    member: 'KioskInventory.locationId',
    operator: 'contains',
    values: [locationId],
  });
  if (filterTypes?.type?.length > 0) {
    const types = [
      { userType: 'men / women', member: 'KioskInventory.men' },
      { userType: 'men / women', member: 'KioskInventory.women' },
      { userType: 'grade school', member: 'KioskInventory.child' },
      { userType: 'toddler', member: 'KioskInventory.infant' },
      { userType: 'pre school', member: 'KioskInventory.preschool' },
      { userType: 'toddler', member: 'KioskInventory.toddler' },
    ];
    let userTypesArray: any = [];
    types?.map((item: any) => {
      if (filterTypes?.type?.includes(item?.userType)) {
        return userTypesArray?.push({
          member: item?.member,
          operator: 'equals',
          values: ['true'],
        });
      }
    });
    const userTypeObj = { or: userTypesArray };
    filterPayload.push(userTypeObj);
  }
  if (filterTypes?.brand?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.brand',
      operator: 'contains',
      values: filterTypes?.brand,
    });
  }
  if (filterTypes?.size?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.option1',
      operator: 'equals',
      values: filterTypes?.size,
    });
  }
  if (filterTypes?.color?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.colorway',
      operator: 'contains',
      values: filterTypes?.color,
    });
  }
  if (filterTypes?.date?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.releaseYear',
      operator: 'contains',
      values: filterTypes?.date,
    });
  }
  if (filterTypes?.availability?.length > 0) {
    const availabilityCriteria = [
      { criteria: 'in stock', operator: 'gt' },
      { criteria: 'out of stock', operator: 'lte' },
    ];
    let availabilityArray: any = [];
    availabilityCriteria?.map((item: any) => {
      if (filterTypes?.availability?.includes(item?.criteria)) {
        return availabilityArray?.push({
          member: 'KioskInventory.availableQuantity',
          operator: item?.operator,
          values: ['0'],
        });
      }
    });
    const availabilityObj = { or: availabilityArray };
    filterPayload?.push(availabilityObj);
  }
  if (filterTypes?.model?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.Model',
      operator: 'contains',
      values: filterTypes?.model,
    });
  }
  if (
    filterTypes?.price?.length > 0 &&
    filterTypes?.price[0] >= 0 &&
    filterTypes?.price[1] > 0
  ) {
    filterPayload?.push({
      and: [
        {
          member: 'KioskInventory.shopifyPrice',
          operator: 'gte',
          values: [`${filterTypes?.price[0]}`],
        },
        {
          member: 'KioskInventory.shopifyPrice',
          operator: 'lte',
          values: [`${filterTypes?.price[1]}`],
        },
      ],
    });
  }

  const orderFlow = selectedSort === 'newest' ? 'desc' : 'asc';

  return {
    dimensions: [
      'KioskInventory.productId',
      'KioskInventory.productType',
      'KioskInventory.tags',
      'KioskInventory.title',
      'KioskInventory.availableQuantity',
      'KioskInventory.vendor',
      'KioskInventory.imageUrl',
      'KioskInventory.locationId',
      'KioskInventory.releaseYear',
      'KioskInventory.variantId',
      'KioskInventory.releaseDate',
      'KioskInventory.shopifyPrice',
      'KioskInventory.sku',
      'KioskInventory.brand',
      'KioskInventory.option1',
      'KioskInventory.colorway',
      'KioskInventory.productDescription',
      'KioskInventory.bin',
      'KioskInventory.shelf',
      'KioskInventory.compartment',
      'KioskInventory.shopifycreatedAt',
      'KioskInventory.consignorName',
    ],
    order: [['KioskInventory.releaseDate', orderFlow]],
    filters: filterPayload,
    limit: limitToFetch,
    offset: currentOffset,
  };
};

export const getKioskInventoryWithSizesTotalCount = (
  filterTypes: any,
  locationId: any,
  currentOffset: any
) => {
  let filterPayload = [];

  const specialChars = ['@', '$', '&', '_', '(', ')'];
  let modifiedUserInput = filterTypes?.title;

  specialChars?.map((item: any) => {
    if (modifiedUserInput?.includes(item)) {
      modifiedUserInput = modifiedUserInput?.replaceAll(item, `\\${item}`);
    }
  });

  let splitUserInput = modifiedUserInput?.trim();
  splitUserInput = splitUserInput?.split(' ');
  let payloadForTitle: any = [];

  splitUserInput?.map((word: any) => {
    payloadForTitle.push({
      or: [
        {
          member: 'KioskInventory.title',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.brand',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.sku',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.colorway',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.tags',
          operator: 'contains',
          values: [word],
        },
      ],
    });
  });

  filterPayload.push({ and: payloadForTitle });
  filterPayload.push({
    member: 'KioskInventory.locationId',
    operator: 'contains',
    values: [locationId],
  });
  if (filterTypes?.type?.length > 0) {
    const types = [
      { userType: 'men / women', member: 'KioskInventory.men' },
      { userType: 'men / women', member: 'KioskInventory.women' },
      { userType: 'grade school', member: 'KioskInventory.child' },
      { userType: 'toddler', member: 'KioskInventory.infant' },
      { userType: 'pre school', member: 'KioskInventory.preschool' },
      { userType: 'toddler', member: 'KioskInventory.toddler' },
    ];
    let userTypesArray: any = [];
    types?.map((item: any) => {
      if (filterTypes?.type?.includes(item?.userType)) {
        return userTypesArray?.push({
          member: item?.member,
          operator: 'equals',
          values: ['true'],
        });
      }
    });
    const userTypeObj = { or: userTypesArray };
    filterPayload.push(userTypeObj);
  }
  if (filterTypes?.brand?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.brand',
      operator: 'contains',
      values: filterTypes?.brand,
    });
  }
  if (filterTypes?.size?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.option1',
      operator: 'equals',
      values: filterTypes?.size,
    });
  }
  if (filterTypes?.color?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.colorway',
      operator: 'contains',
      values: filterTypes?.color,
    });
  }
  if (filterTypes?.date?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.releaseYear',
      operator: 'contains',
      values: filterTypes?.date,
    });
  }
  if (filterTypes?.availability?.length > 0) {
    const availabilityCriteria = [
      { criteria: 'in stock', operator: 'gt' },
      { criteria: 'out of stock', operator: 'lte' },
    ];
    let availabilityArray: any = [];
    availabilityCriteria?.map((item: any) => {
      if (filterTypes?.availability?.includes(item?.criteria)) {
        return availabilityArray?.push({
          member: 'KioskInventory.availableQuantity',
          operator: item?.operator,
          values: ['0'],
        });
      }
    });
    const availabilityObj = { or: availabilityArray };
    filterPayload?.push(availabilityObj);
  }
  if (filterTypes?.model?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.Model',
      operator: 'contains',
      values: filterTypes?.model,
    });
  }
  if (
    filterTypes?.price?.length > 0 &&
    filterTypes?.price[0] >= 0 &&
    filterTypes?.price[1] > 0
  ) {
    filterPayload?.push({
      and: [
        {
          member: 'KioskInventory.shopifyPrice',
          operator: 'gte',
          values: [`${filterTypes?.price[0]}`],
        },
        {
          member: 'KioskInventory.shopifyPrice',
          operator: 'lte',
          values: [`${filterTypes?.price[1]}`],
        },
      ],
    });
  }

  return {
    measures: ['KioskInventory.pcount'],
    filters: filterPayload,
  };
};

export const getProductAndVariantDetailsById = (
  productId: any,
  locationId: any
) => {
  const numericProductId = productId.split('/').pop('');

  return {
    dimensions: [
      'InventoryLineItem.productId',
      'InventoryLineItem.variantId',
      'InventoryLineItem.Title',
      'InventoryLineItem.Price',
      'InventoryLineItem.sku',
      'InventoryLineItem.Option1',
      'InventoryLineItem.Option2',
      'InventoryLineItem.Option3',
      'InventoryLineItem.createdAt',
      'InventoryLineItem.updatedAt',
      'InventoryLineItem.inventoryitemId',
      'InventoryLineItem.inventoryQuantity',
      'InventoryLineItem.imageUrl',
      'ProdutsShopifyOptions.values',
      'ProdutsShopify.title',
      'Catalogue.style',
      'Catalogue.colorway',
      'Catalogue.itemName',
      'Catalogue.shortDescription',
      'InventoryLineItem.locationId',
    ],
    order: {
      'InventoryLineItem.Option1': 'asc',
    },
    filters: [
      {
        member: 'InventoryLineItem.productId',
        operator: 'equals',
        values: [numericProductId],
      },
      // Commented location Id to get sizes of other locations as well
      // {
      //   member: 'InventoryLineItem.locationId',
      //   operator: 'equals',
      //   values: [locationId],
      // },
    ],
  };
};

export const getMinMaxPriceFromInventory = (locationId: any) => {
  let filterPayload = [];

  filterPayload.push(
    {
      member: 'KioskInventory.locationId',
      operator: 'contains',
      values: [locationId],
    },
    {
      member: 'KioskInventory.availableQuantity',
      operator: 'gt',
      values: ['0'],
    }
  );

  return {
    measures: ['KioskInventory.minPrice', 'KioskInventory.maxPrice'],
    filters: filterPayload,
  };
};

export const getSuggestionsFromCube = (userInput: any, locationId: any) => {
  const specialChars = ['@', '$', '&', '_', '(', ')'];
  let modifiedUserInput = userInput;

  specialChars?.map((item: any) => {
    if (modifiedUserInput?.includes(item)) {
      modifiedUserInput = modifiedUserInput?.replaceAll(item, `\\${item}`);
    }
  });

  let userInputArray = modifiedUserInput?.trim();
  userInputArray = userInputArray?.split(' ');
  let wordsArray: any = [];

  userInputArray?.map((word: any) => {
    wordsArray?.push({
      or: [
        {
          member: 'KioskInventory.title',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.sku',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.colorway',
          operator: 'contains',
          values: [word],
        },
      ],
    });
  });

  return {
    dimensions: ['KioskInventory.title'],
    order: { 'KioskInventory.title': 'asc' },
    filters: [
      {
        and: wordsArray,
      },
      {
        member: 'KioskInventory.locationId',
        operator: 'contains',
        values: [locationId],
      },
    ],
    limit: 5,
    offset: 0,
  };
};
