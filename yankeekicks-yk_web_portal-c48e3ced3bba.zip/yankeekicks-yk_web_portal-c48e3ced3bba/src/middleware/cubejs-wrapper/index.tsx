import cubejs from '@cubejs-client/core';
import { CubeProvider } from '@cubejs-client/react';
import { useRouter } from 'next/router';
import React from 'react';
import { Cube_API_URL } from 'services/apiUrl';

const CubeWrapper = (props: any) => {
  const router = useRouter();
  const { pathname } = router;

  const authToken = pathname.includes('/consignment')
    ? localStorage.getItem('token')
    : localStorage.getItem('jwt-token');

  const cubejsAPI = cubejs({
    apiUrl: Cube_API_URL,
    headers: {
      Authorization: authToken || '',
      'Content-Type': 'application/json',
    },
  });
  return <CubeProvider cubejsApi={cubejsAPI}>{props.children}</CubeProvider>;
};

export default CubeWrapper;
