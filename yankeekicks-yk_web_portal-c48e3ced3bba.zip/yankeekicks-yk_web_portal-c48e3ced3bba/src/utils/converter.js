export const kioskObjToShoesizeBrand = (items) => {
  return items.reduce((acc, item) => {
    const itemObj = {
      'Brand.brandName': item?.node?.title,
      'Brand.brandImageUrl': item?.node?.image?.url || '',
    };
    acc = [...acc, itemObj];
    return acc;
  }, []);
};

export const kioskObjToShoesizeProducts = (items) => {
  return items?.reduce((acc, item) => {
    const itemObj = {
      'InventoryLineItem.name': item?.node?.title,
      'CatalogueImages.imageUrl': item?.node?.images?.edges[0]?.node?.url,
      'InventoryLineItem.sku': item?.node?.id,
    };
    acc = [...acc, itemObj];
    return acc;
  }, []);
};
