import axios from 'axios';

export async function doRequest(
  url: any,
  method = 'get',
  dataOrParams = {},
  contentType = '',
  authorizeFrom = false,
  isConsignment = false,
  isResponseTypeNeeded = false
) {
  let token = '';
  /* if (authorizeFrom && isConsignment) {
    token = localStorage?.getItem('token')
      ? `Bearer ${localStorage?.getItem('token')}`
      : '';
  } else if (authorizeFrom && !isConsignment) {
    token = localStorage?.getItem('jwt-token')
      ? `Bearer ${localStorage?.getItem('jwt-token')}`
      : '';
  } else {
    token = localStorage?.getItem('jwt-token')
      ? `Bearer ${localStorage?.getItem('jwt-token')}`
      : '';
  }*/
  if (localStorage?.getItem('jwt-token') || localStorage?.getItem('token')) {
    token = isConsignment
      ? `Bearer ${localStorage?.getItem('token')}`
      : `Bearer ${localStorage?.getItem('jwt-token')}`;
  } else {
    // no authrization required.
  }
  let headers = {
    Accept: 'application/json',
    'Content-type': contentType || 'application/json',
    Authorization: token,
    From: authorizeFrom ? 'Consginee' : '',
    'g-store-location': localStorage?.getItem('graphStoreLocation') || '',
    'r-store-location': localStorage?.getItem('restStoreLocation') || '',
    'x-shopify-access-token': localStorage?.getItem('shopifyAccessToken') || '',
  };
  const params = method === 'get' ? dataOrParams : {};
  const data = method !== 'get' ? dataOrParams : undefined;
  let payloadForAPI: any = isResponseTypeNeeded
    ? {
        url,
        method,
        data,
        params,
        headers,
        responseType: 'arraybuffer',
      }
    : {
        url,
        method,
        data,
        params,
        headers,
      };

  return await axios(payloadForAPI);
}
