export const ValidationRequired = {
  required: 'Please fill this field',
};

export const ValidationMaxLength20 = {
  maxLength: {
    value: 20,
    message: 'This input exceed max length.',
  },
};
export const ValidationMaxLength35 = {
  maxLength: {
    value: 35,
    message: 'This input exceed max length.',
  },
};

export const ValidationMaxLength250 = {
  maxLength: {
    value: 250,
    message: 'This input exceed max length.',
  },
};
export const ValidationMaxLength10 = {
  maxLength: {
    value: 10,
    message: 'This input exceed max length.',
  },
};

export const ValidationMaxLength9 = {
  maxLength: {
    value: 9,
    message: 'This input exceed max length.',
  },
};
export const ValidationMaxLength5 = {
  maxLength: {
    value: 5,
    message: 'This input exceed max length.',
  },
};
export const ValidationMaxLength14 = {
  maxLength: {
    value: 14,
    message: 'This input exceed max length.',
  },
};
export const ValidationMaxLength17 = {
  maxLength: {
    value: 17,
    message: 'This input exceed max length.',
  },
};
export const ValidationMaxLength12 = {
  maxLength: {
    value: 12,
    message: 'This input exceed max length.',
  },
};

export const ValidationMinLength9 = {
  minLength: {
    value: 9,
    message: 'This input required min 9 char.',
  },
};
export const ValidationMinLength8 = {
  minLength: {
    value: 8,
    message: 'This input required min 8 char.',
  },
};
export const ValidationMinLength5 = {
  minLength: {
    value: 5,
    message: 'This input required min 5 char.',
  },
};

export const ValidationMinLength6 = {
  minLength: {
    value: 6,
    message: 'This input required min 6 char.',
  },
};
export const ValidationMinLength20 = {
  minLength: {
    value: 20,
    message: 'This input required min 20 char.',
  },
};
export const ValidationMinLength14 = {
  minLength: {
    value: 14,
    message: 'This input required min 10 char.',
  },
};
export const ValidationMinLength10 = {
  minLength: {
    value: 10,
    message: 'This input required min 10 char.',
  },
};

export const ValidationOnlyNumbers = {
  pattern: {
    value: /^[0-9]*$/,
    message: 'Numbers only allowed',
  },
};

export const ValidationOnlyPhoneNumber = {
  pattern: {
    value: /^[0-9 \)\(-]*$/,
    message: 'Numbers only allowed',
  },
};

export const ValidationOnlyAlpha = {
  pattern: {
    value: /^[a-zA-Z. ]*$/,
    message: 'only characters allowed',
  },
};
export const ValidationPassword = {
  ...ValidationRequired,
  ...ValidationMaxLength12,
  ...ValidationMinLength8,
  pattern: {
    value: /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
    message:
      'Your password must be at least 8 characters, contains at least one number, one special character ,one uppercase and one lower case.',
  },
};

export const ValidationEmail = {
  ...ValidationRequired,
  ...ValidationMaxLength35,
  ...ValidationMinLength6,
  pattern: {
    value: /^[a-z0-9._%+-]+@[a-z0-9-]+\.[a-z]{2,4}$/,
    message: 'Invalid email address',
  },
};

export const ValidationFullName = {
  ...ValidationRequired,
  ...ValidationOnlyAlpha,
  ...ValidationMaxLength35,
  ...ValidationMinLength6,
};
