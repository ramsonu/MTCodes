export const FNS_DATE_FORMAT = 'MMM dd, yyyy';
export const KPI_DATE_FORMAT = 'yyyy-MM-dd';
export const FNS_TIME_FORMAT = 'HH:mm a';
export const FNS_US_DATE_FORMAT = 'MM/dd/yyyy';

export const PERMISSIONS = {
  WAREHOUSE_PORTAL: [
    'Warehouse_Personal',
    'Warehouse_Admin',
    'Super_Admin',
    'YK_Admin',
  ],
  SHOESIZE_PORTAL: [
    'Sales_Associate',
    'Store_Admin',
    'Super_Admin',
    'YK_Admin',
  ],
};

export const USER_ROLES = {
  WAREHOUSE_PERSONAL: 'Warehouse_Personal',
  SALES_ASSOCIATE: 'Sales_Associate',
  CONSIGNEE: 'Consignee',
  WAREHOUSE_ADMIN: 'Warehouse_Admin',
  STORE_ADMIN: 'Store_Admin',
  CONSIGNMENT_ADMIN: 'Consignment_Admin',
  YK_ADMIN: 'YK_Admin',
  SUPER_ADMIN: 'Super_Admin',
};

export const ORDER_DATE_FORMAT = 'MM/dd/yyyy';
export const PAYOUT_DETAILS_FORMAT = 'MMM dd, yyyy HH:mm a';
export const NO_HEADER_ROUTES = [
  'consignment/login',
  'consignment/register',
  'consignment/forget-password',
  'consignment/change-password',
  'consignment/password-reset',
];
export const USER_REGISTRATION_FILE_TYPE_ERROR = 'File Type not accepted!';
export const USER_REGISTRATION_FILE_SIZE_ERROR =
  'Document must be less than 2MB!';
export const NOTIFICATION_REGISTER_UPLOAD_FILE =
  'Please Upload at least one document.';
export const NOTIFICATION_LOGIN_SUCCESS = 'Login successful!';
export const NOTIFICATION_REGISTER_SUCCESS = 'User register successfully!';
export const NOTIFICATION_PASSWORD_RESET_SUCCESS =
  'Password reset link sent successfully!';
export const NOTIFICATION_PASSWORD_RESET_FAIl = "User email doesn't exist!";
export const NOTIFICATION_FORGET_PASSWORD_SUCCESS =
  'Forget password requested!';
export const NOTIFICATION_INVALID_EMAIL_PWD = 'Invalid email or password!';
export const NOTIFICATION_INVALID_OLD_PASSWORD = 'Invalid old password!';
export const NOTIFICATION_INVALID_PASSWORD = 'Invalid password!';
export const NOTIFICATION_PASSWORD_UPDATED_SUCCESS =
  'Password updated successfully!';
export const NOTIFICATION_SOMETHING_WENT_WRONG =
  'Something went wrong, please try later!';
export const NOTIFICATION_CHANGE_PASSWORD_SUCCESS =
  'Password changed, Please login to continue!';
export const NOTIFICATION_OLDPWD_NEWPWD_NOT_MATCHING =
  'New password and confirmation password did not match!';
export const NOTIFICATION_PWD_UPDATED_SUCCESS = 'Password reset successfully!';
export const LINEITEM_ALREDY_EXISTS =
  'This line iteam already exist in the queue';
export const LINEITEM_QUANTITY_UPDATED = 'Item quantity updated.';
export const TRY_OUT_ACCEPTED: any = {
  title: 'Request from Kiosk accepted',
  msg: 'Shoes are added to your request list',
};
export const NO_RESULT_FOUND: any = {
  title: 'No results found',
  msg: "We couldn't find anything for what you are looking.",
};
export const UNAUTHORIZED_USER: any = {
  title: 'You are not authorized to access this page!',
  msg: 'Please contact to Administrator.',
};
export const TIME_INTERVAL_NOTIFICATIONS = 30 * 1000; // 30 SECONDS
export const STORE_ID = 1; // 5 minutes
export const NOTIFICATION_FLAG_SUCCESS = 'Notifications updated successfully';
export const USER_UPDATE_SUCCESS = 'User updated successfully';
export const APP_TITLE = 'Yankeekicks InStore';
export const APP_KEYWORDS =
  'Yankeekicks Store | Footwear | Apparel | Sneaker Care';
