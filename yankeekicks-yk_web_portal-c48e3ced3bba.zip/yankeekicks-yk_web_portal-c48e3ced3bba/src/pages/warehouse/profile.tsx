
import axios from 'axios';
import { NextPage } from 'next';
import ProfilePage from 'components/warehouse/profile/index';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const Profile: NextPage = () => {
  if (!checkPermission('WAREHOUSE_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <ProfilePage />
    </>
  );
};

export default Profile;