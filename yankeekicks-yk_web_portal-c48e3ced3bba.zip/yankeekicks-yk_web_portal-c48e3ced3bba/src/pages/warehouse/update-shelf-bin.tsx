import axios from 'axios';
import { NextPage } from 'next';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

import BulkImport from 'components/warehouse/shelf-bin-bulk-imports';

const Dashboard: NextPage = () => {
  if (!checkPermission('WAREHOUSE_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <BulkImport />
      </CubeWrapper>
    </>
  );
};

export default Dashboard;
