import axios from 'axios';
import { NextPage } from 'next';
import WarehouseDashboard from 'components/warehouse/dashboard';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const Dashboard: NextPage = () => {
  if (!checkPermission('WAREHOUSE_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <WarehouseDashboard />
      </CubeWrapper>
    </>
  );
};

export default Dashboard;
