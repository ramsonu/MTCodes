import React from 'react';
import 'assets/scss/global.scss';
import type { AppProps } from 'next/app';
import { Provider as StoreProvider } from 'react-redux';
import { wrapper } from 'store/createStore';
import ErrorBoundary from 'components/common/error';
import Layout from 'components/laylout';
import { MsalProvider } from '@azure/msal-react';
import { PublicClientApplication } from '@azure/msal-browser';
import { msalConfig } from '../authConfig';
import YkAuth from '../components/common/login/YkAuth';
import router from 'next/router';

function MyApp({ Component, ...rest }: AppProps) {
  const { store, props } = wrapper.useWrappedStore(rest);

  const msalInstance = new PublicClientApplication(msalConfig);

  return (
    <MsalProvider instance={msalInstance}>
      <StoreProvider store={store}>
        <ErrorBoundary>
          <YkAuth>
            <Component {...props.pageProps} />
          </YkAuth>
        </ErrorBoundary>
      </StoreProvider>
    </MsalProvider>
  );
}

export default MyApp;
