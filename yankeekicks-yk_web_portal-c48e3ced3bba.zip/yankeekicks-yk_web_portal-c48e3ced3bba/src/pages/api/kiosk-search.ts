// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';

type Data = {
  name: string;
};
export const PRODUCT_TYPES = [
  { value: 'sneakers' },
  { value: 'Shoes' },
  { value: 'Snowboard' },
  { value: 'streetwear' },
  { value: 'Accesory' },
  { value: 'Backpack' },
  { value: 'Default' },
  { value: 'accesories' },
  { value: 'clothing' },
  { value: 'collectibles' },
  { value: 'handbag' },
  { value: 'ntwrk' },
];
const productTypesList = () => {
  let productTypes: any = [];
  PRODUCT_TYPES?.map((obj: any) => {
    const { value } = obj;
    productTypes.push(`product_type:${value}`);
  });
  return productTypes.join(' OR ');
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  const { title } = req.body;
  let query = productTypesList();
  if (title !== '') {
    query = query.concat(` AND title:*${title}*`);
  }
  const data = `{
    products(first: 10, query: "${query}") {
      edges {
        node {
          id
          title
        }
      }
    }
    
}`;
  const response = await axios({
    method: 'post',
    url: `${req?.headers['g-store-location']}`,
    data: data,
    headers: {
      'X-Shopify-Access-Token': `${req?.headers['x-shopify-access-token']}`,
      'Content-Type': 'application/graphql',
    },
  });

  res.status(200).json({ ...response.data });
}
