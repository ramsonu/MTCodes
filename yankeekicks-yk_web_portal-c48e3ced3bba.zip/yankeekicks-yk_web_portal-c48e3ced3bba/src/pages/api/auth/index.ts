// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';
import https from 'https';
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const data = req.body;
  try {
    const response = await axios({
      method: 'post',
      url: `${process.env.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/authenticate`,
      data: data,
      headers: {
        accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });
    res.status(200).json({ ...response.data });
  } catch (e: unknown) {
    res.status(200).json({ error: 'Not able to login' });
  }
}
