// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';

type Data = {
  name: string;
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  const data = req.body;
  const response = await axios({
    method: 'GET',
    url: `${process.env.NEXT_PUBLIC_APP_INVENTORY_REST_API_DOMAIN}/inventory/export/excel`,
    data: data,
    headers: {
      Authorization: <string>req.headers.authorization,
      Content_Disposition: 'attachment; filename=BinShelfInventory.xlsx',
      CONTENT_TYPE: 'application/vnd.ms-excel',
    },
    responseType: 'arraybuffer',
  });
  res.send(response.data);
}
