// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  try {
    const response = await axios({
      method: 'get',
      url: `${process.env.NEXT_PUBLIC_APP_CATALOGE_S3_API_DOMAIN}/getCatalogueBySKU?id=${req.query.sku}`,
      headers: {
        accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });
    if (response.data.length)
      res.status(200).json({ data: response.data[0], status: true });
    else res.status(200).json({ status: false });
  } catch (e: any) {
    switch (e.response.data.status) {
      default:
        console.log(e);
        res.status(200).json({
          error: 'Somethig went wrong, please try later',
          status: false,
          errorInfo: e.response.data,
        });
    }
  }
}
