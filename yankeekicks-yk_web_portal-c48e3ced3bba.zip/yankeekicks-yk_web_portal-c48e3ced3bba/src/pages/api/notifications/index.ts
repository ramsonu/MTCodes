// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  try {
    const mockData = [
      {
        subject: 'Shoes checked out',
        body: 'Nike Air Presto Mid High OG',
        image:
          'http://localhost:3000/_next/image?url=%2F_next%2Fstatic%2Fmedia%2Fproduct-1.ea2e7100.png&w=256&q=75',
        link: '/',
        read: true,
      },
      {
        subject: 'Shoes checked out',
        body: 'Adida Yeezy Boost 350',
        image:
          'http://localhost:3000/_next/image?url=%2F_next%2Fstatic%2Fmedia%2Fproduct-1.ea2e7100.png&w=256&q=75',
        link: '/',
        read: true,
      },
    ];
    res.status(200).json({ data: mockData, status: true });
  } catch (e: any) {
    switch (e.response.data.status) {
      default:
        res.status(200).json({
          error: 'Somethig went wrong, please try later',
          status: false,
          errorInfo: e.response.data,
        });
    }
  }
}
