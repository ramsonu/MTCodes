import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';

type Data = {
  name: string;
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  const { email } = req.query;
  const response = await axios({
    method: 'get',
    url: `${process.env.NEXT_PUBLIC_APP_API_PORT_NOTIFICATION}/notificationupdate/notificationupdate{userEmail}?userEmail=${email}`,
    headers: {
      Authorization: <string>req.headers.authorization,
      accept: 'application/json',
      'Content-Type': 'application/json',
    },
  });
  res.status(200).json({ ...response.data });
}
