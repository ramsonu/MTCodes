// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  try {
    const data = req.body;
    data['requestStatusFlag'] = true;
    delete data['imgData'];
    const response = await axios({
      method: 'put',
      url: `${process.env.NEXT_PUBLIC_APP_STOREFRONT_REST_API_DOMAIN}/tryoutItem-master/accept`,
      data: data,
      headers: {
        accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    res.status(200).json({ data: response.data, status: true });
  } catch (e: any) {
    switch (e.response.data.status) {
      default:
        res.status(200).json({
          error: 'Somethig went wrong, please try later',
          status: false,
          errorInfo: e.response.data,
        });
    }
  }
}
