import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';

type Data = {
  data: any;
  status: boolean;
  name?: string;
  error?: any;
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  try {
    const { id } = req.query;
    const response = await axios({
      method: 'get',
      url: `${process.env.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/user/${id}`,
      headers: {
        Authorization: <string>req.headers.authorization,
        accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });
    res.status(200).json({ ...response.data, status: true });
  } catch (e: any) {
    console.log('e', e);
    res.status(200).json({
      error: 'Something went wrong, Please try later',
      data: JSON.stringify(e.response),
      status: false,
    });
  }
}
