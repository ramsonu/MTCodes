// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';

type Data = {
  name?: string;
  data: any;
  status: boolean;
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  const { storeId, variantId } = req.query;
  try {
    const response = await axios({
      method: 'get',
      url: `${process.env.NEXT_PUBLIC_APP_INVENTORY_REST_API_DOMAIN}/store/${storeId}/product/variant/${variantId}`,
      headers: {
        Authorization: <string>req.headers.authorization,
        'Content-Type': 'application/json',
      },
    });
    res.status(200).json({ ...response.data, status: true });
  } catch (e: any) {
    if (res.status(500)) {
      res.status(500).json({ data: e?.response?.data, status: false });
    }
    if (res.status(401)) {
      res.status(401).json({ data: e?.response?.data, status: false });
    }
    if (res.status(403)) {
      res.status(403).json({ data: e?.response?.data, status: false });
    }
  }
}
