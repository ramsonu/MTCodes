// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';

type Data = {
  name: string;
};

export const PRODUCT_TYPES = [
  { value: 'sneakers' },
  { value: 'Shoes' },
  // { value: 'Snowboard' },
  // { value: 'streetwear' },
  // { value: 'Accesory' },
  // { value: 'Backpack' },
  // { value: 'Default' },
  // { value: 'accesories' },
  // { value: 'clothing' },
  // { value: 'collectibles' },
  // { value: 'handbag' },
  // { value: 'ntwrk' },
  // { value: 'puma' },
];
const productTypesList = () => {
  let productTypes: any = [];
  PRODUCT_TYPES?.map((obj: any) => {
    const { value } = obj;
    productTypes.push(`product_type:${value}`);
  });
  return productTypes.join(' OR ');
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  const { brandName, limitForQuery, cursorValue, sortValue } = req.body;

  let query = productTypesList();
  if (brandName !== '') {
    query = query.concat(` AND title:*${brandName}*`);
  }
  query = query.concat(` AND (status:ACTIVE)`);
  const limit = limitForQuery || 50;

  const endCursor = cursorValue?.endCursor
    ? `"${cursorValue?.endCursor}"`
    : null;

  const sortDirection = sortValue || false;

  const data = `{
    products(query: "${query}", first: ${limit}, after: ${endCursor}, reverse: ${sortDirection}) {
      edges {
        node {
          id
          productType
          tags
          title
          totalVariants
          vendor
          createdAt
          description
          images(first: 1) {
            edges {
              node {
                src
                url
              }
            }
          }
          variants(first: 20) {
            edges {
              node {
                id
                title
                sku
                price
                selectedOptions{
                  name
                  value
                }
              }
            }
          }
        }
      }
      pageInfo {
        hasPreviousPage
        hasNextPage
        endCursor
        startCursor
      }
    }
  }`;

  const response = await axios({
    method: 'POST',
    url: `${req?.headers['g-store-location']}`,
    data: data,
    headers: {
      'X-Shopify-Access-Token': `${req?.headers['x-shopify-access-token']}`,
      'Content-Type': 'application/graphql',
      'x-shopify-shop-api-call-limit': '10/10',
      'retry-after': 1.0,
    },
  });

  res.status(200).json({ ...response.data });
}
