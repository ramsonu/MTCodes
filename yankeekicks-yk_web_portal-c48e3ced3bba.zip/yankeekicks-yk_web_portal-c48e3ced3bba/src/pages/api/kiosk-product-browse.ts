// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';

type Data = {
  name: string;
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  const data = `{
    collections(query: "product_type:sneakers",first: 50) {
      edges {
        node {
          id
          image {
            src
            id
            url
          }
          productsCount
          title
  
        }
      }
    }
}`;

  try {
    const response = await axios({
      method: 'GET',
      url: `${process.env.NEXT_PUBLIC_APP_INVENTORY_REST_API_DOMAIN}/inventory-Brand`, //${req?.headers['g-store-location']}
      // data: data,
      headers: {
        Authorization: <string>req.headers.authorization,
        'X-Shopify-Access-Token': `${req?.headers['x-shopify-access-token']}`,
        'Content-Type': 'application/graphql',
        'x-shopify-shop-api-call-limit': '10/10',
        'retry-after': 1.0,
      },
    });
    res.status(200).json(response.data);
  } catch (e: any) {
    if (res.status(401)) {
      res.status(401).json(e?.response?.data);
    } else if (res.status(403)) {
      res.status(403).json(e?.response?.data);
    } else {
      res.status(500).json(e?.response?.data);
    }
  }
}
