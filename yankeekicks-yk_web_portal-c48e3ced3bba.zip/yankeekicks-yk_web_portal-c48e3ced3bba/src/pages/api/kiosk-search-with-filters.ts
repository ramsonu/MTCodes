// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';

type Data = {
  name: string;
};

export const SEARCH_BY_TYPES: any = {
  him: '',
  her: 'W,GS',
  toddler: 'TD',
  unisex: '',
  preschool: 'PS',
  infant: 'I,Infants,Infant',
};

export const PRODUCT_TYPES = [
  { value: 'sneakers' },
  { value: 'Shoes' },
  // { value: 'Snowboard' },
  // { value: 'streetwear' },
  // { value: 'Accesory' },
  // { value: 'Backpack' },
  // { value: 'Default' },
  // { value: 'accesories' },
  // { value: 'clothing' },
  // { value: 'collectibles' },
  // { value: 'handbag' },
  // { value: 'ntwrk' },
  // { value: 'puma' },
];

const splitTypes = (type: any) => {
  const types = type.split(',');
  let queryItem: any = [];
  types.map((item: any) => {
    const flt = SEARCH_BY_TYPES[item?.toLowerCase()];
    if (flt !== '') {
      if (flt?.includes(',')) {
        flt?.split(',')?.map((item: any) => {
          return queryItem.push(`title:\\\\(${item}\\\\)$`);
        });
      } else {
        queryItem.push(`title:\\\\(${flt}\\\\)$`);
      }
    }
  });
  return queryItem.join(' OR ');
};

const createTitleBySplit = (type: any) => {
  const types = type.split(',');
  let queryItem: any = [];
  types.map((item: any) => {
    const flt = SEARCH_BY_TYPES[item?.toLowerCase()];
    if (flt !== '') {
      if (flt?.includes(',')) {
        flt?.split(',')?.map((item: any) => {
          return queryItem.push(`title:*\\\\(${item}\\\\)*`);
        });
      } else {
        queryItem.push(`title:*\\\\(${flt}\\\\)*`);
      }
      queryItem.push(`title: `);
    }
  });
  return queryItem.join(' OR ');
};

const multipleSelect = (data: any, dataType: any) => {
  let array = data.split(',');
  let filter;
  if (dataType === 'size') {
    filter = array.map((item: any) => {
      return `(size:${item}) OR `;
    });
  } else {
    filter = array.map((item: any) => {
      return `${
        dataType === 'brand' ? `(title:*${item}*)` : `(tag:${item})`
      } OR `;
    });
  }
  let lastIndex = filter[filter.length - 1].replace(' OR ', '');
  filter.pop();
  filter.push(lastIndex);
  let queryItem = ` AND ${filter.join('')}`;
  return queryItem;
};

const productTypesList = () => {
  let productTypes: any = [];
  PRODUCT_TYPES?.map((obj: any) => {
    const { value } = obj;
    productTypes.push(`product_type:${value}`);
  });
  return productTypes.join(' OR ');
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  const {
    title,
    color,
    size,
    brand,
    type,
    availability,
    limitForQuery,
    cursorValue,
    sortValue,
  } = req.body;
  let query = productTypesList();

  if (title !== '') {
    let withStringTitle = title.includes('"')
      ? title.replace(/"/g, '\\$&')
      : title;
    const titleForQuery = title.includes('"')
      ? withStringTitle
      : `*${withStringTitle}*`;
    query = query.concat(
      ` AND (title:${titleForQuery} OR sku:${titleForQuery})`
    );
  }
  if (type !== '') {
    const isEmptyPresent =
      type?.split(',')?.includes('him') || type?.split(',')?.includes('unisex');
    const isTitleOrBrandEmpty = title === '' && brand === '';
    const queryStr: string = splitTypes(type);
    const queryTitle: string = createTitleBySplit(type);
    // if query str empty (which means him or infant or unisex has been selected)
    if (!queryStr || queryStr?.trim() === '') {
      // if type contains him || unisex || infant -> if do modify query with NOT condition
      if (isEmptyPresent) {
        if (isTitleOrBrandEmpty) {
          if (type?.split(',')?.includes('unisex')) {
            // for unisex with title
            query = query.concat(
              ` AND (title:${title} AND (title:\\\\(W\\\\)$) OR (title:\\\\(GS\\\\)$) OR ((NOT title:\\\\(PS\\\\)$) AND (NOT title:\\\\(TD\\\\)$) AND (NOT title:\\\\(I\\\\)$) AND (NOT title:\\\\(Infants\\\\)$) AND (NOT title:\\\\(Infant\\\\)$))))`
            );
          } else {
            // for him with title
            query = query.concat(
              ` AND (title:${title} AND (NOT title:\\\\(W\\\\)$) AND (NOT title:\\\\(PS\\\\)$) AND (NOT title:\\\\(TD\\\\)$) AND (NOT title:\\\\(GS\\\\)$)))`
            );
          }
        } else {
          if (type?.split(',')?.includes('unisex')) {
            // for unisex without title
            query = query.concat(
              ` AND (title:\\\\(W\\\\)$) OR (title:\\\\(GS\\\\)$) OR ((NOT title:\\\\(PS\\\\)$) AND (NOT title:\\\\(TD\\\\)$) AND (NOT title:\\\\(I\\\\)$) AND (NOT title:\\\\(Infants\\\\)$) AND (NOT title:\\\\(Infant\\\\)$)))`
            );
          } else {
            // for him without title
            query = query.concat(
              ` AND (NOT title:\\\\(W\\\\)$) AND (NOT title:\\\\(PS\\\\)$) AND (NOT title:\\\\(TD\\\\)$) AND (NOT title:\\\\(GS\\\\)$))`
            );
          }
        }
      }
    } else {
      // check if it is a combination of '' and types for ex. (him + her)
      if (isEmptyPresent) {
        const firstCondition = queryStr;
        const leftSideValues = queryStr?.split(' OR ');
        const allConditions = [
          'title:\\\\(W\\\\)$',
          'title:\\\\(PS\\\\)$',
          'title:\\\\(TD\\\\)$',
          'title:\\\\(GS\\\\)$',
          'title:\\\\(I\\\\)$',
          'title:\\\\(Infant\\\\)$',
          'title:\\\\(Infants\\\\)$',
        ];
        const rightSideValues = allConditions.filter(function (obj) {
          return leftSideValues.indexOf(obj) == -1;
        });
        let modifiedConditions = rightSideValues?.map((item: any) => {
          return `(NOT ${item})`;
        });
        const secondCondition = modifiedConditions?.join(' AND ');
        const condition = `(${firstCondition} OR (${secondCondition}))`;
        if (isTitleOrBrandEmpty) {
          const titleToUse = `(${queryTitle})`;
          query = query.concat(` AND (${titleToUse} AND ${condition})`);
        } else {
          query = query.concat(` AND ${condition}`);
        }
      } else {
        if (isTitleOrBrandEmpty) {
          const titleToUse = `(${queryTitle})`;
          query = query.concat(` AND (${titleToUse} AND (${queryStr}))`);
        } else {
          query = query.concat(` AND (${queryStr})`);
        }
      }
    }
  }
  if (color !== '') {
    if (color?.length > 0) {
      let data = multipleSelect(color, 'color');
      query = query.concat(data);
    } else {
      query = query.concat(` AND (tag:${color})`);
    }
  }
  if (size !== '') {
    if (size?.length > 0) {
      let data = multipleSelect(size, 'size');
      query = query.concat(data);
    } else {
      query = query.concat(` AND (size:${size})`);
    }
  }
  if (brand !== '') {
    if (brand?.length > 0) {
      let data = multipleSelect(brand, 'brand');
      query = query.concat(data);
    } else {
      query = query.concat(` AND (title:*${brand}*)`);
    }
  }
  if (availability) {
    if (
      availability?.split(',')?.includes('in stock') &&
      availability?.split(',')?.includes('out of stock')
    ) {
      query = query.concat(` AND (inventory_total:<=0 OR inventory_total:>0)`);
    } else {
      if (availability?.split(',')?.includes('in stock')) {
        query = query.concat(` AND (inventory_total:>0)`);
      } else if (availability?.split(',')?.includes('out of stock')) {
        query = query.concat(` AND (inventory_total:<=0)`);
      }
    }
  }
  query = query.concat(` AND (status:ACTIVE)`);

  const limit = limitForQuery || 50;
  const endCursor = cursorValue?.endCursor
    ? `"${cursorValue?.endCursor}"`
    : null;
  const sortDirection = sortValue || false;

  //**query : //title:*jor* AND ( title:\\(TD\\)$ OR title:\\(W\\)$ ) */
  const data = `{
    products(query: "${query}", first: ${limit}, after: ${endCursor}, reverse: ${sortDirection}) {
      edges {
        node {
          id
          title
          createdAt
          description
          images(first: 1) {
            edges {
              node {
                src
                url
              }
            }
          }
          variants(first: 45) {
            edges {
              node {
                id
                title
                sku
                price
              }
            }
          } 
        }
      }
      pageInfo {
        hasPreviousPage
        hasNextPage
        endCursor
        startCursor
      }
    }
}`;

  const response = await axios({
    method: 'post',
    url: `${req?.headers['g-store-location']}`, //${req?.headers['g-store-location']}
    data: data,
    headers: {
      'X-Shopify-Access-Token': `${req?.headers['x-shopify-access-token']}`,
      'Content-Type': 'application/graphql',
      'x-shopify-shop-api-call-limit': '10/10',
      'retry-after': 1.0,
    },
  });

  res.status(200).json({ ...response.data });
}
