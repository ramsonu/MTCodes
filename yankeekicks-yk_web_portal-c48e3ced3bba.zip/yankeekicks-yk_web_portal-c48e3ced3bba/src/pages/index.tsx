import type { NextPage } from 'next';

const Home: NextPage = () => {
  return <></>;
};

export default Home;
