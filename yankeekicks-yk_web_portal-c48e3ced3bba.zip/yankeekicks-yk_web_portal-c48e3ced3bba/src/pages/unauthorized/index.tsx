import { NextPage } from 'next';
import { displayUnauthorized } from 'utils/util';

const Unauthorized: NextPage = () => {
  return displayUnauthorized();
};

export default Unauthorized;
