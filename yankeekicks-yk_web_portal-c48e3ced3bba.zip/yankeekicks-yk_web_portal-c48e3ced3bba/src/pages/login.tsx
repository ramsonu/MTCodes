import YkLogin from 'components/common/login/YkLogin';
import type { NextPage } from 'next';

const Login: NextPage = () => {
  return <><YkLogin /></>;
};

export default Login;
