import axios from 'axios';
import { NextPage } from 'next';
import ShoesizeDashboard from 'components/shoesize/dashboard';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const LandingPage: NextPage = () => {
  if (!checkPermission('SHOESIZE_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <ShoesizeDashboard />
      </CubeWrapper>
    </>
  );
};

export default LandingPage;
