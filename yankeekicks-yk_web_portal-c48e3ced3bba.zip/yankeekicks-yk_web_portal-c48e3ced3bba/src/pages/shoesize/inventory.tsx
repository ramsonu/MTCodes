import { NextPage } from 'next';
import InventoryPage from 'components/shoesize/inventory';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const Inventory: NextPage = () => {
  if (!checkPermission('SHOESIZE_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <InventoryPage />
      </CubeWrapper>
    </>
  );
};

export default Inventory;
