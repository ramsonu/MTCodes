import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import { getRequestInfo } from 'middleware/cubejs-wrapper/cubejs-query';
import { useCubeQuery } from '@cubejs-client/react';
import CircleLoader from '../loader/circular-loader';
import ImageLoader from '../image-loader';
import { checkInCheckOutRequest } from 'services/shoesize';
import {
  SUCCESS_MESSAGE,
  WARE_HOUSE_TABLE_TAB_QUERY_STATUS,
} from 'components/warehouse/constants';
import { LogoutUser } from 'components/common/logout';
import productImg from 'assets/images/big-product-img.svg';

const style = {
  position: 'absolute' as 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 380,
  bgcolor: 'background.paper',
  boxShadow: 24,
  p: 3,
  borderRadius: 5,
};

const MobileModalPopUp = (props: any) => {
  const {
    requestId,
    open,
    handleClose,
    setIsVisibleMessage,
    setMessage,
    setSeverityType,
  } = props;
  const storeId = localStorage.getItem('storeId');
  const locationId = localStorage.getItem('storeLocationId');
  const bulkRequest: any = getRequestInfo(requestId, storeId, locationId);
  const [data, setData] = useState<any>([]);

  const router = useRouter();
  const {
    resultSet,
    isLoading,
    error: bulkRequestError,
    progress,
  }: any = useCubeQuery(bulkRequest);

  const getStatus = (status: string) => {
    if (status === 'Pending') {
      return 'Pending';
    }
    if (status === 'CheckOut') {
      return 'Checked Out';
    }
    if (status === 'CheckIn') {
      return 'Checked In';
    }
    if (status === 'Sold') {
      return 'Sold';
    }
  };
  const onActionHandler = async () => {
    let eventStatus: any = '';
    if (
      data[0]?.['WarehouseTab.status'] ===
      WARE_HOUSE_TABLE_TAB_QUERY_STATUS.PENDING
    ) {
      eventStatus = 'CheckOut';
    }
    if (
      data[0]?.['WarehouseTab.status'] ===
        WARE_HOUSE_TABLE_TAB_QUERY_STATUS.CHECK_OUT ||
      data[0]?.['WarehouseTab.status'] ===
        WARE_HOUSE_TABLE_TAB_QUERY_STATUS.SOLD
    ) {
      eventStatus = 'CheckIn';
    }
    const payload = data
      ?.filter((item: any) => item['WarehouseTab.status'] !== 'Sold')
      ?.map((item: any) => {
        return {
          barcode: item['WarehouseTab.barcode'],
          locationId: Number(localStorage?.getItem('storeLocationId')),
          orderNumber: '',
          requestNumber: Number(item['WarehouseTab.requestNumber']),
          status: eventStatus,
          storeId: Number(localStorage.getItem('storeId')),
          userId: Number(localStorage.getItem('user-Id')),
          userName: item['WarehouseTab.userName'],
          variantId: Number(item['WarehouseTab.variantId']),
        };
      });
    try {
      await checkInCheckOutRequest(payload);
      setIsVisibleMessage(true);
      setSeverityType('success');
      const notifyMsg = `${data?.length} ${
        data[0]?.['WarehouseTab.status'] === 'Pending'
          ? SUCCESS_MESSAGE.CHECK_OUT_SUCCESS_MSG
          : SUCCESS_MESSAGE.CHECK_IN_SUCCESS_MSG
      }`;
      setMessage(getToastMsg(notifyMsg));
      handleClose();
    } catch (e: any) {
      if (e?.response?.status === 401 || e?.response?.status === 403) {
        LogoutUser();
        router.push('/', undefined, { shallow: true });
      }
      handleClose();
      setIsVisibleMessage(true);
      setSeverityType('error');
      setMessage(getToastMsg(SUCCESS_MESSAGE.ERROR_MSG));
    }
  };
  const getActionStatus = (status: string) => {
    if (status === WARE_HOUSE_TABLE_TAB_QUERY_STATUS.PENDING) {
      return 'Check Out';
    }
    if (
      status === WARE_HOUSE_TABLE_TAB_QUERY_STATUS.CHECK_OUT ||
      WARE_HOUSE_TABLE_TAB_QUERY_STATUS.SOLD
    ) {
      return 'Check In';
    }
  };
  const getToastMsg = (msg: string) => {
    return <h3 className='toast-msg'>{msg}</h3>;
  };
  useEffect(() => {
    if (resultSet) {
      setData(resultSet?.loadResponses[0]?.data);
    } else {
      setData([]);
    }
  }, [resultSet, bulkRequestError]);

  return (
    <>
      <div>
        <Modal
          open={open}
          onClose={handleClose}
          aria-labelledby='modal-modal-title'
          aria-describedby='modal-modal-description'>
          <Box sx={style}>
            <div className='parent-table-wrapper warehouse-table-wrapper YKCH-buldMobilePopup'>
              <div className='mobile-table-wrapper'>
                <div className='products-cards-wrapper'>
                  {isLoading ? (
                    <div className='circular-loader-wrapper yk-mobile-modal-loader'>
                      <CircleLoader />
                    </div>
                  ) : (
                    <ul className='cards-list'>
                      {data?.map((item: any, index: any) => {
                        return (
                          <li className='mb-4' key={index}>
                            <div className='products-data-wrapper'>
                              <div className='product-img-name'>
                                <ImageLoader
                                  src={item['WarehouseTab.imageUrl']}
                                  fallbackImg={productImg}
                                  alt='cart-img'
                                  className='img-fluid'
                                />
                                <p className='name'>
                                  {item['WarehouseTab.itemName']
                                    ? item['WarehouseTab.itemName']
                                    : '-'}
                                  <div className='d-flex mt-1'>
                                    <div className='size'>
                                      {item['WarehouseTab.Option1']
                                        ? item['WarehouseTab.Option1']
                                        : '-'}
                                    </div>
                                    <div className='ms-auto'>
                                      <span
                                        className={`yk-color-badge red ${
                                          item['WarehouseTab.status'] ===
                                            'Pending' ||
                                          item['WarehouseTab.status'] === 'Sold'
                                            ? 'red'
                                            : 'green'
                                        } `}>
                                        {getStatus(item['WarehouseTab.status'])}
                                      </span>
                                    </div>
                                  </div>
                                </p>
                              </div>
                              <div className='descriptions-wrapper'>
                                <p className='description-title'>request</p>
                                <p className='description'>
                                  {item['WarehouseTab.requestNumber']
                                    ? item['WarehouseTab.requestNumber']
                                    : '-'}
                                </p>
                              </div>
                              <div className='descriptions-wrapper'>
                                <p className='description-title'>SKU</p>
                                <p className='description'>
                                  {item['WarehouseTab.sku']
                                    ? item['WarehouseTab.sku']
                                    : '-'}
                                </p>
                              </div>
                              <div className='descriptions-wrapper'>
                                <p className='description-title'>Barcode</p>
                                <p className='description'>
                                  {item['WarehouseTab.barcode']
                                    ? item['WarehouseTab.barcode']
                                    : '-'}
                                </p>
                              </div>
                              <div className='descriptions-wrapper'>
                                <p className='description-title'>Bin-shelf</p>
                                <p className='description'>
                                  <p className='description'>{`${
                                    item['WarehouseTab.bin']
                                      ? item['WarehouseTab.bin']
                                      : '-'
                                  }-${
                                    item['WarehouseTab.rack']
                                      ? item['WarehouseTab.rack']
                                      : '-'
                                  }`}</p>
                                </p>
                              </div>
                              <div className='descriptions-wrapper'>
                                <p className='description-title'>
                                  Requested By
                                </p>
                                <p className='description'>
                                  {item['WarehouseTab.userName']
                                    ? item['WarehouseTab.userName']
                                    : '-'}
                                </p>
                              </div>
                              {/* time is same for so it might get repeated so commented */}
                              {/* <div className='descriptions-wrapper'>
                            <p className='description-title'>Time</p>
                            <p className='description'>
                              {getTime(item['WarehouseTab.eventTime'])}
                            </p>
                          </div> */}
                            </div>
                          </li>
                        );
                      })}
                      {(data[0]?.['WarehouseTab.status'] ===
                        WARE_HOUSE_TABLE_TAB_QUERY_STATUS.PENDING ||
                        data[0]?.['WarehouseTab.status'] ===
                          WARE_HOUSE_TABLE_TAB_QUERY_STATUS.CHECK_OUT ||
                        data[0]?.['WarehouseTab.status'] ===
                          WARE_HOUSE_TABLE_TAB_QUERY_STATUS.SOLD) && (
                        <div className='text-center'>
                          <button
                            className='btn primary-mobile-btn'
                            onClick={onActionHandler}>
                            {getActionStatus(data[0]?.['WarehouseTab.status'])}
                          </button>
                        </div>
                      )}
                    </ul>
                  )}
                </div>
              </div>
            </div>
          </Box>
        </Modal>
      </div>
    </>
  );
};

export default MobileModalPopUp;
