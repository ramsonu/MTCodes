export const sortsBy = [
  {
    key: 'amountLow',
    value: 'Amount: Lowest',
    img: 'down',
  },
  {
    key: 'amountHigh',
    value: 'Amount: Highest',
    img: 'up',
  },
  {
    key: 'dateNew',
    value: 'Date: Newest',
    img: 'down',
  },
  {
    key: 'dateOld',
    value: 'Date: Oldest',
    img: 'up',
  },
  {
    key: 'orderAsc',
    value: 'Order ID: Asc',
    img: 'down',
  },
  {
    key: 'orderDesc',
    value: 'Order ID: Desc',
    img: 'up',
  },
];

export const sortsByPayout = [
  {
    key: 'amountLow',
    value: 'Amount: Lowest',
    img: 'down',
  },
  {
    key: 'amountHigh',
    value: 'Amount: Highest',
    img: 'up',
  },
  {
    key: 'dateNew',
    value: 'Date: Newest',
    img: 'down',
  },
  {
    key: 'dateOld',
    value: 'Date: Oldest',
    img: 'up',
  },
  {
    key: 'payoutAsc',
    value: 'Payout ID: Asc',
    img: 'down',
  },
  {
    key: 'payoutDesc',
    value: 'Payout ID: Desc',
    img: 'up',
  },
];
export const sortsByMyInventory = [
  {
    key: 'skuAsc',
    value: 'SKU: Asc',
    img: 'down',
  },
  {
    key: 'skuDesc',
    value: 'SKU: Desc',
    img: 'up',
  },
  {
    key: 'brandAsc',
    value: 'Brand:Asc',
    img: 'down',
  },
  {
    key: 'brandDesc',
    value: 'Brand: Desc',
    img: 'up',
  },
  {
    key: 'qtyLow',
    value: 'Qty: Lowest',
    img: 'down',
  },
  {
    key: 'qtyHigh',
    value: 'Qty: Highest',
    img: 'up',
  },
];

export const sortsByCatalog = [
  {
    key: 'skuAsc',
    value: 'Date: Oldest',
    img: 'down',
  },
  {
    key: 'skuDesc',
    value: 'Date: Newest',
    img: 'up',
  },
  {
    key: 'brandAsc',
    value: 'Brand:Asc',
    img: 'down',
  },
  {
    key: 'brandDesc',
    value: 'Brand: Desc',
    img: 'up',
  },
];

export const sortsByConsignmentDetails = [
  {
    key: 'skuAsc',
    value: 'SKU: Asc',
    img: 'down',
  },
  {
    key: 'skuDesc',
    value: 'SKU: Desc',
    img: 'up',
  },
  {
    key: 'qtyLow',
    value: 'Qty: Lowest',
    img: 'down',
  },
  {
    key: 'qtyHigh',
    value: 'Qty: Highest',
    img: 'up',
  },
];

export const sortsByConsignmentSkuDetails = [
  {
    key: 'sizeAsc',
    value: 'Size: Asc',
    img: 'down',
  },
  {
    key: 'sizeDesc',
    value: 'Size: Desc',
    img: 'up',
  },
  {
    key: 'sellingPriceLow',
    value: 'Price: Lowest',
    img: 'down',
  },
  {
    key: 'sellingPriceHigh',
    value: 'Price: Highest',
    img: 'up',
  },
  {
    key: 'statusAsc',
    value: 'Status: Asc',
    img: 'down',
  },
  {
    key: 'statusDesc',
    value: 'Status: Desc',
    img: 'up',
  },
];

export const sortsByConsignments = [
  {
    key: 'qtyLow',
    value: 'Qty: Lowest',
    img: 'down',
  },
  {
    key: 'qtyHigh',
    value: 'Qty: Highest',
    img: 'up',
  },
  {
    key: 'dateNew',
    value: 'Date: Newest',
    img: 'down',
  },
  {
    key: 'dateOld',
    value: 'Date: Oldest',
    img: 'up',
  },
  {
    key: 'consignmentIdAsc',
    value: 'Consignment ID: Asc',
    img: 'down',
  },
  {
    key: 'consignmentIdDesc',
    value: 'Consignment ID: Desc',
    img: 'up',
  },
];

export const sortByPreviewBulk = [
  {
    key: 'storeNameAsc',
    value: 'StoreName: Asc',
    img: 'down',
  },
  {
    key: 'storeNameDesc',
    value: 'StoreName: Desc',
    img: 'up',
  },
  {
    key: 'sizeAsc',
    value: 'Size: Asc',
    img: 'down',
  },
  {
    key: 'sizeDesc',
    value: 'Size: Desc',
    img: 'up',
  },
];

export const sortByBinShelfPreview = [
  {
    key: 'NameAsc',
    value: 'Name: Asc',
    img: 'down',
  },
  {
    key: 'NameDesc',
    value: 'Name: Desc',
    img: 'up',
  },
  {
    key: 'skuAsc',
    value: 'SKU: Asc',
    img: 'down',
  },
  {
    key: 'skuDesc',
    value: 'SKU: Desc',
    img: 'up',
  },
];

export const sortBySalesAssoSearch = [
  {
    key: 'newest',
    value: 'Newest',
    img: 'down',
  },
  {
    key: 'oldest',
    value: 'Oldest',
    img: 'up',
  },
];