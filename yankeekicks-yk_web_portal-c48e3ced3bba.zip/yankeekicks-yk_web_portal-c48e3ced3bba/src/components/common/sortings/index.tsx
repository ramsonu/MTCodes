import React, { useEffect, useState } from 'react';
import { MenuItem, Select } from '@mui/material';
import { FormControl } from '@mui/material';
import {
  sortsBy,
  sortsByPayout,
  sortsByMyInventory,
  sortsByCatalog,
  sortsByConsignmentDetails,
  sortsByConsignmentSkuDetails,
  sortsByConsignments,
  sortByPreviewBulk,
  sortBySalesAssoSearch,
  sortByBinShelfPreview,
} from './constants';
import upIcon from 'assets/images/up-arrow-icon.svg';
import downIcon from 'assets/images/down-arrow-icon.svg';
import Image from 'next/image';

const Sortings = (props: any) => {
  const { handleChange = {}, itemKey = '', defaultSelectedValue = '' } = props;
  const [sortsValue, setSortsValue] = useState<any>([]);
  useEffect(() => {
    switch (itemKey) {
      case 'payout':
        setSortsValue(sortsByPayout);
        break;
      case 'inventory':
        setSortsValue(sortsByMyInventory);
        break;
      case 'catalog':
        setSortsValue(sortsByCatalog);
        break;
      case 'consignmentDetails':
        setSortsValue(sortsByConsignmentDetails);
        break;
      case 'skuDetails':
        setSortsValue(sortsByConsignmentSkuDetails);
        break;
      case 'consignments':
        setSortsValue(sortsByConsignments);
        break;
      case 'previewBulk':
        setSortsValue(sortByPreviewBulk);
        break;
      case 'salesAssoSearch':
        setSortsValue(sortBySalesAssoSearch);
        break;
      case 'binShelfPreview':
        setSortsValue(sortByBinShelfPreview);
        break;
      default:
        setSortsValue(sortsBy);
    }
  });
  return (
    <>
      <div className='sort-product-wrapper order-sort-btn YKCH-binSelfProduct'>
        <FormControl sx={{ m: 1, minWidth: 80 }}>
          <p className='sort-text'>sort by:</p>
          <Select
            labelId='demo-simple-select-autowidth-label'
            id='demo-simple-select'
            onChange={(e: any) => handleChange(e)}
            defaultValue={defaultSelectedValue}
          >
            <MenuItem value={'asc'} disabled>
              Select
            </MenuItem>
            {sortsValue?.map((data: any, index: any) => {
              return (
                <MenuItem
                  className='sort-menu-item'
                  key={index}
                  value={data.key}
                >
                  {data.value}
                  <Image
                    src={data?.img === 'up' ? upIcon : downIcon}
                    alt='table-img'
                    className='img-fluid'
                  />
                </MenuItem>
              );
            })}
          </Select>
        </FormControl>
      </div>
    </>
  );
};

export default Sortings;
