import React from 'react';
import Image from 'next/image';
import Modal from '@mui/material/Modal';
import CopyToClipboardComponent from '../copyToClipboard';
import warningIcon from 'assets/images/menu-icons/warning-icon.svg';
import modalCloseIcon from 'assets/images/menu-icons/modal-close-img.svg';
import scanIcon from 'assets/images/menu-icons/scan-icon.svg';
import closeIcon from 'assets/images/close-btn-icon.svg';

const GlobalModal = (props: any) => {
  const {
    toggleModal = false,
    title = '',
    message = '',
    requestIdText = '',
    scanButtonText = '',
    requestId = false,
    closeBtn = false,
    scanSubTitle = false,
    scanCount = '',
    closeButton = false, //to add "x" button
    cancelButton = false, // to show cancel button
    cancelButtonText = '', // cancel button text
    className = '', // classnames
    submitButton = false, // to show submit button
    submitButtonText = '', // submit button text
    onCancelClicked = () => {}, // cancel click
    onSubmitClicked = () => {}, // submit click
    onCloseBtnClicked = () => {}, // clos icon of error modal click
    onCloseClicked = () => {}, // cross icon click
    onScanButtonClicked = () => {}, // scan button click
    children, // extra content
    isIcon = false,
    scanButton = false, //to show scan button
    submitDisabled = false, //to disable submit button
  } = props;
  return (
    <div className={className}>
      <Modal
        open={toggleModal}
        className={className}
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'>
        <div className='app-wrapper yk-modalWrapper'>
          <div className='yk-modal-body'>
            <div className='modal-heading-wrapper '>
              {closeBtn && (
                <div className='dFlexEnd'>
                  <Image
                    className=''
                    src={closeIcon}
                    alt=''
                    onClick={onCloseBtnClicked}
                  />
                </div>
              )}
              {isIcon && (
                <div className='modalImgWrapper'>
                  <Image className='' src={warningIcon} alt='' />
                </div>
              )}
              <div className='dFlexSpaceBetween yk-modalTitleWrapper'>
                <div className='modal-title-wrapper dFlexSpaceBetween'>
                  <h3 className='modal-title yk-badge-h11'>
                    {title}
                    {scanSubTitle && (
                      <span>
                        <p className='modal-sub-title yk-badge mb-0'>
                          {`Scan complete ${scanCount}`}
                        </p>
                      </span>
                    )}
                  </h3>

                  {requestId && (
                    <div className='yk-subTitle yk-badge-h16'>
                      Request ID:&nbsp;
                      <span className='greyText'>{requestIdText}</span>
                      <span className='YKCH-copyClip'>
                        <CopyToClipboardComponent copyText={requestIdText} />
                      </span>
                    </div>
                  )}
                </div>
                {closeButton && (
                  <div>
                    <Image
                      className='modal-close-btn'
                      src={modalCloseIcon}
                      alt=''
                      onClick={onCloseClicked}
                    />
                  </div>
                )}
              </div>
              <p className='modal-sub-title'>{message}</p>
            </div>
            {children}
            <div className='yk-modalBtnWrapper dFlexBaseline'>
              {cancelButton && (
                <button
                  type='button'
                  className='btn btn-transparent cancelBtn p-0'>
                  <h6
                    className='btn-text yk-badge-h7 mb-0'
                    onClick={onCancelClicked}>
                    {cancelButtonText}
                  </h6>
                </button>
              )}
              {submitButton && (
                <button
                  type='button'
                  className='btn submitBtn'
                  disabled={submitDisabled}>
                  <h6
                    className='btn-text yk-badge-h7 mb-0'
                    onClick={onSubmitClicked}>
                    {submitButtonText}
                  </h6>
                </button>
              )}
              {scanButton && (
                <button
                  type='button'
                  className='btn submitBtn yk-scanBtn'
                  onClick={onScanButtonClicked}
                  disabled={submitDisabled}>
                  <h6 className='btn-text yk-badge-h7 mb-0'>
                    <span>
                      <Image className='scanIcon' src={scanIcon} alt='' />
                    </span>
                    {scanButtonText}
                  </h6>
                </button>
              )}
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default GlobalModal;
