/* eslint-disable @next/next/no-img-element */
import React, { useState, useEffect } from 'react';
import { getImage } from 'services/shoesize';
import cachingImage from './caching-image';
import Dummy from 'assets/images/products/dummy.svg';

const ImageLoader = ({
  src,
  alt = '',
  fallbackImg = '',
  isCaching = true,
  className = '',
  imgWidth = 500,
  imgHeight = 100,
}: any) => {
  const [imageData, setImageData] = useState<any>(src);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (isStockxUrl()) {
      const newSrc = `${src.split('?')[0]}?auto=compress&w=200&q=90&dpr=2`;
      setImageData(newSrc);
    } else if (isHttps()) setImageData(src);
    else if (!!src) loadImage();
  }, [src]); //eslint-disable-line

  const isStockxUrl = () => /^(http|https):\/\/images.stockx.com/i.test(src);
  const isHttps = () => /^(http|https):\/\//i.test(src);

  const loadImage = async () => {
    //caching Image to reduce endpoints calls
    if (isCaching) {
      let img: any = await cachingImage(src);
      if (img?.data) {
        setImageData(img?.data);
      } else {
        setImageData(fallbackImg?.src);
      }
    } else {
      try {
        const result: any = await getImage(src);
        if (result?.data?.data) {
          setImageData(result?.data?.data);
        }
      } catch (e) {
        setImageData(fallbackImg?.src);
      }
    }
  };

  const handleImageLoad = () => {
    setIsLoading(false);
  };

  let imageToRender = imageData;

  if (!imageData) {
    imageToRender = fallbackImg?.src;
  }

  return (
    <>
      {isLoading && <img src={Dummy?.src} alt='fallback image' className={className} />}
      <img
        src={imageToRender}
        alt={alt}
        onLoad={handleImageLoad}
        width={imgWidth}
        height={imgHeight}
        className={className}
        style={{ display: isLoading ? 'none' : 'block' }}
      />
    </>
  );
};
export default ImageLoader;
