import memoize from 'lodash.memoize';
import { getImage } from 'services/shoesize';
const cacheImage = async (imageUrl: any) => {
  try {
    const result: any = await getImage(imageUrl);
    if (result?.data) return result.data;
  } catch (e) {
    return imageUrl;
  }
};

export default memoize(cacheImage);
