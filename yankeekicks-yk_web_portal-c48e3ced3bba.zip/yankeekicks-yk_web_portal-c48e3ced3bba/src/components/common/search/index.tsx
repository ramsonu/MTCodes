import React from 'react';
import Image from 'next/image';
import debounce from 'lodash.debounce';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import Autocomplete from '@mui/material/Autocomplete';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import { Paper } from '@mui/material';
import InputAdornment from '@mui/material/InputAdornment';
import CircleLoader from '../loader/circular-loader';
import searchIcon from 'assets/images/search-icon.png';

/**
 * This component is using for search the real time api
 * @returns product with title
 */
const Search = (props: any) => {
  const {
    userInput = '',
    placeholder = '',
    options = [],
    isApiCall = false,
    optionType = 'default',
    showAutoComplete,
    suggestionsHasError = false,
    suggestionsLoading = false,
    onChangeHandler = () => {},
    onSelectHandler = () => {},
    setShowAutoComplete = () => {},
    isWarehouse = false,
  } = props;

  const renderOptions = () => {
    let optionsToShow: any = [];
    switch (optionType) {
      case 'default':
        optionsToShow = options?.map((option: any) => {
          return option?.['KioskInventory.title'];
        });
        break;
      case 'change':
        optionsToShow = options?.map((option: any) => {
          return option['InventoryLineItem.name'];
        });
        break;
      case 'no suggestions':
        optionsToShow = [];
        break;
    }
    return optionsToShow;
  };

  const showAllHandler = () => {
    onSelectHandler('', true);
  };

  const enterKeyHandler = () => {
    onSelectHandler('', true);
  };

  const itemSelectHandler = (event: any) => {
    onSelectHandler(event?.target?.innerText);
  };

  const showMore = ({ children, ...other }: any) => {
    return (
      <>
        {!isWarehouse && (
          <Paper {...other} className='search-box-wrapper'>
            {suggestionsHasError ? (
              <p className='no-result-text'>Something went wrong!</p>
            ) : suggestionsLoading ? (
              <div className='circular-loader-wrapper'>
                <CircleLoader />
              </div>
            ) : (
              <>
                <div className='search-options-wrapper'>
                  {renderOptions()?.length === 0 ? (
                    <p className='no-result-text'>No results found!</p>
                  ) : (
                    renderOptions()?.map((item: any, index: any) => {
                      return (
                        <p
                          // className='search-options yk-textTransformCapitalize'
                          className={`search-options yk-textTransformCapitalize ${
                            renderOptions()?.length === index + 1 ? 'mb-0' : ''
                          }`}
                          key={index}
                          onClick={itemSelectHandler}>
                          {item}
                        </p>
                      );
                    })
                  )}
                </div>
              </>
            )}
            {options?.length > 0 &&
              options?.length >= 5 &&
              !suggestionsLoading && (
                <button
                  type='button'
                  className='btn-transparent show-all-btn yk-badge-20'
                  onClick={showAllHandler}>
                  Show All
                </button>
              )}
          </Paper>
        )}
      </>
    );
  };

  const debounceResult = React.useRef(
    debounce((event: any) => {
      onChangeHandler(event);
    }, 700)
  ).current;

  return (
    <Stack spacing={2} sx={{ width: '100%' }}>
      <ClickAwayListener
        onClickAway={() => {
          setShowAutoComplete(false);
        }}>
        <div>
          <Autocomplete
            freeSolo
            open={showAutoComplete}
            id='searcth-autocomplete'
            disableClearable
            value={userInput}
            options={renderOptions()}
            // onSelect={onSelectHandler}
            renderInput={(params) => (
              <TextField
                className='custom-search-field'
                {...params}
                onChange={(event) => debounceResult(event?.target?.value)}
                placeholder={placeholder}
                onKeyDown={(e: any) => {
                  if (e.keyCode === 13 && e.target.value && isApiCall) {
                    enterKeyHandler();
                  }
                }}
                InputProps={{
                  ...params.InputProps,
                  type: 'search',
                  startAdornment: (
                    <InputAdornment position='start'>
                      <Image src={searchIcon} alt='search-icon' />
                    </InputAdornment>
                  ),
                  inputProps: { ...params.inputProps, maxLength: 50 },
                }}
              />
            )}
            PaperComponent={showMore}
          />
        </div>
      </ClickAwayListener>
    </Stack>
  );
};

export default Search;
