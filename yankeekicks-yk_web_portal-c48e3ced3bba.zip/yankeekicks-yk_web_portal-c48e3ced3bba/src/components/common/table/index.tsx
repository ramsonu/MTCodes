import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
} from '@mui/material';
import { format } from 'date-fns';
import ImageLoader from '../image-loader';
import productImg from 'assets/images/big-product-img.svg';

import Image from 'next/image';
import CopyToClipboardComponent from '../copyToClipboard';

const VirtualTable = React.forwardRef(
  (props: any, ref: React.Ref<HTMLDivElement>) => {
    const { headers = [], rowData = [], offSet = 0 } = props;

    const renderValue = (data: any, row: any) => {
      let value = data[row?.value];
      if (value) {
        if (row?.methodToApply === 'toFix') {
          value = data[row?.value]?.toFixed(2);
        }
        if (row?.prefix && row?.suffix) {
          value = `${row?.prefix}${value}${row?.suffix}`;
        } else {
          if (row?.prefix) {
            value = `${row?.prefix}${value}`;
          }
          if (row?.suffix) {
            value = `${data[row?.value]}${row?.suffix}`;
          }
        }
        return value;
      } else {
        return '--';
      }
    };

    const getAge = (releaseDate: any) => {
      const currentDate = new Date();
      const releaseDates = new Date(releaseDate);
      var diff = Math.floor(currentDate.getTime() - releaseDates?.getTime());
      var day = 1000 * 60 * 60 * 24;
      var days = Math.floor(diff / day);
      var months = Math.floor(days / 31);
      var years = Math.floor(months / 12);

      if (days < 31) {
        return days + 'days';
      }
      if (months < 12) {
        return months + 'months';
      }
      if (months > 12) {
        return years + 'years';
      }
      // return days;
    };
    const calCulateTotalPrice = (data: any) => {
      const calculatedTotal =
        parseInt(data['price']) * parseInt(data['quantity']);
      return calculatedTotal?.toFixed(2);
    };
    const calCulatePayOut = (data: any) => {
      const calculatedPay = (23 / 100) * parseInt(data['price']);
      const pay = parseInt(data['price']) - calculatedPay;
      return pay?.toFixed(2);
    };
    const showShelfBin = (data: any) => {
      return `${data['rack']}-${data['bin']}`;
    };
    return (
      <div className='table-parent-wrapper'>
        <div className='table-wrapper  YKCH-overloadDataTable' ref={ref}>
          <TableContainer component={Paper}>
            <Table
              aria-label='collapsible table'
              className='yk-inventory-table YKCH-FixedTableData'>
              <TableHead>
                <TableRow className='yk-parent-table-row YKCH-FixedRow'>
                  {headers.map((row: any, index: any) => (
                    <TableCell
                      className={`yk-parent-table-th YKCH-FixedCel ${
                        row?.type === 'button' ? 'hide-on-print' : ''
                      }`}
                      key={index}>
                      {row?.title}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {rowData.map((data: any, i: any) => (
                  <TableRow
                    key={data.id}
                    className='yk-body-table-row YKCH-FixedRow'>
                    {headers.map((row: any, index: any) => (
                      <>
                        {row?.type === 'sno' && (
                          <TableCell
                            className='yk-table-body-td cursor-data YKCH-FixedCel'
                            key={index}>
                            {offSet + i + 1}
                          </TableCell>
                        )}
                        {row?.type === 'image' && (
                          <TableCell
                            className='yk-table-body-td cursor-data YKCH-FixedCel'
                            key={index}>
                            {row?.mode === 'static' ? (
                              <Image
                                src={row?.value}
                                alt='cart-img'
                                className='img-fluid'
                                onClick={() => row?.onClick(data)}
                              />
                            ) : (
                              <ImageLoader
                                src={data[row?.value]}
                                fallbackImg={productImg}
                                alt='cart-img'
                                className='img-fluid'
                                onClick={() => row?.onClick(data.size)}
                              />
                            )}
                          </TableCell>
                        )}
                        {row?.type === 'button' && (
                          <TableCell className='yk-table-body-td cursor-data YKCH-FixedCel'>
                            <a
                              role='button'
                              className='yk-table-link-btn clear-filter-btn hide-on-print'
                              onClick={() => row?.onClick(data)}>
                              {row?.value}
                            </a>{' '}
                          </TableCell>
                        )}
                        {row?.type === 'textbox' && (
                          <TableCell
                            className='yk-table-body-td cursor-data YKCH-FixedCel'
                            key={index}>
                            <div
                              className={
                                row?.title === 'Selling Price' ||
                                row?.title === 'Payout/Item'
                                  ? `input-group input-prepend ${
                                      row.disabled ? 'disabled' : ''
                                    }`
                                  : 'input-outer-wrapper'
                              }>
                              <span
                                className={
                                  row?.title === 'Selling Price' ||
                                  row?.title === 'Payout/Item'
                                    ? 'input-prepend'
                                    : ''
                                }>
                                {row?.title === 'Selling Price' ||
                                row?.title === 'Payout/Item' ? (
                                  <span
                                    className={
                                      row?.title === 'Selling Price' ||
                                      row?.title === 'Payout/Item'
                                        ? 'input-group-text'
                                        : ''
                                    }>
                                    $
                                  </span>
                                ) : (
                                  <></>
                                )}
                                <input
                                  type='text'
                                  // className='form-control modal-input'
                                  value={row?.value}
                                  disabled={row?.disabled}
                                  maxLength={10}
                                  onChange={(e) => row?.onChange(e, i)}
                                />
                              </span>
                            </div>
                          </TableCell>
                        )}

                        {row?.type === 'date' && (
                          <TableCell className='yk-table-body-td cursor-data YKCH-FixedCel'>
                            {data[row?.value] !== null
                              ? format(new Date(data[row?.value]), row?.format)
                              : '--'}
                          </TableCell>
                        )}
                        {row?.type === 'status' && (
                          <TableCell className='yk-table-body-td cursor-data YKCH-FixedCel'>
                            <button
                              className={`btn btn-status payment-pending yk-color-badge ${
                                data[row?.value] === row?.success
                                  ? 'green'
                                  : data[row?.value] === row?.warning
                                  ? 'yellow'
                                  : data[row?.value] === row?.danger &&
                                    !row?.consignment
                                  ? 'red'
                                  : data[row?.value] === row?.danger &&
                                    row?.consignment &&
                                    'orange'
                              }`}>
                              {data[row?.value]}
                            </button>
                          </TableCell>
                        )}
                        {row?.type === 'external' && (
                          <TableCell
                            className='yk-table-body-td cursor-data YKCH-FixedCel'
                            key={index}>
                            {row?.prefix ? row?.prefix : ''}
                            {row?.value?.toFixed(2)}
                          </TableCell>
                        )}
                        {row?.type === 'age' && (
                          <TableCell
                            className='yk-table-body-td cursor-data YKCH-FixedCel'
                            key={index}>
                            {getAge(data[row?.value])}
                          </TableCell>
                        )}
                        {row?.type === 'copyToClipboard' && (
                          <TableCell
                            className='yk-table-body-td cursor-data YKCH-FixedCel'
                            key={index}
                            id='sku'>
                            {data[row?.value]}
                            <CopyToClipboardComponent
                              copyText={data[row?.value]}
                            />
                          </TableCell>
                        )}
                        {row?.type === 'product-sell' && (
                          <>
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel d-flex align-items-center'
                              key={index}>
                              <ImageLoader
                                src={data[row?.assignedImage]}
                                fallbackImg={productImg}
                                alt='cart-img'
                                className='img-fluid'
                                imgWidth={80}
                                imgHeight={80}
                              />
                              <span className='ms-2'>
                                {renderValue(data, row)}
                              </span>
                            </TableCell>
                          </>
                        )}
                        {!row?.type && (
                          <TableCell
                            className='yk-table-body-td cursor-data YKCH-FixedCel'
                            key={index}>
                            {renderValue(data, row)}
                          </TableCell>
                        )}
                        {row?.type === 'previewTotalPrice' && (
                          <TableCell className='yk-table-body-td cursor-data YKCH-FixedCel'>
                            {calCulateTotalPrice(data)}
                          </TableCell>
                        )}
                        {row?.type === 'previewPayout' && (
                          <TableCell className='yk-table-body-td cursor-data YKCH-FixedCel'>
                            {calCulatePayOut(data)}
                          </TableCell>
                        )}
                        {row?.type === 'shelf-bin' && (
                          <TableCell className='yk-table-body-td cursor-data YKCH-FixedCel'>
                            {showShelfBin(data)}
                          </TableCell>
                        )}
                      </>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </div>
      </div>
    );
  }
);
VirtualTable.displayName = 'Print Summary';
export default VirtualTable;
