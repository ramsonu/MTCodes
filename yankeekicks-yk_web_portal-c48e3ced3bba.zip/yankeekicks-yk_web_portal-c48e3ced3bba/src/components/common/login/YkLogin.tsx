import React, { useEffect } from 'react';
import Image from 'next/image';
import { useMsal, useIsAuthenticated } from '@azure/msal-react';
import { InteractionRequiredAuthError } from '@azure/msal-browser';
import { msalConfig, loginRequest } from '../../../authConfig';
import YKStdLogo from 'assets/images/yk-std-logo-lg.svg';

const YkLogin = (props: any) => {
  const { instance } = useMsal();
  const isAuthenticated = useIsAuthenticated();

  useEffect(() => {
    if (isAuthenticated) {
      getTokenRedirect();
    }
  });

  const getCachedUser = () => {
    if (instance) {
      const allAccounts = instance.getAllAccounts();

      if (allAccounts.length > 0) {
        return allAccounts[0];
      }
      return null;
    }

    return null;
  };

  const getTokenRedirect = async () => {
    if (!localStorage.getItem('access-token')) {
      const accessTokenRequest: any = {
        scopes: ['User.Read'],
        account: getCachedUser(),
      };

      // setAuthenticated(isAuthenticated);
      return instance
        .acquireTokenSilent(accessTokenRequest)
        .then((response) => {
          const { accessToken } = response;
          const userDetails = getCachedUser();
          if (accessToken) {
            localStorage.setItem('access-token', accessToken);
            localStorage.setItem('UserDetails', JSON.stringify(userDetails));
            return accessToken;
          }

          // return null;
        })
        .catch(async (error) => {
          if (error instanceof InteractionRequiredAuthError) {
            const response: any = await instance.acquireTokenRedirect(
              accessTokenRequest
            );
            const { accessToken } = response;
            // const reducedExpiry = new Date(expiresOn - 1000 * (60 * 5));
            if (accessToken) {
              localStorage.setItem('access-token', accessToken);
              // getUser(response, getCachedUser(), authenticated);
              return accessToken;
            }
            // return null;
          } else {
            console.error(error);
          }
        });
    } else {
      return localStorage.getItem('access-token');
    }
  };

  const triggerLogin = () => {
    const redirect: any = process.env.NEXT_PUBLIC_APP_REDIRECT_URI;
    localStorage.setItem('msalConfig', msalConfig);
    localStorage.setItem('redirect', redirect);
    if (instance) {
      if (redirect) {
        instance.loginRedirect(loginRequest).catch((e) => {
          console.error(e);
        });
      } else {
        instance.loginPopup(loginRequest).catch((e) => {
          console.error(e);
        });
      }
    }
  };

  return (
    <div className='login-wrapper login-page-wrapper auth-login-page-wrapper'>
      <div className='login-bg'>
        <div className='container-lg h-100'>
          <div className='row h-100 align-items-center'>
            <div className='col-sm-12 col-md-7 col-lg-7 col-xl-7'>
              <div className='welcome-wrapper'>
                <Image src={YKStdLogo} alt='' className='img-fluid'></Image>
                <h1 className='login-title'>Welcome to YankeeKicks!</h1>
                <p className='description yk-badge-h14'>
                  Sign In to your account
                </p>
              </div>
            </div>
            <div className='col-sm-12 col-md-5 col-lg-5 col-xl-5'>
              <div className='card login-card'>
                <div className='card-body'>
                  <div className='form-wrapper'>
                    <h2 className='form-title'>Sign In</h2>
                    <p className='description'>
                      Please proceed to authenticate with Office365 credentials
                    </p>
                    <div className='login-btn-office-wrapper'>
                      <button
                        className='btn yk-btn-primary-sm btn-login-with-office'
                        onClick={triggerLogin}
                      >
                        Login with Office 365
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default YkLogin;
