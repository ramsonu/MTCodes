import React, { useEffect, useState } from 'react';
import { useIsAuthenticated, useMsal } from '@azure/msal-react';
import YkLogin from './YkLogin';
import { useRouter } from 'next/router';
import Layout from 'components/laylout';
import CircleLoader from '../loader/circular-loader';
import { APP_KEYWORDS, APP_TITLE } from 'utils/constants';
import Head from 'next/head';

const YkAuth = (props: any) => {
  const [showLogin, setShowLogin] = useState(false);
  const isAuthenticated = useIsAuthenticated();
  const router = useRouter();
  const { inProgress }: any = useMsal();

  useEffect(() => {
    if (isAuthenticated || localStorage.getItem('access-token')) {
      setShowLogin(false);
    } else {
      setShowLogin(true);
    }
  }, [isAuthenticated]);

  return (
    <>
      <Head>
        <title>{APP_TITLE}</title>
        <meta charSet='UTF-8' />
        <meta name='keywords' content={APP_KEYWORDS} />
        <meta name='author' content='MOURI Tech' />
        <meta name='viewport' content='width=device-width, initial-scale=1.0' />
      </Head>
      {showLogin ? (
        inProgress !== 'none' ? (
          <div className='login-loader-wrapper circular-loader-wrapper'>
            <CircleLoader />
          </div>
        ) : (
          <YkLogin />
        )
      ) : (
        <Layout>{props.children}</Layout>
      )}
    </>
  );
};

export default YkAuth;
