import React, { useState, useEffect } from 'react';
import { Checkbox, InputAdornment } from '@mui/material';
import { actions } from 'store/reducers/kiosk';
import { actions as warehouseActions } from 'store/reducers/warehouse';
import { useDispatch } from 'react-redux';
import {
  SEARCH_COLOURS,
  SEARCH_BRAND,
  SEARCH_BY_TYPES,
  SEARCH_RELEASE_NO_OF_YEARS,
  SEARCH_BIN,
  SEARCH_BY_AVAILABILITY,
  SIZE_MATRIX_GRADESCHOOL,
  SIZE_MATRIX_MENWOMEN,
  SIZE_MATRIX_PRESCHOOL,
  SIZE_MATRIX_TODDLER,
  SEARCH_BY_MODEL_NIKE,
  SEARCH_BY_MODEL_AIR_JORDAN,
  SEARCH_BY_MODEL_NEW_BALANCE,
  SEARCH_BY_MODEL_ADIDAS,
  SEARCH_BY_MODEL_YEEZY,
} from './constants';
import searchIcon from 'assets/images/search-icon.png';
import { useSelector } from 'react-redux';
import { getPreviousFullYear } from 'utils/util';
import { TextField } from '@mui/material';
import Image from 'next/image';
import { useRouter } from 'next/router';
import sizeMatrix from 'utils/sizeMatrix.json';

const DynamicFilter = ({ itemKey, toShowModelFilter = false }: any) => {
  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const { wareHouseFilters } = useSelector((state: any) => state.warehouse);
  const [items, setItems] = useState([]);
  const dispatch = useDispatch();
  const filterlabel = { inputProps: { 'aria-label': itemKey } };
  let searchSizes: any = [];
  const router = useRouter();
  let tempArray: any = [];

  useEffect(() => {
    renderFilters();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const applyFilters = (objectItems: any, val: any) =>
    objectItems.filter((obj: any) =>
      obj.value.toLowerCase().includes(val.toLowerCase())
    );
  const applySizes = () => {
    if (filterTypes.type == '') {
      sizeMatrix.forEach((type: any, index: number) => {
        searchSizes = searchSizes.concat(type.sizeList);
      });
    } else {
      filterTypes.type?.forEach((type: any, index: number) => {
        if (type == 'men / women') {
          searchSizes = searchSizes.concat(
            sizeMatrix[SIZE_MATRIX_MENWOMEN].sizeList
          );
        } else if (type == 'grade school') {
          searchSizes = searchSizes.concat(
            sizeMatrix[SIZE_MATRIX_GRADESCHOOL].sizeList
          );
        } else if (type == 'pre school') {
          searchSizes = searchSizes.concat(
            sizeMatrix[SIZE_MATRIX_PRESCHOOL].sizeList
          );
        } else if (type == 'toddler') {
          searchSizes = searchSizes.concat(
            sizeMatrix[SIZE_MATRIX_TODDLER].sizeList
          );
        }
      });
    }
  };
  applySizes();
  filterTypes?.brand?.map((obj: any, index: any) => {
    if (obj === 'nike') {
      tempArray.push(SEARCH_BY_MODEL_NIKE);
    } else if (obj === 'jordan') {
      tempArray.push(SEARCH_BY_MODEL_AIR_JORDAN);
    } else if (obj === 'adidas') {
      tempArray.push(SEARCH_BY_MODEL_ADIDAS);
    } else if (obj === 'new balance') {
      tempArray.push(SEARCH_BY_MODEL_NEW_BALANCE);
    } else if (obj === 'yeezy') {
      tempArray.push(SEARCH_BY_MODEL_YEEZY);
    } else {
      tempArray.push([]);
    }
  });
  const flatDepth = filterTypes?.brand?.length;
  const latestArray = tempArray.flat(flatDepth);
  const renderFilters = (value: any = '') => {
    let items: any = [];
    switch (itemKey) {
      case 'brand':
        items = value !== '' ? applyFilters(SEARCH_BRAND, value) : SEARCH_BRAND;
        break;
      case 'size':
        items = value !== '' ? applyFilters(searchSizes, value) : searchSizes;
        break;
      case 'color':
        items =
          value !== '' ? applyFilters(SEARCH_COLOURS, value) : SEARCH_COLOURS;
        break;
      case 'date':
        const year = getPreviousFullYear(SEARCH_RELEASE_NO_OF_YEARS);
        items = value !== '' ? applyFilters(year, value) : year;
        break;
      case 'type':
        items =
          value !== '' ? applyFilters(SEARCH_BY_TYPES, value) : SEARCH_BY_TYPES;
        break;
      case 'availability':
        items =
          value !== ''
            ? applyFilters(SEARCH_BY_AVAILABILITY, value)
            : SEARCH_BY_AVAILABILITY;
        break;
      case 'bin':
        items = value !== '' ? applyFilters(SEARCH_BIN, value) : SEARCH_BIN;
        break;
      case 'model':
        items = value !== '' ? applyFilters(latestArray, value) : latestArray;
        break;
      default:
        break;
    }
    setItems(items);
  };

  const setDynamicFilters = (filterItem: string, filterType: string) => {
    if (router?.pathname?.includes('/warehouse')) {
      dispatch(
        warehouseActions.setWareHouseFilters({
          filterItem: filterItem,
          filterType: filterType,
        })
      );
    } else {
      dispatch(
        actions.setFilters({ filterItem: filterItem, filterType: filterType })
      );
    }
  };

  const onChange = (e: any) => {
    renderFilters(e.target.value);
  };

  return (
    <div>
      <TextField
        id='outlined-search'
        label=''
        type='search'
        onChange={onChange}
        InputProps={{
          type: 'search',
          placeholder: 'Search',
          startAdornment: (
            <InputAdornment position='start'>
              <Image src={searchIcon} alt='search-icon' />
            </InputAdornment>
          ),
        }}
      />
      <ul className='sub-filter-list mt-3'>
        {items?.map((obj: any, index: any) => {
          const { key, value } = obj;
          const valueToPass =
            itemKey?.toLowerCase() === 'model'
              ? key?.toString()?.toLowerCase()
              : itemKey?.toLowerCase() === 'size'
              ? value?.toString()
              : value?.toString()?.toLowerCase();
          const valueToPassWithoutLowerCase =
            itemKey?.toLowerCase() === 'model'
              ? key?.toString()
              : value?.toString();
          const isChecked = router?.pathname?.includes('/warehouse')
            ? wareHouseFilters[itemKey]?.includes(value) ||
              wareHouseFilters[itemKey]?.includes(value?.toLowerCase())
            : filterTypes[itemKey]?.includes(valueToPass) ||
              filterTypes[itemKey]?.includes(valueToPassWithoutLowerCase);
          return (
            <div className='list-wrapper' key={`${itemKey}-${index}`}>
              <li className='d-block clearfix'>
                <div className='YKCH-colorBadge float-start'>
                  {itemKey === 'color' && (
                    <span className='yk-color-badge-wrapper'>
                      <span
                        className='yk-color-badge yk-shoesize-color-badge'
                        style={{
                          background: `var(--bs-${value})`,
                        }}></span>
                    </span>
                  )}
                  <span className='yk-textColor'>{value}</span>
                </div>
                <Checkbox
                  sx={{
                    color: '#b1afb6',
                    '&.Mui-checked': {
                      color: '#2d2c30',
                    },
                  }}
                  {...filterlabel}
                  checked={isChecked}
                  className='filter-sidebar-checkbox float-end'
                  onClick={() => setDynamicFilters(valueToPass, itemKey)}
                />
              </li>
            </div>
          );
        })}
      </ul>
    </div>
  );
};

export default DynamicFilter;
