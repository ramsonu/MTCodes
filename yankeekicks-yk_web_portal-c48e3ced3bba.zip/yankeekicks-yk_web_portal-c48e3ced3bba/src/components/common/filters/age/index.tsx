import React from 'react';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import { SEARCH_AGE } from '../constants';
import Radio from '@mui/material/Radio';

const AgeFilters = (props: any) => {
  const { onChange = () => {} } = props;
  return (
    <>
      <ul className='sub-filter-list'>
        <RadioGroup
          aria-labelledby='demo-radio-buttons-group-label'
          name='radio-buttons-group'
          className='filter-sidebar-checkbox'
          onChange={onChange}
        >
          {SEARCH_AGE?.map((obj: any, index: any) => {
            const { key, value } = obj;
            return (
              <div className='list-wrapper' key={index}>
                <li>
                  <span>{value}</span>

                  <FormControlLabel value={key} control={<Radio />} label='' />
                </li>
              </div>
            );
          })}
        </RadioGroup>
      </ul>
    </>
  );
};

export default AgeFilters;
