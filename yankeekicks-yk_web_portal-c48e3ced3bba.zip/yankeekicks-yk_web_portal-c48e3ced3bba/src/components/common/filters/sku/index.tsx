import React from 'react';
import { Checkbox } from '@mui/material';

const SKUFilters = (props: any) => {
  const { onChange = () => {}, data = [], checkedValue = {} } = props;
  return (
    <>
      <ul className='sub-filter-list'>
        {data?.map((sku: any, index: any) => {
          return (
            <div className='list-wrapper' key={index}>
              <span>{sku?.['ConsignmentviewDetails.sku']}</span>
              <Checkbox
                className='filter-sidebar-checkbox'
                checked={checkedValue.includes(
                  sku?.['ConsignmentviewDetails.sku']
                )}
                name={sku?.['ConsignmentviewDetails.sku']}
                onChange={(event: any) => onChange(event)}
              />
            </div>
          );
        })}
      </ul>
    </>
  );
};

export default SKUFilters;
