import React, { useState } from 'react';
import { Checkbox } from '@mui/material';

const PayoutStatusFilters = (props: any) => {
  const { onChange = () => {}, checkedValue = {}, itemKey = '' } = props;

  const pendingColor =
    itemKey === 'consignment' ||
    itemKey === 'consignmentDetails' ||
    itemKey === 'skuDetails'
      ? 'orange'
      : 'red';

  return (
    <div>
      <div className='list-wrapper'>
        <button className={`btn yk-color-badge ${pendingColor}`}>
          Pending
        </button>
        <Checkbox
          className='filter-sidebar-checkbox'
          checked={checkedValue?.Pending}
          name='Pending'
          onChange={(event: any) => onChange(event)}
        />
      </div>
      {itemKey === 'order' && (
        <div className='list-wrapper'>
          <button className='btn yk-color-badge green'>Paid</button>
          <Checkbox
            className='filter-sidebar-checkbox'
            checked={checkedValue?.Paid}
            name='Paid'
            onChange={(event: any) => onChange(event)}
          />
        </div>
      )}
      {(itemKey === 'consignment' || itemKey === 'consignmentDetails') && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge green'>Completed</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Completed}
              name='Completed'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}
      {itemKey === 'consignment' && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge yellow'>Yet To Start</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.['Yet To Start']}
              name='Yet To Start'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}
      {itemKey === 'skuDetails' && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge green'>Approved</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Approved}
              name='Approved'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}
    </div>
  );
};

export default PayoutStatusFilters;
