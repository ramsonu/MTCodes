import React, { useState } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const DateFilters = (props: any) => {
  const { onChange = () => {}, startDate = '', endDate = '' } = props;

  return (
    <>
      <div className="YKEE-datePicker">
        <DatePicker
          onChange={onChange}
          selectsRange
          inline
          showMonthDropdown
          showYearDropdown
          dropdownMode="select"
          startDate={startDate}
          endDate={endDate}
        />
      </div>
    </>
  );
};

export default DateFilters;
