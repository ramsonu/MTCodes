import React from 'react';
import { Checkbox } from '@mui/material';

const ProductNameFilters = (props: any) => {
  const { onChange = () => {}, data = [], checkedValue = [] } = props;
  return (
    <>
      <ul className='sub-filter-list'>
        {data?.map((product: any, index: any) => {
          return (
            <div className='list-wrapper' key={index}>
              <span>{product?.['ConsignmentviewDetails.itemName']}</span>
              <Checkbox
                className='filter-sidebar-checkbox'
                checked={checkedValue.includes(
                  product?.['ConsignmentviewDetails.itemName']
                )}
                name={product?.['ConsignmentviewDetails.itemName']}
                onChange={(event: any) => onChange(event)}
              />
            </div>
          );
        })}
      </ul>
    </>
  );
};

export default ProductNameFilters;
