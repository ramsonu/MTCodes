import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import DynamicFilter from '../dynamic-filter';
import DateFilters from '../date';
import Slider from '@mui/material/Slider';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import Tabs from '@mui/material/Tabs';
import { Typography, Button } from '@mui/material';
import {
  filterBySalesAssociateWithoutModel,
  filterBySalesAssociateWithModel,
  filterByWarehouse,
} from '../constants';

const ProductFilters = (props: any) => {
  const {
    itemKey = '',
    startDate = '',
    endDate = '',
    onDateChange = () => {},
    onApplyClick = () => {},
    onClearFilters = () => {},
    priceValue = [0, 0],
    minMax = {},
    userPriceInput = {},
    setUserPriceInput = () => {},
    clearDisable = Boolean,
    toShowModelFilter = false,
  } = props;

  const dispatch = useDispatch();

  const [tabIndex, setTabIndex] = useState(0);
  const [filterBy, setFilterBy] = useState<any>([]);

  const handleTabChange = (event: any, newTabIndex: any) => {
    setTabIndex(newTabIndex);
  };

  useEffect(() => {
    switch (itemKey) {
      case 'salesAssociate':
        setFilterBy(
          toShowModelFilter
            ? filterBySalesAssociateWithModel
            : filterBySalesAssociateWithoutModel
        );
        break;
      case 'warehouse':
        setFilterBy(filterByWarehouse);
        break;
    }
  });

  const valuetext = (value: number) => {
    return `${value}`;
  };

  const priceChangeHandler = (event: Event, newValue: any) => {
    dispatch(
      actions.setFilterValueBasedOnKey({
        filterKey: 'price',
        filterValue: newValue,
      })
    );
    setUserPriceInput({ first: newValue[0], second: newValue[1] });
  };

  const handlePriceChange = (event: any, type: any) => {
    const position = type === 'min' ? 'first' : 'second';
    const priceValue: any = event?.target?.value;
    if (priceValue?.length <= 5) {
      if (priceValue?.length === 0) {
        let valueAsZero = { ...userPriceInput, ...{ [position]: 0 } };
        setUserPriceInput(valueAsZero);
      } else if (priceValue?.length > 1 && priceValue?.startsWith('0')) {
        let removeZero = {
          ...userPriceInput,
          ...{ [position]: priceValue.replace(/^0/, '') },
        };
        setUserPriceInput(removeZero);
      } else {
        let value = {
          ...userPriceInput,
          ...{ [position]: priceValue },
        };
        setUserPriceInput(value);
      }
    }
  };

  const numFormatter = (num: any) => {
    if (num > 999 && num < 1000000) {
      return (num / 1000).toFixed(1) + 'K'; // convert to K for number from > 1000 < 1 million
    } else if (num > 1000000) {
      return (num / 1000000).toFixed(1) + 'M'; // convert to M for number from > 1 million
    } else if (num <= 999) {
      return num; // if value < 1000, nothing to do
    }
  };

  return (
    <div className='filters-outer-wrapper'>
      <div className='products-filter-wrapper'>
        <Box sx={{ display: 'flex' }}>
          <Tabs
            value={tabIndex}
            onChange={handleTabChange}
            orientation='vertical'
            className='text-left'
          >
            {filterBy?.map((data: any, i: any) => {
              return <Tab key={i} label={data} />;
            })}
          </Tabs>
          <Box className='yk-filter-options'>
            {/* for Sales associate */}
            {tabIndex === 0 && itemKey === 'salesAssociate' && (
              <Box>
                <Typography>
                  <div className='list-wrapper'>
                    <DynamicFilter itemKey={'brand'} />
                  </div>
                </Typography>
              </Box>
            )}
            {toShowModelFilter &&
              tabIndex === 1 &&
              itemKey === 'salesAssociate' &&
              toShowModelFilter && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <DynamicFilter
                        itemKey={'model'}
                        toShowModelFilter={toShowModelFilter}
                      />
                    </div>
                  </Typography>
                </Box>
              )}
            {toShowModelFilter
              ? tabIndex === 2 &&
                itemKey === 'salesAssociate' && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <DynamicFilter itemKey={'type'} />
                      </div>
                    </Typography>
                  </Box>
                )
              : tabIndex === 1 &&
                itemKey === 'salesAssociate' && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <DynamicFilter itemKey={'type'} />
                      </div>
                    </Typography>
                  </Box>
                )}
            {toShowModelFilter
              ? tabIndex === 3 &&
                itemKey === 'salesAssociate' && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <DynamicFilter itemKey={'size'} />
                      </div>
                    </Typography>
                  </Box>
                )
              : tabIndex === 2 &&
                itemKey === 'salesAssociate' && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <DynamicFilter itemKey={'size'} />
                      </div>
                    </Typography>
                  </Box>
                )}
            {toShowModelFilter
              ? tabIndex === 4 &&
                itemKey === 'salesAssociate' && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <DynamicFilter itemKey={'color'} />
                      </div>
                    </Typography>
                  </Box>
                )
              : tabIndex === 3 &&
                itemKey === 'salesAssociate' && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <DynamicFilter itemKey={'color'} />
                      </div>
                    </Typography>
                  </Box>
                )}
            {toShowModelFilter
              ? tabIndex === 5 &&
                itemKey === 'salesAssociate' && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <DynamicFilter itemKey={'date'} />
                      </div>
                    </Typography>
                  </Box>
                )
              : tabIndex === 4 &&
                itemKey === 'salesAssociate' && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <DynamicFilter itemKey={'date'} />
                      </div>
                    </Typography>
                  </Box>
                )}
            {toShowModelFilter
              ? tabIndex === 6 &&
                itemKey === 'salesAssociate' && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <DynamicFilter itemKey={'availability'} />
                      </div>
                    </Typography>
                  </Box>
                )
              : tabIndex === 5 &&
                itemKey === 'salesAssociate' && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <DynamicFilter itemKey={'availability'} />
                      </div>
                    </Typography>
                  </Box>
                )}
            {toShowModelFilter
              ? tabIndex === 7 &&
                itemKey === 'salesAssociate' && (
                  <Box>
                    <Typography>
                      <div className='ykch-priceFilter'>
                        <div className='yk-priceText'>
                          <span className='price-min'>
                            ${numFormatter(priceValue[0])}
                          </span>
                          <span className='price-space'>-</span>
                          <span className='price-max'>
                            ${numFormatter(priceValue[1])}
                          </span>
                        </div>
                        <div className='yk-sliderWrapper'>
                          <Slider
                            className='ykch-sliderPriceFilter'
                            getAriaLabel={() => 'Temperature range'}
                            value={priceValue}
                            onChange={priceChangeHandler}
                            max={minMax?.max}
                            valueLabelDisplay='auto'
                            getAriaValueText={valuetext}
                          />
                        </div>
                        <div className='yk-sliderInputWrapper mt-2'>
                          <input
                            type='number'
                            name='min'
                            value={userPriceInput?.first}
                            placeholder='Min'
                            onChange={(e) => handlePriceChange(e, 'min')}
                          />
                          <input
                            type='text'
                            name='max'
                            value={userPriceInput?.second}
                            placeholder='Max'
                            onChange={(e) => handlePriceChange(e, 'max')}
                          />
                        </div>
                      </div>
                    </Typography>
                  </Box>
                )
              : tabIndex === 6 &&
                itemKey === 'salesAssociate' && (
                  <Box>
                    <Typography>
                      <div className='ykch-priceFilter'>
                        <div className='yk-priceText'>
                          <span className='price-min'>
                            ${numFormatter(priceValue[0])}
                          </span>
                          <span className='price-space'>-</span>
                          <span className='price-max'>
                            ${numFormatter(priceValue[1])}
                          </span>
                        </div>
                        <div className='yk-sliderWrapper'>
                          <Slider
                            className='ykch-sliderPriceFilter'
                            getAriaLabel={() => 'Temperature range'}
                            value={priceValue}
                            onChange={priceChangeHandler}
                            max={minMax?.max}
                            valueLabelDisplay='auto'
                            getAriaValueText={valuetext}
                          />
                        </div>
                        <div className='yk-sliderInputWrapper mt-2'>
                          <input
                            type='number'
                            name='min'
                            value={userPriceInput?.first}
                            placeholder='Min'
                            onChange={(e) => handlePriceChange(e, 'min')}
                          />
                          <input
                            type='text'
                            name='max'
                            value={userPriceInput?.second}
                            placeholder='Max'
                            onChange={(e) => handlePriceChange(e, 'max')}
                          />
                        </div>
                      </div>
                    </Typography>
                  </Box>
                )}
            {/*  for warehouse */}
            {tabIndex === 0 && itemKey === 'warehouse' && (
              <Box>
                <Typography>
                  <div className='list-wrapper'>
                    <DynamicFilter itemKey={'bin'} />
                  </div>
                </Typography>
              </Box>
            )}
            {tabIndex === 1 && itemKey === 'warehouse' && (
              <Box>
                <Typography>
                  <div className='list-wrapper'>
                    <DynamicFilter itemKey={'size'} />
                  </div>
                </Typography>
              </Box>
            )}
            {tabIndex === 2 && itemKey === 'warehouse' && (
              <Box className='m-0'>
                <Typography>
                  <DateFilters
                    onChange={onDateChange}
                    startDate={startDate}
                    endDate={endDate}
                  />
                </Typography>
              </Box>
            )}
          </Box>
        </Box>

        <div className='search-filter-button-wrapper shoesize-apply-btn size-tab'>
          <Button
            className='btn-transparent clear-filter-btn yk-badge-h7 text-capitalize'
            onClick={onClearFilters}
            disabled={clearDisable}
          >
            Clear
          </Button>
          <Button
            variant='contained'
            className='btn yk-btn-primary-sm text-capitalize'
            onClick={onApplyClick}
          >
            Apply
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProductFilters;
