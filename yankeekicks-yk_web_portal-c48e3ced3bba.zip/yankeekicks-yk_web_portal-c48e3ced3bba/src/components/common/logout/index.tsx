import React from 'react';
import { PublicClientApplication } from '@azure/msal-browser';

export const LogoutUser = () => {
  const msalConfig: any = localStorage.getItem('msalConfig') || '';
  const msalInstance = new PublicClientApplication(msalConfig);

  const getCachedUser = () => {
    if (msalInstance) {
      const allAccounts = msalInstance.getAllAccounts();

      if (allAccounts.length > 0) {
        return allAccounts[0];
      }

      return null;
    }

    return null;
  };

  const logout = () => {
    if (msalInstance) {
      const logoutRequest = {
        account: getCachedUser(),
        postLogoutRedirectUri: '/',
      };
      if (
        localStorage.getItem('redirect')?.toLocaleLowerCase() === 'redirect'
      ) {
        msalInstance.logoutRedirect(logoutRequest).catch((e) => {
          console.error(e);
        });
      } else {
        msalInstance.logoutPopup(logoutRequest).catch((e) => {
          console.error(e);
        });
      }
    }

    localStorage.clear();
    sessionStorage.clear();
  };

  return logout();
};
