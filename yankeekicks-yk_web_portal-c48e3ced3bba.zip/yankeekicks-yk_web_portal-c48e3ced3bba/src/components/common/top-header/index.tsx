import React, { useEffect, useState, useRef } from 'react';
import Image from 'next/image';
import dummyUserImg from 'assets/images/user-img.png';
import notificationBell from 'assets/images/notification-bell.svg';
import notificationDot from 'assets/images/notification-dot.svg';
import LogOutIcon from 'assets/images/log-out.svg';
import Button from '@mui/material/Button';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import Grow from '@mui/material/Grow';
import Paper from '@mui/material/Paper';
import Popper from '@mui/material/Popper';
import MenuItem from '@mui/material/MenuItem';
import MenuList from '@mui/material/MenuList';
import Stack from '@mui/material/Stack';
import leftArrowIcon from 'assets/images/back-icon.svg';
import { useRouter } from 'next/router';
import { useSelector, useDispatch } from 'react-redux';
import { actions } from 'store/reducers/shoesize';
import { actions as authActions } from 'store/reducers/auth';
import { actions as warehouseActions } from 'store/reducers/warehouse';
import ContactusIcon from 'assets/images/contact-us.svg';
import jwt_decode from 'jwt-decode';
import Axios from 'axios';
import productImage from 'assets/images/products/dummy.png';
import checkedOutIcon from 'assets/images/checked-out-up-arrow.svg';
import { LogoutUser } from '../logout';

const TopHeader = () => {
  const dispatch = useDispatch();
  const router = useRouter();

  const [open, setOpen] = useState(false);
  const [showNotification, setShowNotification] = useState(false);
  const [imageUrl, setImageUrl] = useState<any>('');

  const anchorRef = useRef<HTMLButtonElement>(null);

  const { isShoeSizeBackButtonVisible, goBackTrigger } = useSelector(
    (state: any) => state.shoesize
  );

  const { requestDetailsToggle } = useSelector((state: any) => state.warehouse);
  // let userDetails = { user_id: '' };

  // userDetails = jwt_decode(localStorage.getItem('jwt-token') || '{}');
  useEffect(() => {
    Axios.get('https://graph.microsoft.com/v1.0/me/photo/$value', {
      headers: {
        Authorization: `Bearer ${localStorage?.getItem('access-token')}`,
        'Content-Type': 'image/jpeg',
      },
      responseType: 'blob',
    }).then((o) => {
      const url = window.URL || window.webkitURL;
      const blobUrl = url.createObjectURL(o.data);
      setImageUrl(blobUrl);
    });
  }, []);

  const handleToggle = (trigger: string) => {
    if (trigger === 'user') {
      setOpen((prevOpen) => !prevOpen);
    }
    if (trigger === 'notification') {
      setShowNotification((prevNotification) => !prevNotification);
    }
  };

  const handleClose = (
    event: Event | React.SyntheticEvent,
    trigger: string
  ) => {
    if (
      anchorRef.current &&
      anchorRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }
    if (trigger === 'user') setOpen(false);
    if (trigger === 'notification') setShowNotification(false);
  };

  const logoutHandler = () => {
    dispatch(authActions.clearUserDetails());
    LogoutUser();
    router.push('/', undefined, { shallow: true });
  };

  const handleListKeyDown = (event: React.KeyboardEvent, input: string) => {
    let stateMethod: any = setOpen;
    if (input === 'user') {
      stateMethod = setOpen;
    }
    if (input === 'notification') {
      stateMethod = setShowNotification(false);
    }

    if (event.key === 'Tab') {
      event.preventDefault();
      stateMethod(false);
    } else if (event.key === 'Escape') {
      stateMethod(false);
    }
  };

  // return focus to the button when we transitioned from !open -> open
  const prevOpen = React.useRef(open);
  React.useEffect(() => {
    if (prevOpen.current === true && open === false) {
      anchorRef.current!.focus();
    }

    prevOpen.current = open;
  }, [open]);

  const isBackToListVisible = () => {
    if (router.pathname === '/warehouse') {
      dispatch(warehouseActions.setRequestDetailsToggle(false));
    }

    if (router.pathname.includes('/warehouse/request-details')) {
      return true;
    }
  };

  const goBackHandler = () => {
    if (router.pathname.includes('/shoesize/inventory')) {
      router.push('/shoesize');
    }
    dispatch(actions.setBackButtonTrigger(!goBackTrigger));
  };

  const isBackButtonVisible = () => {
    if (router.pathname.includes('/shoesize') && isShoeSizeBackButtonVisible) {
      return true;
    }
    if (router.pathname.includes('/shoesize/inventory')) {
      return true;
    }
  };

  const onBackButtonClick = () => {
    dispatch(warehouseActions.setRequestDetailsToggle(!requestDetailsToggle));
  };

  const onProfileClick = () => {
    if (router.pathname.includes('/shoesize')) {
      router.push('/shoesize/profile');
    }
    if (router.pathname.includes('/warehouse')) {
      router.push('/warehouse/profile');
    }
    setOpen(false);
  };

  const showNotificationIcon = false;

  return (
    <div className='container-fluid'>
      <div className='row'>
        <div className='col-lg-12 col-md-12 col-sm-12'>
          <div className='heading-wrapper yk-heading-wrapper'>
            {isBackToListVisible() && (
              <div
                className='yk-heading-btn-wrapper'
                onClick={onBackButtonClick}
              >
                <button className='btn btn-transparent left-arrow-btn'>
                  <Image
                    src={leftArrowIcon}
                    alt='left-arrow-icon'
                    className='Image-fluid'
                  />
                  Back to list
                </button>
              </div>
            )}
            {isBackButtonVisible() && (
              <div className='yk-heading-btn-wrapper' onClick={goBackHandler}>
                <button className='btn btn-transparent left-arrow-btn'>
                  <Image
                    src={leftArrowIcon}
                    alt='left-arrow-icon'
                    className='Image-fluid'
                  />
                  Back
                </button>
              </div>
            )}
            <div className='yk-nav-wrapper'>
              <ul className='nav nav-tabs user-nav'>
                {showNotificationIcon && (
                  <li className='nav-item notification-li'>
                    <Stack direction='row' spacing={2}>
                      <Button
                        ref={anchorRef}
                        id='notification-button'
                        aria-controls={
                          showNotification ? 'composition-menu' : undefined
                        }
                        aria-expanded={showNotification ? 'true' : undefined}
                        aria-haspopup='true'
                        onClick={() => handleToggle('notification')}
                        className='btn user-actions-btn'
                      >
                        <a className='nav-link' aria-current='page' href='#'>
                          <Image
                            src={notificationBell}
                            alt=''
                            className='img-fluid notification-bell'
                          />
                          <Image
                            src={notificationDot}
                            alt=''
                            className='img-fluid notification-dot'
                          />
                        </a>
                      </Button>
                      <Popper
                        open={showNotification}
                        anchorEl={anchorRef.current}
                        role={undefined}
                        placement='right-end'
                        transition
                        disablePortal
                      >
                        {({ TransitionProps, placement }) => (
                          <Grow
                            {...TransitionProps}
                            style={{
                              transformOrigin:
                                placement === 'right-end' ? 'top' : 'bottom',
                            }}
                          >
                            <Paper>
                              <ClickAwayListener
                                onClickAway={(event) =>
                                  handleClose(event, 'notification')
                                }
                              >
                                <MenuList
                                  autoFocusItem={showNotification}
                                  id='composition-menu'
                                  aria-labelledby='notification-button'
                                  onKeyDown={(event) =>
                                    handleListKeyDown(event, 'notification')
                                  }
                                  className='users-menu-list'
                                >
                                  <MenuItem className='users-menu-list-item'>
                                    <div className='shoes-checkout-notification-wrapper'>
                                      <div className='product-img-wrapper'>
                                        <Image
                                          src={productImage}
                                          alt='product-img'
                                          className='product-image img-fluid'
                                        />
                                      </div>
                                      <span className='product-content-wrapper'>
                                        <h6 className='checked-out-text yk-badge-h16'>
                                          Shoes checked out
                                        </h6>
                                        <h6 className='product-name yk-badge-h8'>
                                          Nike Air Presto Mid High OG
                                        </h6>
                                      </span>
                                      <div className='checked-out-img-wrapper'>
                                        <Image
                                          src={checkedOutIcon}
                                          alt='arrow-img'
                                          className='img-fluid'
                                        />
                                      </div>
                                    </div>
                                  </MenuItem>
                                  <MenuItem className='users-menu-list-item'>
                                    <div className='shoes-checkout-notification-wrapper d-flex'>
                                      <div className='product-img-wrapper'>
                                        <Image
                                          src={productImage}
                                          alt='product-img'
                                          className='product-image img-fluid'
                                        />
                                      </div>
                                      <span className='product-content-wrapper'>
                                        <h6 className='checked-out-text'>
                                          Shoes checked out
                                        </h6>
                                        <h6 className='product-name'>
                                          Nike Air Presto Mid High OG
                                        </h6>
                                      </span>
                                      <div className='checked-out-img-wrapper'>
                                        <Image
                                          src={checkedOutIcon}
                                          alt='arrow-img'
                                          className='img-fluid'
                                        />
                                      </div>
                                    </div>
                                  </MenuItem>
                                </MenuList>
                              </ClickAwayListener>
                            </Paper>
                          </Grow>
                        )}
                      </Popper>
                    </Stack>
                  </li>
                )}
                <li className='nav-item dropdown'>
                  <Stack direction='row' spacing={2}>
                    <Button
                      ref={anchorRef}
                      id='composition-button'
                      aria-controls={open ? 'composition-menu' : undefined}
                      aria-expanded={open ? 'true' : undefined}
                      aria-haspopup='true'
                      onClick={() => handleToggle('user')}
                      className='btn btn-dropdown user-actions-btn'
                    >
                      <Image
                        src={imageUrl || dummyUserImg}
                        alt='User'
                        className='img-fluid'
                        height={40}
                        width={40}
                      />
                      <span className='user-details-wrapper'>
                        <span className='user-name'>
                          {localStorage?.getItem('user-name') || '--'}
                        </span>
                        <span className='emp-id '>
                          {localStorage?.getItem('user-role') || '--'}
                        </span>
                      </span>
                    </Button>
                    <Popper
                      open={open}
                      anchorEl={anchorRef.current}
                      role={undefined}
                      placement='bottom-start'
                      transition
                      disablePortal
                    >
                      {({ TransitionProps, placement }) => (
                        <Grow
                          {...TransitionProps}
                          style={{
                            transformOrigin:
                              placement === 'bottom-start'
                                ? 'left top'
                                : 'left bottom',
                          }}
                        >
                          <Paper>
                            <ClickAwayListener
                              onClickAway={(event) =>
                                handleClose(event, 'user')
                              }
                            >
                              <MenuList
                                autoFocusItem={open}
                                id='composition-menu'
                                aria-labelledby='composition-button'
                                onKeyDown={(event) =>
                                  handleListKeyDown(event, 'user')
                                }
                                className='users-menu-list'
                              >
                                <MenuItem
                                  className='users-menu-list-item'
                                  onClick={onProfileClick}
                                >
                                  {router.pathname.includes('/shoesize') ||
                                  router.pathname.includes('/warehouse')
                                    ? 'Profile'
                                    : 'Contact Us'}
                                </MenuItem>
                                <MenuItem
                                  className='users-menu-list-item'
                                  onClick={logoutHandler}
                                >
                                  Logout
                                  <Image
                                    src={LogOutIcon}
                                    alt=''
                                    className='img-fluid'
                                  ></Image>
                                </MenuItem>
                              </MenuList>
                            </ClickAwayListener>
                          </Paper>
                        </Grow>
                      )}
                    </Popper>
                  </Stack>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TopHeader;
