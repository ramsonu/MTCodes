import React, { useState } from 'react';
import { useZxing } from 'react-zxing';

const QrCodeScanner = (props: any) => {
  const { setBarCodeScanResult } = props;
  const { ref } = useZxing({
    onResult(result: any) {
      setBarCodeScanResult(result.getText());
    },
    // onError: (error: any) => {
    //   setBarCodeScanError(error?.message);
    // },
  });
  return (
    <div className='yk-cameraSectionWrapper'>
      <video ref={ref} />
    </div>
  );
};

export default QrCodeScanner;
