import React from 'react';
import Image from 'next/image';
import noRecordImg from 'assets/images/no-table-record-img.png';
import { NO_RESULT_FOUND } from './constant';
const NoDataFound = React.forwardRef(
  (props: any, ref: React.Ref<HTMLDivElement>) => {
    const { title = NO_RESULT_FOUND.title, msg = NO_RESULT_FOUND.msg } = props;

    return (
      <div
        className='no-record-found-wrapper text-center yk-center-align'
        ref={ref}
      >
        <div>
          <Image
            src={noRecordImg}
            alt='filter-btn-icon'
            className='no-result-img img-fluid'
          />
          {title && <h4 className='yk-title'>{title}</h4>}
          {msg && <p className='yk-subtitle'>{msg}</p>}
        </div>
      </div>
    );
  }
);
NoDataFound.displayName = 'Print Summary';
export default NoDataFound;
