export const NO_RESULT_FOUND = {
    title: 'No results found',
    msg: 'We couldnt find anything for what you are looking.',
  };