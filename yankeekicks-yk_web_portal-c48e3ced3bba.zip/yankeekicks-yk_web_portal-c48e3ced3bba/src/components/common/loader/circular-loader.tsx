import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';

const CircleLoader = () => {
  return (
    <Box className='loader-wrapper' sx={{ display: 'flex' }}>
      <CircularProgress />
    </Box>
  );
};

export default CircleLoader;
