import { FormControl, Menu, MenuItem, Select } from '@mui/material';
import Image from 'next/image';
import csvIcon from 'assets/images/csv-file.svg';
import xlsIcon from 'assets/images/xls-file.svg';
import pdfIcon from 'assets/images/pdf-file.svg';
import ExportToExcel from './excel';
import ExportToPDF from './pdf';
import ExportToCSV from './csv';
import React from 'react';

const ExportFiles = ({ data, fileName }: any) => {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  return (
    <>
      <div className='export-selectbox-wrapper'>
        <FormControl className='export-selectbox' sx={{ m: 1, minWidth: 80 }}>
          <span
            id='basic-button'
            className='yk-export-select-item'
            aria-controls={open ? 'basic-menu' : undefined}
            aria-haspopup='true'
            aria-expanded={open ? 'true' : undefined}
            onClick={handleClick}
          >
            Export
          </span>
          <Menu
            id='basic-menu'
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            MenuListProps={{
              'aria-labelledby': 'basic-button',
            }}
          >
            <MenuItem className='export-select-item' value={'asc'} disabled>
              Export
            </MenuItem>
            <MenuItem
              onClick={handleClose}
              className='export-select-item'
              value={'csv'}
            >
              <ExportToCSV data={data} fileName={fileName}>
                CSV
              </ExportToCSV>
              <Image src={csvIcon} alt='table-img' className='img-fluid' />
            </MenuItem>
            <MenuItem
              onClick={handleClose}
              className='export-select-item'
              value={'xlsx'}
            >
              <ExportToExcel data={data} fileName={fileName} />
              <Image src={xlsIcon} alt='table-img' className='img-fluid' />
            </MenuItem>
            <MenuItem
              onClick={handleClose}
              className='export-select-item'
              value={'pdf'}
            >
              <ExportToPDF />
              <Image src={pdfIcon} alt='table-img' className='img-fluid' />
            </MenuItem>
          </Menu>
        </FormControl>
      </div>
    </>
  );
};
export default ExportFiles;
