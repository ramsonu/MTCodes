import { CSVLink } from 'react-csv';

const ExportToCSV = ({ headers, data, fileName }: any) => {
  const csvReport = {
    data: data,
    headers: headers,
    filename: `${fileName}.csv`,
  };

  return (
    <CSVLink className='deafultLink' {...csvReport}>
      CSV
    </CSVLink>
  );
};
export default ExportToCSV;
