const ExportToPDF = () => {
  return <span>PDF</span>;
};

export default ExportToPDF;
