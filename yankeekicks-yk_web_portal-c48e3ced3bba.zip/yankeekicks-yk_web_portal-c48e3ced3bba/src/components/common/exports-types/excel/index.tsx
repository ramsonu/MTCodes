import React from 'react';
import * as FileSaver from 'file-saver';
import XLSX from 'sheetjs-style';

const ExportToExcel = ({ data, fileName }: any) => {
  const fileType =
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
  const fileExtension = '.xlsx';

  const exportToExcel = () => {
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = { Sheets: { data: ws }, SheetNames: ['data'] };
    const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const excdata = new Blob([excelBuffer], { type: fileType });
    FileSaver.saveAs(excdata, fileName + fileExtension);
  };

  return <span onClick={exportToExcel}>XLSX </span>;
};

export default ExportToExcel;
