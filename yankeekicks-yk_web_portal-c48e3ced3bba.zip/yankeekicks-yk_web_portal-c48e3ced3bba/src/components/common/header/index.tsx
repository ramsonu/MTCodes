import React from 'react';
import ProductFilters from '../filters/product-filter';
import Sortings from '../sortings';
import ExportsTypes from '../exports-types';
import Image from 'next/image';
import filterIcon from 'assets/images/filter-icon.png';

const Headers = (props: any) => {
  const {
    sortHandler = () => {},
    handleFilterClick = () => {},
    exportsResultsSet = {},
    showFilters = Boolean,
    onDateChange = () => {},
    selectedStartDate = '',
    selectedEndDate = '',
    onClick = () => {},
    onPayoutChange = () => {},
    checked = {},
    onClearFilters = () => {},
  } = props;
  return (
    <>
      <div className='col-lg-6 col-md-12 col-sm-12'>
        <div className='consignment-btn-wrapper'>
          <Sortings handleChange={sortHandler} />

          <div className='filter-btn-wrapper'>
            <button className='btn filter-btn' onClick={handleFilterClick}>
              <Image
                src={filterIcon}
                alt='filter-btn-icon'
                className='filter-btn-icon img-fluid'
              />
              <span className='filter-btn-text yk-badge-h15'>Filter</span>
              {showFilters && (
                <ProductFilters
                  itemKey='order'
                  onDateChange={onDateChange}
                  startDate={selectedStartDate}
                  endDate={selectedEndDate}
                  onClick={onClick}
                  onPayoutChange={onPayoutChange}
                  checkedValue={checked}
                  onClearFilters={onClearFilters}
                />
              )}
            </button>
          </div>

          <div className='sort-product-wrapper export-btn'>
            <ExportsTypes
              data={
                (exportsResultsSet?.loadResponses &&
                  exportsResultsSet?.loadResponses[0]?.data) ||
                []
              }
              fileName='orders'
            />
          </div>
        </div>
      </div>
    </>
  );
};
export default Headers;
