import { PublicClientApplication } from '@azure/msal-browser';
import { useRouter } from 'next/router';
import React, { useState, useEffect } from 'react';
import { useIdleTimer } from 'react-idle-timer';
import { useDispatch } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import { LOGOUT_TIME } from './constant';
import { actions as authActions } from 'store/reducers/auth';

const IdleTimerContainer = (props: any) => {
  const router = useRouter();
  const dispatch = useDispatch();
  const [requiredTime, setRequiredTime] = useState(0);
  const currentPath = router.pathname;

  const msalConfig: any = localStorage.getItem('msalConfig');
  const msalInstance = new PublicClientApplication(msalConfig);

  useEffect(() => {
    setRequiredTime(LOGOUT_TIME.IN_MINS * 30);

    return () => {
      setRequiredTime(0);
    };
  }, [currentPath]);

  const getCachedUser = () => {
    if (msalInstance) {
      const allAccounts = msalInstance.getAllAccounts();

      if (allAccounts.length > 0) {
        return allAccounts[0];
      }

      return null;
    }

    return null;
  };

  const logout = () => {
    dispatch(authActions.clearUserDetails());

    if (msalInstance) {
      const logoutRequest = {
        account: getCachedUser(),
        postLogoutRedirectUri: '/',
      };
      if (
        localStorage.getItem('redirect')?.toLocaleLowerCase() === 'redirect'
      ) {
        msalInstance.logoutRedirect(logoutRequest).catch((e) => {
          console.error(e);
        });
      } else {
        msalInstance.logoutPopup(logoutRequest).catch((e) => {
          console.error(e);
        });
      }
    }

    localStorage.clear();
    sessionStorage.clear();
    router.push('/', undefined, { shallow: true });
  };

  const onIdle = () => {
    if (requiredTime !== 0) {
      logout();
    }
  };

  const idleTimer = useIdleTimer({ onIdle, timeout: requiredTime });
  return <>{props.children}</>;
};
export default IdleTimerContainer;
