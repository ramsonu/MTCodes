import React, { useState, useEffect } from 'react';
import type { NextPage } from 'next';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import { actions } from 'store/reducers/shoesize';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
interface Props {
  initialPanes?: Array<any>;
  tabHandler?: (event: Event | React.SyntheticEvent) => void;
}

const CommonTabs: NextPage<Props> = (props: any) => {
  const { activeStatus } = useSelector((state: any) => state.shoesize); 
  const dispatch = useDispatch();
  const [panes, setPanes] = useState(props.initialPanes);
  const [value, setValue] = React.useState('1');

  useEffect(() => {
    setPanes([...props.initialPanes]);
    dispatch(actions.filterByStatus(value));
  }, [dispatch,props, value]);

  useEffect(()=>{
    setValue(activeStatus)
  }, [activeStatus])

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
    dispatch(actions.filterByStatus(newValue));
  };
  return (
    <Box sx={{ width: '100%', typography: 'body1' }}>
      <TabContext value={value}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <TabList onChange={handleChange} aria-label='lab API tabs example'>
            {panes?.map((tab: any) => (
              <Tab key={`tab-${tab.title}`} label={tab.title} value={tab.key} onClick={(e)=>{props.tabHandler?.(e)}} />
            ))}
          </TabList>
        </Box>
        {panes?.map((pane: any) => (
          <TabPanel key={`pan-${pane.title}`} value={pane.key}>
            {pane.content}
          </TabPanel>
        ))}
      </TabContext>
    </Box>
  );
};
export default CommonTabs;
