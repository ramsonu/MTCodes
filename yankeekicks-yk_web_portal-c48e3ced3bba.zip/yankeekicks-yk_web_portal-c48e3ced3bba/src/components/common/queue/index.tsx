import React from 'react';

const Queue = () => {
  return <div>Queue</div>;
};

export default Queue;
