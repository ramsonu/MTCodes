import React from 'react';

const StatusTabs = () => {
  return <div></div>;
};

export default StatusTabs;
