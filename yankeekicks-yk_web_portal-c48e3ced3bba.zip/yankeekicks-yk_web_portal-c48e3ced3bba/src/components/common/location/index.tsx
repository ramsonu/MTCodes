import React, { useState, useEffect } from 'react';
import { styled, alpha } from '@mui/material/styles';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { MenuItem, Button, InputLabel } from '@mui/material';
import FormControl from '@mui/material/FormControl';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import Menu, { MenuProps } from '@mui/material/Menu';
import { useSelector, useDispatch } from 'react-redux';
import { actions } from 'store/reducers/shared';
import { actions as kioskActions } from 'store/reducers/kiosk';
import {
  STORE_LOCATION_REQUEST,
  STORE_BY_LOCATION_REQUEST,
} from 'actions/shared';
import { useRouter } from 'next/router';
import closeIcon from 'assets/images/black-close-icon.svg';
import Image from 'next/image';

const StyledMenu = styled((props: MenuProps) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: 'bottom',
      horizontal: 'right',
    }}
    transformOrigin={{
      vertical: 'top',
      horizontal: 'right',
    }}
    {...props}
  />
))(({ theme }) => ({
  '& .MuiPaper-root': {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 180,
    color:
      theme.palette.mode === 'light'
        ? 'rgb(55, 65, 81)'
        : theme.palette.grey[300],
    boxShadow:
      'rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px',
    '& .MuiMenu-list': {
      padding: '4px 0',
    },
    '& .MuiMenuItem-root': {
      '& .MuiSvgIcon-root': {
        fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      '&:active': {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));

const Locations = ({ item, innerPage = false }: any) => {
  const { storeLocations, selected } = useSelector(
    (state: any) => state.shared
  );
  const dispatch = useDispatch();

  const [selectedLocation, setSelectedLocation] = useState('');
  const [totalLocationsFromStorage, setTotalLocationsFromStorage] = useState(
    []
  );

  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [showLocationSidebar, setShowLocationSidebar] = useState<any>(false);
  const openBtn = Boolean(anchorEl);
  const router = useRouter();
  const kioskpath = /^\/kiosk.*$/.test(router.pathname);
  useEffect(() => {
    if (kioskpath) dispatch({ type: STORE_LOCATION_REQUEST });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const params = {
      locations: localStorage?.getItem('storeLocation'),
    };
    if (!kioskpath)
      dispatch({ type: STORE_BY_LOCATION_REQUEST, payload: { params } });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    setSelectedLocation(selected?.id);
    const totalLoc: any = localStorage?.getItem('totalLocation')?.split(',');
    setTotalLocationsFromStorage(totalLoc);
  }, [selected]);

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
    setShowLocationSidebar(true);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const locationHandler = (value: any) => {
    setSelectedLocation(value as string);
    // const selectedItem: any = storeLocations.find(
    //   (store: any) => store.id === value
    // );
    dispatch(kioskActions.clearAllFilters({}));
    dispatch(kioskActions.clearAllFiltersForCube({}));
    let selectedLocations: any = [];
    storeLocations?.map((item: any) => {
      item?.locations?.map((subItem: any) => {
        if (subItem?.id === value) {
          return selectedLocations?.push(subItem);
        }
      });
    });
    let selectedItem: any = [];
    storeLocations?.map((loc: any) => {
      loc?.locations?.map((item: any) => {
        if (item?.id === value) {
          return selectedItem?.push({
            id: loc?.id,
            shopifyApiDomain: loc?.shopifyApiDomain,
            shopifyRestApiDomain: loc?.shopifyRestApiDomain,
            location: loc?.location,
            accessToken: loc?.accessToken,
            locations: selectedLocations,
          });
        }
      });
    });
    localStorage?.setItem('storeId', selectedItem[0].locations[0]?.storeId);
    localStorage?.setItem('storeLocation', selectedItem[0].locations[0]?.name);
    localStorage.setItem('storeLocationId', selectedItem[0]?.locations[0]?.id);
    dispatch(actions.selected(selectedItem[0]));
    innerPage && handleClose && handleClose();
    setShowLocationSidebar(false);
  };
  const showLocationTitle: any = item?.text
    ? localStorage?.getItem('storeLocation')
    : '';
  return (
    <>
      {innerPage && totalLocationsFromStorage?.length > 1 && (
        <div className='locations-dropdown-wrapper'>
          <Button
            className='location-dropdown-btn btn'
            id='demo-customized-button'
            aria-controls={openBtn ? 'demo-customized-menu' : undefined}
            aria-haspopup='true'
            aria-expanded={openBtn ? 'true' : undefined}
            variant='contained'
            disableElevation
            onClick={handleClick}
            endIcon={<KeyboardArrowDownIcon />}>
            <span className='location-text-wrapper'>
              <span className='portal-text'>
                {item?.subText ? 'Location' : ''}
              </span>
              <span className='location-name' title={showLocationTitle}>
                {item?.text ? localStorage?.getItem('storeLocation') : ''}
              </span>
            </span>
          </Button>
          {showLocationSidebar && (
            <div className='yk-overlapping-window'>
              <div className='close-btn-wrapper'>
                <button
                  className='btn btn-transparent close-btn'
                  onClick={() => setShowLocationSidebar(false)}>
                  <Image src={closeIcon} alt='' className='img-fluid' />
                </button>
              </div>
              <h4 className='yk-store-select'>Select Store</h4>
              <ul className='yk-location-list'>
                {storeLocations?.map((loc: any) => {
                  return loc?.locations?.map((item: any, index: any) => {
                    return (
                      <li key={index} onClick={() => locationHandler(item?.id)}>
                        <a>{item?.name}</a>
                      </li>
                    );
                  });
                })}
                {/* {storeLocations?.map((loc: any, index: any) => {
                  return (
                    <li key={index} onClick={() => locationHandler(loc?.id)}>
                      <a>{loc?.location}</a>
                    </li>
                  );
                })} */}
              </ul>
            </div>
          )}
        </div>
      )}
      {innerPage && totalLocationsFromStorage?.length === 1 && (
        <div className='locations-dropdown-wrapper'>
          <button className='location-dropdown-btn btn'>
            <span className='location-text-wrapper'>
              <span className='portal-text'>
                {item?.subText ? 'Location' : ''}
              </span>
              <span className='location-name' title={showLocationTitle}>
                {item?.text ? localStorage?.getItem('storeLocation') : ''}
              </span>
            </span>
          </button>
        </div>
      )}
    </>
  );
};

export default Locations;
