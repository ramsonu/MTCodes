import React, { useState } from 'react';
import Image from 'next/image';
import leftArrow from 'assets/images/left-arrow.svg';
import rightArrow from 'assets/images/right-arrow.svg';

const Pagination = (props: any) => {
  const {
    lengthOfData = 10,
    itemsPerPage = 2,
    currentOffset = 0,
    setOffset = () => {},
    isLoading = false,
  } = props;
  const [currentIndex, setCurrentIndex] = useState(1);

  let totalPagesToDisplay = lengthOfData / itemsPerPage;
  totalPagesToDisplay = Math.ceil(totalPagesToDisplay); // pages to display in pagination

  const pivotPoint = Math.ceil(totalPagesToDisplay / 2); // Pivot point to show "..."
  const minLength = 5;

  const pageClickHandler = (value: any) => {
    setCurrentIndex(value);
    const calculateOffset = value * itemsPerPage - itemsPerPage;
    setOffset(calculateOffset);
  };

  const prevNextHandler = (flag: String) => {
    if (flag === 'prev') {
      if (currentIndex !== 1) {
        setCurrentIndex(currentIndex - 1);
        setOffset(currentOffset - itemsPerPage);
      }
    } else {
      if (currentIndex !== totalPagesToDisplay) {
        setCurrentIndex(currentIndex + 1);
        setOffset(currentOffset + itemsPerPage);
      }
    }
  };

  return (
    <>
      {!isLoading && (
        <div className='custom-pagination'>
          <nav aria-label='page-navigation'>
            <ul className='pagination'>
              <li
                className={`page-item prev ${
                  currentIndex === 1 ? 'disabled' : ''
                }`}
              >
                <a
                  className='page-link'
                  tabIndex={-1}
                  onClick={() => prevNextHandler('prev')}
                >
                  <Image
                    src={leftArrow}
                    alt='left-arrow-icon'
                    className='left-arrow-icon img-fluid'
                  />
                  Previous
                </a>
              </li>

              {totalPagesToDisplay <= 5 &&
                [...Array(totalPagesToDisplay)].map((item, index) => {
                  return (
                    <li
                      className={`page-item ${
                        currentIndex === index + 1 ? 'active' : ''
                      }`}
                      key={index}
                      onClick={() => pageClickHandler(index + 1)}
                    >
                      <a className='page-link'>{index + 1}</a>
                    </li>
                  );
                })}

              {/* The first page will be displayed when the index exceeds the pivot point */}
              {currentIndex > pivotPoint - 1 &&
                totalPagesToDisplay > minLength && (
                  <li
                    className={`page-item ${
                      currentIndex === 1 ? 'active' : ''
                    }`}
                    onClick={() => pageClickHandler(1)}
                  >
                    <a className='page-link'>1</a>
                  </li>
                )}

              {/* To display "..." when index is goes beyond pivot point */}
              {currentIndex >= pivotPoint &&
                totalPagesToDisplay > minLength && <li>...</li>}

              {/* Displaying pages before pivot point is reached */}
              {currentIndex < pivotPoint &&
                totalPagesToDisplay > minLength &&
                [...Array(totalPagesToDisplay)].map((item, index) => {
                  return (
                    (index + 1 < pivotPoint || currentIndex > pivotPoint) && (
                      <li
                        className={`page-item ${
                          currentIndex === index + 1 ? 'active' : ''
                        }`}
                        key={index}
                        onClick={() => pageClickHandler(index + 1)}
                      >
                        <a className='page-link'>{index + 1}</a>
                      </li>
                    )
                  );
                })}

              {/* To display pages after pivot point hit */}
              {currentIndex >= pivotPoint &&
                totalPagesToDisplay > minLength &&
                [...Array(totalPagesToDisplay)].map((item, index) => {
                  return (
                    (index + 1 >= pivotPoint || currentIndex < pivotPoint) && (
                      <li
                        className={`page-item ${
                          currentIndex === index + 1 ? 'active' : ''
                        }`}
                        key={index}
                        onClick={() => pageClickHandler(index + 1)}
                      >
                        <a className='page-link'>{index + 1}</a>
                      </li>
                    )
                  );
                })}

              {/* When the index drops below the pivot point, display "..." */}
              {currentIndex < pivotPoint && totalPagesToDisplay > minLength && (
                <li>...</li>
              )}

              {/* The last page should be displayed when the index is less than the pivot point */}
              {currentIndex < pivotPoint && totalPagesToDisplay > minLength && (
                <li
                  className={`page-item ${
                    currentIndex === totalPagesToDisplay ? 'active' : ''
                  }`}
                  onClick={() => pageClickHandler(totalPagesToDisplay)}
                >
                  <a className='page-link'>{totalPagesToDisplay}</a>
                </li>
              )}

              <li
                className={`page-item next ${
                  currentIndex === totalPagesToDisplay ? 'disabled' : ''
                }`}
                onClick={() => prevNextHandler('next')}
              >
                <a className='page-link'>
                  Next
                  <Image
                    src={rightArrow}
                    alt='right-arrow-icon'
                    className='right-arrow-icon img-fluid'
                  />
                </a>
              </li>
            </ul>
          </nav>
        </div>
      )}
    </>
  );
};

export default Pagination;
