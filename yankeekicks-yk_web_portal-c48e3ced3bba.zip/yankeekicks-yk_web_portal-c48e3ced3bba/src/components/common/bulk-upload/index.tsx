import { useRouter } from 'next/router';
import React, { useState } from 'react';
import uploadImg from 'assets/images/image-upload.svg';
import { useDropzone } from 'react-dropzone';
import Image from 'next/image';
import { FILE_UPLOAD } from 'components/warehouse/constants';
export const BulkUpload = (props: any) => {
  const [files, setFiles] = useState<any>([]);
  const { sendFile, setSendFile, showMsg } = props;

  const { getRootProps, getInputProps } = useDropzone({
    accept: {
      csv: ['.csv'],
      excel: ['.xlsx', '.xls'],
    },
    onDrop: (acceptedFiles: any) => {
      setFiles(
        acceptedFiles.map((file: any) =>
          Object.assign(file, {
            preview: URL.createObjectURL(file),
          })
        )
      );
      setSendFile(
        acceptedFiles.map((file: any) =>
          Object.assign(file, {
            preview: URL.createObjectURL(file),
          })
        )
      );
    },
  });

  return (
    <div className='text-center'>
      <div {...getRootProps()}>
        <input {...getInputProps()} />
        <>
          <Image
            src={uploadImg}
            alt='upload-img'
            className='img-fluid upload-img'
          />
          <p className='drag-drop-text mt-4'>Drag & Drop document here</p>
          <p className='drag-drop-text-bold'>OR</p>
          <button type='button' className='btn yk-btn-primary-sm browse-btn'>
            {sendFile?.length > 0 ? sendFile[0]?.name : 'Browse'}
          </button>
        </>
      </div>
      <p className='mt-3'>Support only .XLSX format</p>
      {showMsg && <p className='file-upload-msg'>{FILE_UPLOAD}</p>}
    </div>
  );
};
