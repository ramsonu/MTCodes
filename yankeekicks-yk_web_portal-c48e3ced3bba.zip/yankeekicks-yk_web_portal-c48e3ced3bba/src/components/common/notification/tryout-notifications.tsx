/* eslint-disable @next/next/no-img-element */
import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import { useDispatch, useSelector } from 'react-redux';
import { actions } from 'store/reducers/shoesize';
import {
  getTryoutNotification,
  postUpdateTryOutData,
} from 'services/notifications';
import Notification from 'components/common/notification';
import { doRequest } from 'utils/request';
import { GET_BARCODE_OF_PRODUCT } from 'services/apiUrl';
import { PRODUCT_INVENTORY_COUNT_ERROR_MSG } from 'components/shoesize/constants';
import {
  NOTIFICATION_SOMETHING_WENT_WRONG,
  TIME_INTERVAL_NOTIFICATIONS,
  TRY_OUT_ACCEPTED,
} from 'utils/constants';
import thumbnailIcon1 from 'assets/images/thumbnail/thumbnail-1.png';
import RejectIcon from 'assets/images/reject-icon.svg';
import tickMarkIcon from 'assets/images/green-tick-icon.svg';

type notificationType = {
  customerId?: string;
  inventoryItemId?: number;
  name?: string;
  requestStatusFlag?: boolean;
  size?: string;
  sku?: string;
  storeId?: number;
  tryoutItemId?: number;
  tryoutNumber?: number;
  userId?: number;
  imgData?: any;
  price?: any;
};
export default function TryOutNotification(props: any) {
  const dispatch = useDispatch();
  const audioPlayer: any = React.useRef(null);
  const { filteredCart } = useSelector((state: any) => state.shoesize);
  const [isLoaded, setIsLoaded] = useState<boolean>(true);
  const [notificationInfo, setNotificationInfo] = useState<notificationType[]>(
    []
  );
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [showTryOut, setShowTryOut] = useState<boolean>(false);
  const [severityType, setSeverityType] = useState<string>('');
  const [requestedBy, setRequestedBy] = useState(false);
  const [notificationMsg, setNotificationMsg] = useState<any>('');
  const [toastClassName, setToastClassName] = useState<string>('');

  const loadNotifications = async () => {
    if (isLoaded) {
      const storeId = localStorage.getItem('storeId');
      const tryoutNotificationList = await getTryoutNotification(storeId);
      if (tryoutNotificationList.status) {
        if (tryoutNotificationList?.data) {
          let disAgreedItems = localStorage.getItem('tryoutItemId')?.split(',');
          let notification = tryoutNotificationList.data.filter(
            (data: any, index: number) => {
              if (
                !disAgreedItems?.includes(data[0].tryoutItemId.toString()) &&
                !data.requestStatusFlag
              )
                return data[0];
            }
          );
          if (notification.length > 0) {
            playSound();
            setIsLoaded(false);
            setRequestedBy(notification[0][0]?.name);
            setNotificationInfo(notification[0]);
            setShowTryOut(true);
          }
        }
      }
    }
  };

  useEffect(() => {
    loadNotifications();
    setInterval(() => {
      loadNotifications();
    }, TIME_INTERVAL_NOTIFICATIONS);
  }, []);

  const playSound = () => {
    const resp = audioPlayer?.current?.play();
    if (resp !== undefined) {
      resp
        .then((_: any) => {
          // autoplay starts!
        })
        .catch((error: any) => {
          //show error
          console.log(error);
        });
    }
  };

  const handleAgree = async () => {
    notificationInfo.map((data: any, index: any) => {
      return (data.requestStatusFlag = true);
    });
    try {
      const acceptReq = await postUpdateTryOutData(notificationInfo);
      let isItemExists = false;
      if (acceptReq?.status) {
        for (const product of notificationInfo) {
          try {
            const getResponse = await doRequest(
              `${GET_BARCODE_OF_PRODUCT}/location/${Number(
                localStorage?.getItem('storeLocationId')
              )}/variant/${Number(product?.inventoryItemId)}`,
              'get',
              {}
            );
            if (!!getResponse?.data?.barcode) {
              let addItem = {
                inventoryLineItemId: product?.inventoryItemId,
                name: getResponse?.status ? getResponse?.data?.name : '',
                style: product?.sku,
                imageUrl: getResponse?.status
                  ? getResponse?.data?.images[0]?.src
                  : thumbnailIcon1,
                size: product?.size,
                price: product?.price,
                status: '1',
                requestedBy: product?.name,
                tryOutItem: true,
                barcode: getResponse?.data?.barcode,
              };
              dispatch(actions.addToCart(addItem));

              isItemExists = isItemExists
                ? isItemExists
                : filteredCart.find(
                    (item: any) =>
                      item.inventoryLineItemId === addItem.inventoryLineItemId
                  );
              setIsVisibleMessage(true);
              const requestAccepted: any = (
                <div className='acceptance-alert-wrapper'>
                  <h3 className='notification-heading yk-badge-h17'>
                    {TRY_OUT_ACCEPTED.title}
                  </h3>
                  <p className='notification-subtitle yk-badge-h16'>
                    {TRY_OUT_ACCEPTED.msg}
                  </p>
                </div>
              );
              setToastClassName('yk-shoe-size-alert');
              setSeverityType('success');
              setNotificationMsg(requestAccepted);
            } else {
              setNotificationMsg(PRODUCT_INVENTORY_COUNT_ERROR_MSG);
              setSeverityType('warning');
              setIsVisibleMessage(true);
            }
          } catch (barcodeError: any) {
            console.log('barcode api error', barcodeError);
            if (barcodeError?.response?.status === 400) {
              setToastClassName('yk-shoe-size-alert');
              setNotificationMsg(barcodeError?.response?.data?.message);
              setSeverityType('warning');
              setIsVisibleMessage(true);
            } else {
              setToastClassName('yk-shoe-size-alert');
              setNotificationMsg(NOTIFICATION_SOMETHING_WENT_WRONG);
              setSeverityType('error');
              setIsVisibleMessage(true);
            }
          }
        }
      } else {
        setToastClassName('yk-shoesize-alert-wrapper');
        setNotificationMsg(acceptReq?.errorInfo?.message || acceptReq?.error);
        setSeverityType('warning');
        setIsVisibleMessage(true);
      }
    } catch (error: any) {
      console.log('error in accept api', error);
      setToastClassName('yk-shoesize-alert-wrapper');
      setNotificationMsg(NOTIFICATION_SOMETHING_WENT_WRONG);
      setSeverityType('error');
      setIsVisibleMessage(true);
    }

    setShowTryOut(false);
    setIsLoaded(true);
  };

  const handleDisagree = () => {
    let localItes = `${localStorage.getItem('tryoutItemId')},${
      notificationInfo[0].tryoutItemId
    }`;
    localStorage.setItem('tryoutItemId', localItes);
    setIsLoaded(true);
    setShowTryOut(false);
  };

  const TryoutNotification = () => {
    return (
      <div className='tryout-notification'>
        <h5 className='notification-heading yk-badge-h17'>
          New request from Kiosk {requestedBy}!
        </h5>
        <div className='btn-action-wrapper'>
          <button
            type='button'
            onClick={handleDisagree}
            className='transparent-red-btn btn-reject'>
            <Image
              src={RejectIcon}
              className='tick-mark-icon img-fluid'
              alt='tick-icon'
            />
            Reject
          </button>
          <button
            type='button'
            onClick={handleAgree}
            className='btn-transparent btn-accept'>
            <span className='img-wrapper'>
              <Image
                src={tickMarkIcon}
                className='tick-mark-icon img-fluid'
                alt='tick-icon'
              />
            </span>
            Accept
          </button>
        </div>
      </div>
    );
  };

  return (
    <>
      <audio
        ref={audioPlayer}
        src='./notification_sound.mp3'
        autoPlay={false}></audio>
      <Notification
        showSuccessPopup={showTryOut}
        showAlways={true}
        severityType={'info'}
        message={<TryoutNotification />}
        className='yk-kiosk-confirmation-alert'
      />
      <Notification
        showSuccessPopup={isVisibleMessage}
        handleSnackbarClose={() => setIsVisibleMessage(false)}
        severityType={severityType}
        message={notificationMsg}
        className={toastClassName}
      />
    </>
  );
}
