import React, { useEffect } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/router';
import ykLogoBlack from 'assets/images/yk-std-logo-lg.svg';
import YKmenuLogo from 'assets/images/menu-icons/yk-menu-logo.svg';
import {
  styled,
  useTheme,
  Theme,
  CSSObject,
  alpha,
} from '@mui/material/styles';
import {
  Box,
  Drawer as MuiDrawer,
  Toolbar,
  List,
  CssBaseline,
  Divider,
  IconButton,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
} from '@mui/material';
import MuiAppBar, { AppBarProps as MuiAppBarProps } from '@mui/material/AppBar';
import MenuIcon from '@mui/icons-material/Menu';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
// import Tooltip from '@mui/joy/Tooltip';
import {
  shoesizeMenuItems,
  warehouseMenuItems,
  consignmentsMenuItems,
} from './constants';

import Button from '@mui/material/Button';
import MenuItem from '@mui/material/MenuItem';
import EditIcon from '@mui/icons-material/Edit';
import ArchiveIcon from '@mui/icons-material/Archive';
import FileCopyIcon from '@mui/icons-material/FileCopy';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import Menu, { MenuProps } from '@mui/material/Menu';
import LocationIcon from 'assets/images/portal-icon.svg';
import { useDispatch } from 'react-redux';
import { actions } from 'store/reducers/shoesize';
import { actions as kioskActions } from 'store/reducers/kiosk';
import { useSelector } from 'react-redux';
import LocationComp from 'components/common/location';
import useWindowDimensions from '../mobile-card-dimension';

const StyledMenu = styled((props: MenuProps) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: 'bottom',
      horizontal: 'right',
    }}
    transformOrigin={{
      vertical: 'top',
      horizontal: 'right',
    }}
    {...props}
  />
))(({ theme }) => ({
  '& .MuiPaper-root': {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 180,
    color:
      theme.palette.mode === 'light'
        ? 'rgb(55, 65, 81)'
        : theme.palette.grey[300],
    boxShadow:
      'rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px',
    '& .MuiMenu-list': {
      padding: '4px 0',
    },
    '& .MuiMenuItem-root': {
      '& .MuiSvgIcon-root': {
        fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      '&:active': {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));

const drawerWidth = 240;

const openedMixin = (theme: Theme): CSSObject => ({
  width: drawerWidth,
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: 'hidden',
});

const closedMixin = (theme: Theme): CSSObject => ({
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: 'hidden',
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up('sm')]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});

const DrawerHeader = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'flex-end',
  padding: theme.spacing(0, 1),
  // necessary for content to be below app bar
  ...theme.mixins.toolbar,
}));

interface AppBarProps extends MuiAppBarProps {
  open?: boolean;
}

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== 'open',
})<AppBarProps>(({ theme, open }) => ({
  zIndex: theme.zIndex.drawer + 1,
  transition: theme.transitions.create(['width', 'margin'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

const Drawer = styled(MuiDrawer, {
  shouldForwardProp: (prop) => prop !== 'open',
})(({ theme, open }) => ({
  width: drawerWidth,
  flexShrink: 0,
  whiteSpace: 'nowrap',
  boxSizing: 'border-box',
  ...(open && {
    ...openedMixin(theme),
    '& .MuiDrawer-paper': openedMixin(theme),
  }),
  ...(!open && {
    ...closedMixin(theme),
    '& .MuiDrawer-paper': closedMixin(theme),
  }),
}));

const LeftSideBar = () => {
  const theme = useTheme();
  const [open, setOpen] = React.useState(true);
  const router = useRouter();
  const dispatch = useDispatch();
  const { goBackTrigger } = useSelector((state: any) => state.shoesize);

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };
  const { width } = useWindowDimensions();
  useEffect(() => {
    if (width < 500) {
      setOpen(false);
    } else {
      setOpen(true);
    }
  }, [width]);
  const locationMenu = (item: any) => {
    return (
      <div className='locations-dropdown-wrapper'>
        <Button
          className='location-dropdown-btn btn'
          id='demo-customized-button'
          aria-controls={openBtn ? 'demo-customized-menu' : undefined}
          aria-haspopup='true'
          aria-expanded={openBtn ? 'true' : undefined}
          variant='contained'
          disableElevation
          onClick={handleClick}
          endIcon={<KeyboardArrowDownIcon />}
        >
          {/* <Image src={LocationIcon} className='img-fluid' alt={''}></Image> */}
          <span className='location-text-wrapper'>
            <span className='portal-text'>{item?.subText}</span>
            {/* <Tooltip title='{item.text}' variant='outlined'>
              <span className='location-name' title='{item.text}'>
                {item.text}
              </span>
            </Tooltip> */}
            <span className='location-name' title={item.text}>
              {item.text}
            </span>
          </span>
        </Button>
        <StyledMenu
          id='demo-customized-menu'
          MenuListProps={{
            'aria-labelledby': 'demo-customized-button',
          }}
          anchorEl={anchorEl}
          open={openBtn}
          onClose={handleClose}
        >
          <MenuItem onClick={handleClose} disableRipple>
            Location 1
          </MenuItem>
          <MenuItem onClick={handleClose} disableRipple>
            Location 2
          </MenuItem>
          {/* <Divider sx={{ my: 0.5 }} /> */}
          <MenuItem onClick={handleClose} disableRipple>
            Location 3
          </MenuItem>
          <MenuItem onClick={handleClose} disableRipple>
            Location 4
          </MenuItem>
        </StyledMenu>
      </div>
    );
  };

  const routeHandler = (value: any) => {
    /* TODO Need to remove if condition in the future when route will handle properly 
     for back button on search results */
    if (
      router.pathname === '/shoesize' ||
      router.pathname === '/shoesize/inventory'
    ) {
      dispatch(actions.setBackButtonTrigger(!goBackTrigger));
      dispatch(kioskActions.clearAllFilters({}));
      dispatch(kioskActions.clearAllFiltersForCube({}));
    }
    router.push(value);
  };

  const renderMenuItems = () => {
    const shoesize = /^\/shoesize.*$/.test(router.pathname);
    const warehouse = /^\/warehouse.*$/.test(router.pathname);
    const consignment = /^\/consignment.*$/.test(router.pathname);

    const menuItems: any = shoesize
      ? shoesizeMenuItems
      : warehouse
      ? warehouseMenuItems
      : consignment
      ? consignmentsMenuItems
      : [];

    return (
      <List>
        {menuItems?.map((item: any) => (
          <ListItem
            key={item?.text}
            disablePadding
            sx={{ display: 'block' }}
            className={`${
              (router?.pathname === item?.path ||
                item?.subPaths?.includes(router?.pathname)) &&
              !item.isLocation
                ? 'item-active'
                : ''
            } ${item.notVisible ? 'not-visible' : ''}`}
          >
            <ListItemButton
              sx={{
                minHeight: 48,
                justifyContent: open ? 'initial' : 'center',
                px: 2.5,
              }}
              onClick={() => routeHandler(item.path)}
              className={`${
                (router?.pathname === item?.path ||
                  item?.subPaths?.includes(router?.pathname)) &&
                !item.isLocation
                  ? 'item-active'
                  : ''
              }`}
            >
              <ListItemIcon
                sx={{
                  minWidth: 0,
                  mr: open ? 3 : 'auto',
                  justifyContent: 'center',
                }}
              >
                <Image src={item.imgIcon} alt='icon' className='img-fluid' />
              </ListItemIcon>
              {!item.isLocation && (
                <ListItemText
                  primary={item.text}
                  sx={{ opacity: open ? 1 : 0 }}
                />
              )}
              {/* {item.isLocation && locationMenu(item)} */}
              {item.isLocation && <LocationComp item={item} innerPage />}
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    );
  };

  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const openBtn = Boolean(anchorEl);
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <Box sx={{ display: 'flex' }}>
        <CssBaseline />
        <AppBar
          position='fixed'
          open={open}
          className={open ? 'yk-header-open' : 'yk-header-close'}
        >
          <Toolbar>
            <IconButton
              color='inherit'
              aria-label='open drawer'
              onClick={handleDrawerOpen}
              edge='start'
              sx={{
                marginRight: 5,
                ...(open && { display: 'none' }),
              }}
            >
              <MenuIcon />
            </IconButton>
          </Toolbar>
        </AppBar>
        <Drawer
          variant='permanent'
          className={open ? 'yk-menu-open' : 'yk-menu-close'}
          open={open}
        >
          <DrawerHeader>
            <Image src={ykLogoBlack} alt='icon' className='img-fluid yk-logo' />
            {!open && (
              <Image
                src={YKmenuLogo}
                alt='icon'
                className='img-fluid yk-menu-icon'
              />
            )}
            <IconButton onClick={handleDrawerClose}>
              {theme.direction === 'rtl' ? (
                <ChevronRightIcon />
              ) : (
                <ChevronLeftIcon />
              )}
            </IconButton>
          </DrawerHeader>
          <Divider />

          {renderMenuItems()}
        </Drawer>
      </Box>
    </div>
  );
};

export default LeftSideBar;
