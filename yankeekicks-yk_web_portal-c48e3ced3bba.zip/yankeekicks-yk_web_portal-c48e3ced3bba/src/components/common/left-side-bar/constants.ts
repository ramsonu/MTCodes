import DashboardIcon from 'assets/images/menu-icons/dashboard-default.svg';
import SettingsIcon from 'assets/images/menu-icons/orders-default.svg';
import InventoryD from 'assets/images/menu-icons/inventory-default.svg';
import LocationIcon from 'assets/images/location-icon.svg';

export const shoesizeMenuItems = [
  {
    text: 'Sales Associates',
    path: '/shoesize',
    imgIcon: LocationIcon,
    subText: 'Portal',
    isLocation: true,
  },
  {
    text: 'Dashboard',
    path: '/shoesize',
    imgIcon: DashboardIcon,
  },
  {
    text: 'Inventory',
    path: '/shoesize/inventory',
    imgIcon: InventoryD,
  },
];

export const warehouseMenuItems = [
  {
    text: 'Warehouse',
    path: '/warehouse',
    imgIcon: LocationIcon,
    subText: 'Portal',
    isLocation: true,
  },
  {
    text: 'Dashboard',
    path: '/warehouse',
    imgIcon: DashboardIcon,
    subPaths: ['/warehouse/request-details'],
  },
  {
    text: 'Bin/Shelf',
    path: '/warehouse/update-shelf-bin',
    imgIcon: DashboardIcon,
  },
];

export const consignmentsMenuItems = [
  {
    notVisible: true, //first item needs to hide
  },
  {
    text: 'Dashboard',
    path: '/consignment',
    imgIcon: DashboardIcon,
  },
  {
    text: 'My Inventory',
    path: '/consignment/inventory',
    imgIcon: InventoryD,
    subPaths: [
      '/consignment/inventory/skudetails',
      '/consignment/inventory/bulkimport',
      '/consignment/inventory/AddShoesCatalog',
    ],
  },
  {
    text: 'Orders',
    path: '/consignment/orders',
    imgIcon: InventoryD,
    subPaths: [
      '/consignment/orders/order-details',
      '/consignment/orders/payout-history',
    ],
  },
  {
    text: 'Consignments',
    path: '/consignment/consignments',
    imgIcon: InventoryD,
    subPaths: [
      '/consignment/consignments/consignment-details',
      '/consignment/consignments/sku-details',
    ],
  },
  {
    text: 'settings',
    path: '/consignment/settings',
    imgIcon: SettingsIcon,
  },
];
