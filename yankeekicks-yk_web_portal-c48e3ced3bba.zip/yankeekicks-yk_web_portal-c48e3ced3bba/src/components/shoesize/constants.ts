export const STATUS: any = {
  1: 'request',
  2: 'pending',
  3: 'checkedout',
};

export const ACTIVE_STATUS: any = {
  REQUEST: 'request',
  PENDING: 'pending',
  CHECKEDOUT: 'checkedout',
};

export const STATUS_TYPE: any = {
  PENDING: 'Pending',
  CHECKED_IN: 'Checked In',
  CHECKED_OUT: 'Checked Out',
  SOLD_OUT: 'Sold',
};

export const SIZE_TYPES: any = ['Him', 'Her', 'Infant', 'Preschool', 'Toddler'];

export const PLACE_REQUEST_LABEL = 'Place request to warehouse ?';
export const PLACE_REQUEST_DESC = 'pair of shoes will be requested';
export const PLACE_REQUEST_BTN_LABEL = 'PLACE REQUEST';
export const PLACE_REQUEST_SUCCESS_TEXT = 'Request Placed Successfully';
export const PLACE_REQUEST_SKU_NOT_PRESENT =
  "Can't place the request. SKU is not present for this product!";
export const PLACE_REQUEST_ERROR_MSG = 'Something went wrong.';
export const RETAIL_SELL_SUCCESS_MSG = 'Product Updated Successfully.';
export const PRODUCT_INVENTORY_COUNT_ERROR_MSG =
  'All available items are in Warehouse queue. Cannot process the request!';

export const USE_KIOSK_API = true;

export const INVENTORY_ITEM_NOT_AVAILABLE = 'Sorry this item is unavailable.';
export const NO_PRODUCTS_ITEMS_IN_PENDING_TAB = 'No pending requests.';
export const NO_PRODUCTS_ITEMS_IN_CHECKEDOUT_TAB = 'No shoes checked out.';
