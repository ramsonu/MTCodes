import React, { useState } from 'react';
import Image from 'next/image';
import { format } from 'date-fns';
import Modal from '@mui/material/Modal';
import {
  getTime,
  getTrimmedText,
  capitalizeFirstLetter,
  convertPriceToUSFormat,
} from 'utils/util';
import ImageLoader from 'components/common/image-loader';
import { FNS_US_DATE_FORMAT } from 'utils/constants';
import CopyToClipboardComponent from 'components/common/copyToClipboard';
import greyCloseIcon from 'assets/images/grey-close-icon.svg';
import productImg from 'assets/images/big-product-img.svg';
import binIcon from 'assets/images/bin-icon.svg';
import rackIcon from 'assets/images/rack-icon.svg';
import compartmentIcon from 'assets/images/compartment-icon.svg';
import consignorImg from 'assets/images/consignor-img.svg';

const UpdatedProductDetailsModal = (props: any) => {
  const { showModal, setShowModal, variantDataForInventory } = props;

  const [showLess, setShowLess] = useState(true);

  return (
    <>
      <Modal
        open={showModal}
        onClose={() => setShowModal(false)}
        className='yk-product-details-modal-wrapper'
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'>
        <div className='app-wrapper product-details-modal-wrapper container'>
          <div className='yk-modal-body row'>
            <div className='heading-wrapper modal-heading-wrapper'>
              <p className='modal-title yk-badge-h11'>Product Details</p>
              <button
                className='btn btn-transparent left-arrow-btn'
                onClick={() => setShowModal(false)}>
                <Image
                  src={greyCloseIcon}
                  alt='grey-close-icon'
                  className='Image-fluid'
                />
              </button>
            </div>
            <div className='product-details-wrapper modal-details-body-wrapper'>
              <div className='container'>
                <div className='row'>
                  <div className='col-lg-6 col-md-12 col-sm-12 col-12'>
                    <div className='product-img-wrapper'>
                      <ImageLoader
                        src={
                          variantDataForInventory?.['KioskInventory.imageUrl']
                        }
                        fallbackImg={productImg}
                        alt='cart-img'
                        className='img-fluid'
                        imgWidth={500}
                        imgHeight={100}
                      />
                    </div>
                    <div className='product-content-wrapper'>
                      <h3 className='yk-product-title yk-badge-h11'>
                        {variantDataForInventory?.['KioskInventory.title'] ||
                          '--'}
                      </h3>
                      <div className='product-details-wrapper'>
                        <div className='row'>
                          <div className='col-lg-12 col-md-12 col-sm-12 col-12'>
                            <div className='product-details yk-badge-h16'>
                              <div className='row'>
                                <div className='col-lg-6 col-md-6 col-sm-6'>
                                  <span className='brand-text yk-badge-h16'>
                                    Brand:
                                  </span>
                                </div>
                                <div className='col-lg-6 col-md-6 col-sm-6'>
                                  <span className='brand-value yk-badge-h16'>
                                    {variantDataForInventory?.[
                                      'KioskInventory.brand'
                                    ]
                                      ? capitalizeFirstLetter(
                                          variantDataForInventory?.[
                                            'KioskInventory.brand'
                                          ]
                                        )
                                      : '--'}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className='product-details yk-badge-h16'>
                              <div className='row'>
                                <div className='col-lg-6 col-md-6 col-sm-6'>
                                  <span className='brand-text yk-badge-h16'>
                                    Size:
                                  </span>
                                </div>
                                <div className='col-lg-6 col-md-6 col-sm-6'>
                                  <span className='brand-value yk-badge-h16'>
                                    {variantDataForInventory?.[
                                      'KioskInventory.option1'
                                    ] || '--'}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className='product-details yk-badge-h16'>
                              <div className='row'>
                                <div className='col-lg-6 col-md-6 col-sm-6'>
                                  <span className='brand-text yk-badge-h16'>
                                    SKU:
                                  </span>
                                </div>
                                <div className='col-lg-6 col-md-6 col-sm-6'>
                                  <span
                                    className='brand-value yk-badge-h16'
                                    id='inventory-sku'>
                                    {variantDataForInventory?.[
                                      'KioskInventory.sku'
                                    ] || '--'}
                                  </span>
                                  {variantDataForInventory?.[
                                    'KioskInventory.sku'
                                  ] && (
                                    <CopyToClipboardComponent
                                      copyText={
                                        variantDataForInventory?.[
                                          'KioskInventory.sku'
                                        ]
                                      }
                                    />
                                  )}
                                </div>
                              </div>
                            </div>
                            <div className='product-details yk-badge-h16'>
                              <div className='row'>
                                <div className='col-lg-6 col-md-6 col-sm-6'>
                                  <span className='brand-text yk-badge-h16'>
                                    Date:
                                  </span>
                                </div>
                                <div className='col-lg-6 col-md-6 col-sm-6'>
                                  <span className='brand-value yk-badge-h16'>
                                    {variantDataForInventory?.[
                                      'KioskInventory.shopifycreatedAt'
                                    ]
                                      ? format(
                                          new Date(
                                            variantDataForInventory?.[
                                              'KioskInventory.shopifycreatedAt'
                                            ]
                                          ),
                                          FNS_US_DATE_FORMAT
                                        )
                                      : '--'}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className='product-details yk-badge-h16'>
                              <div className='row'>
                                <div className='col-lg-6 col-md-6 col-sm-6'>
                                  <span className='brand-text yk-badge-h16'>
                                    Time:
                                  </span>
                                </div>
                                <div className='col-lg-6 col-md-6 col-sm-6'>
                                  <span className='brand-value yk-badge-h16'>
                                    {variantDataForInventory?.[
                                      'KioskInventory.shopifycreatedAt'
                                    ]
                                      ? getTime(
                                          variantDataForInventory?.[
                                            'KioskInventory.shopifycreatedAt'
                                          ]
                                        )
                                      : '--'}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className='col-lg-6 col-md-12 col-sm-12'>
                    <div className='product-location-section-wrapper'>
                      <h3 className='location-subtitle yk-badge-h14'>
                        Location:
                      </h3>
                      <div className='product-location-details-wrapper'>
                        <div className='product-location-details-info'>
                          <div className='card-img-wrapper'>
                            <Image
                              src={binIcon}
                              alt='bin-icon'
                              className='img-fluid'
                            />
                          </div>
                          <div className='product-count-info-wrapper'>
                            <span className='location-type-title yk-badge-h16'>
                              Bin:
                            </span>
                            <span className='product-count-info yk-badge-h16'>
                              {variantDataForInventory?.[
                                'KioskInventory.bin'
                              ] || '--'}
                            </span>
                          </div>
                        </div>
                        <div className='product-location-details-info'>
                          <div className='card-img-wrapper'>
                            <Image
                              src={rackIcon}
                              alt='bin-icon'
                              className='img-fluid'
                            />
                          </div>
                          <div className='product-count-info-wrapper'>
                            <span className='location-type-title yk-badge-h16'>
                              Shelf:
                            </span>
                            <span className='product-count-info yk-badge-h16'>
                              {variantDataForInventory?.[
                                'KioskInventory.shelf'
                              ] || '--'}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className='product-content-wrapper'>
                        <div className='product-details-wrapper'>
                          <div className='row'>
                            <div className='col-lg-12 col-md-12 col-sm-12'>
                              <div className='product-details yk-badge-h16 consignorDetailsWrapper'>
                                <div className='row'>
                                  <div className='col-lg-12 col-md-12 col-sm-12 col-12'>
                                    <span className='location-subtitle yk-badge-h14 mb-0'>
                                      Consignor:
                                    </span>
                                  </div>
                                  <div className='consignorInfoWrapper'>
                                    <Image
                                      src={consignorImg}
                                      alt='consignor-img'
                                      className='img-fluid consignorImg'
                                    />
                                    <span className='brand-text yk-badge-h16'>
                                      {variantDataForInventory?.[
                                        'KioskInventory.consignorName'
                                      ] || '--'}
                                    </span>
                                  </div>
                                </div>
                              </div>
                              <div className='product-details yk-badge-h16'>
                                <div className='row'>
                                  <div className='col-lg-6 col-md-6 col-sm-6'>
                                    <span className='brand-text yk-badge-h16'>
                                      Style:
                                    </span>
                                  </div>
                                  <div className='col-lg-6 col-md-6 col-sm-6'>
                                    <span className='brand-value yk-badge-h16'>
                                      {variantDataForInventory?.[
                                        'KioskInventory.sku'
                                      ] || '--'}
                                    </span>
                                  </div>
                                </div>
                              </div>
                              <div className='product-details yk-badge-h16'>
                                <div className='row'>
                                  <div className='col-lg-6 col-md-6 col-sm-6'>
                                    <span className='brand-text yk-badge-h16'>
                                      Colorway:
                                    </span>
                                  </div>
                                  <div className='col-lg-6 col-md-6 col-sm-6'>
                                    <span className='brand-value yk-badge-h16'>
                                      {variantDataForInventory?.[
                                        'KioskInventory.colorway'
                                      ] || '--'}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className='col-lg-12 col-md-12 col-sm-12'>
                              <div className='product-details yk-badge-h16'>
                                <div className='row'>
                                  <div className='col-lg-6 col-md-6 col-sm-6'>
                                    <span className='brand-text yk-badge-h16'>
                                      Price:
                                    </span>
                                  </div>
                                  <div className='col-lg-6 col-md-6 col-sm-6'>
                                    <span className='brand-value yk-badge-h16'>
                                      {variantDataForInventory?.[
                                        'KioskInventory.shopifyPrice'
                                      ]
                                        ? convertPriceToUSFormat(
                                            Number(
                                              variantDataForInventory?.[
                                                'KioskInventory.shopifyPrice'
                                              ]
                                            )?.toFixed(2)
                                          )
                                        : '--'}
                                    </span>
                                  </div>
                                </div>
                              </div>
                              <div className='product-details yk-badge-h16'>
                                <div className='row'>
                                  <div className='col-lg-6 col-md-6 col-sm-6'>
                                    <span className='brand-text yk-badge-h16'>
                                      Release Date:
                                    </span>
                                  </div>
                                  <div className='col-lg-6 col-md-6 col-sm-6'>
                                    <span className='brand-value yk-badge-h16'>
                                      {variantDataForInventory?.[
                                        'KioskInventory.releaseDate'
                                      ]
                                        ? format(
                                            new Date(
                                              variantDataForInventory?.[
                                                'KioskInventory.releaseDate'
                                              ]
                                            ),
                                            FNS_US_DATE_FORMAT
                                          )
                                        : '--'}
                                    </span>
                                  </div>
                                </div>
                              </div>
                              <div className='product-details product-description-wrapper yk-badge-h16'>
                                <h6 className='brand-text colorway-title yk-badge-h16'>
                                  Product Description:
                                </h6>
                                <div className='brand-description-wrapper'>
                                  <div className='brand-description yk-badge-h16'>
                                    {variantDataForInventory?.[
                                      'KioskInventory.productDescription'
                                    ]
                                      ? variantDataForInventory?.[
                                          'KioskInventory.productDescription'
                                        ]?.length > 200
                                        ? showLess
                                          ? getTrimmedText(
                                              variantDataForInventory?.[
                                                'KioskInventory.productDescription'
                                              ],
                                              200
                                            )
                                          : variantDataForInventory?.[
                                              'KioskInventory.productDescription'
                                            ]
                                        : variantDataForInventory?.[
                                            'KioskInventory.productDescription'
                                          ]
                                      : '--'}

                                    {variantDataForInventory?.[
                                      'KioskInventory.productDescription'
                                    ] &&
                                      variantDataForInventory?.[
                                        'KioskInventory.productDescription'
                                      ]?.length > 200 && (
                                        <button
                                          className='btn btn-transparent view-more-btn'
                                          onClick={() =>
                                            setShowLess(!showLess)
                                          }>
                                          {showLess ? 'View More' : 'View Less'}
                                        </button>
                                      )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default UpdatedProductDetailsModal;
