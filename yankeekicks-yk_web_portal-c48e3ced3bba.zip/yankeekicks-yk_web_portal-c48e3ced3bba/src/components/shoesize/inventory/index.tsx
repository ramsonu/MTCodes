import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import { useDispatch, useSelector } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import SearchComp from 'components/common/search';
import SearchResults from '../search-result';
import {
  getKioskInventoryWithSizes,
  getKioskInventoryWithSizesTotalCount,
  getSuggestionsFromCube,
} from 'middleware/cubejs-wrapper/cubejs-query';
import { LogoutUser } from 'components/common/logout';

const InventoryPage = () => {
  const { filterTypes, filterTypesForCube } = useSelector(
    (state: any) => state.kiosk
  );
  const { goBackTrigger } = useSelector((state: any) => state.shoesize);
  const { selected } = useSelector((state: any) => state.shared);
  const dispatch = useDispatch();
  const router = useRouter();
  const [userInput, setUserInput] = useState('');
  const [selectedSort, setSelectedSort] = useState('newest');

  const [inventoryProductsDataFromCube, setInventoryProductsDataFromCube] =
    useState<any>([]);
  const [locId, setLocId] = useState<any>('');
  const [typeAhead, setTypeAhead] = useState([]);
  const [showAutoComplete, setShowAutoComplete] = useState(false);
  const [currentOffset, setCurrentOffset] = useState(0);
  const [totalInventoryProductsCount, setTotalInventoryProductsCount] =
    useState(0);
  const [shouldFetchInventoryResults, setShouldFetchInventoryResults] =
    useState(false);
  const [shouldFetchSuggestions, setShouldFetchSuggestions] = useState(false);

  useEffect(() => {
    onLoadInventory();
  }, [goBackTrigger]);

  useEffect(() => {
    if (localStorage?.getItem('storeLocationId')) {
      setLocId(localStorage?.getItem('storeLocationId'));
      setShouldFetchInventoryResults(true);
    } else {
      setLocId('');
      setShouldFetchInventoryResults(false);
    }
  }, [selected]);

  const limitForCubeQuery: number = 18;

  const kioskInventoryWithSizesQuery: any = getKioskInventoryWithSizes(
    filterTypesForCube,
    locId,
    selectedSort,
    limitForCubeQuery,
    currentOffset
  );
  const kioskInventoryWithSizesCountQuery: any =
    getKioskInventoryWithSizesTotalCount(
      filterTypesForCube,
      locId,
      currentOffset
    );
  const kioskInventorySuggestionQuery: any = getSuggestionsFromCube(
    filterTypesForCube?.title,
    locId
  );

  const {
    resultSet: inventoryProductsResultSet,
    isLoading: inventoryProductsLoading,
    error: inventoryProductsError,
  }: any = useCubeQuery(kioskInventoryWithSizesQuery, {
    skip: !shouldFetchInventoryResults,
  });

  const {
    resultSet: inventoryProductsCountResultSet,
    error: inventoryProductsCountError,
  }: any = useCubeQuery(kioskInventoryWithSizesCountQuery, {
    skip: !shouldFetchInventoryResults,
  });

  const {
    resultSet: inventorySuggestionsResultSet,
    isLoading: inventorySuggestionsLoading,
    error: inventorySuggestionsError,
  }: any = useCubeQuery(kioskInventorySuggestionQuery, {
    skip: !shouldFetchSuggestions,
  });

  const isArrayEquals = (a: any, b: any) => {
    return (
      Array.isArray(a) &&
      Array.isArray(b) &&
      a.length === b.length &&
      a.every(
        (val, index) =>
          val?.['KioskInventory.variantId'] ===
          b[index]?.['KioskInventory.variantId']
      )
    );
  };

  useEffect(() => {
    if (
      inventoryProductsError?.status === 401 ||
      inventoryProductsError?.status === 403
    ) {
      LogoutUser();
      router.push('/', undefined, { shallow: true });
    } else {
      const data = inventoryProductsResultSet?.loadResponses[0]?.data;
      if (data) {
        if (!isArrayEquals(inventoryProductsDataFromCube, data)) {
          const combineData: any = [...inventoryProductsDataFromCube, ...data];
          setInventoryProductsDataFromCube(combineData);
          setShouldFetchInventoryResults(false);
        }
      } else {
        if (currentOffset === 0) {
          setInventoryProductsDataFromCube([]);
        }
      }
    }
  }, [inventoryProductsResultSet, inventoryProductsError]);

  useEffect(() => {
    if (
      inventoryProductsCountError?.status === 401 ||
      inventoryProductsCountError?.status === 403
    ) {
      LogoutUser();
      router.push('/', undefined, { shallow: true });
    } else {
      const data: any =
        inventoryProductsCountResultSet?.loadResponses[0]?.data[0];
      if (data) {
        const count = parseInt(data['KioskInventory.pcount']);
        setTotalInventoryProductsCount(count);
        setShouldFetchInventoryResults(false);
      } else {
        setTotalInventoryProductsCount(0);
      }
    }
  }, [inventoryProductsCountResultSet, inventoryProductsCountError]);

  useEffect(() => {
    const data: any = inventorySuggestionsResultSet?.loadResponses[0]?.data;
    if (data) {
      setTypeAhead(data);
      setShouldFetchSuggestions(false);
    } else {
      setTypeAhead([]);
    }
  }, [inventorySuggestionsResultSet]);

  const onLoadInventory = () => {
    if (!inventoryProductsLoading) {
      const clearFilters = {
        type: [],
        color: [],
        size: [],
        brand: [],
        date: [],
        availability: [],
        title: '',
      };
      if (clearFilters !== filterTypes) {
        dispatch(actions.clearAllFilters({}));
        dispatch(actions.clearAllFiltersForCube({}));
        setInventoryProductsDataFromCube([]);
      }
      setUserInput('');
    }
    setShouldFetchInventoryResults(true);
  };

  const getAutoCompleteSuggestions = (value: any) => {
    dispatch(
      actions.setFilters({
        filterItem: value,
        filterType: 'title',
      })
    );
    dispatch(
      actions.setFiltersForCube({
        filterItem: value,
        filterType: 'title',
      })
    );
    // setUserInput(value);
    setShowAutoComplete(true);
    if (value) {
      setShouldFetchSuggestions(true);
    }
    setShouldFetchInventoryResults(false);
  };

  const onChangeHandler = (userValue: any) => {
    getAutoCompleteSuggestions(userValue);

    if (userValue === '') {
      dispatch(actions.clearAllFilters({}));
      dispatch(actions.clearAllFiltersForCube({}));
      setUserInput(userValue);
      setInventoryProductsDataFromCube([]);
      setCurrentOffset(0);
      setTotalInventoryProductsCount(0);
      setShouldFetchInventoryResults(true);
      setShowAutoComplete(false);
    }
  };

  const onSelectHandler = (selectedItem: any = '', isEnterKey: any = false) => {
    const titleValue: any = isEnterKey ? filterTypes?.title : selectedItem;
    dispatch(
      actions.setFilters({
        filterItem: titleValue,
        filterType: 'title',
      })
    );
    dispatch(
      actions.setFiltersForCube({
        filterItem: titleValue,
        filterType: 'title',
      })
    );
    dispatch(actions.clearFiltersExceptTitle({}));
    dispatch(actions.clearFiltersExceptTitleForCube({}));

    setUserInput(titleValue);
    setShowAutoComplete(false);
    setInventoryProductsDataFromCube([]);
    setCurrentOffset(0);
    setTotalInventoryProductsCount(0);
    setShouldFetchInventoryResults(true);
  };

  return (
    <>
      <div className='landing-page-wrapper inventory-page-wrapper'>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-lg-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12'>
              <div className='search-bar-wrapper yk-search-bar'>
                <SearchComp
                  userInput={userInput}
                  placeholder='Search for brand, color etc.'
                  options={typeAhead}
                  isApiCall={true}
                  onChangeHandler={onChangeHandler}
                  onSelectHandler={onSelectHandler}
                  showAutoComplete={showAutoComplete}
                  setShowAutoComplete={setShowAutoComplete}
                  suggestionsHasError={inventorySuggestionsError}
                  suggestionsLoading={inventorySuggestionsLoading}
                />
              </div>

              <SearchResults
                userInput={userInput}
                selectedSort={selectedSort}
                setSelectedSort={setSelectedSort}
                limitForCubeQuery={limitForCubeQuery}
                productsDataFromCube={inventoryProductsDataFromCube}
                inventoryProductsLoading={inventoryProductsLoading}
                setProductsDataFromCube={setInventoryProductsDataFromCube}
                currentOffset={currentOffset}
                setCurrentOffset={setCurrentOffset}
                totalProductsCount={totalInventoryProductsCount}
                setTotalProductsCount={setTotalInventoryProductsCount}
                setShouldFetchResults={setShouldFetchInventoryResults}
                locId={locId}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default InventoryPage;
