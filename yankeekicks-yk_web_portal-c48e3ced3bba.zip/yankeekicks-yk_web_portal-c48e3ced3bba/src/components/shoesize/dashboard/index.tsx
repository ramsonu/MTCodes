import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import type { NextPage } from 'next';
import { useCubeQuery } from '@cubejs-client/react';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { actions } from 'store/reducers/shoesize';
import { actions as kioskActions } from 'store/reducers/kiosk';
import { BRANDS_REQUEST } from 'actions/kiosk';
import CommonTabs from 'components/common/tabs';
import SearchResults from '../search-result';
import ProductStatus from '../product-status';
import KpiStatus from '../kpi-status';
import ImageLoader from 'components/common/image-loader';
import { USE_KIOSK_API } from '../constants';
import { LogoutUser } from 'components/common/logout';
import CircleLoader from 'components/common/loader/circular-loader';
import {
  getKioskInventory,
  getKioskInventoryTotalCount,
  getSuggestionsFromCube,
} from 'middleware/cubejs-wrapper/cubejs-query';
import brandImg1 from 'assets/images/big-product-img.svg';
import SearchComp from 'components/common/search';

const Dashboard: NextPage = (props: any) => {
  const [brandsData, setBrandsData] = useState([]);
  const [showResultsPage, setShowResultsPage] = useState(false);
  const [userInput, setUserInput] = useState('');
  const [selectedBrandName, setSelectedBrandName] = useState<any>('');
  const [selectedSort, setSelectedSort] = useState('newest');

  const [productsDataFromCube, setProductsDataFromCube] = useState<any>([]);
  const [locId, setLocId] = useState<any>('');
  const [currentOffset, setCurrentOffset] = useState(0);
  const [totalProductsCount, setTotalProductsCount] = useState(0);
  const [typeAhead, setTypeAhead] = useState([]);
  const [showAutoComplete, setShowAutoComplete] = useState(false);
  const [shouldFetchResults, setShouldFetchResults] = useState(false);
  const [shouldFetchSuggestions, setShouldFetchSuggestions] = useState(false);

  const dispatch = useDispatch();
  const router = useRouter();
  const { goBackTrigger } = useSelector((state: any) => state.shoesize);
  const { selected } = useSelector((state: any) => state.shared);
  const { brandProducts, filterTypes, filterTypesForCube, isBrandsLoading } =
    useSelector((state: any) => state.kiosk);

  //**Add below useEffect for sync data from kiosk */
  useEffect(() => {
    if (USE_KIOSK_API && selected?.id) {
      dispatch({ type: BRANDS_REQUEST });
    }
    if (localStorage?.getItem('storeLocationId')) {
      setLocId(localStorage?.getItem('storeLocationId'));
    } else {
      setLocId('');
    }
  }, [dispatch, selected]);

  useEffect(() => {
    setBrandsData(brandProducts);
  }, [brandProducts]);

  const limitForCubeQuery: number = 12;

  const kioskInventoryQuery: any = getKioskInventory(
    filterTypesForCube,
    locId,
    selectedSort,
    limitForCubeQuery,
    currentOffset
  );
  const kioskInventoryCountQuery: any = getKioskInventoryTotalCount(
    filterTypesForCube,
    locId,
    currentOffset
  );
  const kioskInventorySuggestionQuery: any = getSuggestionsFromCube(
    filterTypesForCube?.title,
    locId
  );

  const {
    resultSet: inventoryProductsResultSet,
    isLoading: inventoryProductsLoading,
    error: inventoryProductsError,
  }: any = useCubeQuery(kioskInventoryQuery, { skip: !shouldFetchResults });

  const { resultSet: inventoryProductsCountResultSet }: any = useCubeQuery(
    kioskInventoryCountQuery,
    {
      skip: !shouldFetchResults,
    }
  );

  const {
    resultSet: inventorySuggestionsResultSet,
    isLoading: inventorySuggestionsLoading,
    error: inventorySuggestionsError,
  }: any = useCubeQuery(kioskInventorySuggestionQuery, {
    skip: !shouldFetchSuggestions,
  });

  const isArrayEquals = (a: any, b: any) => {
    return (
      Array.isArray(a) &&
      Array.isArray(b) &&
      a.length === b.length &&
      a.every(
        (val, index) =>
          val?.['KioskInventory.productId'] ===
          b[index]?.['KioskInventory.productId']
      )
    );
  };

  useEffect(() => {
    if (
      inventoryProductsError?.status === 401 ||
      inventoryProductsError?.status === 403
    ) {
      LogoutUser();
      router.push('/', undefined, { shallow: true });
    } else {
      const data = inventoryProductsResultSet?.loadResponses[0]?.data;
      if (data) {
        if (!isArrayEquals(productsDataFromCube, data)) {
          const combineData: any = [...productsDataFromCube, ...data];
          setProductsDataFromCube(combineData);
          setShouldFetchResults(false);
        }
      } else {
        if (currentOffset === 0) {
          setProductsDataFromCube([]);
        }
      }
    }
  }, [inventoryProductsResultSet, inventoryProductsError]);

  useEffect(() => {
    const data: any =
      inventoryProductsCountResultSet?.loadResponses[0]?.data[0];
    if (data) {
      const count = Number(data['KioskInventory.rowCount']);
      setTotalProductsCount(count);
      setShouldFetchResults(false);
    } else {
      setTotalProductsCount(0);
    }
  }, [inventoryProductsCountResultSet]);

  useEffect(() => {
    const data: any = inventorySuggestionsResultSet?.loadResponses[0]?.data;
    if (data) {
      setTypeAhead(data);
      setShouldFetchSuggestions(false);
    } else {
      setTypeAhead([]);
    }
  }, [inventorySuggestionsResultSet]);

  useEffect(() => {
    if (showResultsPage) {
      dispatch(actions.setBackButtonVisibility(true));
      setShouldFetchResults(true);
    } else {
      dispatch(actions.setBackButtonVisibility(false));
      dispatch(actions.setBackButtonTrigger(false));
      setShouldFetchResults(false);
    }
  }, [showResultsPage]); // eslint-disable-line react-hooks/exhaustive-deps

  /* TODO Need to remove useEffect in the future when route will handle properly 
     for back button on search results */
  useEffect(() => {
    setShowResultsPage(false);
    setUserInput('');
    setSelectedBrandName('');
    setProductsDataFromCube([]);
  }, [goBackTrigger]);

  const browseProductHandler = (value: any) => {
    setUserInput(value);
    setSelectedBrandName(value);
    setShowResultsPage(true);
    dispatch(kioskActions.clearAllFilters({}));
    dispatch(kioskActions.clearAllFiltersForCube({}));
    getProducts(value);
  };

  const getProducts = (brandName: string) => {
    dispatch(
      kioskActions.setFilters({ filterItem: brandName, filterType: 'title' })
    );
    dispatch(
      kioskActions.setFiltersForCube({
        filterItem: brandName,
        filterType: 'title',
      })
    );
    setProductsDataFromCube([]);
    setTotalProductsCount(0);
    setCurrentOffset(0);
  };

  const getAutoCompleteSuggestions = (value: any) => {
    dispatch(
      kioskActions.setFilters({
        filterItem: value,
        filterType: 'title',
      })
    );
    dispatch(
      kioskActions.setFiltersForCube({
        filterItem: value,
        filterType: 'title',
      })
    );
    // setUserInput(value);
    setShowAutoComplete(true);
    if (value) {
      setShouldFetchSuggestions(true);
    }
    setShouldFetchResults(false);
  };

  const onSearchChange = (userValue: any) => {
    getAutoCompleteSuggestions(userValue);

    if (userValue === '') {
      dispatch(kioskActions.clearAllFilters({}));
      dispatch(kioskActions.clearAllFiltersForCube({}));
      setProductsDataFromCube([]);
      setUserInput(userValue);
      setCurrentOffset(0);
      setTotalProductsCount(0);
      setShouldFetchResults(true);
      setShowAutoComplete(false);
    }
  };

  const onSelectHandler = (selectedItem: any = '', isEnterKey: any = false) => {
    const titleValue: any = isEnterKey ? filterTypes?.title : selectedItem;
    dispatch(
      kioskActions.setFilters({
        filterItem: titleValue,
        filterType: 'title',
      })
    );
    dispatch(
      kioskActions.setFiltersForCube({
        filterItem: titleValue,
        filterType: 'title',
      })
    );
    dispatch(kioskActions.clearFiltersExceptTitle({}));
    dispatch(kioskActions.clearFiltersExceptTitleForCube({}));

    setUserInput(titleValue);
    setShowAutoComplete(false);
    setSelectedBrandName('');
    setProductsDataFromCube([]);
    setCurrentOffset(0);
    setTotalProductsCount(0);
    setShowResultsPage(true);
    setShouldFetchResults(true);
  };

  const initialPanes: any = [
    {
      title: 'Request',
      content: <ProductStatus {...props} />,
      key: '1',
    },
    {
      title: 'Pending',
      content: <ProductStatus {...props} />,
      key: '2',
    },
    {
      title: 'Checked Out',
      content: <ProductStatus {...props} />,
      key: '3',
    },
  ];

  return (
    <>
      <div className='landing-page-wrapper sales-associate-dashboard-wrapper'>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12 pe-xl-0'>
              {!showResultsPage && <KpiStatus></KpiStatus>}

              <div className='search-bar-wrapper yk-search-bar'>
                <SearchComp
                  userInput={userInput}
                  placeholder='Search for brand, color etc.'
                  options={typeAhead}
                  isApiCall={true}
                  onChangeHandler={onSearchChange}
                  onSelectHandler={onSelectHandler}
                  showAutoComplete={showAutoComplete}
                  setShowAutoComplete={setShowAutoComplete}
                  suggestionsHasError={inventorySuggestionsError}
                  suggestionsLoading={inventorySuggestionsLoading}
                />
              </div>

              {!showResultsPage && (
                <>
                  <div className='heading-wrapper yk-browseTitle'>
                    <h3 className='heading'>browse</h3>
                  </div>
                  {isBrandsLoading && brandsData?.length === 0 ? (
                    <div className='circular-loader-wrapper yk-dashboard-loader-wrapper'>
                      <CircleLoader />
                    </div>
                  ) : (
                    <div className='custom-brand-card-wrapper'>
                      <div className='row'>
                        {brandsData &&
                          brandsData.map((item: any, index: any) => {
                            return (
                              <div
                                className='col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12'
                                key={index}>
                                <div className='brand-card-wrapper'>
                                  <div
                                    className='card'
                                    onClick={() =>
                                      browseProductHandler(item?.name)
                                    }>
                                    <div className='card-body dFlexCenter'>
                                      <ImageLoader
                                        src={`${item?.brandImageUrl}`}
                                        fallbackImg={brandImg1}
                                        alt='brand-img'
                                        className='img-fluid brand-card-img'
                                        imgWidth={250}
                                        imgHeight={100}
                                      />
                                      <h4 className='brand-card-text'>
                                        {item?.name}
                                      </h4>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                      </div>
                    </div>
                  )}
                </>
              )}

              {showResultsPage && (
                <SearchResults
                  userInput={userInput}
                  selectedBrandName={selectedBrandName}
                  productsDataFromCube={productsDataFromCube}
                  inventoryProductsLoading={inventoryProductsLoading}
                  setProductsDataFromCube={setProductsDataFromCube}
                  selectedSort={selectedSort}
                  setSelectedSort={setSelectedSort}
                  limitForCubeQuery={limitForCubeQuery}
                  currentOffset={currentOffset}
                  setCurrentOffset={setCurrentOffset}
                  totalProductsCount={totalProductsCount}
                  setTotalProductsCount={setTotalProductsCount}
                  hasError={inventoryProductsError}
                  setShouldFetchResults={setShouldFetchResults}
                  locId={locId}
                />
              )}
            </div>
            <div className='col-xl-4 col-lg-12 col-md-12 col-sm-12 col-12'>
              <div className='status-tabs-wrapper'>
                <CommonTabs initialPanes={initialPanes} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
