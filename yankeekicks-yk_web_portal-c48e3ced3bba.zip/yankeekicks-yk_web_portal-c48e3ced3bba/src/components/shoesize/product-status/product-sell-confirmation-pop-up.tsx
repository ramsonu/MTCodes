import React, { useEffect, useState, useMemo } from 'react';
import Modal from '@mui/material/Modal';
import VirtualTable from 'components/common/table';
import { PLACE_REQUEST_ERROR_MSG, RETAIL_SELL_SUCCESS_MSG } from '../constants';
import { retailSellOfProduct } from 'services/shoesize';

const ProductSellConfirmationPopUp = (props: any) => {
  const {
    selectedItem,
    setShowSoldConfirmationModal,
    setIsVisibleMessage,
    setErrorMessage,
    setIsShowModal,
    setSuccessMessage,
    setShouldFetchCheckedOut,
  } = props;
  const [orderIdInput, setOrderIdInput] = useState<any>('');
  const [waitingResponce, setWaitingResponce] = useState<any>(false);
  const [orderIdErrorMsg, setOrderIdErrorMessage] = useState<String>('');
  const tableColumns = useMemo(
    () => [
      {
        title: 'Barcode',
        value: 'barcode',
      },
      {
        title: 'Name',
        assignedImage: 'imageUrl',
        value: 'name',
        type: 'product-sell',
      },
      {
        title: 'Size',
        value: 'size',
      },
      {
        title: 'Price',
        value: 'price',
        methodToApply: 'toFix',
        prefix: '$',
      },
    ],
    [] // eslint-disable-line react-hooks/exhaustive-deps
  );
  const handleChange = (event: any) => {
    const value = event?.target?.value;
    const orderIdRegex = /^-?\d+?\d*$/;

    if (value.match(orderIdRegex) || value === '') {
      if (value?.length <= 8) {
        setOrderIdInput(value);
        setOrderIdErrorMessage('');
      }
    }
  };
  const handleSubmit = async () => {
    const storeId = localStorage.getItem('storeId');
    const locationId = localStorage.getItem('storeLocationId');
    const retailSellPayload = selectedItem?.reduce((acc: any, item: any) => {
      const rest = {
        barcode: item?.barcode,
        inventoryItemId: Number(item?.inventoryId),
        locationId: Number(locationId),
        orderNumber: orderIdInput,
        productId: Number(item?.productId),
        requestNumber: Number(item?.requestNumber),
        storeId: Number(storeId),
        variantId: Number(item?.variantId),
      };
      acc = [...acc, rest];
      return acc;
    }, []);

    try {
      const response = await retailSellOfProduct(
        orderIdInput,
        retailSellPayload
      );
      if (response?.status === 200) {
        setSuccessMessage(RETAIL_SELL_SUCCESS_MSG);
        setShowSoldConfirmationModal(false);
        setIsShowModal(true);
        setWaitingResponce(false);
      }
    } catch (e: any) {
      setWaitingResponce(false);
      console.log('error:', e);
      if (e?.response?.data?.error === 'RecordNotFoundException') {
        setOrderIdErrorMessage(e?.response?.data?.message);
      } else {
        setErrorMessage(PLACE_REQUEST_ERROR_MSG);
        setShowSoldConfirmationModal(false);
        setIsVisibleMessage(true);
      }
    }
    setShouldFetchCheckedOut(true);
  };

  return (
    <div className='app-wrapper w-100 landing-page-wrapper'>
      <Modal
        open={true}
        className='yk-upload-error-modal-wrapper yk-confirm-wrapper'
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'>
        <div className='upload-error-modal-wrapper'>
          <div className='yk-modal-body'>
            <div className='modal-heading-wrapper mb-1'>
              <p className='modal-title'>Confirm Sold Out</p>
              <p className='modal-sub-title'>
                {`  Ensure that you're marking the correct products as sold out.`}
              </p>
            </div>
            <div className='yk-table-wrapper'>
              <VirtualTable headers={tableColumns} rowData={selectedItem} />
            </div>

            <h4 className='yk-form-title-text'>Order ID</h4>
            <input
              type='text'
              onChange={(e) => handleChange(e)}
              className='form-control w-100'
              placeholder='Enter Order ID'
              value={orderIdInput}
            />
            {orderIdErrorMsg && (
              <p className='my-2 btn-reject'>{orderIdErrorMsg}</p>
            )}
            <div className='row mt-4 yk-modal-button-wrapper'>
              <div className='col-6'>
                <button
                  className='btn YK-cancel-link'
                  type='button'
                  onClick={() => setShowSoldConfirmationModal(false)}>
                  Cancel
                </button>
              </div>
              <div className='col-6'>
                <button
                  className='btn yk-btn-primary modal-download-btn ms-auto '
                  type='button'
                  disabled={!orderIdInput || waitingResponce}
                  onClick={() => {
                    setWaitingResponce(true);
                    handleSubmit();
                  }}>
                  <h6 className='btn-text yk-badge-h7'>CONFIRM</h6>
                </button>
              </div>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default ProductSellConfirmationPopUp;
