import React, { useEffect, useState, useRef } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import { useSelector, useDispatch } from 'react-redux';
import { actions } from 'store/reducers/shoesize';
import { actions as authActions } from 'store/reducers/auth';
import {
  getPendingStatusTabQuery,
  getCheckedOutStatusTabQuery,
} from 'middleware/cubejs-wrapper/cubejs-query';
import { checkInCheckOutRequest } from 'services/shoesize';
import Modal from '@mui/material/Modal';
import { Checkbox } from '@mui/material';
import Notification from 'components/common/notification';
import {
  STATUS,
  ACTIVE_STATUS,
  PLACE_REQUEST_LABEL,
  PLACE_REQUEST_DESC,
  PLACE_REQUEST_BTN_LABEL,
  PLACE_REQUEST_SUCCESS_TEXT,
  PLACE_REQUEST_SKU_NOT_PRESENT,
  PLACE_REQUEST_ERROR_MSG,
  NO_PRODUCTS_ITEMS_IN_CHECKEDOUT_TAB,
  NO_PRODUCTS_ITEMS_IN_PENDING_TAB,
} from '../constants';
import ImageLoader from 'components/common/image-loader';
import { format } from 'date-fns';
import { KPI_DATE_FORMAT } from 'utils/constants';
import { LogoutUser } from 'components/common/logout';
import { convertPriceToUSFormat } from 'utils/util';
import CircleLoader from 'components/common/loader/circular-loader';
import NoDataFound from 'components/common/no-data-found';
import ProductSellConfirmationPopUp from './product-sell-confirmation-pop-up';
import AddIcon from 'assets/images/add-icon.svg';
import CloseIcon from 'assets/images/close-circle.svg';
import ThumbnailIcon from 'assets/images/big-product-img.svg';

const ProductStatus = (props: any) => {
  const { filteredCart, activeStatus, goBackTrigger } = useSelector(
    (state: any) => state.shoesize
  );
  const [isPlaceOrderLoading, setIsPlaceOrderLoading] =
    useState<boolean>(false);
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [pendingStatusData, setPendingStatusData] = useState([]);
  const [checkedOutStatusData, setCheckedOutStatusData] = useState([]);
  const [isVisible, setIsVisible] = useState(false);
  const [isShowModal, setIsShowModal] = useState(false);
  const [shouldFetchPending, setShouldFetchPending] = useState(false);
  const [shouldFetchCheckedOut, setShouldFetchCheckedOut] = useState(false);
  const [showSoldConfirmationModal, setShowSoldConfirmationModal] =
    useState(false);
  const [selectedItem, setSelectedItem] = useState<string[]>([]);
  const applyRef = useRef<HTMLButtonElement>(null);

  const dispatch = useDispatch();
  const router = useRouter();

  const removeItem = (id: string) => {
    dispatch(actions.removeItem(id));
  };
  const storeId = localStorage.getItem('storeId');
  const userId = localStorage.getItem('user-Id');
  const locationId = localStorage.getItem('storeLocationId');

  useEffect(() => {
    if (activeStatus === '2') {
      setShouldFetchPending(true);
      setShouldFetchCheckedOut(false);
    }
    if (activeStatus === '3') {
      setShouldFetchPending(false);
      setShouldFetchCheckedOut(true);
    }
  }, [activeStatus]);

  const pendingTabQuery: any = getPendingStatusTabQuery(
    storeId,
    format(new Date(), KPI_DATE_FORMAT),
    locationId,
    userId
  );
  const checkedOutTabQuery: any = getCheckedOutStatusTabQuery(
    storeId,
    format(new Date(), KPI_DATE_FORMAT),
    locationId,
    userId
  );

  const {
    resultSet: resultSetPending,
    isLoading: isLoadingPending,
    error: pendingTabError,
  }: any = useCubeQuery(pendingTabQuery, { skip: !shouldFetchPending });
  const {
    resultSet: resultSetCheckedOut,
    isLoading: isLoadingCheckedOut,
    error: checkoutTabError,
  }: any = useCubeQuery(checkedOutTabQuery, { skip: !shouldFetchCheckedOut });

  useEffect(() => {
    setPendingStatusData(
      renderPendingAndCheckoutItems(resultSetPending?.loadResponses[0]?.data)
    );
  }, [resultSetPending]);
  useEffect(() => {
    setCheckedOutStatusData(
      renderPendingAndCheckoutItems(resultSetCheckedOut?.loadResponses[0]?.data)
    );
    if (resultSetCheckedOut?.loadResponses[0]?.data) {
      setShouldFetchCheckedOut(false);
    }
  }, [resultSetCheckedOut]);
  useEffect(() => {
    if (pendingTabError?.status === 401 || pendingTabError?.status === 403) {
      LogoutUser();
      router.push('/', undefined, { shallow: true });
    }
  }, [pendingTabError]);
  useEffect(() => {
    if (checkoutTabError?.status === 401 || checkoutTabError?.status === 403) {
      LogoutUser();
      router.push('/', undefined, { shallow: true });
    }
  }, [checkoutTabError]);

  const renderPendingAndCheckoutItems = (statusData: any) => {
    return statusData?.reduce((acc: any, item: any) => {
      const rest = {
        inventoryId: item?.['StoreTab.inventoryItemId'],
        name: item?.['StoreTab.itemName'],
        imageUrl: item?.['StoreTab.imageUrl'],
        size: item?.['StoreTab.option1'],
        price: item?.['StoreTab.price'],
        variantId: item?.['StoreTab.variantId'],
        productId: item?.['StoreTab.productId'],
        barcode: item?.['StoreTab.barcode'],
        requestNumber: item?.['StoreTab.requestNumber'],
      };
      acc = [...acc, rest];
      return acc;
    }, []);
  };

  const onClicked = async () => {
    setIsVisible(false);
    let params: any = [];
    console.log('filteredCart', filteredCart);
    filteredCart?.map((item: any) => {
      if (!!item?.style) {
        return params?.push({
          locationId: Number(localStorage?.getItem('storeLocationId')),
          requestNumber: 0,
          status: 'Pending',
          storeId: Number(localStorage.getItem('storeId')),
          userId: Number(localStorage.getItem('user-Id')),
          userName: localStorage.getItem('user-name'),
          variantId: Number(item.inventoryLineItemId),
          barcode: item?.barcode,
          orderNumber: '',
        });
      }
    });
    if (
      params[0] !== undefined &&
      typeof params !== undefined &&
      Array.isArray(params) &&
      params?.length > 0
    ) {
      try {
        setIsPlaceOrderLoading(true);
        const response = await checkInCheckOutRequest(params);
        if (response.status === 200) {
          dispatch(actions.clearRequestCart({}));
          setIsShowModal(true);
          setIsVisibleMessage(false);
          setErrorMessage('');
          setIsPlaceOrderLoading(false);
          if (params?.length !== filteredCart?.length) {
            const message = `Request placed successfully for ${params?.length} of ${filteredCart?.length} products.`;
            setSuccessMessage(message);
          } else {
            setSuccessMessage('');
          }
          dispatch(actions.setBackButtonTrigger(!goBackTrigger));
        }
      } catch (e: any) {
        setIsVisibleMessage(true);
        setErrorMessage(PLACE_REQUEST_ERROR_MSG);
        setIsPlaceOrderLoading(false);
        if (e?.response?.status === 401 || e?.response?.status === 403) {
          dispatch(authActions.clearUserDetails());
          LogoutUser();
          router.push('/', undefined, { shallow: true });
        }
      }
    } else {
      setIsVisibleMessage(true);
      setErrorMessage(PLACE_REQUEST_SKU_NOT_PRESENT);
      dispatch(actions.clearRequestCart({}));
    }
  };

  const handleSnackbarClose = () => {
    setIsVisibleMessage(false);
    setErrorMessage('');
  };
  const handleClose = (event: Event | React.SyntheticEvent) => {
    if (
      applyRef.current &&
      applyRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }

    setIsVisible(false);
  };

  const handleSuccessModalClose = () => {
    setIsShowModal(false);
  };
  const message = (
    <h4 className='notification-heading'>
      {successMessage ? successMessage : PLACE_REQUEST_SUCCESS_TEXT}
    </h4>
  );
  const isActiveStatus = filteredCart?.length === 0;

  let data =
    STATUS[activeStatus] === ACTIVE_STATUS.PENDING
      ? pendingStatusData
      : STATUS[activeStatus] === ACTIVE_STATUS.CHECKEDOUT
      ? checkedOutStatusData
      : filteredCart;

  const isLoading =
    (STATUS[activeStatus] === ACTIVE_STATUS.PENDING && isLoadingPending) ||
    (STATUS[activeStatus] === ACTIVE_STATUS.CHECKEDOUT &&
      isLoadingCheckedOut) ? (
      <div className='circular-loader-wrapper yk-tabs-loader'>
        <CircleLoader />
      </div>
    ) : (
      ''
    );
  let tryoutItems: any = [];
  let tryoutFromItems: any = [];
  if (STATUS[activeStatus] == ACTIVE_STATUS.REQUEST) {
    tryoutItems = data
      .filter((value: any) => value.tryOutItem)
      .reduce(function (r: any, a: any) {
        r[a.requestedBy] = r[a.requestedBy] || [];
        r[a.requestedBy].push(a);
        return r;
      }, Object.create(null));
    tryoutFromItems = Object.keys(tryoutItems);
    data = data.filter((value: any) => !value.tryOutItem);
  }
  const titleForNoDataFound =
    STATUS[activeStatus] === ACTIVE_STATUS.PENDING
      ? NO_PRODUCTS_ITEMS_IN_PENDING_TAB
      : STATUS[activeStatus] === ACTIVE_STATUS.CHECKEDOUT
      ? NO_PRODUCTS_ITEMS_IN_CHECKEDOUT_TAB
      : '';

  const onClickHandler = (value: any) => {
    if (selectedItem.includes(value)) {
      console.log('selectedItem', selectedItem);
      let tempOption = [];
      tempOption = selectedItem.filter(
        (data: any) => data?.inventoryId !== value?.inventoryId
      );
      setSelectedItem(tempOption);
    } else {
      setSelectedItem([...selectedItem, value]);
    }
  };

  const renderItems = () => {
    return (
      <ul className='pending-list list-all'>
        {(STATUS[activeStatus] === ACTIVE_STATUS.PENDING ||
          STATUS[activeStatus] === ACTIVE_STATUS.CHECKEDOUT) &&
          data?.length === 0 && (
            <NoDataFound title={titleForNoDataFound} msg={''} />
          )}
        {data?.map((cartItem: any, indx: any) => {
          return (
            <li key={indx}>
              <div className='img-thumbnail-icon'>
                <ImageLoader
                  src={cartItem.imageUrl}
                  fallbackImg={ThumbnailIcon}
                  alt='cart-img'
                  className='img-fluid'
                />
                <div>
                  <p className='product-name' title={cartItem.name || '--'}>
                    {cartItem.name || '--'}
                  </p>
                  <div
                    title={cartItem?.barcode || '-'}
                    className='yk-para-p5 m-0 yk-custom-ellipse'>
                    {cartItem?.barcode || '--'}{' '}
                  </div>
                </div>
              </div>
              <div className='product-detail-inner-wrapper'>
                <div className='product-details'>
                  <p className='size'>{cartItem.size || '--'}</p>
                  <p
                    className='price'
                    title={
                      convertPriceToUSFormat(
                        Number(cartItem?.price)?.toFixed(2)
                      ) || '--'
                    }>
                    {cartItem?.price
                      ? convertPriceToUSFormat(
                          Number(cartItem?.price)?.toFixed(2)
                        )
                      : '--'}{' '}
                  </p>
                </div>
                {STATUS[activeStatus] === ACTIVE_STATUS.CHECKEDOUT && (
                  <>
                    <Checkbox
                      className='filter-sidebar-checkbox'
                      onChange={() => onClickHandler(cartItem)}
                    />
                  </>
                )}

                {STATUS[activeStatus] === ACTIVE_STATUS.REQUEST && (
                  <div className='close-btn-wrapper'>
                    <button
                      className='btn prod-close'
                      onClick={() => removeItem(cartItem.inventoryLineItemId)}>
                      <Image src={CloseIcon} alt='' className='img-fluid' />
                    </button>
                  </div>
                )}
              </div>
            </li>
          );
        })}
        {tryoutFromItems.length > 0 && (
          <>
            {tryoutFromItems.map((from: string, tindex: number) => (
              <div key={tindex} className='tryOutItemRequestBlock'>
                <div className='col-md-12'>
                  <div className='users-request-wrapper'>
                    <h6>From</h6>
                    <p>{from}</p>
                  </div>
                </div>
                <div className='col-md-12'>
                  {tryoutItems[from]?.map((cartItem: any, indx: number) => (
                    <li key={indx}>
                      <div className='img-thumbnail-icon'>
                        <ImageLoader
                          src={cartItem.imageUrl}
                          fallbackImg={ThumbnailIcon}
                          alt='cart-img'
                          className='img-fluid'
                        />
                        <div>
                          <p
                            className='product-name'
                            title={cartItem.name || '--'}>
                            {cartItem.name || '--'}
                          </p>
                          <div
                            title={cartItem?.barcode || '-'}
                            className='yk-para-p5 m-0 yk-custom-ellipse'>
                            {cartItem?.barcode || '--'}{' '}
                          </div>
                        </div>
                      </div>

                      <div className='product-detail-inner-wrapper'>
                        <div className='product-details'>
                          <p className='size'>{cartItem.size || '--'}</p>
                          <p
                            className='price'
                            title={
                              convertPriceToUSFormat(
                                Number(cartItem?.price)?.toFixed(2)
                              ) || '--'
                            }>
                            {cartItem?.price
                              ? convertPriceToUSFormat(
                                  Number(cartItem?.price)?.toFixed(2)
                                )
                              : '--'}{' '}
                          </p>
                        </div>

                        {STATUS[activeStatus] === ACTIVE_STATUS.REQUEST && (
                          <div className='close-btn-wrapper'>
                            <button
                              className='btn prod-close'
                              onClick={() =>
                                removeItem(cartItem.inventoryLineItemId)
                              }>
                              <Image
                                src={CloseIcon}
                                alt=''
                                className='img-fluid'
                              />
                            </button>
                          </div>
                        )}
                      </div>
                    </li>
                  ))}
                </div>
              </div>
            ))}
          </>
        )}
      </ul>
    );
  };

  const emptyBox = () => {
    if (isActiveStatus && STATUS[activeStatus] === ACTIVE_STATUS.REQUEST) {
      return (
        <>
          <div className='empty-wrapper'>
            <div className='empty-list'>
              <Image src={AddIcon} alt='' className='img-fluid' />
              <p>Add shoes to request from warehouse</p>
            </div>
          </div>
        </>
      );
    }
  };

  return (
    <>
      <div className='tab-content-inner-wrapper'>
        <Notification
          showSuccessPopup={isVisibleMessage}
          handleSnackbarClose={handleSnackbarClose}
          severityType='error'
          message={errorMessage}
          className='yk-shoesize-alert-wrapper'
        />
        <div
          className={`add-shoes-wrapper pending-tab-wrapper ${
            activeStatus === '1' ? 'request-tab-wrapper' : ''
          }`}>
          {isLoading}
          {renderItems()}
          {emptyBox()}
        </div>
        {STATUS[activeStatus] === ACTIVE_STATUS.REQUEST && (
          <div className='button-action-wrapper'>
            <button
              className='btn btn-place-request'
              disabled={isActiveStatus || isPlaceOrderLoading}
              onClick={() => setIsVisible(true)}>
              place request
            </button>
          </div>
        )}
        {STATUS[activeStatus] === ACTIVE_STATUS.CHECKEDOUT && (
          <div className='button-action-wrapper'>
            <button
              className='btn btn-place-request'
              onClick={() => setShowSoldConfirmationModal(true)}
              disabled={!selectedItem?.length}>
              MARK AS SOLD OUT
            </button>
          </div>
        )}
        <Modal
          open={isVisible}
          onClose={handleClose}
          className='yk-request-btn-modal-wrapper'
          aria-labelledby='modal-modal-title'
          aria-describedby='modal-modal-description'>
          <div className='app-wrapper request-modal-wrapper'>
            <div className='yk-modal-body'>
              <div className='modal-heading-wrapper'>
                <p className='modal-title yk-badge-h11'>
                  {PLACE_REQUEST_LABEL}
                </p>
                <h5 className='modal-sub-title yk-badge-h16'>
                  {filteredCart?.length} {PLACE_REQUEST_DESC}
                </h5>
              </div>
              <div className='place-request-btn-wrapper'>
                <button
                  className='btn yk-btn-primary modal-place-request-btn'
                  type='button'
                  onClick={onClicked}>
                  <h6 className='btn-text yk-badge-h7'>
                    {PLACE_REQUEST_BTN_LABEL}
                  </h6>
                </button>
              </div>
            </div>
          </div>
        </Modal>
        {showSoldConfirmationModal && (
          <ProductSellConfirmationPopUp
            selectedItem={selectedItem}
            setShowSoldConfirmationModal={setShowSoldConfirmationModal}
            setIsVisibleMessage={setIsVisibleMessage}
            setErrorMessage={setErrorMessage}
            setIsShowModal={setIsShowModal}
            setSuccessMessage={setSuccessMessage}
            setShouldFetchCheckedOut={setShouldFetchCheckedOut}
          />
        )}
      </div>
      {isShowModal && (
        <Notification
          showSuccessPopup={isShowModal}
          handleSnackbarClose={handleSuccessModalClose}
          severityType='success'
          message={message}
          className='yk-shoesize-alert-wrapper'
        />
      )}
    </>
  );
};

export default ProductStatus;
