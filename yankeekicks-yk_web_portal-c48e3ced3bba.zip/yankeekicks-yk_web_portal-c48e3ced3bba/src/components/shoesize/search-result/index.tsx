import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Image from 'next/image';
import { useDispatch, useSelector } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import InfiniteScroll from 'react-infinite-scroll-component';
import ImageLoader from 'components/common/image-loader';
import NoDataFound from 'components/common/no-data-found';
import UpdatedAddRequest from '../add-request/updated-add-request';
import UpdatedProductDetailsModal from '../inventory/updated-product-details-modal';
import Sortings from 'components/common/sortings';
import ProductFilters from 'components/common/filters/product-filter';
import CircleLoader from 'components/common/loader/circular-loader';
import product1 from 'assets/images/big-product-img.svg';
import filterIcon from 'assets/images/filter-icon.png';
import {
  SEARCH_BY_MODEL_ADIDAS,
  SEARCH_BY_MODEL_AIR_JORDAN,
  SEARCH_BY_MODEL_NEW_BALANCE,
  SEARCH_BY_MODEL_NIKE,
  SEARCH_BY_MODEL_YEEZY,
} from 'components/common/filters/constants';
import { useCubeQuery } from '@cubejs-client/react';
import { getMinMaxPriceFromInventory } from 'middleware/cubejs-wrapper/cubejs-query';
import Notification from 'components/common/notification';

const SearchResults = (props: any) => {
  const {
    userInput,
    selectedBrandName = '',
    productsDataFromCube,
    setProductsDataFromCube,
    inventoryProductsLoading,
    totalProductsCount,
    selectedSort,
    setSelectedSort,
    limitForCubeQuery,
    currentOffset,
    setCurrentOffset,
    setTotalProductsCount,
    hasError = false,
    setShouldFetchResults = () => {},
    locId = '',
  } = props;

  const dispatch = useDispatch();
  const { filterTypes, filterTypesForCube } = useSelector(
    (state: any) => state.kiosk
  );
  const [showModal, setShowModal] = useState<boolean>(false);
  const [selectedProductId, setSelectedProductId] = useState<any>('');
  const [showFilters, setShowFilters] = useState<boolean>(false);
  const [selectedBrands, setSelectedBrands] = useState<any>([]);
  const [previousBrand, setPreviousBrand] = useState<any>('');
  const [variantDataForInventory, setVariantDataForInventory] = useState<any>(
    []
  );
  const [isClearButtonDisabled, setIsClearButtonDisabled] = useState<any>(true);
  const [filteredModelValues, setFilteredModelValues] = useState<any>([]);
  const [shouldMinMaxResultsFetch, setShouldMinMaxResultsFetch] =
    useState(false);
  const [minMax, setMinMax] = useState<any>({ min: 0, max: 0 });
  const [userPriceInput, setUserPriceInput] = useState<any>({
    first: filterTypes?.price[0],
    second: filterTypes?.price[1],
  });
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<any>('');
  const [notificationSeverityType, setNotificationSeverityType] =
    useState<string>('');
  useEffect(() => {
    if (locId) {
      setShouldMinMaxResultsFetch(true);
    } else {
      setShouldMinMaxResultsFetch(false);
    }
  }, [locId]);

  const kioskInventoryMinMaxPriceQuery: any =
    getMinMaxPriceFromInventory(locId);

  const {
    resultSet: inventoryMinMaxResultSet,
    isLoading: inventoryMinMaxLoading,
  }: any = useCubeQuery(kioskInventoryMinMaxPriceQuery, {
    skip: !shouldMinMaxResultsFetch,
  });

  //useEffect for Min Max price
  useEffect(() => {
    const minMaxData: any = inventoryMinMaxResultSet?.loadResponses[0]?.data[0];
    if (minMaxData) {
      setMinMax({
        min: minMaxData['KioskInventory.minPrice'],
        max: minMaxData['KioskInventory.maxPrice'],
      });
      setShouldMinMaxResultsFetch(false);
    } else {
      setMinMax({
        min: 0,
        max: 100000,
      });
    }
  }, [inventoryMinMaxResultSet]);

  // useEffect to set Price Inputs
  useEffect(() => {
    if (
      userPriceInput?.first?.toString() ||
      userPriceInput?.second?.toString()
    ) {
      dispatch(
        actions.setFilterValueBasedOnKey({
          filterKey: 'price',
          filterValue: [userPriceInput?.first, userPriceInput?.second],
        })
      );
    } else {
      dispatch(
        actions.setFilterValueBasedOnKey({
          filterKey: 'price',
          filterValue: [0, 0],
        })
      );
    }
  }, [userPriceInput]);

  useEffect(() => {
    let minValue = Math.min(
      Number(userPriceInput?.first),
      Number(userPriceInput?.second)
    );
    let maxValue = Math.max(
      Number(userPriceInput?.first),
      Number(userPriceInput?.second)
    );

    dispatch(
      actions.setFilterValueBasedOnKey({
        filterKey: 'price',
        filterValue: [minValue, maxValue],
      })
    );
  }, [userPriceInput]);

  useEffect(() => {
    if (selectedBrandName) {
      setSelectedBrands([...selectedBrands, selectedBrandName]);
      setPreviousBrand(selectedBrandName);
    } else {
      const tempBrands = selectedBrands.filter(
        (data: any) => data !== previousBrand
      );
      setSelectedBrands(tempBrands);
    }
  }, [selectedBrandName, previousBrand]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (
      !filterTypes?.brand?.length &&
      !filterTypes?.color?.length &&
      !filterTypes?.size?.length &&
      !filterTypes?.type?.length &&
      !filterTypes?.date?.length &&
      !filterTypes?.availability?.length &&
      !filterTypes?.model?.length &&
      !filterTypes?.price[1]
    ) {
      setIsClearButtonDisabled(true);
    } else {
      setIsClearButtonDisabled(false);
    }
  }, [filterTypes]);

  useEffect(() => {
    let valuesToHold: any = [];
    filterTypes?.brand?.map((brandName: any) => {
      let constantsToUse: any = [];
      switch (brandName) {
        case 'nike':
          constantsToUse = SEARCH_BY_MODEL_NIKE;
          break;
        case 'jordan':
          constantsToUse = SEARCH_BY_MODEL_AIR_JORDAN;
          break;
        case 'adidas':
          constantsToUse = SEARCH_BY_MODEL_ADIDAS;
          break;
        case 'new balance':
          constantsToUse = SEARCH_BY_MODEL_NEW_BALANCE;
          break;
        case 'yeezy':
          constantsToUse = SEARCH_BY_MODEL_YEEZY;
          break;
        case 'supreme':
          constantsToUse = [];
          break;
        case 'puma':
          constantsToUse = [];
          break;
      }

      constantsToUse?.map((item: any) => {
        filterTypes?.model?.map((subItem: any) => {
          if (item?.key === subItem) {
            return valuesToHold?.push(subItem);
          }
        });
      });
    });
    setFilteredModelValues(valuesToHold);

    if (filterTypes?.brand?.length === 0) {
      dispatch(
        actions.clearFiltersByKey({
          filterItem: [],
          filterType: 'model',
        })
      );
      dispatch(
        actions.clearFiltersByKeyForCube({
          filterItem: [],
          filterType: 'model',
        })
      );
    }
  }, [filterTypes?.brand]);

  useEffect(() => {
    dispatch(
      actions.setFilterValueBasedOnKey({
        filterKey: 'model',
        filterValue: filteredModelValues,
      })
    );
  }, [filteredModelValues, filterTypes?.brand]);

  const productClickHandler = (product: any) => {
    const shopifyIdText = 'gid://shopify/Product/';
    const productIdOrData = shopifyIdText.concat(
      product?.['KioskInventory.productId']
    );
    if (pathname === '/shoesize/inventory') {
      setVariantDataForInventory(product);
    } else {
      setVariantDataForInventory([]);
    }
    setSelectedProductId(productIdOrData);
    setShowModal(true);
  };

  const onClickApplyFilters = () => {
    dispatch(actions.setSelectedFiltersForCube(filterTypes));
    if (JSON.stringify(filterTypes) !== JSON.stringify(filterTypesForCube)) {
      setProductsDataFromCube([]);
      setCurrentOffset(0);
      setTotalProductsCount([]);
    }
    setShowFilters(false);
    setShouldFetchResults(true);
  };

  const clearAll = () => {
    const filterItems = [
      'brand',
      'color',
      'size',
      'type',
      'date',
      'model',
      'availability',
    ];
    filterItems?.map((item: any) => {
      dispatch(
        actions.clearFiltersByKey({
          filterItem: [],
          filterType: item,
        })
      );
    });
    filterItems?.map((item: any) => {
      dispatch(
        actions.clearFiltersByKeyForCube({
          filterItem: [],
          filterType: item,
        })
      );
    });
    dispatch(
      actions.setFilterValueBasedOnKey({
        filterKey: 'price',
        filterValue: [0, 0],
      })
    );
    dispatch(
      actions.setFilterValueBasedOnKeyForCube({
        filterKey: 'price',
        filterValue: [0, 0],
      })
    );
    setProductsDataFromCube([]);
    setCurrentOffset(0);
    setTotalProductsCount([]);
    setShowFilters(false);
    setShouldFetchResults(true);
    setUserPriceInput({ first: 0, second: 0 });
  };

  const sortHandler = (event: any) => {
    const sortValue = event?.target?.value;
    setSelectedSort(sortValue);
    setProductsDataFromCube([]);
    setCurrentOffset(0);
    setShouldFetchResults(true);
  };

  const { pathname } = useRouter();
  const isFullScreen =
    pathname === '/shoesize/inventory' ? 'inventory' : 'dashboard';

  const fetchMoreData = () => {
    if (
      productsDataFromCube?.length < totalProductsCount &&
      !inventoryProductsLoading
    ) {
      setCurrentOffset(currentOffset + limitForCubeQuery);
      setShouldFetchResults(true);
    } else {
      return;
    }
  };

  const handleSnackbarClose = () => {
    setIsVisibleMessage(false);
  };

  return (
    <>
      <div className='sales-filter-page-wrapper'>
        <div className='products-wrapper'>
          <div className='products-wrapper-header'>
            <div className='heading-shoesize-wrapper'>
              <div className='row'>
                <div className='col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12'>
                  <div className='yk-show-results-section'>
                    <h3 className='text-heading me-3'>Showing</h3>
                    <div className='product-name'>
                      <div
                        className='product-title'
                        title={userInput ? userInput : 'All'}>
                        {userInput ? userInput : 'All'}
                      </div>
                      <div className='product-count'>
                        - {totalProductsCount || 0} Results
                      </div>
                    </div>
                  </div>
                </div>

                <div className='col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 sort-filter-container'>
                  <div className='sort-filter-wrapper'>
                    <div className='filter-btn-wrapper'>
                      <ClickAwayListener
                        onClickAway={() => {
                          setShowFilters(false);
                        }}>
                        <div>
                          <button
                            className='btn filter-btn'
                            onClick={() => setShowFilters(!showFilters)}>
                            <Image
                              src={filterIcon}
                              alt='filter-btn-icon'
                              className='filter-btn-icon img-fluid'
                            />
                            <span className='filter-btn-text yk-badge-h15'>
                              Filter
                            </span>
                          </button>

                          {showFilters && (
                            <ProductFilters
                              itemKey='salesAssociate'
                              onApplyClick={onClickApplyFilters}
                              onClearFilters={clearAll}
                              priceValue={filterTypes?.price}
                              minMax={minMax}
                              userPriceInput={userPriceInput}
                              setUserPriceInput={setUserPriceInput}
                              clearDisable={isClearButtonDisabled}
                              toShowModelFilter={
                                filterTypes?.brand?.length > 0 &&
                                (filterTypes?.brand?.includes('nike') ||
                                  filterTypes?.brand?.includes('jordan') ||
                                  filterTypes?.brand?.includes('adidas') ||
                                  filterTypes?.brand?.includes('new balance') ||
                                  filterTypes?.brand?.includes('yeezy') ||
                                  !(
                                    filterTypes?.brand?.includes('supreme') ||
                                    filterTypes?.brand?.includes('puma')
                                  ))
                              }
                            />
                          )}
                        </div>
                      </ClickAwayListener>
                    </div>

                    <Sortings
                      itemKey='salesAssoSearch'
                      handleChange={sortHandler}
                      defaultSelectedValue={selectedSort}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {hasError ? (
            <NoDataFound />
          ) : inventoryProductsLoading && productsDataFromCube?.length === 0 ? (
            <div className='circular-loader-wrapper yk-dashboard-product-page-loader'>
              <CircleLoader />
            </div>
          ) : (
            <div className='product-inner-wrapper' id='infiniteScrollableDiv'>
              {productsDataFromCube?.length > 0 ? (
                <InfiniteScroll
                  dataLength={productsDataFromCube?.length}
                  next={fetchMoreData}
                  hasMore={
                    productsDataFromCube?.length < totalProductsCount &&
                    productsDataFromCube?.length > 0
                      ? true
                      : false
                  }
                  loader={
                    inventoryProductsLoading ? (
                      <p>
                        <div className='circular-loader-wrapper yk-dashboard-product-loader'>
                          <CircleLoader />
                        </div>
                      </p>
                    ) : (
                      <p style={{ visibility: 'hidden', display: 'none' }}>
                        Loading...
                      </p>
                    )
                  }
                  endMessage={
                    productsDataFromCube?.length >= totalProductsCount ? (
                      <p style={{ textAlign: 'center' }}>
                        <b>Yay! You have seen it all</b>
                      </p>
                    ) : (
                      ''
                    )
                  }
                  scrollableTarget='infiniteScrollableDiv'
                  style={{ overflowX: 'hidden' }}>
                  <div className='row search-results-list'>
                    {productsDataFromCube?.length > 0 ? (
                      productsDataFromCube?.map((product: any, index: any) => {
                        const imageUrl = product?.['KioskInventory.imageUrl'];
                        const productTitle = product?.['KioskInventory.title'];
                        return (
                          <div
                            className={
                              isFullScreen === 'inventory'
                                ? 'col-sm-12 col-6 col-md-6 col-lg-4 col-xl-3'
                                : 'col-sm-12 col-6 col-md-6 col-lg-4 col-xl-3'
                            }
                            key={index}>
                            <div
                              className='card product-card'
                              onClick={() => productClickHandler(product)}>
                              {imageUrl ? (
                                <ImageLoader
                                  src={`${imageUrl}`}
                                  fallbackImg={product1}
                                  alt='product-img'
                                  className='card-img-top img-fluid'
                                  imgWidth={500}
                                  imgHeight={100}
                                />
                              ) : (
                                <Image
                                  src={product1}
                                  alt='product-img'
                                  className='card-img-top img-fluid'
                                />
                              )}
                              <div className='card-body p-0'>
                                <h5 className='card-title'>
                                  {productTitle?.length > 22
                                    ? productTitle
                                        .substring(0, 22)
                                        .concat('...')
                                    : productTitle}
                                </h5>
                                {isFullScreen === 'inventory' && (
                                  <p className='product-size-info'>
                                    {product?.['KioskInventory.option1'] ||
                                      '--'}
                                  </p>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })
                    ) : (
                      <div className='col-lg-12'>
                        <NoDataFound />
                      </div>
                    )}
                  </div>
                </InfiniteScroll>
              ) : (
                <div className='yk-no-result-align'>
                  <NoDataFound />
                </div>
              )}
            </div>
          )}
        </div>

        {showModal && isFullScreen === 'dashboard' && (
          <UpdatedAddRequest
            showModal={showModal}
            setShowModal={setShowModal}
            selectedProductId={selectedProductId}
            setIsVisibleMessage={setIsVisibleMessage}
            setErrorMessage={setErrorMessage}
            setNotificationSeverityType={setNotificationSeverityType}
          />
        )}

        {showModal && isFullScreen === 'inventory' && (
          <UpdatedProductDetailsModal
            showModal={showModal}
            setShowModal={setShowModal}
            variantDataForInventory={variantDataForInventory}
          />
        )}
        <Notification
          showSuccessPopup={isVisibleMessage}
          handleSnackbarClose={handleSnackbarClose}
          severityType={notificationSeverityType}
          message={errorMessage}
          className='yk-shoesize-alert-wrapper'
        />
      </div>
    </>
  );
};

export default SearchResults;
