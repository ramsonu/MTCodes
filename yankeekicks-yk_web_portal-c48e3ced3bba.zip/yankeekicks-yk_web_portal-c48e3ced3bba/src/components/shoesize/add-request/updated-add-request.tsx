import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useDispatch } from 'react-redux';
import { useCubeQuery } from '@cubejs-client/react';
import { ClickAwayListener, Tooltip } from '@mui/material';
import Modal from '@mui/material/Modal';
import { actions } from 'store/reducers/shoesize';
import { actions as authActions } from 'store/reducers/auth';
import { doRequest } from 'utils/request';
import { convertPriceToUSFormat } from 'utils/util';
import { LogoutUser } from 'components/common/logout';
import { GET_BARCODE_OF_PRODUCT } from 'services/apiUrl';
import { PRODUCT_INVENTORY_COUNT_ERROR_MSG } from '../constants';
import { NOTIFICATION_SOMETHING_WENT_WRONG } from 'utils/constants';
import { getProductAndVariantDetailsById } from 'middleware/cubejs-wrapper/cubejs-query';
import LocationsTooltip from './locations-tooltip';
import ImageLoader from 'components/common/image-loader';
import CircleLoader from 'components/common/loader/circular-loader';
import CopyToClipboardComponent from 'components/common/copyToClipboard';
import productImage from 'assets/images/big-product-img.svg';

interface Props {
  showModal?: Boolean;
  setShowModal?: Function;
  selectedProductId?: any;
  setIsVisibleMessage?: Function;
  setErrorMessage?: Function;
}

const UpdatedAddRequest = (props: any) => {
  const {
    showModal,
    setShowModal,
    selectedProductId,
    setIsVisibleMessage,
    setErrorMessage,
    setNotificationSeverityType,
  } = props;

  const [totalVariants, setTotalVariants] = useState<any>();
  const [availableVariants, setAvailableVariants] = useState<any>([]);
  const [unavailableVariants, setUnavailableVariants] = useState<any>([]);
  const [selectedVariants, setSelectedVariants] = useState<any>([]);
  const [selectedVariantsId, setSelectedVariantsId] = useState<any>([]);
  const [selectedInventoryLineItemId, setSelectedInventoryLineItemId] =
    useState<any>('');
  const [showLocationToolTip, setShowLocationToolTip] = useState<any>(false);
  const [conditions, setConditions] = useState<any>([]);
  const [selectedCondition, setSelectedCondition] = useState<any>(null);
  const [sku, setSku] = useState<any>('');
  const [productDetails, setProductDetails] = useState<any>([]);
  const [productImages, setProductImages] = useState<any>([]);
  const [shouldFetchProductDetails, setShouldFetchProductDetails] =
    useState<any>(false);

  const dispatch = useDispatch();
  const router = useRouter();

  const locId: any = localStorage.getItem('storeLocationId');

  useEffect(() => {
    if (selectedProductId && locId) {
      setShouldFetchProductDetails(true);
    }
  }, []);

  const productAndVariantDetailsByIdQuery: any =
    getProductAndVariantDetailsById(selectedProductId, locId);

  const {
    resultSet: productsAndVariantsDetailsResultSet,
    isLoading: productsAndVariantsDetailsLoading,
    error: productsAndVariantsDetailsError,
  }: any = useCubeQuery(productAndVariantDetailsByIdQuery, {
    skip: !shouldFetchProductDetails,
  });

  useEffect(() => {
    if (
      productsAndVariantsDetailsError?.status === 401 ||
      productsAndVariantsDetailsError?.status === 403
    ) {
      LogoutUser();
      router.push('/', undefined, { shallow: true });
    } else {
      const data = productsAndVariantsDetailsResultSet?.loadResponses[0]?.data;
      if (data) {
        setProductDetails(data);
        setShouldFetchProductDetails(false);
      } else {
        setProductDetails([]);
      }
    }
  }, [productsAndVariantsDetailsResultSet, productsAndVariantsDetailsError]);

  useEffect(() => {
    if (productDetails?.length && !productsAndVariantsDetailsLoading) {
      // const uniqueItemsByVariantId: any = [];
      // productDetails.map((item: any) => {
      //   var findItem = uniqueItemsByVariantId.find(
      //     (x: any) =>
      //       x?.['InventoryLineItem.variantId'] ===
      //       item?.['InventoryLineItem.variantId']
      //   );
      //   if (!findItem) uniqueItemsByVariantId.push(item);
      // });

      // * 'ProdutsShopifyOptions.values' gives all conditions which belong to this shoe
      // ! Replaced uniqueItemsByVariantId with productDetails because now we will be getting variantId of different location as well
      if (productDetails?.length) {
        const uniqueConditions = productDetails[0]?.[
          'ProdutsShopifyOptions.values'
        ]
          ? productDetails[0]?.['ProdutsShopifyOptions.values']?.split(',')
          : [''];

        const defaultCondition =
          uniqueConditions[0] === 'New' ? 'New' : uniqueConditions[0];

        const uniqueImages = productDetails
          ?.map((item: any) => item?.['InventoryLineItem.imageUrl'])
          ?.filter(
            (variant: any, i: any, ar: any) =>
              ar.indexOf(variant) === i && !!variant
          );

        const currentLocationsVariants: any = productDetails?.filter(
          (variant: any) =>
            Number(variant?.['InventoryLineItem.locationId']) === Number(locId)
        );
        const differentLocationVariants: any = productDetails?.filter(
          (variant: any) =>
            Number(variant?.['InventoryLineItem.locationId']) !== Number(locId)
        );

        let mergedArray: any = [];

        if (
          currentLocationsVariants?.length ||
          differentLocationVariants?.length
        ) {
          mergedArray = [
            ...currentLocationsVariants,
            ...differentLocationVariants?.filter((diffVariant: any) => {
              const Option1 = diffVariant?.['InventoryLineItem.Option1'];
              const variantId = diffVariant?.['InventoryLineItem.variantId'];

              return !currentLocationsVariants.some((currVariant: any) => {
                const currOption1 = currVariant?.['InventoryLineItem.Option1'];
                const currVariantId =
                  currVariant?.['InventoryLineItem.variantId'];
                return currOption1 === Option1 && currVariantId === variantId;
              });
            }),
          ];
        }

        // setTotalVariants(productDetails);
        setTotalVariants(mergedArray);
        setConditions(uniqueConditions);
        setSelectedCondition(defaultCondition);
        setProductImages(uniqueImages);
      }
    } else {
      setUnavailableVariants([]);
      setAvailableVariants([]);
      setTotalVariants([]);
      setConditions([]);
      setSelectedCondition([]);
      setProductImages([]);
    }
  }, [productDetails, productsAndVariantsDetailsLoading]);

  useEffect(() => {
    if (
      (selectedCondition !== null && selectedCondition !== undefined) ||
      selectedCondition === ''
    ) {
      let unavailableSizes: any = [];
      let availableSizes: any = [];
      if (selectedCondition === '') {
        unavailableSizes = totalVariants
          ?.filter(
            (item: any) =>
              (Number(item?.['InventoryLineItem.inventoryQuantity']) <= 0 ||
                Number(item?.['InventoryLineItem.locationId']) !==
                  Number(locId)) &&
              // && item?.['InventoryLineItem.Title']?.split(' / ')
              !!item?.['InventoryLineItem.Title']
          )
          ?.map((size: any) => {
            return {
              variantId: size?.['InventoryLineItem.variantId'],
              variantSize: size?.['InventoryLineItem.Option1'],
              variantPrice: Number(size?.['InventoryLineItem.Price']),
              variantInventoryId: size?.['InventoryLineItem.inventoryitemId'],
            };
          });

        availableSizes = totalVariants
          ?.filter(
            (item: any) =>
              Number(item?.['InventoryLineItem.inventoryQuantity']) > 0 &&
              // && item?.['InventoryLineItem.Title']?.split(' / ')
              !!item?.['InventoryLineItem.Title'] &&
              Number(item?.['InventoryLineItem.locationId']) === Number(locId)
          )
          ?.map((size: any) => {
            return {
              variantId: size?.['InventoryLineItem.variantId'],
              variantSize: size?.['InventoryLineItem.Option1'],
              variantPrice: parseInt(size?.['InventoryLineItem.Price']),
              variantInventoryId: size?.['InventoryLineItem.inventoryitemId'],
              variantInventoryQuantity:
                size?.['InventoryLineItem.inventoryQuantity'],
            };
          });
      } else {
        unavailableSizes = totalVariants
          ?.filter(
            (item: any) =>
              (Number(item?.['InventoryLineItem.inventoryQuantity']) <= 0 ||
                Number(item?.['InventoryLineItem.locationId']) !==
                  Number(locId)) &&
              // item?.['InventoryLineItem.Title']?.split(' / ')?.includes(selectedCondition)
              !!item?.['InventoryLineItem.Title'] &&
              item?.['InventoryLineItem.Option2']?.trim()?.toLowerCase() ===
                selectedCondition?.trim()?.toLowerCase()
          )
          ?.map((size: any) => {
            return {
              variantId: size?.['InventoryLineItem.variantId'],
              variantSize: size?.['InventoryLineItem.Option1'],
              variantPrice: Number(size?.['InventoryLineItem.Price']),
              variantInventoryId: size?.['InventoryLineItem.inventoryitemId'],
            };
          });

        availableSizes = totalVariants
          ?.filter(
            (item: any) =>
              Number(item?.['InventoryLineItem.inventoryQuantity']) > 0 &&
              // item?.['InventoryLineItem.Title']?.split(' / ')?.includes(selectedCondition)
              !!item?.['InventoryLineItem.Title'] &&
              item?.['InventoryLineItem.Option2']?.trim()?.toLowerCase() ===
                selectedCondition?.trim()?.toLowerCase() &&
              Number(item?.['InventoryLineItem.locationId']) === Number(locId)
          )
          ?.map((size: any) => {
            return {
              variantId: size?.['InventoryLineItem.variantId'],
              variantSize: size?.['InventoryLineItem.Option1'],
              variantPrice: parseInt(size?.['InventoryLineItem.Price']),
              variantInventoryId: size?.['InventoryLineItem.inventoryitemId'],
              variantInventoryQuantity:
                size?.['InventoryLineItem.inventoryQuantity'],
            };
          });
      }

      const skuOfProduct = totalVariants
        ?.map((item: any) => item?.['InventoryLineItem.sku'])
        ?.filter((variant: any, i: any, ar: any) => ar.indexOf(variant) === i)
        ?.filter((skuItem: any) => !skuItem?.includes('('));

      setSku(skuOfProduct.join(''));

      setUnavailableVariants(unavailableSizes);
      setAvailableVariants(availableSizes);
    }
  }, [selectedCondition, totalVariants]);

  const variantHandler = (value: any, isVariantsUnavailable: any) => {
    if (isVariantsUnavailable === 'unavailable') {
      setSelectedInventoryLineItemId(value?.variantInventoryId);
      setShowLocationToolTip(!showLocationToolTip);
      return;
    } else {
      if (availableVariants && availableVariants.length > 0) {
        if (selectedVariants.includes(value)) {
          let tempVariants = [];
          tempVariants = selectedVariants.filter((data: any) => data !== value);
          setSelectedVariants(tempVariants);
        } else {
          setSelectedVariants([...selectedVariants, value]);
        }

        if (selectedVariantsId.includes(value?.variantId)) {
          let tempVariants = [];
          tempVariants = selectedVariantsId.filter(
            (data: any) => data !== value?.variantId
          );
          setSelectedVariantsId(tempVariants);
        } else {
          setSelectedVariantsId([...selectedVariantsId, value?.variantId]);
        }
      }
    }
  };

  const addProductHandler = () => {
    if (totalVariants) {
      let itemsForCart: any = [];
      let barCode: any = '';
      selectedVariants.map(async (product: any) => {
        const payloadForStore = {
          storeId: localStorage.getItem('storeId'),
          variantId: product?.variantId,
        };
        const payloadForProductDetails = {
          storeId: localStorage.getItem('storeId'),
          variantId: product?.variantId,
        };
        try {
          // const response: any = await getStoreInfoFromShopify(payloadForStore);
          const response: any = await doRequest(
            `${GET_BARCODE_OF_PRODUCT}/location/${localStorage?.getItem(
              'storeLocationId'
            )}/variant/${product?.variantId}`,
            'get',
            {}
          );
          if (!!response?.data?.barcode) {
            barCode = response?.data?.barcode || '';
            itemsForCart.push({
              inventoryLineItemId: product?.variantId,
              name: totalVariants[0]?.['ProdutsShopify.title'],
              style: sku,
              imageUrl: productImages[0],
              size: product?.variantSize,
              price: product?.variantPrice,
              barcode: barCode,
            });
            itemsForCart.map((product: any) => {
              dispatch(actions.addToCart(product));
            });
          } else {
            setErrorMessage(PRODUCT_INVENTORY_COUNT_ERROR_MSG);
            setNotificationSeverityType('warning');
            setIsVisibleMessage(true);
          }
        } catch (error: any) {
          console.log('error  in getting barcodes api', error);
          if (
            error?.response?.status === 401 ||
            error?.response?.status === 403
          ) {
            dispatch(authActions.clearUserDetails());
            LogoutUser();
            router.push('/', undefined, { shallow: true });
          }
          if (error?.response?.status === 400) {
            setErrorMessage(error?.response?.data?.message);
            setNotificationSeverityType('warning');
            setIsVisibleMessage(true);
          } else {
            setErrorMessage(NOTIFICATION_SOMETHING_WENT_WRONG);
            setNotificationSeverityType('error');
            setIsVisibleMessage(true);
          }
        }
      });
      setShowModal(false);
    }
  };

  const handleTooltipVisibility = (value: string) => {
    const visibilityOfToolTip = value === 'show' ? true : false;
    setShowLocationToolTip(visibilityOfToolTip);
  };

  const bodyOfToolTip = (value: any) => {
    return (
      showLocationToolTip && (
        <LocationsTooltip
          selectedInventoryLineItemId={selectedInventoryLineItemId}
          value={value}
        />
      )
    );
  };

  const clickAwayHandler = () => {
    handleTooltipVisibility('hide');
    setSelectedInventoryLineItemId('');
  };

  return (
    <>
      <div className='app-wrapper w-100 landing-page-wrapper'>
        <Modal
          open={showModal}
          onClose={() => setShowModal(false)}
          className='yk-add-request-modal-wrapper'
          aria-labelledby='modal-modal-title'
          aria-describedby='modal-modal-description'>
          <div className='app-wrapper add-request-modal-wrapper'>
            <div className='yk-modal-body'>
              {productsAndVariantsDetailsError ? (
                <p>Something went wrong!</p>
              ) : productsAndVariantsDetailsLoading ? (
                <div className='circular-loader-wrapper yk-modal-loader'>
                  <CircleLoader />
                </div>
              ) : (
                <>
                  {' '}
                  <div className='yk-image-info-wrapper'>
                    <div className='d-none d-sm-block d-lg-block'>
                      <div className='d-flex'>
                        <div className='image-info-card '>
                          <ImageLoader
                            src={productImages[0]}
                            fallbackImg={productImage}
                            alt='product-img'
                            className='img-fluid image-card'
                          />
                        </div>
                        <div className='product-info-wrapper'>
                          <p className='yk-product-title yk-badge-h14'>
                            {totalVariants?.[0]?.['ProdutsShopify.title'] || '--'}
                          </p>
                          <div className='product-sku-wrapper yk-badge-h16'>
                            <span className='yk-modal-title yk-badge-h16'>
                              SKU No:
                            </span>
                            <span
                              className='yk-info-text yk-badge-h16'
                              id='sku-of-product'>
                              {sku || '--'}
                            </span>
                            {sku && <CopyToClipboardComponent copyText={sku} />}
                          </div>
                          <div className='product-color-wrapper d-flex'>
                            <div className='yk-modal-title yk-badge-h16'>
                              Colorway:
                            </div>
                            <div>
                              <span
                                className='yk-info-text yk-badge-h16 yk-colorway-ellipse'
                                title={
                                  totalVariants?.[0]?.['Catalogue.colorway'] ||
                                  '--'
                                }>
                                {totalVariants?.[0]?.['Catalogue.colorway'] ||
                                  '--'}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className='d-block d-sm-none d-lg-none add-update-mobile-modal'>
                      <div className='d-flex'>
                        <div className='image-info-card'>
                          <ImageLoader
                            src={productImages[0]}
                            fallbackImg={productImage}
                            alt='product-img'
                            className='img-fluid'
                          />
                        </div>
                        <div>
                          <p className='yk-product-title yk-badge-h14'>
                            {totalVariants?.[0]?.['ProdutsShopify.title'] || '--'}
                          </p>
                        </div>
                      </div>
                      <div className='product-info-wrapper'>
                        <div className='product-sku-wrapper yk-badge-h16 d-flex'>
                          <span className='yk-modal-title yk-badge-h16'>
                            SKU No:
                          </span>
                          <span
                            className='yk-info-text yk-badge-h16'
                            id='sku-of-product1'>
                            {sku || '--'}
                          </span>
                          {sku && <CopyToClipboardComponent copyText={sku} />}
                        </div>
                        <div className='product-color-wrapper d-flex'>
                          <div className='yk-modal-title yk-badge-h16 '>
                            Colorway:
                          </div>
                          <div>
                            <span
                              className='yk-info-text yk-badge-h16 yk-colorway-ellipse'
                              title={
                                totalVariants?.[0]?.['Catalogue.colorway'] || '--'
                              }>
                              {totalVariants?.[0]?.['Catalogue.colorway'] || '--'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className='modal-body-wrapper'>
                    {!!conditions[0] && (
                      <div className='yk-card-title-wrapper'>
                        <p className='yk-card-title yk-badge-h16'>Condition</p>
                      </div>
                    )}

                    {!!conditions[0] && (
                      <div className='product-size-card-wrapper  add-request-cards-wrapper'>
                        {conditions &&
                          conditions?.length > 0 &&
                          conditions?.map((name: any, index: any) => {
                            return (
                              <div
                                className='product-size-cards condition-size-cards'
                                key={index}
                                onClick={() => setSelectedCondition(name)}
                                title={name}>
                                <div
                                  className={`card ${
                                    selectedCondition === name ? 'selected' : ''
                                  }`}>
                                  <div className='card-body'>
                                    <h6 className='product-size-text yk-title-h17'>
                                      {!!name ? name : 'No Condition'}
                                    </h6>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                      </div>
                    )}
                    <div className='yk-card-title-wrapper'>
                      <p className='yk-card-title yk-badge-h16'>Size</p>
                    </div>
                    <div
                      className={`product-size-card-wrapper row row-cols-5 text-center ${
                        !!conditions[0] && selectedInventoryLineItemId
                          ? 'mt-3'
                          : selectedInventoryLineItemId
                          ? 'ykch-tooltipSize'
                          : ''
                      }`}>
                      <ClickAwayListener onClickAway={clickAwayHandler}>
                        <div className='click-away-listener-wrapper YKCH-tooltipListner'>
                          {unavailableVariants?.length > 0 &&
                            unavailableVariants.map(
                              (variant: any, index: any) => {
                                return (
                                  <Tooltip
                                    PopperProps={{
                                      disablePortal: true,
                                    }}
                                    onClose={clickAwayHandler}
                                    open={
                                      showLocationToolTip &&
                                      selectedInventoryLineItemId ===
                                        variant?.variantInventoryId
                                    }
                                    disableFocusListener
                                    disableHoverListener
                                    disableTouchListener
                                    title={bodyOfToolTip(variant)}
                                    placement='right'
                                    arrow
                                    key={index}>
                                    <div
                                      className='product-size-cards yk-fiveOrder'
                                      key={index}
                                      onClick={() =>
                                        variantHandler(variant, 'unavailable')
                                      }
                                      style={{ display: 'inline-block' }}>
                                      <div
                                        className={`card disabled ${
                                          selectedInventoryLineItemId ===
                                          variant?.variantInventoryId
                                            ? 'activeDisabledItem'
                                            : ''
                                        }`}>
                                        <div className='card-body'>
                                          <h6 className='product-size-text yk-title-h17'>
                                            {variant?.variantSize || '--'}
                                          </h6>
                                          <p className='product-price-text yk-badge-h8'>
                                            {variant?.variantPrice
                                              ? convertPriceToUSFormat(
                                                  variant?.variantPrice?.toFixed(
                                                    2
                                                  )
                                                )
                                              : '--'}
                                          </p>
                                        </div>
                                      </div>
                                    </div>
                                  </Tooltip>
                                );
                              }
                            )}
                        </div>
                      </ClickAwayListener>

                      {availableVariants?.length > 0 &&
                        availableVariants.map((variant: any) => {
                          return (
                            <div
                              className='product-size-cards yk-fiveOrder'
                              key={variant?.variantId}
                              onClick={() =>
                                variantHandler(variant, 'available')
                              }>
                              <div
                                className={`card ${
                                  selectedVariantsId?.includes(
                                    variant?.variantId
                                  )
                                    ? 'selected'
                                    : ''
                                }`}>
                                <div className='card-body'>
                                  <h6 className='product-size-text'>
                                    {variant?.variantSize || '--'}
                                  </h6>
                                  <p className='product-price-text yk-modal-text mb-1'>
                                    {variant?.variantPrice
                                      ? convertPriceToUSFormat(
                                          variant?.variantPrice?.toFixed(2)
                                        )
                                      : '--'}
                                  </p>
                                  <p className='product-price-text yk-modal-text'>
                                    QTY -{' '}
                                    {variant?.variantInventoryQuantity
                                      ? variant?.variantInventoryQuantity
                                      : '--'}
                                  </p>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                    </div>
                  </div>
                  <div className='add-btn-wrapper'>
                    <button
                      className='btn modal-add-btn yk-badge-h7'
                      type='button'
                      onClick={addProductHandler}
                      disabled={!selectedVariants.length}>
                      ADD
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </Modal>
      </div>
    </>
  );
};

export default UpdatedAddRequest;
