import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import { useCubeQuery } from '@cubejs-client/react';
import { getAvailableLocations } from 'middleware/cubejs-wrapper/cubejs-query';
import { LogoutUser } from 'components/common/logout';
import { useRouter } from 'next/router';
import storeIcon from 'assets/images/menu-icons/store-icon.svg';
import browserIcon from 'assets/images/menu-icons/browser-icon.svg';
import CircleLoader from 'components/common/loader/circular-loader';

const LocationsTooltip = (props: any) => {
  const { selectedInventoryLineItemId, value } = props;

  const [locations, setLocations] = useState<any>([]);
  const [shouldFetchTooltip, setShouldFetchTooltip] = useState<any>(false);

  const router = useRouter();

  const locationsQuery: any = getAvailableLocations(
    selectedInventoryLineItemId
  );

  useEffect(() => {
    if (selectedInventoryLineItemId) {
      setShouldFetchTooltip(true);
    }
  }, []);

  const {
    resultSet: locationsResultSet,
    isLoading: locationsIsLoading,
    error: locationsError,
  }: any = useCubeQuery(locationsQuery, { skip: !shouldFetchTooltip });

  useEffect(() => {
    if (locationsError?.status === 401 || locationsError?.status === 403) {
      LogoutUser();
      router.push('/', undefined, { shallow: true });
    } else {
      const data = locationsResultSet?.loadResponses[0]?.data;
      if (data) {
        setLocations(data[0]);
        setShouldFetchTooltip(false);
      } else {
        setLocations([]);
      }
    }
  }, [locationsResultSet, locationsError]);

  const allLocations = locations?.['AvailableLocations.Name']
    ?.toString()
    ?.replaceAll(',', ', ');

  return (
    <>
      {locationsError ? (
        <p>Something went wrong!</p>
      ) : locationsIsLoading ? (
        <div className='circular-loader-wrapper yk-tooltip-loader'>
          <CircleLoader />
        </div>
      ) : (
        <div className='location-tooltip-wrapper'>
          <div className='location-data-wrapper'>
            <div className='tooltip-img-wrapper'>
              <div className='tooltip-img'>
                <Image
                  src={storeIcon}
                  alt='store-img'
                  className='img img-fluid'
                />
              </div>
            </div>
            <span className='store-content-wrapper'>
              <h6 className='location-title yk-badge-h14'>In Stores:</h6>
              <p
                className='location-sub-title yk-badge-h16'
                title={locations?.['AvailableLocations.Name'] || '--'}>
                {allLocations || '--'}
              </p>
            </span>
          </div>
          <div className='location-data-wrapper online-store-data-wrapper'>
            <div className='tooltip-img-wrapper'>
              <div className='tooltip-img'>
                <Image
                  src={browserIcon}
                  alt='browser-img'
                  className='img img-fluid'
                />
              </div>
            </div>
            <span className='store-content-wrapper'>
              <h6 className='location-title yk-badge-h14'>Online:</h6>
              <p className='location-sub-title yk-badge-h16'>
                {locations?.['AvailableLocations.location']
                  ? locations?.['AvailableLocations.location'] === 'Online'
                    ? 'Yes'
                    : 'No'
                  : '--'}
              </p>
            </span>
          </div>
        </div>
      )}
    </>
  );
};

export default LocationsTooltip;
