import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import get from 'lodash.get';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import { format } from 'date-fns';
import Loader from 'components/common/loader';
import { getShoesizeWarehouseKPIQuery } from 'middleware/cubejs-wrapper/cubejs-query';
import { STATUS_TYPE } from '../constants';
import { KPI_DATE_FORMAT } from 'utils/constants';
import { LogoutUser } from 'components/common/logout';
import checkedInImg from 'assets/images/checked-in.svg';
import CheckedOutImg from 'assets/images/checked-out.svg';
import pendingImg from 'assets/images/pending.svg';
import soldOutImg from 'assets/images/sold-out.svg';
import CircleLoader from 'components/common/loader/circular-loader';

const KpiStatus = () => {
  const router = useRouter();
  const [shoesizeKPIData, setShoesizeKPIData] = useState([]);
  const storeId = localStorage.getItem('storeId');
  const userId = localStorage.getItem('user-Id');
  const locationId = localStorage.getItem('storeLocationId');
  const shoesizeKPIQuery: any = getShoesizeWarehouseKPIQuery(
    storeId,
    locationId,
    format(new Date(), KPI_DATE_FORMAT),
    format(new Date(), KPI_DATE_FORMAT),
    userId
  );

  const {
    resultSet: shoesizeKPIResultSet,
    isLoading: isshoesizeKPILoading,
    error: shoesizeKPIError,
  }: any = useCubeQuery(shoesizeKPIQuery, { subscribe: true });

  useEffect(() => {
    if (shoesizeKPIError?.status === 401 || shoesizeKPIError?.status === 403) {
      LogoutUser();
      router.push('/', undefined, { shallow: true });
    } else {
      setShoesizeKPIData(shoesizeKPIResultSet?.loadResponses[0]?.data);
    }
  }, [shoesizeKPIResultSet, shoesizeKPIError, router]);

  const renderKpi = (
    isLaodingData: any,
    imagePath: any,
    statusType: string,
    data: any
  ) => {
    return (
      <>
        <div className='col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12'>
          <div className='card status-card pending mb-1'>
            <div className='card-body shoe-card-info pt-1 pb-0 ps-2 pe-2'>
              <div className='card-heading-wrapper'>
                <div className='d-flex align-items-center'>
                  <div className='icon-wrapper'>
                    <Image src={imagePath} alt='' className='img-fluid' />
                  </div>
                  <div className='flex-grow-1'>
                    <div className='status-info'>{statusType}</div>
                    {isshoesizeKPILoading ? (
                      <div className='YKCH-loader'>
                        <CircleLoader />
                      </div>
                    ) : (
                      <h5 className='status-value'>{data}</h5>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  };

  return (
    <div className='status-wrapper'>
      <div className='row'>
        {renderKpi(
          isshoesizeKPILoading,
          pendingImg,
          STATUS_TYPE?.PENDING,
          shoesizeKPIData?.length &&
            shoesizeKPIData[0] &&
            get(shoesizeKPIData[0], ['WarehouseKPICount.pendingCount']) !== null
            ? get(shoesizeKPIData[0], ['WarehouseKPICount.pendingCount'])
            : 0
        )}
        {renderKpi(
          isshoesizeKPILoading,
          CheckedOutImg,
          STATUS_TYPE?.CHECKED_OUT,
          shoesizeKPIData?.length &&
            shoesizeKPIData[0] &&
            get(shoesizeKPIData[0], ['WarehouseKPICount.checkoutCount']) !==
              null
            ? get(shoesizeKPIData[0], ['WarehouseKPICount.checkoutCount'])
            : 0
        )}
        {renderKpi(
          isshoesizeKPILoading,
          checkedInImg,
          STATUS_TYPE?.CHECKED_IN,
          shoesizeKPIData?.length &&
            shoesizeKPIData[0] &&
            get(shoesizeKPIData[0], ['WarehouseKPICount.checkinCount']) !== null
            ? get(shoesizeKPIData[0], ['WarehouseKPICount.checkinCount'])
            : 0
        )}
        {renderKpi(
          isshoesizeKPILoading,
          soldOutImg,
          STATUS_TYPE?.SOLD_OUT,
          shoesizeKPIData?.length &&
            shoesizeKPIData[0] &&
            get(shoesizeKPIData[0], ['WarehouseKPICount.soldCount']) !== null
            ? get(shoesizeKPIData[0], ['WarehouseKPICount.soldCount'])
            : 0
        )}
      </div>
    </div>
  );
};

export default KpiStatus;
