import React, { useEffect, useState } from 'react';
import type { NextPage } from 'next';
import Image from 'next/image';
import Axios from 'axios';
import jwt_decode from 'jwt-decode';
import { getSalesAssociate } from 'services/shared';
import dummyUserImg from 'assets/images/user-img.png';
import bannerImg from 'assets/images/request-details-banner.png';

const ProfilePage: NextPage = () => {
  const [imageUrl, setImageUrl] = useState<any>('');
  const [userData, setUserData] = useState<any>({});
  let userDetails = { user_id: '' };

  userDetails = jwt_decode(localStorage.getItem('jwt-token') || '{}');

  useEffect(() => {
    getUserById();
  }, []);

  const getUserById = async () => {
    await getSalesAssociate(userDetails?.user_id).then((response) => {
      setUserData(response?.data);
    });
  };

  useEffect(() => {
    Axios.get('https://graph.microsoft.com/v1.0/me/photo/$value', {
      headers: {
        Authorization: `Bearer ${localStorage?.getItem('access-token')}`,
        'Content-Type': 'image/jpeg',
      },
      responseType: 'blob',
    }).then((o) => {
      const url = window.URL || window.webkitURL;
      const blobUrl = url.createObjectURL(o.data);
      setImageUrl(blobUrl);
    });
  }, []);

  return (
    <>
      <div className='app-wrapper w-100 profile-details-page-wrapper'>
        <div className='page-inner-wrapper'>
          <div className='container-fluid'>
            <div className='user-area-wrapper'>
              <div className='request-details-banner-wrapper setting-details-banner profile-details-banner'>
                <div className='yk-request-banner-wrapper'>
                  <Image
                    src={bannerImg}
                    alt=''
                    className='w-100 yk-request-banner img-fluid'
                  />
                </div>
                <div className='YKCH-newSettingERA d-flex justify-content-start align-items-center'>
                  <div className='user-img-wrapper'>
                    <Image
                      src={imageUrl || dummyUserImg}
                      alt='user-img'
                      className='yk-request-banner-user-img img-fluid'
                      height={173}
                      width={173}
                    />
                  </div>

                  <div className='profile-heading-wrapper ykch-leftAlignings'>
                    <h3 className='profile-name'>
                      {userData?.fullName || '--'}
                    </h3>
                    <p className='profile-request-text'>Profile</p>
                  </div>
                </div>
              </div>
              <div className='user-area-inner-wrapper'>
                <div className='yk-profile-form'>
                  <div className='form-wrapper'>
                    <div className='yk-form-title-text'>Primary Details</div>
                    <div className='row'>
                      <div className='col-lg-6'>
                        <form>
                          <div className='form-group'>
                            <label className='form-label'>Full Name</label>
                            <input
                              type='email'
                              className='form-control'
                              id='exampleInputEmail1'
                              aria-describedby='emailHelp'
                              value={userData?.fullName || '--'}
                              disabled
                            />
                          </div>
                        </form>
                      </div>
                      <div className='col-lg-6'>
                        <form>
                          <div className='form-group'>
                            <label className='form-label'>Employee ID</label>
                            <input
                              type='email'
                              className='form-control'
                              id='exampleInputEmail1'
                              aria-describedby='emailHelp'
                              disabled
                            />
                          </div>
                        </form>
                      </div>
                      <div className='col-lg-6'>
                        <form>
                          <div className='form-group'>
                            <label className='form-label'>Mail ID</label>
                            <input
                              type='email'
                              className='form-control'
                              id='exampleInputPassword1'
                              value={userData?.email || '--'}
                              disabled
                            />
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProfilePage;
