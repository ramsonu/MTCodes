import React from 'react';
import Link from 'next/link';
import type { NextPage } from 'next';
import logo1 from 'assets/images/yk-kiosk-logo.png';
import YKStdLogo from 'assets/images/yk-std-logo.svg';
import cartIcon from 'assets/images/cart-icon.svg';
import Image from 'next/image';
import leftArrowIcon from 'assets/images/left-arrow-icon.png';
import { useRouter } from 'next/router';
import { useSelector, useDispatch } from 'react-redux';
import { Badge } from '@mui/material';
import { actions } from 'store/reducers/kiosk';
import { SEARCH_WTIH_FILTERS_REQUEST } from 'actions/kiosk';

const Header: NextPage = () => {
  const { cart, filterTypes } = useSelector((state: any) => state.kiosk);
  const router = useRouter();
  const dispatch = useDispatch();
  const isLandingPage = ['/kiosk'].includes(router.pathname);
  let isKioskFeaturePage = ['/kiosk/features'].includes(router.pathname);
  const isKioskLocationPage = ['/kiosk/location'].includes(router.pathname);
  if (isKioskLocationPage) {
    isKioskFeaturePage = true;
  }
  if (isLandingPage) {
    return null;
  }
  const goBackHandler = () => {
    router.back();
    if (filterTypes?.title !== '') {
      dispatch(
        actions.setFilters({
          filterItem: '',
          filterType: 'title',
        })
      );
      dispatch(
        actions.setFiltersForCube({
          filterItem: '',
          filterType: 'title',
        })
      );
    }
  };
  return (
    <>
      <div className='container-fluid yk-container-fluid'>
        <div className='row'>
          <div className='col-lg-12 col-md-12'>
            <div className='kiosk-top-header-wrapper'>
              {!isKioskFeaturePage && (
                <div className='back-btn-wrapper'>
                  <button
                    className='btn btn-transparent arrow-icon-wrapper'
                    onClick={goBackHandler}
                  >
                    <Image
                      src={leftArrowIcon}
                      alt='left-arrow-icon'
                      className='Image-fluid'
                    />
                  </button>
                </div>
              )}
              <div className='top-logo-wrapper'>
                <a className='navbar-brand'>
                  <Image
                    src={YKStdLogo}
                    alt='yk-kiosk-logo'
                    className='Image-fluid'
                  />
                </a>
              </div>
              {!isKioskLocationPage && (
                <div className='cart-icon-wrapper'>
                  <div className='shopping-cart-wrapper d-flex'>
                    <a className='navbar-brand'>
                      <Badge
                        badgeContent={cart?.length}
                        className='cart-count-badge'
                        overlap='circular'
                      >
                        <Image
                          src={cartIcon}
                          alt='yk-shopping-cart-logo'
                          className='Image-fluid yk-shopping-cart-logo'
                          onClick={() => router.push('/kiosk/cart')}
                        />
                      </Badge>
                    </a>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Header;
