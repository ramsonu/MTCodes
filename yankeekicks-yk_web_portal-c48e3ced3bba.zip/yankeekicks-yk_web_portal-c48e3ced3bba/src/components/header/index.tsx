export { default as KioskHeader } from './kiosk';
export { default as ShoesizeHeader } from './shoesize';
export { default as WarehouseHeader } from './warehouse';
