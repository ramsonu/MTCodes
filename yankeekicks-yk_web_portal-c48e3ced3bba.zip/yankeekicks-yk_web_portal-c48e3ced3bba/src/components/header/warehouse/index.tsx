import React from 'react';
import type { NextPage } from 'next';

const Header: NextPage = () => {
  return (
    <>
      <div className='container-fluid yk-container-fluid'>Warehouse header</div>
    </>
  );
};
export default Header;
