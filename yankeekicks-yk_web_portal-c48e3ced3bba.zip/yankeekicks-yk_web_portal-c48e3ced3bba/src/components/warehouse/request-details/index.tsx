/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabPanel from '@mui/lab/TabPanel';
import { format } from 'date-fns';
import get from 'lodash.get';
import { useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import { getRequestInfo } from 'middleware/cubejs-wrapper/cubejs-query';
import { withRouter } from 'next/router';
import Modal from '@mui/material/Modal';
import Tabs, { tabsClasses } from '@mui/material/Tabs';
import { FNS_US_DATE_FORMAT } from 'utils/constants';
import { LogoutUser } from 'components/common/logout';
import Notification from 'components/common/notification';
import ImageLoader from 'components/common/image-loader';
import CircleLoader from 'components/common/loader/circular-loader';
import CopyToClipboardComponent from 'components/common/copyToClipboard';
import ScannerModal from '../modals/scanner-modal';
import CompleteCheckoutModal from '../modals/complete-checkout-modal';
import MissingShoesModal from '../modals/missing-shoes-modal';
import ScannerErrorModal from '../modals/scanner-error-modal';
import { doRequest } from 'utils/request';
import { BARCODE_SCAN_CHECKOUT } from 'services/apiUrl';
import {
  convertPriceToUSFormat,
  getAllUpperCase,
  getDate,
  getTime,
  getTrimmedText,
} from 'utils/util';
import { SUCCESS_MESSAGE, WAREHOUSE_STATUS, WARNING_MODAL } from '../constants';
import productImg from 'assets/images/products/dummy.svg';
import binIcon from 'assets/images/bin-icon.svg';
import rackIcon from 'assets/images/rack-icon.svg';

const RequestDetails = (props: any) => {
  const { id } = props;

  const router = useRouter();
  const storeId = localStorage.getItem('storeId');
  const locationId = localStorage.getItem('storeLocationId');
  const { requestDetailsToggle } = useSelector((state: any) => state.warehouse);

  const [showLessDescription, setShowLessDescription] = useState(true);
  const [showLessColorWay, setShowLessColorWay] = useState(true);
  const [data, setData] = useState<any>([]);
  const [index, setIndex] = useState<any>(0);
  const [value, setValue] = useState(0);
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [severityType, setSeverityType] = useState<string>('');
  const [message, setMessage] = useState<any>('');
  const [isModalVisible, setIsModalVisible] = useState<boolean>(false);
  const [itemsLength, setItemsLength] = useState<any>({
    soldItemsLength: 0,
    availableItemsLength: 0,
  });
  const [availableItems, setAvailableItems] = useState<any>([]);
  const [checkoutSummaryTableData, setCheckoutSummaryTableData] = useState<any>(
    []
  );
  const [barcodesList, setBarcodesList] = useState<any>([]);
  const [showScanModal, setShowScanModal] = useState<boolean>(false);
  const [showScannerErrorModal, setShowScannerErrorModal] =
    useState<boolean>(false);
  const [showSummaryModal, setShowSummaryModal] = useState<boolean>(false);
  const [barCodeScanResult, setBarCodeScanResult] = useState<any>('');
  const [isBarcodeLoading, setIsBarcodeLoading] = useState<boolean>(false);
  const [scannerIndex, setScannerIndex] = useState<any>(0);
  const [isMarkMissingModal, setIsMarkMissingModal] = useState<boolean>(false);
  const [missingBarcode, setMissingBarcode] = useState<any>('');
  const [showCountAlert, setShowCountAlert] = useState<boolean>(false);
  const [showItemExistAlert, setShowItemExistAlert] = useState<boolean>(false);
  const [showCountAlertMsg, setShowCountAlertMsg] = useState<any>('');
  const [isManualCheckout, setIsManualCheckout] = useState<any>(false);

  const requestDetailsInfo: any = getRequestInfo(
    props.router.query.requestId,
    storeId,
    locationId
  );
  const {
    resultSet: searchResultSet,
    isLoading: searchResultsLoading,
    error: requestDetailsError,
  }: any = useCubeQuery(requestDetailsInfo);

  useEffect(() => {
    if (
      requestDetailsError?.status === 401 ||
      requestDetailsError?.status === 403
    ) {
      LogoutUser();
      router.push('/', undefined, { shallow: true });
    } else {
      let result = searchResultSet?.loadResponses[0]?.data;
      if (result) {
        let soldItems: any = result?.filter(
          (item: any) => item['WarehouseTab.status'] === 'Sold'
        );
        let missingItems: any = result?.filter(
          (item: any) => item['WarehouseTab.status'] === 'Missing'
        );
        let foundItems: any = result?.filter(
          (item: any) => item['WarehouseTab.status'] === 'Found'
        );
        let remainingItems: any = result?.filter(
          (item: any) =>
            !(
              item['WarehouseTab.status'] === 'Sold' ||
              item['WarehouseTab.status'] === 'Missing' ||
              item['WarehouseTab.status'] === 'Found'
            )
        );
        let appendSold = remainingItems?.concat(soldItems);
        let appendMissing = appendSold?.concat(missingItems);
        let appendFound = appendMissing?.concat(foundItems);
        setData(appendFound);
        setAvailableItems(remainingItems);
        setItemsLength({
          soldItemsLength: soldItems?.length,
          availableItemsLength: remainingItems?.length,
        });
      }
    }
  }, [searchResultSet, requestDetailsError, router]);

  useEffect(() => {
    if (router.query.index) {
      setIndex(parseInt(props.router.query.index));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [router.query]);

  // if user wants to leave in middle bulk request
  useEffect(() => {
    if (index !== 0) {
      setIsModalVisible(true);
    }
    if (requestDetailsToggle && index === 0) {
      router.push('/warehouse');
    }
  }, [requestDetailsToggle]); // eslint-disable-line react-hooks/exhaustive-deps

  // single request barcode scan check out
  useEffect(() => {
    if (barCodeScanResult?.length > 0 && availableItems?.length === 1) {
      if (
        compareBarcode(
          availableItems?.[index]?.['WarehouseTab.barcode'],
          barCodeScanResult
        )
      ) {
        const scanCheckOut = async () => {
          const barcode = [barCodeScanResult];
          try {
            setIsBarcodeLoading(true);
            const response = await doRequest(
              `${BARCODE_SCAN_CHECKOUT}/${props.router.query.requestId}`,
              'post',
              barcode,
              ''
            );
            if (response) {
              setShowScanModal(false);
              setIsBarcodeLoading(false);
              setBarCodeScanResult('');
              setShowScannerErrorModal(false);
              setIsVisibleMessage(true);
              setSeverityType('success');
              setMessage(
                getToastMsg(
                  response?.data?.[0]?.status === WAREHOUSE_STATUS.CHECKOUT
                    ? SUCCESS_MESSAGE.CHECK_OUT_SUCCESS_MSG
                    : SUCCESS_MESSAGE.CHECK_IN_SUCCESS_MSG
                )
              );
            }
            router.push('/warehouse');
          } catch (error: any) {
            console.log('api error in Scan qr', error);
            if (
              error?.response?.status === 401 ||
              error?.response?.status === 403
            ) {
              LogoutUser();
              router.push('/', undefined, { shallow: true });
            }
            setIsBarcodeLoading(false);
            setShowScanModal(false);
            setShowScannerErrorModal(false);
            setIsVisibleMessage(true);
            setSeverityType('error');
            setMessage(
              getToastMsg(
                error?.response?.data?.message
                  ? error?.response?.data?.message
                  : SUCCESS_MESSAGE.ERROR_MSG
              )
            );
          }
        };
        scanCheckOut();
      } else {
        setShowScannerErrorModal(true);
      }
    }

    return () => {
      setBarCodeScanResult('');
      // setIsBarcodeLoading(false);
    };
  }, [barCodeScanResult]);

  //  scan multiple barcodes
  /*useEffect(() => {
    const barcode: any = [...barcodesList];
    if (barCodeScanResult?.length > 0) {
      if (
        compareBarcode(
          availableItems?.[index]?.['WarehouseTab.barcode'],
          barCodeScanResult
        )
      ) {
        barcode.push(barCodeScanResult);
        //  to increase index value
        if (index < availableItems?.length - 1) {
          setBarcodesList(barcode);
          setShowCountAlert(true);
          setShowCountAlertMsg(
            `${barcode?.length} of ${availableItems?.length}`
          );
          setBarCodeScanResult('');
          setIndex(index + 1);
        }
        if (index < availableItems?.length) {
          setBarcodesList(barcode);
          setBarCodeScanResult('');
          setScannerIndex(index + 1);
        }

        // to show auto summary modal
        if (
          index === availableItems?.length - 1 &&
          availableItems?.length > 1
        ) {
          setShowSummaryModal(true);
        }
      } else {
        // to show scanner error modal
        // setBarCodeScanResult('');
        setShowScannerErrorModal(true);
      }
    } else {
      // setShowScanModal(false);
    }
  }, [barCodeScanResult, index]);*/

  //  scan multiple barcodes with random scan
  useEffect(() => {
    const barcode: any = [...barcodesList];
    if (barCodeScanResult?.length > 0) {
      if (checkRequestedBarcodes(barCodeScanResult)) {
        if (!barcode.includes(barCodeScanResult)) {
          barcode.push(barCodeScanResult);
          setBarcodesList(barcode);
        } else {
          console.log('already exit');
          setShowItemExistAlert(true);
        }
        if (barcode?.length !== availableItems?.length) {
          setShowScanModal(true);
          setShowCountAlert(true);
          setShowCountAlertMsg(
            `${barcode?.length} of ${availableItems?.length}`
          );
        }
        // to show auto summary modal
        if (
          (barcode?.length === availableItems?.length ||
            barcodesList?.length === availableItems?.length) &&
          availableItems?.length > 1
        ) {
          setShowSummaryModal(true);
        }
      } else {
        // to show scanner error modal
        // setBarCodeScanResult('');
        setShowScannerErrorModal(true);
      }
    }
  }, [barCodeScanResult]);

  useEffect(() => {
    if (isManualCheckout) {
      const markManualCheckInOut = () => {
        const randomNumber = Math.floor(Math.random() * availableItems?.length);
        const randomObject = availableItems[randomNumber];
        const isBarcodeAvaliable = checkRequestedBarcodes(
          randomObject?.['WarehouseTab.barcode']
        );
        if (isBarcodeAvaliable) {
          const barcode: any = [...barcodesList];
          if (!barcode.includes(randomObject?.['WarehouseTab.barcode'])) {
            barcode.push(randomObject?.['WarehouseTab.barcode']);
            setBarCodeScanResult(randomObject?.['WarehouseTab.barcode']);
            setBarcodesList(barcode);
            setShowScannerErrorModal(false);
            setIsManualCheckout(false);
          } else {
            // recheck for barcode
            markManualCheckInOut();
          }
        }
      };
      markManualCheckInOut();
    }
  }, [isManualCheckout]);

  const manualCheckInOutClickHandler = () => {
    setIsManualCheckout(true);
  };

  //  filter out the records to be sent to summary
  useEffect(() => {
    if (barcodesList?.length === availableItems?.length) {
      const filteredData = availableItems.filter((item: any, index: any) =>
        barcodesList.includes(item?.['WarehouseTab.barcode'])
      );
      setCheckoutSummaryTableData(filteredData);
    }
  }, [barcodesList]);

  // to check whether the barcodes are requested or not
  const checkRequestedBarcodes = (scannedBarcode: string) => {
    let isAvailable = false;
    isAvailable = availableItems?.some((elements: any) => {
      return elements['WarehouseTab.barcode'] == scannedBarcode;
    });
    return isAvailable;
  };

  // to switch tabs
  const tabHandler = (index: any) => {
    setIndex(index);
    setValue(index);
  };

  // to handle index and open scanner component
  const indexHandler = () => {
    if (scannerIndex < availableItems?.length) {
      setShowScanModal(true);
    }
  };

  //  compare requested barcode and scanned barcode
  const compareBarcode = (requestBarcode: string, scannedBarcode: string) => {
    let correctBarcodes = false;
    if (requestBarcode?.toLowerCase() === scannedBarcode?.toLowerCase()) {
      correctBarcodes = true;
    }
    return correctBarcodes;
  };

  const handleSnackbarClose = () => {
    setIsVisibleMessage(false);
  };

  const getToastMsg = (msg: string) => {
    return <h3 className='toast-msg'>{msg}</h3>;
  };

  const closeModal = (type: string) => {
    setIsModalVisible(false);
    if (type === 'leave') {
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setMessage(getToastMsg(SUCCESS_MESSAGE.REQUEST_WARNING));
      setTimeout(() => router.push('/warehouse'), 3000);
    }
  };

  const isCurrentIndexSold: any =
    index === data?.length - 1 &&
    get(data[data?.length - 1], ['WarehouseTab.status']) === 'Sold'
      ? true
      : false;

  const markMissingPairHandler = (missedBarcode: string) => {
    setMissingBarcode(missedBarcode);
    setIsMarkMissingModal(true);
  };

  /* const manualCheckout = () => {
    if (availableItems?.length === 1) {
      setBarCodeScanResult(data?.[index]?.['WarehouseTab.barcode']);
    } else {
      const manualscan: any = [...barcodesList];
      manualscan.push(data?.[index]?.['WarehouseTab.barcode']);
      setBarcodesList(manualscan);
      setShowCountAlertMsg(
        `${manualscan?.length} of ${availableItems?.length}`
      );
      setShowCountAlert(true);
      setShowScannerErrorModal(false);
      if (index < availableItems?.length - 1) {
        setIndex(index + 1);
      }
      if (index < availableItems?.length) {
        setScannerIndex(index + 1);
      }
      if (index === availableItems?.length - 1 && availableItems?.length > 1) {
        setShowSummaryModal(true);
      }
    }
  };*/

  const closeButtonHandler = () => {
    setBarCodeScanResult('');
    setIndex(0);
    setScannerIndex(0);
    setBarcodesList([]);
    setShowCountAlertMsg('');
    setShowCountAlert(false);
    setShowScanModal(false);
    setIsBarcodeLoading(false);
    setCheckoutSummaryTableData([]);
  };
  const getActionStatus = (status: string) => {
    if (status === WAREHOUSE_STATUS.PENDING) {
      return WAREHOUSE_STATUS.CHECK__OUT;
    }
    if (status === WAREHOUSE_STATUS.CHECKOUT) {
      return WAREHOUSE_STATUS.CHECK__IN;
    }
  };

  return (
    <>
      {requestDetailsError ? (
        <p>Something went wrong!</p>
      ) : searchResultsLoading ? (
        <div className='circular-loader-wrapper request-details-loader-wrapper'>
          <CircleLoader />
        </div>
      ) : (
        <div className='app-wrapper w-100 warehouse-request-details-page-wrapper'>
          <div className='tabs-wrapper'>
            <div className='product-tabs-wrapper'>
              <Box sx={{ width: '100%', typography: 'body1' }}>
                <TabContext value={value.toString()}>
                  <div className='container-fluid'>
                    <div className='row'>
                      <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                        {data?.length > 1 && (
                          <div className='product-name-tab-wrapper'>
                            <Box
                              sx={{
                                flexGrow: 1,
                                maxWidth: { xs: 400, sm: 480 },
                                bgcolor: 'background.paper',
                              }}>
                              <Tabs
                                variant='scrollable'
                                scrollButtons
                                aria-label='visible arrows tabs example'
                                sx={{
                                  [`& .${tabsClasses.scrollButtons}`]: {
                                    '&.Mui-disabled': { opacity: 0.3 },
                                  },
                                }}>
                                {data?.length > 1 &&
                                  data?.map((item: any, indx: any) => {
                                    return (
                                      <Tab
                                        label={item['WarehouseTab.itemName']}
                                        key={indx}
                                        onClick={() => tabHandler(indx)}
                                        className={
                                          index === indx ? 'active' : ''
                                        }
                                      />
                                    );
                                  })}
                              </Tabs>
                            </Box>
                          </div>
                        )}
                      </div>

                      <div className='col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12'>
                        <TabPanel value={value.toString()}>
                          <div className='tab-content-inner-wrapper'>
                            <div className='tab-section-heading'>
                              <div className='yk-requestdetailsHeadingWrapper'>
                                <h3 className='tab-heading yk-badge-h11 me-4'>
                                  {/* {get(data[0], ['WarehouseTab.status']) ===
                                  'Pending' && ' Check Out Request'}
                                {get(data[0], ['WarehouseTab.status']) ===
                                  'CheckOut' && ' Check In Request'} */}

                                  {isCurrentIndexSold
                                    ? 'Sold'
                                    : get(data[index], [
                                        'WarehouseTab.status',
                                      ]) === 'Sold'
                                    ? 'Sold'
                                    : get(data[index], [
                                        'WarehouseTab.status',
                                      ]) === 'Pending'
                                    ? 'Check Out Request'
                                    : get(data[index], [
                                        'WarehouseTab.status',
                                      ]) === 'CheckOut'
                                    ? 'Check In Request'
                                    : get(data[index], [
                                        'WarehouseTab.status',
                                      ]) === 'CheckIn'
                                    ? 'Check In Complete'
                                    : get(data[index], [
                                        'WarehouseTab.status',
                                      ]) === 'Missing'
                                    ? 'Missing Pair'
                                    : get(data[index], [
                                        'WarehouseTab.status',
                                      ]) === 'Found'
                                    ? 'Found'
                                    : ''}
                                </h3>
                                <div className='product-content-wrapper yk-requestIdDetails mb-0'>
                                  <div className='product-details yk-badge-h16 mb-0'>
                                    <span className='brand-text yk-badge-h16'>
                                      Request ID:
                                    </span>
                                    <span
                                      className='brand-value yk-badge-h16'
                                      id='requestId'>
                                      {get(data[index], [
                                        'WarehouseTab.requestNumber',
                                      ]) || '-'}
                                    </span>
                                    <CopyToClipboardComponent
                                      copyText={get(data[index], [
                                        'WarehouseTab.requestNumber',
                                      ])}
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className='dFlexSpaceBetween yk-associateDetails'>
                                <p className='associate-name-wrapper yk-title-h17'>
                                  <span className='yk-associate-title yk-badge-h16'>
                                    Requested By:
                                  </span>
                                  <span className='yk-associate-name yk-badge-h16'>
                                    {data?.[index]?.['WarehouseTab.userName'] ||
                                      '-'}
                                  </span>
                                </p>
                                <p className='associate-name-wrapper yk-title-h17'>
                                  <span className='yk-associate-title yk-badge-h16'>
                                    Consignor :
                                  </span>
                                  <span className='yk-associate-name yk-badge-h16'>
                                    {get(data[index], [
                                      'WarehouseTab.consignorName',
                                    ]) || '-'}
                                  </span>
                                </p>
                              </div>
                            </div>
                            <div className='product-img-wrapper'>
                              <ImageLoader
                                src={data?.[index]?.['WarehouseTab.imageUrl']}
                                fallbackImg={productImg}
                                alt='cart-img'
                                className='img-fluid'
                                imgWidth={500}
                                imgHeight={100}
                              />
                            </div>
                            <div className='product-content-wrapper pt-5'>
                              <h3 className='yk-product-title yk-badge-h11'>
                                {/* {data?.[index]?.['WarehouseTab.itemName'] ||
                                  '-'} */}
                                {get(data[index], ['WarehouseTab.itemName']) ||
                                  '-'}
                              </h3>
                              <div className='product-details-wrapper'>
                                <div className='row'>
                                  <div className='col-lg-12 col-md-12 col-sm-12'>
                                    <div className='row'>
                                      <div className='col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12'>
                                        <div className='product-details yk-badge-h16'>
                                          <span className='brand-text yk-badge-h16'>
                                            Brand:
                                          </span>
                                          <span className='brand-value yk-badge-h16'>
                                            {getAllUpperCase(
                                              get(data[index], [
                                                'WarehouseTab.brand',
                                              ])
                                            ) || '-'}
                                          </span>
                                        </div>
                                      </div>
                                      <div className='col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12'>
                                        <div className='product-details yk-badge-h16'>
                                          <span className='brand-text yk-badge-h16'>
                                            Size:
                                          </span>
                                          <span className='brand-value yk-badge-h16'>
                                            {get(data[index], [
                                              'WarehouseTab.Option1',
                                            ]) || '-'}
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                    <div className='row'>
                                      <div className='col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12'>
                                        <div className='product-details yk-badge-h16'>
                                          <span className='brand-text yk-badge-h16'>
                                            SKU:
                                          </span>
                                          <span
                                            className='brand-value yk-badge-h16'
                                            id='sku'>
                                            {get(data[index], [
                                              'WarehouseTab.sku',
                                            ]) || '-'}
                                          </span>
                                          <CopyToClipboardComponent
                                            copyText={get(data[index], [
                                              'WarehouseTab.sku',
                                            ])}
                                          />
                                        </div>
                                      </div>
                                      <div className='col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12'>
                                        <div className='product-details yk-badge-h16'>
                                          <span className='brand-text yk-badge-h16'>
                                            Date:
                                          </span>
                                          <span className='brand-value yk-badge-h16'>
                                            {get(data[index], [
                                              'WarehouseTab.eventTime',
                                            ])
                                              ? format(
                                                  new Date(
                                                    get(data[index], [
                                                      'WarehouseTab.eventTime',
                                                    ])
                                                  ),
                                                  FNS_US_DATE_FORMAT
                                                )
                                              : '-'}
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                    <div className='row'>
                                      <div className='col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12'>
                                        <div className='product-details yk-badge-h16'>
                                          <span className='brand-text yk-badge-h16'>
                                            Time:
                                          </span>
                                          <span className='brand-value yk-badge-h16'>
                                            {get(data[index], [
                                              'WarehouseTab.eventTime',
                                            ])
                                              ? getTime(
                                                  get(data[index], [
                                                    'WarehouseTab.eventTime',
                                                  ])
                                                )
                                              : '-'}
                                          </span>
                                        </div>
                                      </div>
                                      <div className='col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12'></div>
                                    </div>
                                    <div className='row'>
                                      <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                                        <div className='product-details yk-badge-h16'>
                                          <span className='brand-text yk-badge-h16'>
                                            Barcode:
                                          </span>
                                          <span className='brand-value yk-badge-h16'>
                                            {get(data[index], [
                                              'WarehouseTab.barcode',
                                            ]) || '-'}
                                          </span>
                                          <CopyToClipboardComponent
                                            copyText={get(data[index], [
                                              'WarehouseTab.barcode',
                                            ])}
                                          />
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </TabPanel>
                      </div>
                      <div className='col-lg-6 col-md-12 col-sm-12'>
                        <TabPanel value={value.toString()}>
                          <div className='tab-content-inner-wrapper'>
                            <div className='tab-section-heading dFlexSpaceBetween'>
                              <h3 className='tab-heading yk-badge-h11'>
                                Product Details
                              </h3>
                              {get(data[index], ['WarehouseTab.status']) ===
                                WAREHOUSE_STATUS.PENDING && (
                                <button
                                  type='button'
                                  className='btn yk-markMissingBtn dFlexCenter'
                                  onClick={() =>
                                    markMissingPairHandler(
                                      get(data[index], ['WarehouseTab.barcode'])
                                    )
                                  }>
                                  MARK MISSING
                                </button>
                              )}
                            </div>
                            <div className='tab-location-section-wrapper'>
                              <h3 className='tab-subtitle yk-badge-h14'>
                                Location:
                              </h3>
                              <div className='product-location-details-wrapper'>
                                <div className='product-location-details-info'>
                                  <div className='card-img-wrapper'>
                                    <Image
                                      src={binIcon}
                                      alt='bin-icon'
                                      className='img-fluid'
                                    />
                                  </div>
                                  <div className='product-count-info-wrapper'>
                                    <span className='location-type-title yk-badge-h16'>
                                      Bin:
                                    </span>
                                    <span className='product-count-info yk-badge-h16'>
                                      {get(data[index], ['WarehouseTab.bin'])
                                        ? get(data[index], [
                                            'WarehouseTab.bin',
                                          ]) === null
                                          ? '-'
                                          : get(data[index], [
                                              'WarehouseTab.bin',
                                            ])
                                        : '-'}
                                    </span>
                                  </div>
                                </div>
                                <div className='product-location-details-info'>
                                  <div className='card-img-wrapper'>
                                    <Image
                                      src={rackIcon}
                                      alt='bin-icon'
                                      className='img-fluid'
                                    />
                                  </div>
                                  <div className='product-count-info-wrapper'>
                                    <span className='location-type-title yk-badge-h16'>
                                      Shelf:
                                    </span>
                                    <span className='product-count-info yk-badge-h16'>
                                      {get(data[index], ['WarehouseTab.rack'])
                                        ? get(data[index], [
                                            'WarehouseTab.rack',
                                          ]) === null
                                          ? '-'
                                          : get(data[index], [
                                              'WarehouseTab.rack',
                                            ])
                                        : '-'}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className='product-content-wrapper'>
                              <div className='product-details-wrapper'>
                                <div className='row'>
                                  <div className='col-lg-12 col-md-12 col-sm-12'>
                                    <div className='row'>
                                      <div className='col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12'>
                                        <div className='product-details yk-badge-h16'>
                                          <span className='brand-text yk-badge-h16'>
                                            Style:
                                          </span>
                                          <span className='brand-value yk-badge-h16'>
                                            {get(data[index], [
                                              'WarehouseTab.sku',
                                            ]) || '-'}
                                          </span>
                                        </div>
                                      </div>
                                      <div className='col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12'>
                                        <div className='product-details yk-badge-h16'>
                                          <span className='brand-text yk-badge-h16'>
                                            Colorway:
                                          </span>
                                          <span className='brand-value yk-badge-h16'>
                                            {get(data[index], [
                                              'WarehouseTab.colorway',
                                            ])
                                              ? get(data[index], [
                                                  'WarehouseTab.colorway',
                                                ])?.length < 35
                                                ? get(data[index], [
                                                    'WarehouseTab.colorway',
                                                  ])
                                                : showLessColorWay
                                                ? getTrimmedText(
                                                    get(data[index], [
                                                      'WarehouseTab.colorway',
                                                    ]),
                                                    35
                                                  )
                                                : get(data[index], [
                                                    'WarehouseTab.colorway',
                                                  ])
                                              : '-'}
                                            {get(data[index], [
                                              'WarehouseTab.colorway',
                                            ])?.length > 35 && (
                                              <button
                                                className='btn btn-transparent view-more-btn'
                                                onClick={() =>
                                                  setShowLessColorWay(
                                                    !showLessColorWay
                                                  )
                                                }>
                                                {showLessColorWay
                                                  ? 'View More'
                                                  : 'View Less'}
                                              </button>
                                            )}
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                    <div className='row'>
                                      <div className='col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12'>
                                        <div className='product-details yk-badge-h16'>
                                          <span className='brand-text yk-badge-h16'>
                                            Retail Price:
                                          </span>
                                          <span className='brand-value yk-badge-h16'>
                                            {get(data[index], [
                                              'WarehouseTab.Price',
                                            ])
                                              ? convertPriceToUSFormat(
                                                  Number(
                                                    get(data[index], [
                                                      'WarehouseTab.Price',
                                                    ])
                                                  )?.toFixed(2)
                                                )
                                              : '-'}
                                          </span>
                                        </div>
                                      </div>
                                      <div className='col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12'>
                                        <div className='product-details yk-badge-h16'>
                                          <span className='brand-text yk-badge-h16'>
                                            Release Date:
                                          </span>
                                          <span className='brand-value yk-badge-h16'>
                                            {get(data[index], [
                                              'WarehouseTab.releaseDate',
                                            ])
                                              ? format(
                                                  new Date(
                                                    get(data[index], [
                                                      'WarehouseTab.releaseDate',
                                                    ])
                                                  ),
                                                  FNS_US_DATE_FORMAT
                                                )
                                              : '-'}
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                    <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                                      <div className='product-details product-description-wrapper  yk-badge-h16'>
                                        <h6 className='brand-text colorway-title yk-badge-h16'>
                                          Product Description:
                                        </h6>
                                        <div className='brand-description-wrapper'>
                                          <div className='brand-description yk-badge-h16'>
                                            {get(data[index], [
                                              'WarehouseTab.productDescription',
                                            ])
                                              ? get(data[index], [
                                                  'WarehouseTab.productDescription',
                                                ])?.length < 200
                                                ? get(data[index], [
                                                    'WarehouseTab.productDescription',
                                                  ])
                                                : showLessDescription
                                                ? getTrimmedText(
                                                    get(data[index], [
                                                      'WarehouseTab.productDescription',
                                                    ]),
                                                    200
                                                  )
                                                : get(data[index], [
                                                    'WarehouseTab.productDescription',
                                                  ])
                                              : '-'}
                                            {get(data[index], [
                                              'WarehouseTab.productDescription',
                                            ])?.length > 200 && (
                                              <button
                                                className='btn btn-transparent view-more-btn'
                                                onClick={() =>
                                                  setShowLessDescription(
                                                    !showLessDescription
                                                  )
                                                }>
                                                {showLessDescription
                                                  ? 'View More'
                                                  : 'View Less'}
                                              </button>
                                            )}
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </TabPanel>
                      </div>
                    </div>
                    <div className='button-action-wrapper'>
                      {(get(data[index], ['WarehouseTab.status']) ===
                        'Pending' ||
                        get(data[index], ['WarehouseTab.status']) ===
                          'CheckOut') &&
                        !isCurrentIndexSold && (
                          <button
                            type='button'
                            className='btn btn-checkout yk-badge-h7'
                            onClick={indexHandler}>
                            {/* if 1 record and flag true will show check out */}
                            {itemsLength?.availableItemsLength === 1 &&
                              get(data[index], ['WarehouseTab.status']) ===
                                'Pending' && <>{'CHECK OUT'} </>}
                            {/* if 1 record and flag true will show check In */}
                            {itemsLength?.availableItemsLength === 1 &&
                              get(data[index], ['WarehouseTab.status']) ===
                                'CheckOut' && <>{'CHECK IN'} </>}
                            {/* if multiple records and flag true will show check out */}
                            {itemsLength?.availableItemsLength > 1 &&
                              get(data[index], ['WarehouseTab.status']) ===
                                'Pending' && (
                                <>{`CHECK OUT ${index + 1} of ${
                                  itemsLength?.availableItemsLength
                                }`}</>
                              )}
                            {/* if multiple records and flag false will show check In */}
                            {itemsLength?.availableItemsLength > 1 &&
                              get(data[index], ['WarehouseTab.status']) ===
                                'CheckOut' && (
                                <>{`CHECK IN ${index + 1} of ${
                                  itemsLength?.availableItemsLength
                                }`}</>
                              )}
                          </button>
                        )}
                    </div>
                  </div>
                </TabContext>
              </Box>
            </div>
          </div>
        </div>
      )}

      <Notification
        showSuccessPopup={isVisibleMessage}
        handleSnackbarClose={handleSnackbarClose}
        severityType={severityType}
        message={message}
        className='yk-shoesize-alert-wrapper'
      />

      {isModalVisible && (
        <div className='yk-request-details-modal-wrapper'>
          <Modal
            open={isModalVisible}
            className='yk-request-incomplete-modal-wrapper'
            aria-labelledby='modal-modal-title'
            aria-describedby='modal-modal-description'>
            <div className='app-wrapper request-incomplete-modal-wrapper'>
              <div className='yk-modal-body'>
                <div className='modal-heading-wrapper'>
                  <h3 className='modal-title yk-badge-h11'>
                    {' '}
                    {WARNING_MODAL.TITLE}
                  </h3>
                  <p className='modal-sub-title yk-badge-h16'>
                    {WARNING_MODAL.MSG}
                  </p>
                </div>
                <div className='incomplete-request-modal-btn-wrapper'>
                  <button
                    type='button'
                    className='btn btn-transparent complete-request-btn'>
                    <h6
                      className='btn-text yk-badge-h7'
                      onClick={() => closeModal('complete')}>
                      {WARNING_MODAL.COMPLETE_BUTTON_TITLE}
                    </h6>
                  </button>
                  <button
                    type='button'
                    className='btn yk-btn-primary modal-leave-btn'>
                    <h6
                      className='btn-text yk-badge-h7'
                      onClick={() => closeModal('leave')}>
                      {WARNING_MODAL.LEAVE_BUTTON_TITLE}
                    </h6>
                  </button>
                </div>
              </div>
            </div>
          </Modal>
        </div>
      )}
      {showScanModal && (
        <ScannerModal
          barCodeScanResult={barCodeScanResult}
          setBarCodeScanResult={setBarCodeScanResult}
          isBarcodeLoading={isBarcodeLoading}
          scanCounter={showCountAlert}
          count={showCountAlertMsg}
          closeButtonHandler={closeButtonHandler}
        />
      )}
      {showSummaryModal && (
        <CompleteCheckoutModal
          checkoutSummaryTableData={checkoutSummaryTableData}
          setShowSummaryModal={setShowSummaryModal}
          requestNumber={props?.router?.query?.requestId}
          barcodesList={barcodesList}
          setIsVisibleMessage={setIsVisibleMessage}
          setSeverityType={setSeverityType}
          setMessage={setMessage}
          getToastMsg={getToastMsg}
          requestedItems={Number(availableItems?.length)}
          setShowScanModal={setShowScanModal}
          closeButtonHandler={closeButtonHandler}
        />
      )}
      {isMarkMissingModal && (
        <MissingShoesModal
          setIsMarkMissingModal={setIsMarkMissingModal}
          isVisibleMessage={isVisibleMessage}
          setIsVisibleMessage={setIsVisibleMessage}
          setSeverityType={setSeverityType}
          setMessage={setMessage}
          missingBarcode={missingBarcode}
        />
      )}
      {showScannerErrorModal && (
        <ScannerErrorModal
          setShowScanModal={setShowScanModal}
          setShowScannerErrorModal={setShowScannerErrorModal}
          manualCheckout={manualCheckInOutClickHandler}
          statusText={getActionStatus(
            get(data[index], ['WarehouseTab.status'])
          )}
        />
      )}
    </>
  );
};
export default withRouter(RequestDetails);
