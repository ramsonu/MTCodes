import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import downloadRed from 'assets/images/download-red.svg';
import { BulkUpload } from 'components/common/bulk-upload';
import { downloadBinShelfInventory } from 'services/shoesize';
import CircleLoader from 'components/common/loader/circular-loader';
import { doRequest } from 'utils/request';
import Notification from 'components/common/notification';
import {
  BIN_SHELF_DISCLAIMER,
  FILE_UPLOAD,
  SHELF_BIN_NOTIFICATION,
  STATUS_POLLING_TIME,
} from '../constants';
import UploadErrorModal from './upload-error-modal';
import { LogoutUser } from 'components/common/logout';
import { useRouter } from 'next/router';

const BulkImport = () => {
  const [sendFile, setSendFile] = useState<any>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [iserror, setIsError] = useState<boolean>(false);
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [notificationMsg, setNotificationMsg] = useState('');
  const [severityType, setSeverityType] = useState('');
  const [isErrorModalVisible, setIsErrorModalVisible] =
    useState<boolean>(false);
  const [startPolling, setStartPolling] = useState<boolean>(false);
  const [showMsg, setShowMsg] = useState<any>();
  const router = useRouter();

  useEffect(() => {
    if (sendFile && sendFile?.length > 0) {
      uploadFile();
      return () => {
        setSendFile([]);
      };
    }
  }, [sendFile]);

  useEffect(() => {
    if (startPolling) {
      const intervalId = setInterval(() => getStatus(), STATUS_POLLING_TIME);
      return () => {
        clearInterval(intervalId);
      };
    }
  }, [startPolling]);

  const handleDownload = async (ee: any) => {
    ee.preventDefault();
    try {
      setIsLoading(true);
      await downloadBinShelfInventory().then((response) => {
        let binaryData: any = [];

        binaryData = response?.data;
        const link = document.createElement('a');
        link.href = window.URL.createObjectURL(new Blob([binaryData]));

        link.setAttribute('download', 'BinShelfInventory.xlsx');
        document.body.appendChild(link);
        link.click();
      });
      setIsLoading(false);
      setIsError(false);
    } catch (e: any) {
      if (e?.response?.status === 401 || e?.response?.status === 403) {
        LogoutUser();
        router.push('/', undefined, { shallow: true });
      }
      setIsLoading(false);
      setIsVisibleMessage(true);
      setIsError(true);
      setSeverityType('warning');
      setNotificationMsg(SHELF_BIN_NOTIFICATION.ERROR_MESSAGE);
      console.log(e);
    }
  };

  const uploadFile = async () => {
    let formData = new FormData();
    formData.append('file', sendFile[0]);
    setIsLoading(true);
    try {
      const response = await doRequest(
        `${process.env.NEXT_PUBLIC_APP_INVENTORY_REST_API_DOMAIN}/inventory/import`,
        'post',
        formData,
        'multipart/form-data'
      );
      if (response) {
        setShowMsg(true);
        setStartPolling(true);
      }
    } catch (error: any) {
      if (error?.response?.status === 401 || error?.response?.status === 403) {
        LogoutUser();
        router.push('/', undefined, { shallow: true });
      }
      setIsLoading(false);
      setIsVisibleMessage(true);
      setSeverityType('error');
      if (error?.response?.status === 400) {
        setNotificationMsg(SHELF_BIN_NOTIFICATION.INVALID_FILE_ERROR_MESSAGE);
      } else if (error?.response?.status === 406) {
        setNotificationMsg(error?.response?.data?.message);
      } else {
        setNotificationMsg(SHELF_BIN_NOTIFICATION.FILE_ERROR_MESSAGE);
      }

      setSendFile([]);
      setStartPolling(false);
    }
  };

  const getStatus = async () => {
    setIsLoading(true);
    try {
      const response = await doRequest(
        `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/shoesize-check-bin-shelf-status`,
        'GET',
        {},
        ''
      );
      if (typeof response?.data !== 'object') {
        setStartPolling(false);
        if (response?.data?.length > 3400) {
          setIsLoading(false);
          setIsErrorModalVisible(true);
          setShowMsg(false);
          setSendFile([]);
        } else {
          setIsErrorModalVisible(false);
          setIsLoading(false);
          setShowMsg(false);
          setIsVisibleMessage(true);
          setSeverityType('success');
          setNotificationMsg(SHELF_BIN_NOTIFICATION.SUCCESS_MESSAGE);
          setSendFile([]);
        }
      }
    } catch (error: any) {
      setStartPolling(false);
      setIsVisibleMessage(true);
      setSeverityType('error');
      setNotificationMsg(SHELF_BIN_NOTIFICATION.FILE_ERROR_MESSAGE);
      console.log('error', error);
    }
  };
  const handleSnackbarClose = () => {
    setIsVisibleMessage(false);
  };
  return (
    <>
      <div className='bulk-import-page-wrapper'>
        <div className='container-fluid'>
          <div className='row m-auto'>
            <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
              <div className='breadcrumbs-wrapper'></div>
              <div className='heading-wrapper'>
                <div className='heading-inner-wrapper'>
                  <h3 className='heading'>Update Bin / Shelf</h3>
                  <p className='description'>
                    Please fill the relevant information in the sheet and
                    upload.
                  </p>
                </div>
              </div>
              <div className='bulk-import-upload-wrapper'>
                {iserror ? (
                  <p>Something went wrong</p>
                ) : isLoading ? (
                  <div className='circular-loader-wrapper'>
                    <CircleLoader />
                  </div>
                ) : (
                  ''
                )}
                <div className='upload-wrapper'>
                  <div className='upload-inner-wrapper'>
                    <form action='' className='import-form'>
                      <div className='form-group upload-group'>
                        <div className='documents-upload-wrapper'>
                          <BulkUpload
                            setSendFile={setSendFile}
                            sendFile={sendFile}
                            showMsg={showMsg}
                          ></BulkUpload>
                        </div>
                        <p className='description'>
                          DISCLAIMER :{BIN_SHELF_DISCLAIMER}
                        </p>
                        <div className='download-btn-wrapper'>
                          <button
                            className='btn btn-download yk-btn-outline'
                            onClick={(e) => handleDownload(e)}
                          >
                            <Image
                              src={downloadRed}
                              className='img-fluid'
                              alt=''
                            />
                            Download Inventory
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Notification
        showSuccessPopup={isVisibleMessage}
        handleSnackbarClose={handleSnackbarClose}
        severityType={severityType}
        message={notificationMsg}
        className='yk-shoesize-alert-wrapper'
      />
      {isErrorModalVisible && (
        <UploadErrorModal
          setIsErrorModalVisible={setIsErrorModalVisible}
          setIsVisibleMessage={setIsVisibleMessage}
          setSeverityType={setSeverityType}
          setNotificationMsg={setNotificationMsg}
        />
      )}
    </>
  );
};

export default BulkImport;
