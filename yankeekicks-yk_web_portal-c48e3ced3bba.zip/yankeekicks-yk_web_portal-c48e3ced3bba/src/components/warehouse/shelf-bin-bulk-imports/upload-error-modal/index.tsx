import React from 'react';
import Modal from '@mui/material/Modal';
import {
  SHELF_BIN_NOTIFICATION,
  UPLOAD_ERROR_POP_UP,
} from 'components/warehouse/constants';
import { getBinShelfUpdateStatus } from 'services/shoesize';
import { LogoutUser } from 'components/common/logout';
import { useRouter } from 'next/router';

const UploadErrorModal = (props: any) => {
  const {
    setIsErrorModalVisible,
    setIsVisibleMessage,
    setSeverityType,
    setNotificationMsg,
  } = props;

  const router = useRouter();

  const downloadHandler = async (ee: any) => {
    ee.preventDefault();
    try {
      await getBinShelfUpdateStatus().then((response: any) => {
        let binaryData: any = [];

        binaryData = response?.data;
        const link = document.createElement('a');
        link.href = window.URL.createObjectURL(new Blob([binaryData]));

        link.setAttribute('download', 'BinShelfFaultyRecords.xlsx');
        document.body.appendChild(link);
        link.click();
      });
    } catch (e: any) {
      if (e?.response?.status === 401 || e?.response?.status === 403) {
        LogoutUser();
        router.push('/', undefined, { shallow: true });
      }
      setIsVisibleMessage(true);
      setSeverityType('error');
      setNotificationMsg(SHELF_BIN_NOTIFICATION.FILE_ERROR_MESSAGE);
      console.log(e);
    }
    setIsErrorModalVisible(false);
  };
  return (
    <>
      <div className='app-wrapper w-100 landing-page-wrapper'>
        <Modal
          open={true}
          className='yk-upload-error-modal-wrapper'
          aria-labelledby='modal-modal-title'
          aria-describedby='modal-modal-description'>
          <div className='upload-error-modal-wrapper'>
            <div className='yk-modal-body'>
              <div className='modal-heading-wrapper'>
                <p className='modal-title yk-badge-h14'>
                  {UPLOAD_ERROR_POP_UP.TITLE}
                </p>
                <h5 className='modal-sub-title yk-badge-h16'>
                  {UPLOAD_ERROR_POP_UP.MESSAGE}
                </h5>
              </div>
              <button
                className='btn yk-btn-primary modal-download-btn'
                type='button'
                onClick={(e) => downloadHandler(e)}>
                <h6 className='btn-text yk-badge-h7'>
                  {UPLOAD_ERROR_POP_UP.BUTTON_TITLE}
                </h6>
              </button>
            </div>
          </div>
        </Modal>
      </div>
    </>
  );
};
export default UploadErrorModal;
