/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/router';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
} from '@mui/material';
import { format } from 'date-fns';
import { useCubeQuery } from '@cubejs-client/react';
import { getWareHouseData } from 'middleware/cubejs-wrapper/cubejs-query';
import { SUCCESS_MESSAGE, WAREHOUSE_STATUS } from '../constants';
import useWindowDimensions from 'components/common/mobile-card-dimension';
import { LogoutUser } from 'components/common/logout';
import NoDataFound from 'components/common/no-data-found';
import productImg from 'assets/images/products/dummy.svg';
import ImageLoader from 'components/common/image-loader';
import CircleLoader from 'components/common/loader/circular-loader';
import ScannerModal from '../modals/scanner-modal';
import ScannerErrorModal from '../modals/scanner-error-modal';
import { BARCODE_SCAN_CHECKOUT } from 'services/apiUrl';
import CheckOutRequestModal from '../modals/checkout-request-modal';
import WarehouseMobileViewCard from '../mobile-view';
import WarehouseTableExpand from '../warehouse-table-expand';
import { doRequest } from 'utils/request';
import { KPI_DATE_FORMAT } from 'utils/constants';
import { getTime, getTrimmedText } from 'utils/util';
import downArrowImg from 'assets/images/down-arrow.svg';

const WareHouseTable = (props: any) => {
  const {
    tabType,
    filterInput,
    getRowData,
    userOffset,
    userInput,
    setIsVisibleMessage,
    setSeverityType,
    setMessage,
    setRedirect,
    isSubScribe,
  } = props;
  const [data, setData] = useState<any>([]);
  const [isExpandVisible, setIsExpandVisible] = useState(false);
  const [isMobileView, setIsMobileView] = useState<boolean>(false);
  const [selectedRows, setSelectedRows] = useState<any>([]);
  const [showScanModal, setShowScanModal] = useState<boolean>(false);
  const [showScannerErrorModal, setShowScannerErrorModal] =
    useState<boolean>(false);
  const [barCodeScanResult, setBarCodeScanResult] = useState<any>('');
  const [requestNumber, setRequestNumber] = useState<any>('');
  const [isBarcodeLoading, setIsBarcodeLoading] = useState<boolean>(false);
  const [showCheckOutRequestModal, setShowCheckOutRequestModal] =
    useState<boolean>(false);
  const [rowData, setRowData] = useState<any>([]);
  const router = useRouter();

  const storeId = localStorage.getItem('storeId');
  const locationId = localStorage.getItem('storeLocationId');
  const { width } = useWindowDimensions();

  const warehouseData: any = getWareHouseData(
    tabType,
    filterInput,
    userOffset,
    userInput,
    storeId,
    format(new Date(), KPI_DATE_FORMAT),
    locationId
  );
  const {
    resultSet,
    isLoading,
    error: warehouseError,
    progress,
  }: any = useCubeQuery(warehouseData, { subscribe: isSubScribe });

  const headers = [
    'Request #',
    'SKU',
    'Barcode',
    'Name',
    'Size',
    'Status',
    'Bin-Shelf',
    'Requested By',
    'Time',
    'Action',
  ];

  //to sort the data based on Pending-CheckIn-Checkout status in table
  useEffect(() => {
    if (warehouseError?.status === 401 || warehouseError?.status === 403) {
      LogoutUser(); //log out user
      router.push('/', undefined, { shallow: true });
    } else {
      if (resultSet) {
        const pending: any = resultSet?.loadResponses[0]?.data?.reduce(
          (acc: any, item: any) => {
            if (
              item['WarehouseProductList.eventType'] ===
              WAREHOUSE_STATUS.PENDING
            ) {
              acc['pending'] = [...acc['pending'], item];
            }
            if (
              item['WarehouseProductList.eventType'] ===
              WAREHOUSE_STATUS.CHECKIN
            ) {
              acc['checkin'] = [...acc['checkin'], item];
            }
            if (
              item['WarehouseProductList.eventType'] ===
              WAREHOUSE_STATUS.CHECKOUT
            ) {
              acc['checkout'] = [...acc['checkout'], item];
            }
            if (
              item['WarehouseProductList.eventType'] === WAREHOUSE_STATUS.SOLD
            ) {
              acc['sold'] = [...acc['sold'], item];
            }
            if (
              item['WarehouseProductList.eventType'] ===
              WAREHOUSE_STATUS.MISSING
            ) {
              acc['missing'] = [...acc['missing'], item];
            }
            return acc;
          },
          { pending: [], checkin: [], checkout: [], sold: [], missing: [] }
        );
        setData([
          ...pending?.pending,
          ...pending.checkout,
          ...pending?.checkin,
          ...pending?.sold,
          ...pending?.missing,
        ]);
      } else {
        setData([]);
      }
    }
  }, [resultSet, warehouseError]);

  useEffect(() => {
    if (width < 500) {
      setIsMobileView(true);
    } else {
      setIsMobileView(false);
    }
  }, [width]);

  useEffect(() => {
    if (barCodeScanResult?.length > 0) {
      if (
        compareBarcode(
          rowData?.['WarehouseProductList.Barcode'],
          barCodeScanResult
        )
      ) {
        const scanCheckOut = async () => {
          const barcode = [barCodeScanResult];
          try {
            setIsBarcodeLoading(true);
            const response = await doRequest(
              `${BARCODE_SCAN_CHECKOUT}/${requestNumber}`,
              'post',
              barcode,
              ''
            );
            if (response) {
              setShowScanModal(false);
              setIsBarcodeLoading(false);
              setBarCodeScanResult('');

              setShowScannerErrorModal(false);
              setIsVisibleMessage(true);
              setSeverityType('success');
              setMessage(
                getToastMsg(
                  response?.data?.[0]?.status === WAREHOUSE_STATUS.CHECKOUT
                    ? SUCCESS_MESSAGE.CHECK_OUT_SUCCESS_MSG
                    : SUCCESS_MESSAGE.CHECK_IN_SUCCESS_MSG
                )
              );
            }
          } catch (error: any) {
            console.log('api error in Scan qr', error);
            if (
              error?.response?.status === 401 ||
              error?.response?.status === 403
            ) {
              LogoutUser();
              router.push('/', undefined, { shallow: true });
            }
            setIsBarcodeLoading(false);
            setShowScanModal(false);
            setBarCodeScanResult('');

            setShowScannerErrorModal(false);
            setIsVisibleMessage(true);
            setSeverityType('error');
            setMessage(
              getToastMsg(
                error?.response?.data?.message
                  ? error?.response?.data?.message
                  : SUCCESS_MESSAGE.ERROR_MSG
              )
            );
          }
        };
        scanCheckOut();
      } else {
        setBarCodeScanResult('');
        setShowScannerErrorModal(true);
      }
      //commented for not to sent api call
    }

    return () => {
      // setBarCodeScanResult('');
      // setRequestNumber('');
      // setIsBarcodeLoading(false);
    };
  }, [barCodeScanResult]);

  //get status of action tab
  const getActionStatus = (status: string) => {
    if (status === WAREHOUSE_STATUS.PENDING) {
      return WAREHOUSE_STATUS.CHECK__OUT;
    }
    if (status === WAREHOUSE_STATUS.CHECKOUT) {
      return WAREHOUSE_STATUS.CHECK__IN;
    }
  };

  //get status of status tab
  const getStatus = (status: string) => {
    if (status === WAREHOUSE_STATUS.PENDING) {
      return WAREHOUSE_STATUS.PENDING;
    }
    if (status === WAREHOUSE_STATUS.CHECKOUT) {
      return WAREHOUSE_STATUS.CHECKED_OUT;
    }
    if (status === WAREHOUSE_STATUS.CHECKIN) {
      return WAREHOUSE_STATUS.CHECKED_IN;
    }
    if (status === WAREHOUSE_STATUS.SOLD) {
      return WAREHOUSE_STATUS.SOLD;
    }
    if (status === WAREHOUSE_STATUS.MISSING) {
      return WAREHOUSE_STATUS.MISSING;
    }
    if (status === WAREHOUSE_STATUS.FOUND) {
      return WAREHOUSE_STATUS.FOUND;
    }
  };

  //open sub section (collapse)
  const expandHandler = (indx: any) => {
    if (selectedRows.includes(indx)) {
      let tempOption = [];
      tempOption = selectedRows.filter((data: any) => data !== indx);
      setSelectedRows(tempOption);
    } else {
      setSelectedRows([...selectedRows, indx]);
    }
  };

  // compare barcodes (requested and scanned)
  const compareBarcode = (requestBarcode: string, scannedBarcode: string) => {
    let correctBarcodes = false;
    if (requestBarcode?.toLowerCase() === scannedBarcode?.toLowerCase()) {
      correctBarcodes = true;
    }
    return correctBarcodes;
  };

  //notification msg
  const getToastMsg = (msg: string) => {
    return <h3 className='toast-msg'>{msg}</h3>;
  };

  const checkInCheckoutHandler = (requestId: Number, rowData: any) => {
    setRequestNumber(requestId);
    setRowData(rowData);
    setShowCheckOutRequestModal(true);
  };

  const scannerHandler = () => {
    setShowCheckOutRequestModal(false);
    setShowScanModal(true);
  };

  const manualCheckout = () => {
    setBarCodeScanResult(rowData?.['WarehouseProductList.Barcode']);
    setRequestNumber(rowData?.['WarehouseProductList.RequestNumber']);
  };

  const closeButtonHandler = () => {
    setBarCodeScanResult('');
    setShowScanModal(false);
    setIsBarcodeLoading(false);
  };
  return (
    <div className='parent-table-wrapper warehouse-table-wrapper'>
      <div className='table-wrapper YKCH-overloadDataTable'>
        <TableContainer component={Paper} className='yk-table-container'>
          <Table
            aria-label='collapsible table'
            className='yk-wh-table YKCH-FixedTableData'>
            <TableHead>
              <TableRow className='yk-parent-table-row YKCH-FixedRow'>
                {headers.map((row: any, index: any) => (
                  <TableCell
                    className='yk-parent-table-th warehouse-table-th YKCH-FixedCel'
                    key={index}>
                    {row}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {isLoading ? (
                <div className='circular-loader-wrapper'>
                  <CircleLoader />
                </div>
              ) : (
                <>
                  {data?.length > 0 &&
                    data?.map((row: any, index: any) => {
                      return (
                        <React.Fragment key={index}>
                          {!selectedRows.includes(index) && (
                            <TableRow
                              key={index}
                              className='yk-body-table-row YKCH-FixedRow'>
                              <TableCell
                                className='yk-table-body-td cursor-data y YKCH-FixedCel'
                                onClick={() => {
                                  row['WarehouseProductList.request_count'] <=
                                    1 &&
                                    getRowData(
                                      row['WarehouseProductList.RequestNumber']
                                    );
                                }}>
                                {row['WarehouseProductList.RequestNumber']}
                              </TableCell>
                              <TableCell
                                className='yk-table-body-td cursor-data YKCH-FixedCel'
                                onClick={() => {
                                  row['WarehouseProductList.request_count'] <=
                                    1 &&
                                    getRowData(
                                      row['WarehouseProductList.RequestNumber']
                                    );
                                }}>
                                {row['WarehouseProductList.inventory_sku']}
                              </TableCell>
                              <TableCell
                                className='yk-table-body-td cursor-data warehouse-table-td YKCH-FixedCel'
                                onClick={() => {
                                  row['WarehouseProductList.request_count'] <=
                                    1 &&
                                    getRowData(
                                      row['WarehouseProductList.RequestNumber']
                                    );
                                }}>
                                {row['WarehouseProductList.Barcode']
                                  ? row['WarehouseProductList.Barcode']
                                  : '-'}
                              </TableCell>
                              <TableCell
                                className='yk-table-body-td cursor-data warehouse-table-td YKCH-FixedCel'
                                onClick={() => {
                                  row['WarehouseProductList.request_count'] <=
                                    1 &&
                                    getRowData(
                                      row['WarehouseProductList.RequestNumber']
                                    );
                                }}
                                title={row['WarehouseProductList.itemName']}>
                                <span className='d-flex align-items-center'>
                                  <ImageLoader
                                    src={row['WarehouseProductList.imageUrl']}
                                    fallbackImg={productImg}
                                    alt='cart-img'
                                    className='img-fluid YKCH-negative'
                                    imgWidth={500}
                                    imgHeight={100}
                                  />
                                  {getTrimmedText(
                                    row['WarehouseProductList.itemName'],
                                    16
                                  )}
                                </span>
                              </TableCell>
                              <TableCell
                                className='yk-table-body-td cursor-data warehouse-table-td YKCH-FixedCel'
                                onClick={() => {
                                  row['WarehouseProductList.request_count'] <=
                                    1 &&
                                    getRowData(
                                      row['WarehouseProductList.RequestNumber']
                                    );
                                }}>
                                {row['WarehouseProductList.size']}
                              </TableCell>
                              <TableCell
                                className='yk-table-body-td cursor-data warehouse-table-td YKCH-FixedCel'
                                onClick={() => {
                                  row['WarehouseProductList.request_count'] <=
                                    1 &&
                                    getRowData(
                                      row['WarehouseProductList.RequestNumber']
                                    );
                                }}>
                                <span
                                  className={`yk-color-badge warehouse-color-badge ${
                                    row['WarehouseProductList.eventType'] ===
                                      WAREHOUSE_STATUS.PENDING ||
                                    row['WarehouseProductList.eventType'] ===
                                      WAREHOUSE_STATUS.MISSING ||
                                    row['WarehouseProductList.eventType'] ===
                                      WAREHOUSE_STATUS.SOLD
                                      ? 'red'
                                      : 'green'
                                  } `}>
                                  {getStatus(
                                    row['WarehouseProductList.eventType']
                                  )}
                                </span>
                              </TableCell>
                              <TableCell
                                className='yk-table-body-td cursor-data warehouse-table-td YKCH-FixedCel'
                                onClick={() => {
                                  row['WarehouseProductList.request_count'] <=
                                    1 &&
                                    getRowData(
                                      row['WarehouseProductList.RequestNumber']
                                    );
                                }}>
                                {`${
                                  row['WarehouseProductList.bin']
                                    ? row['WarehouseProductList.bin'] === null
                                      ? '-'
                                      : row['WarehouseProductList.bin']
                                    : '-'
                                }-${
                                  row['WarehouseProductList.rack']
                                    ? row['WarehouseProductList.rack'] === null
                                      ? '-'
                                      : row['WarehouseProductList.rack']
                                    : '-'
                                }`}
                              </TableCell>
                              <TableCell
                                className='yk-table-body-td cursor-data warehouse-table-td YKCH-FixedCel'
                                onClick={() => {
                                  row['WarehouseProductList.request_count'] <=
                                    1 &&
                                    getRowData(
                                      row['WarehouseProductList.RequestNumber']
                                    );
                                }}>
                                {row['WarehouseProductList.userName']}
                              </TableCell>
                              <TableCell
                                className='yk-table-body-td cursor-data warehouse-table-td YKCH-FixedCel'
                                onClick={() => {
                                  row['WarehouseProductList.request_count'] <=
                                    1 &&
                                    getRowData(
                                      row['WarehouseProductList.RequestNumber']
                                    );
                                }}>
                                {row['WarehouseProductList.eventTime']
                                  ? getTime(
                                      row['WarehouseProductList.eventTime']
                                    )
                                  : '--'}
                              </TableCell>
                              <TableCell className='yk-table-body-td warehouse-table-td YKCH-FixedCel'>
                                {row['WarehouseProductList.request_count'] >
                                1 ? (
                                  <>
                                    <span
                                      className='table-actions'
                                      onClick={() => expandHandler(index)}>
                                      <span className='yk-table-count-collapse'>
                                        {`+${row['WarehouseProductList.request_count']}`}
                                      </span>
                                      <Image
                                        src={downArrowImg}
                                        alt='filter-btn-icon'
                                        className='table-down-arrow img-fluid'
                                        onClick={() => expandHandler(index)}
                                      />
                                    </span>
                                  </>
                                ) : (
                                  <a
                                    role='button'
                                    className='yk-table-link-btn clear-filter-btn'
                                    // onClick={() => onActionHandler(row, index)}>

                                    onClick={() =>
                                      checkInCheckoutHandler(
                                        Number(
                                          row[
                                            'WarehouseProductList.RequestNumber'
                                          ]
                                        ),
                                        row
                                      )
                                    }>
                                    {getActionStatus(
                                      row['WarehouseProductList.eventType']
                                    )}
                                  </a>
                                )}
                                <div></div>
                              </TableCell>
                            </TableRow>
                          )}
                          {selectedRows.includes(index) && (
                            <WarehouseTableExpand
                              id={row['WarehouseProductList.RequestNumber']}
                              expandHandler={expandHandler}
                              isExpandVisible={isExpandVisible}
                              setIsExpandVisible={setIsExpandVisible}
                              selectedRows={selectedRows}
                              setRedirect={setRedirect}
                              currentIndex={index}
                              setIsVisibleMessage={setIsVisibleMessage}
                              setSeverityType={setSeverityType}
                              setMessage={setMessage}
                              getRowData={getRowData}
                              getStatus={getStatus}
                              getToastMsg={getToastMsg}
                              getActionStatus={getActionStatus}
                            />
                          )}
                        </React.Fragment>
                      );
                    })}
                </>
              )}
            </TableBody>
          </Table>
          {!data?.length && !isLoading && <NoDataFound />}
        </TableContainer>
      </div>
      {showCheckOutRequestModal && (
        <CheckOutRequestModal
          data={rowData}
          getActionStatus={getActionStatus}
          scannerHandler={scannerHandler}
          setShowCheckOutRequestModal={setShowCheckOutRequestModal}
        />
      )}
      {showScanModal && (
        <ScannerModal
          barCodeScanResult={barCodeScanResult}
          setBarCodeScanResult={setBarCodeScanResult}
          isBarcodeLoading={isBarcodeLoading}
          closeButtonHandler={closeButtonHandler}
        />
      )}

      {isMobileView && (
        <WarehouseMobileViewCard
          data={data}
          setIsVisibleMessage={setIsVisibleMessage}
          setSeverityType={setSeverityType}
          setMessage={setMessage}
          setRedirect={setRedirect}
          getRowData={getRowData}
          isDataLoading={isLoading}
          getStatus={getStatus}
          getActionStatus={getActionStatus}
          setShowScanModal={setShowScanModal}
          setRequestNumber={setRequestNumber}
          setBarCodeScanResult={setBarCodeScanResult}
          setRowData={setRowData}
          checkInCheckoutHandler={checkInCheckoutHandler}
        />
      )}
      {showScannerErrorModal && (
        <ScannerErrorModal
          setShowScanModal={setShowScanModal}
          setShowScannerErrorModal={setShowScannerErrorModal}
          manualCheckout={manualCheckout}
          statusText={getActionStatus(rowData['WarehouseProductList.eventType'])}
        />
      )}
    </div>
  );
};
export default WareHouseTable;
