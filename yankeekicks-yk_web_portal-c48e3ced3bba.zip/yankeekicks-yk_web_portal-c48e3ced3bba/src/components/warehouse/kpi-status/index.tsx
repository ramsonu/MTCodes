import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import get from 'lodash.get';
import { getShoesizeWarehouseKPIQuery } from 'middleware/cubejs-wrapper/cubejs-query';
import { STATUS_TYPE } from '../constants';
import { useCubeQuery } from '@cubejs-client/react';
import soldOutIcon from 'assets/images/checked-in.svg';
import checkedOutIcon from 'assets/images/checked-out.svg';
import { format } from 'date-fns';
import { KPI_DATE_FORMAT } from 'utils/constants';
import { LogoutUser } from 'components/common/logout';
import { useRouter } from 'next/router';
import CircleLoader from 'components/common/loader/circular-loader';

const KpiStatus = (props: any) => {
  const { selectedStartDate, selectedEndDate } = props;
  const [checkInCheckOutKPIData, setCheckInCheckOutKPIData] = useState([]);
  const storeId = localStorage.getItem('storeId');
  const locationId = localStorage.getItem('storeLocationId');
  const checkInCheckOutKPIQuery: any = getShoesizeWarehouseKPIQuery(
    storeId,
    locationId,
    selectedStartDate
      ? format(new Date(selectedStartDate), KPI_DATE_FORMAT)
      : format(new Date(), KPI_DATE_FORMAT),
    selectedEndDate
      ? format(new Date(selectedEndDate), KPI_DATE_FORMAT)
      : format(new Date(), KPI_DATE_FORMAT)
  );
  const {
    resultSet: checkInCheckOutKPIResultSet,
    isLoading: checkInCheckOutKPIIsLoading,
    error: checkInOutKPIError,
  }: any = useCubeQuery(checkInCheckOutKPIQuery, { subscribe: true });

  const router = useRouter();

  useEffect(() => {
    setCheckInCheckOutKPIData(
      checkInCheckOutKPIResultSet?.loadResponses[0]?.data
    );
  }, [checkInCheckOutKPIResultSet]);

  useEffect(() => {
    if (
      checkInOutKPIError?.status === 401 ||
      checkInOutKPIError?.status === 403
    ) {
      LogoutUser();
      router.push('/', undefined, { shallow: true });
    }
  }, [checkInOutKPIError, router]);

  const renderKpi = (
    statusType: any,
    imagePath: any,
    data: any,
    className: any
  ) => {
    return (
      <div className='col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 pe-3'>
        <div className={`card status-card mb-2 mt-1 ${className}`}>
          <div className='card-body pb-0 ps-3 pe-3'>
            <div className='card-heading-wrapper'>
              <div className='d-flex align-items-center'>
                <div className='icon-wrapper'>
                  <Image
                    src={imagePath}
                    alt='checked-out-icon'
                    className='Image-fluid'
                  />
                </div>
                <div>
                  <div className='status-info'>{statusType}</div>
                  <div className=''>
                    {checkInCheckOutKPIIsLoading ? (
                      <div className='YKCH-loader'>
                        <CircleLoader />
                      </div>
                    ) : (
                      <h5 className='status-value'>{data}</h5>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className='status-wrapper'>
      <div className='row'>
        {renderKpi(
          STATUS_TYPE?.CHECK_OUT_PENDING,
          checkedOutIcon,
          checkInCheckOutKPIData?.length &&
            checkInCheckOutKPIData[0] &&
            get(checkInCheckOutKPIData[0], [
              'WarehouseKPICount.checkoutPendingCount',
            ]) !== null
            ? get(checkInCheckOutKPIData[0], [
                'WarehouseKPICount.checkoutPendingCount',
              ])
            : 0,
          'check outs pendings'
        )}
        {renderKpi(
          STATUS_TYPE?.CHECK_IN_PENDING,
          soldOutIcon,
          checkInCheckOutKPIData?.length &&
            checkInCheckOutKPIData[0] &&
            get(checkInCheckOutKPIData[0], [
              'WarehouseKPICount.checkinPendingCount',
            ]) !== null
            ? get(checkInCheckOutKPIData[0], [
                'WarehouseKPICount.checkinPendingCount',
              ])
            : 0,
          'check ins pending'
        )}
      </div>
    </div>
  );
};

export default KpiStatus;
