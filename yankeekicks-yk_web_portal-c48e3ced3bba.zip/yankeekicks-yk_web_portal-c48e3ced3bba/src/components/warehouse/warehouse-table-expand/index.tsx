/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import get from 'lodash.get';
import { getRequestInfo } from 'middleware/cubejs-wrapper/cubejs-query';
import { useCubeQuery } from '@cubejs-client/react';
import { useRouter } from 'next/router';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Collapse,
} from '@mui/material';
import { LogoutUser } from 'components/common/logout';
import ImageLoader from 'components/common/image-loader';
import CircleLoader from 'components/common/loader/circular-loader';
import { getAllUpperCase, getTime, getTrimmedText } from 'utils/util';
import productImg from 'assets/images/big-product-img.svg';
import upArrowImg from 'assets/images/up-arrow.svg';
import { WAREHOUSE_STATUS } from '../constants';

const WarehouseTableExpand = (props: any) => {
  const {
    id,
    selectedRows,
    currentIndex,
    expandHandler,
    getRowData,
    getStatus,
    getActionStatus,
  } = props;
  const router = useRouter();
  const storeId = localStorage.getItem('storeId');
  const locationId = localStorage.getItem('storeLocationId');
  const [data, setData] = useState([]);
  const [headerData, setHeaderData] = useState({
    Name: '',
    RequestId: '',
    Time: '',
  });

  const bulkRequest: any = getRequestInfo(id.toString(), storeId, locationId);

  const {
    resultSet,
    isLoading: bulkRequestLoading,
    error: bulkRequestError,
    progress,
  }: any = useCubeQuery(bulkRequest);

  useEffect(() => {
    if (bulkRequestError?.status === 401 || bulkRequestError?.status === 403) {
      LogoutUser();
      router.push('/', undefined, { shallow: true });
    } else {
      let result = resultSet?.loadResponses[0]?.data;
      if (result) {
        let soldItems: any = result?.filter(
          (item: any) => item['WarehouseTab.status'] === 'Sold'
        );
        let missingItems: any = result?.filter(
          (item: any) => item['WarehouseTab.status'] === 'Missing'
        );
        let foundItems: any = result?.filter(
          (item: any) => item['WarehouseTab.status'] === 'Found'
        );
        let remainingItems: any = result?.filter(
          (item: any) =>
            !(
              item['WarehouseTab.status'] === 'Sold' ||
              item['WarehouseTab.status'] === 'Missing' ||
              item['WarehouseTab.status'] === 'Found'
            )
        );
        let appendSold = remainingItems?.concat(soldItems);
        let appendMissing = appendSold?.concat(missingItems);
        let appendFound = appendMissing?.concat(foundItems);
        setData(appendFound);
        setHeaderData({
          ...headerData,
          Name: get(data[0], ['WarehouseTab.userName'])
            ? getAllUpperCase(get(data[0], ['WarehouseTab.userName']))
            : '-',
          RequestId: get(data[0], ['WarehouseTab.requestNumber'])
            ? get(data[0], ['WarehouseTab.requestNumber'])
            : '-',
          Time: get(data[0], ['WarehouseTab.eventTime'])
            ? getTime(get(data[0], ['WarehouseTab.eventTime']))
            : '-',
        });
      } else {
        setData([]);
      }
    }
  }, [resultSet, bulkRequestError]);

  useEffect(() => {
    if (data) {
      setHeaderData({
        ...headerData,
        Name: get(data[0], ['WarehouseTab.userName'])
          ? getAllUpperCase(get(data[0], ['WarehouseTab.userName']))
          : '-',
        RequestId: get(data[0], ['WarehouseTab.requestNumber'])
          ? get(data[0], ['WarehouseTab.requestNumber'])
          : '-',
        Time: get(data[0], ['WarehouseTab.eventTime'])
          ? getTime(get(data[0], ['WarehouseTab.eventTime']))
          : '-',
      });
    }
  }, [data]);

  return (
    <React.Fragment>
      <TableRow className='YKCH-FixedRow'>
        <TableCell
          className='YKCH-FixedCel'
          style={{ paddingBottom: 0, paddingTop: 0 }}
          colSpan={12}>
          <Collapse
            className='yk-child-table'
            in={true}
            timeout='auto'
            unmountOnExit>
            <Table
              size='small'
              aria-label='purchases'
              className='YCKH-subTableData'>
              <TableHead className='yk-child-table-head'>
                <TableRow className='yk-child-table-row YKCH-FixedRow'>
                  <TableCell className='yk-child-table-th YKCH-FixedCel'>
                    <div className='yk-para-p1'>Request ID</div>
                    <div className='yk-form-title-text'>
                      {headerData.RequestId || '-'}
                    </div>
                  </TableCell>
                  <TableCell className='yk-child-table-th YKCH-FixedCel'></TableCell>
                  <TableCell className='yk-child-table-th YKCH-FixedCel'></TableCell>
                  <TableCell className='yk-child-table-th YKCH-FixedCel'>
                    <div className='yk-para-p1'>Requested By</div>
                    <div className='yk-form-title-text'>
                      {headerData.Name || '-'}
                    </div>
                  </TableCell>
                  <TableCell className='yk-child-table-th YKCH-FixedCel'>
                    <div className='yk-para-p1'>Time</div>
                    <div className='yk-form-title-text'>
                      {headerData.Time || '-'}
                    </div>
                  </TableCell>
                  <TableCell className='yk-child-table-th YKCH-FixedCel'></TableCell>
                  <TableCell className='yk-child-table-th YKCH-FixedCel'></TableCell>
                  <TableCell className='yk-child-table-th YKCH-FixedCel'></TableCell>
                  <TableCell className='yk-child-table-th YKCH-FixedCel'></TableCell>
                  <TableCell className='yk-child-table-th YKCH-FixedCel'>
                    {/* {data?.length === selectedItem.length && */}
                    {(get(data[0], ['WarehouseTab.status']) === 'Pending' ||
                      get(data[0], ['WarehouseTab.status']) === 'Missing' ||
                      get(data[0], ['WarehouseTab.status']) === 'CheckOut' ||
                      get(data[0], ['WarehouseTab.status']) === 'Sold') && (
                      <a
                        role='button'
                        className={`yk-table-link-btn clear-filter-btn `}
                        onClick={() =>
                          getRowData(
                            get(data[0], ['WarehouseTab.requestNumber']),
                            0
                          )
                        }>
                        {getActionStatus(get(data[0], ['WarehouseTab.status']))}
                      </a>
                    )}
                    {selectedRows.includes(currentIndex) && (
                      <Image
                        src={upArrowImg}
                        alt='filter-btn-icon'
                        className='table-up-arrow img-fluid'
                        onClick={() => expandHandler(currentIndex)}
                      />
                    )}
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody className='yk-child-table-body'>
                {bulkRequestError ? (
                  <p>Something went wrong!</p>
                ) : bulkRequestLoading ? (
                  <div className='circular-loader-wrapper collapse-table-loader-wrapper'>
                    <CircleLoader />
                  </div>
                ) : (
                  data?.map((row: any, index: any) => {
                    return (
                      <TableRow
                        className='yk-child-table-row YKCH-FixedRow'
                        key={index}>
                        <TableCell
                          className='yk-child-table-td cursor-data YKCH-FixedCel'
                          onClick={() =>
                            getRowData(row['WarehouseTab.requestNumber'], index)
                          }>
                          {row['WarehouseTab.sku']}
                        </TableCell>
                        <TableCell className='yk-child-table-td YKCH-FixedCel'></TableCell>
                        <TableCell
                          className='yk-child-table-td YKCH-FixedCel'
                          onClick={() =>
                            getRowData(row['WarehouseTab.requestNumber'], index)
                          }>
                          {row['WarehouseTab.barcode']}
                        </TableCell>
                        <TableCell
                          className='yk-child-table-td cursor-data YKCH-FixedCel'
                          onClick={() =>
                            getRowData(row['WarehouseTab.requestNumber'], index)
                          }
                          title={row['WarehouseTab.itemName']}>
                          <span className='d-flex align-items-center'>
                            <ImageLoader
                              src={row['WarehouseTab.imageUrl']}
                              fallbackImg={productImg}
                              alt='cart-img'
                              className='img-fluid YKCH-negative'
                              imgWidth={500}
                              imgHeight={100}
                            />
                            {getTrimmedText(row['WarehouseTab.itemName'], 13)}
                          </span>
                        </TableCell>
                        <TableCell
                          className='yk-child-table-td cursor-data YKCH-FixedCel'
                          onClick={() =>
                            getRowData(row['WarehouseTab.requestNumber'], index)
                          }>
                          {row['WarehouseTab.Option1']}
                        </TableCell>
                        <TableCell
                          className='yk-child-table-td cursor-data YKCH-FixedCel'
                          onClick={() =>
                            getRowData(row['WarehouseTab.requestNumber'], index)
                          }>
                          <span
                            className={`yk-color-badge ${
                              row['WarehouseTab.status'] ===
                                WAREHOUSE_STATUS.PENDING ||
                              row['WarehouseTab.status'] ===
                                WAREHOUSE_STATUS.MISSING ||
                              row['WarehouseTab.status'] ===
                                WAREHOUSE_STATUS.SOLD
                                ? 'red'
                                : 'green'
                            }`}>
                            {getStatus(row['WarehouseTab.status'])}
                          </span>
                        </TableCell>
                        <TableCell
                          className='yk-child-table-td cursor-data YKCH-FixedCel'
                          onClick={() =>
                            getRowData(row['WarehouseTab.requestNumber'], index)
                          }>
                          {`${
                            row['WarehouseTab.bin']
                              ? row['WarehouseTab.bin'] === null
                                ? '-'
                                : row['WarehouseTab.bin']
                              : '-'
                          }-${
                            row['WarehouseTab.rack']
                              ? row['WarehouseTab.rack'] === null
                                ? '-'
                                : row['WarehouseTab.rack']
                              : '-'
                          }`}
                        </TableCell>
                        <TableCell className='yk-child-table-td YKCH-FixedCel'></TableCell>
                        <TableCell className='yk-child-table-td YKCH-FixedCel'></TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </Collapse>
        </TableCell>
      </TableRow>
    </React.Fragment>
  );
};
export default WarehouseTableExpand;
