import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import filterIcon from 'assets/images/filter-icon.png';
import { useRouter } from 'next/router';
import WareHouseTable from '../warehouse-table';
import CommonTabs from 'components/common/tabs';
import { useCubeQuery } from '@cubejs-client/react';
import { getPaginationCount } from 'middleware/cubejs-wrapper/cubejs-query';
import Pagination from 'components/common/pagination';
import { actions } from 'store/reducers/warehouse';
import SearchComp from 'components/common/search';
import Notification from 'components/common/notification';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import ProductFilters from 'components/common/filters/product-filter';
import { useSelector, useDispatch } from 'react-redux';
import { format } from 'date-fns';
import { KPI_DATE_FORMAT } from 'utils/constants';
import KpiStatus from '../kpi-status';

const WarehouseDashboard = () => {
  const { wareHouseFilters } = useSelector((state: any) => state.warehouse);
  const [tabType, setTabType] = useState<string>('All');
  const [userInput, setUserInput] = useState('');
  const [isRedirect, setRedirect] = useState(false);
  const [filterInput, setFilterInput] = useState<any>({});
  const [isFilterVisible, setIsFilterVisible] = useState<boolean>(false);
  const [searchOffset, setSearchOffset] = useState<any>(0);
  const [countForPagination, setCountForPagination] = useState(0);
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [severityType, setSeverityType] = useState<string>('');
  const [message, setMessage] = useState<string>('');
  const [isSubScribe, setIsSubScribe] = useState(true);
  const [isClearButtonDisabled, setIsClearButtonDisabled] = useState<any>(true);
  const [selectedStartDate, setSelectedStartDate] = useState<any>('');
  const [selectedEndDate, setSelectedEndDate] = useState<any>('');
  const [startDate, setStartDate] = useState<any>('');
  const [endDate, setEndDate] = useState<any>('');

  const tabHandler = (e: any) => {
    setTabType(e.target.innerText);
  };

  const onChangeHandler = (value: any) => {
    setUserInput(value);
    setSearchOffset(0);
    setIsSubScribe(false);
  };

  const initialPanes: any = [
    {
      title: 'All',
      key: '1',
    },
    {
      title: 'Pending',
      key: '2',
    },

    {
      title: 'Checked Out',
      key: '3',
    },
    {
      title: 'Checked In',
      key: '4',
    },
  ];

  const router = useRouter();

  const dispatch = useDispatch();

  //pagination
  const storeId = localStorage.getItem('storeId');
  const locationId = localStorage.getItem('storeLocationId');
  const getPageCount: any = getPaginationCount(
    tabType,
    filterInput,
    userInput,
    storeId,
    format(new Date(), KPI_DATE_FORMAT),
    locationId
  );
  const { resultSet: pageCountResultSet }: any = useCubeQuery(getPageCount);

  useEffect(() => {
    if (pageCountResultSet) {
      let countData =
        +pageCountResultSet?.loadResponses[0]?.data[0]?.[
          'WarehouseProductList.count'
        ] || 0;
      setCountForPagination(countData);
    } else {
      setCountForPagination(0);
    }
  }, [pageCountResultSet]);

  useEffect(() => {
    if (
      !wareHouseFilters?.requestBy?.length &&
      !wareHouseFilters?.bin?.length &&
      !wareHouseFilters?.size?.length &&
      !startDate
    ) {
      setIsClearButtonDisabled(true);
    } else {
      setIsClearButtonDisabled(false);
    }
  }, [wareHouseFilters, startDate]);

  const onFilterHandler = () => {
    setIsFilterVisible(!isFilterVisible);
  };



  // to get the data of per row
  const getRowData = (id: string) => {
    router.push(
      {
        pathname: '/warehouse/request-details',
        query: { requestId: id },
      }
      // '/warehouse/request-details'
    );
  };

  const handleSnackbarClose = () => {
    setIsVisibleMessage(false);
  };

  if (isRedirect) {
    router.reload();
  }

  const onApplyFilterClick = () => {
    const filterPayload = {
      requestBy: wareHouseFilters?.requestBy || [],
      bin: wareHouseFilters?.bin || [],
      size: wareHouseFilters?.size || [],
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setIsFilterVisible(false);
    setSelectedStartDate(startDate);
    setSelectedEndDate(endDate);
    setSearchOffset(0);
  };
  const onClearFilters = () => {
    dispatch(actions.clearWareHouseFilters({}));
    const clearFilters = {
      requestBy: [],
      bin: [],
      size: [],
    };
    setFilterInput(clearFilters);
    setIsFilterVisible(false);
    setSelectedStartDate('');
    setSelectedEndDate('');
    setStartDate('');
    setEndDate('');
    setSearchOffset(0);
  };
  const onDateChange = (dates: any) => {
    const [start, end] = dates;
    setStartDate(start);
    setEndDate(end);
  };

  return (
    <>
      <div className='app-wrapper w-100 landing-page-wrapper'>
        <div className='page-inner-wrapper'>
          <div className='warehouse-dashboard-wrapper'>
            <div className='warehouse-dashboard-inner-wrapper'>
              <div className='container-fluid'>
                <div className='row m-auto'>
                  <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                    <KpiStatus
                      selectedStartDate={selectedStartDate}
                      selectedEndDate={selectedEndDate}
                    />
                  </div>
                  <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                    <h3 className='yk-browse-title yk-badge-h11'>Browse</h3>
                    <div className='row'>
                      <div className='col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12'>
                        <div className='status-tabs-wrapper warehouse-status-tabs'>
                          <CommonTabs
                            initialPanes={initialPanes}
                            tabHandler={tabHandler}
                          />
                        </div>
                      </div>
                      <div className='col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 text-end '>
                        <div className='top-action-items-wrapper d-flex justify-content-end w-100'>
                          <div className='search-bar-wrapper yk-search-bar warehouse-dashboard-search table-filter-search'>
                            <SearchComp
                              onChangeHandler={onChangeHandler}
                              optionType='change'
                              placeholder='Search'
                              isWarehouse={true}
                            />
                          </div>
                          <div className='filter-btn-wrapper'>
                            <ClickAwayListener
                              onClickAway={() => {
                                setIsFilterVisible(false);
                              }}>
                              <div>
                                <button
                                  className='btn filter-btn me-0'
                                  onClick={onFilterHandler}>
                                  <Image
                                    src={filterIcon}
                                    alt='filter-btn-icon'
                                    className='filter-btn-icon img-fluid'
                                  />
                                  <span className='filter-btn-text yk-badge-h15'>
                                    Filter
                                  </span>
                                </button>
                                {isFilterVisible && (
                                  <ProductFilters
                                    itemKey='warehouse'
                                    onDateChange={onDateChange}
                                    startDate={startDate}
                                    endDate={endDate}
                                    onApplyClick={onApplyFilterClick}
                                    onClearFilters={onClearFilters}
                                    clearDisable={isClearButtonDisabled}
                                  />
                                )}
                              </div>
                            </ClickAwayListener>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                    <WareHouseTable
                      tabType={tabType}
                      filterInput={filterInput}
                      getRowData={getRowData}
                      userOffset={searchOffset}
                      userInput={userInput}
                      isVisibleMessage={isVisibleMessage}
                      setIsVisibleMessage={setIsVisibleMessage}
                      setSeverityType={setSeverityType}
                      severityType={severityType}
                      message={message}
                      setMessage={setMessage}
                      setRedirect={setRedirect}
                      isRedirect={isRedirect}
                      isSubScribe={isSubScribe}
                    />
                  </div>
                </div>
              </div>
              {countForPagination > 0 && (
                <div className='warehouse-dashboard-pagination-wrapper'>
                  <Pagination
                    lengthOfData={countForPagination}
                    itemsPerPage={8}
                    currentOffset={searchOffset}
                    setOffset={setSearchOffset}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <Notification
        showSuccessPopup={isVisibleMessage}
        handleSnackbarClose={handleSnackbarClose}
        severityType={severityType}
        message={message}
        className='yk-shoesize-alert-wrapper'
      />
    </>
  );
};
export default WarehouseDashboard;
