import React, { useState } from 'react';
import GlobalModal from '../../common/common-modal/common-modal';
import { doRequest } from 'utils/request';
import { MARK_MISSING } from 'services/apiUrl';

const MissingShoesModal = (props: any) => {
  const {
    setIsMarkMissingModal,
    setIsVisibleMessage,
    setSeverityType,
    setMessage,
    missingBarcode,
  } = props;
  const [isMarMissingLoading, setIsMarMissingLoading] =
    useState<boolean>(false);
  const markMissingHandler = async () => {
    setIsMarMissingLoading(true);
    try {
      const markMissingResponse = await doRequest(
        `${MARK_MISSING}/${missingBarcode}`,
        'post',
        {},
        ''
      );
      if (markMissingResponse) {
        setIsMarMissingLoading(false);
        setIsMarkMissingModal(false);
        setIsVisibleMessage(true);
        setSeverityType('success');
        setMessage('Marked as Missing Pair');
      }
    } catch (error: any) {
      console.log('error in missing pair', error);
      setIsMarMissingLoading(false);
      setIsMarkMissingModal(false);
      setIsVisibleMessage(true);
      setSeverityType('error');
      setMessage('Something went wrong');
    }
  };
  return (
    <GlobalModal
      toggleModal={true}
      title='Missing Shoes'
      message='Are you sure you want to mark this barcode as missing?'
      cancelButton={true}
      cancelButtonText='Cancel'
      submitButton={true}
      onSubmitClicked={markMissingHandler}
      submitButtonText='Mark Missing'
      submitDisabled={isMarMissingLoading}
      onCancelClicked={() => setIsMarkMissingModal(false)}
      className='yk-commonModalWrapper yk-missingShoesModalWrapper'
    />
  );
};

export default MissingShoesModal;
