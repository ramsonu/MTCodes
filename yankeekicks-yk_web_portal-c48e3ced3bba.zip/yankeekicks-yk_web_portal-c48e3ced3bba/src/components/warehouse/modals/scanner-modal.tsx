import React, { useState, useEffect } from 'react';
import GlobalModal from '../../common/common-modal/common-modal';
import CircleLoader from 'components/common/loader/circular-loader';
import QrCodeScanner from 'components/common/qr-scanner';

const ScannerModal = (props: any) => {
  const {
    barCodeScanResult,
    setBarCodeScanResult,
    isBarcodeLoading,
    scanCounter,
    count,
    closeButtonHandler,
  } = props;

  return (
    <GlobalModal
      toggleModal={true}
      title='Scanning in Process'
      scanSubTitle={scanCounter}
      scanCount={count}
      closeButton={true}
      onCloseClicked={closeButtonHandler}
      className={`yk-commonModalWrapper yk-scanningInProgressModal  ${
        barCodeScanResult?.length <= 0 && !isBarcodeLoading
          ? 'yk-videoScanModalWrapper'
          : ''
      }`}>
      <div className='dFlexCenter'>
        {barCodeScanResult?.length <= 0 && !isBarcodeLoading && (
          <QrCodeScanner setBarCodeScanResult={setBarCodeScanResult} />
        )}
      </div>
      <div className='dFlexCenter'>
        <div className='circular-loader-wrapper'>
          {isBarcodeLoading && <CircleLoader />}
        </div>
      </div>
    </GlobalModal>
  );
};

export default ScannerModal;
