import React from 'react';
import GlobalModal from '../../common/common-modal/common-modal';

const RequestIncompleteModal = () => {
  return (
    <GlobalModal
      toggleModal={true}
      title='Request Incomplete'
      message='Check out is not complete this shoes. Request will not be complete if you go back. Are you sure you want to leave?'
      cancelButton={true}
      cancelButtonText='Complete Request'
      submitButton={true}
      submitButtonText='Leave'
      className='yk-commonModalWrapper yk-requestIncompleteModalWrapper'></GlobalModal>
  );
};

export default RequestIncompleteModal;
