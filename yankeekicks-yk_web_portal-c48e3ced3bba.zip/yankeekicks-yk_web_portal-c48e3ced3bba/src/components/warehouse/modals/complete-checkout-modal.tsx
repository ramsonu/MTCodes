import React, { useState, useMemo } from 'react';
import { useRouter } from 'next/router';
import GlobalModal from '../../common/common-modal/common-modal';
import VirtualTable from 'components/common/table';
import { LogoutUser } from 'components/common/logout';
import { doRequest } from 'utils/request';
import { BARCODE_SCAN_CHECKOUT } from 'services/apiUrl';
import { SUCCESS_MESSAGE, WAREHOUSE_STATUS } from '../constants';
import BulkRequestMobileViewSummary from '../mobile-view/bulk-request-mobile-view-summary';

const CompleteCheckoutModal = (props: any) => {
  const {
    checkoutSummaryTableData,
    setShowSummaryModal,
    requestNumber,
    barcodesList,
    setIsVisibleMessage,
    setSeverityType,
    setMessage,
    getToastMsg,
    requestedItems,
    setShowScanModal,
    closeButtonHandler,
  } = props;
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const router = useRouter();

  const columns = useMemo(
    () => [
      {
        title: 'SKU',
        value: 'WarehouseTab.sku',
      },
      {
        title: 'Barcode',
        value: 'WarehouseTab.barcode',
      },
      {
        title: 'Name',
        value: 'WarehouseTab.itemName',
      },
      {
        title: 'Size',
        value: 'WarehouseTab.Option1',
      },
      // {
      //   title: 'Bin - Rack',
      //   value: `${'WarehouseTab.bin'}-${'WarehouseTab.rack'}`,
      // }, if required we can enable
    ],

    []
  );

  const checkOutHandler = async () => {
    try {
      setIsLoading(true);
      const response = await doRequest(
        `${BARCODE_SCAN_CHECKOUT}/${requestNumber}`,
        'post',
        barcodesList,
        ''
      );
      if (response) {
        setIsLoading(false);
        setShowSummaryModal(false);
        setShowScanModal(false);
        setIsVisibleMessage(true);
        setSeverityType('success');
        const notifyMsg = `${checkoutSummaryTableData?.length} ${
          response?.data?.[0]?.status === WAREHOUSE_STATUS.CHECKOUT
            ? SUCCESS_MESSAGE.CHECK_OUT_SUCCESS_MSG
            : SUCCESS_MESSAGE.CHECK_IN_SUCCESS_MSG
        }`;
        setMessage(getToastMsg(notifyMsg));
        router.push('/warehouse');
      }
    } catch (e: any) {
      if (e?.response?.status === 401 || e?.response?.status === 403) {
        LogoutUser();
        router.push('/', undefined, { shallow: true });
      }
      setShowSummaryModal(false);
      setIsVisibleMessage(true);
      setSeverityType('error');
      setMessage(getToastMsg(SUCCESS_MESSAGE.ERROR_MSG));
    }
  };

  const cancelClickHandler = () => {
    closeButtonHandler();
    setShowSummaryModal(false);
    setShowScanModal(false);
  };

  const getActionStatus = (status: string) => {
    if (status === WAREHOUSE_STATUS.PENDING) {
      return WAREHOUSE_STATUS.CHECK__OUT;
    }
    if (status === WAREHOUSE_STATUS.CHECKOUT) {
      return WAREHOUSE_STATUS.CHECK__IN;
    }
  };

  return (
    <GlobalModal
      toggleModal={true}
      title={`Complete ${getActionStatus(
        checkoutSummaryTableData?.[0]?.['WarehouseTab.status']
      )}`}
      cancelButton={true}
      cancelButtonText='Cancel'
      onCancelClicked={cancelClickHandler}
      submitButton={true}
      submitDisabled={
        requestedItems !== checkoutSummaryTableData?.length || isLoading
      }
      submitButtonText={`${getActionStatus(
        checkoutSummaryTableData?.[0]?.['WarehouseTab.status']
      )}`}
      onSubmitClicked={checkOutHandler}
      className='yk-commonModalWrapper yk-completeCheckoutModalWrapper'>
      <p className='yk-modalTitle yk-subTitleText'>
        {`Are you sure you want to ${getActionStatus(
          checkoutSummaryTableData?.[0]?.['WarehouseTab.status']
        )} all the shoes?`}
      </p>
      <h6 className='yk-modalFieldLabel'>Summary</h6>
      <div className='yk-modalTableWrapper'>
        <VirtualTable headers={columns} rowData={checkoutSummaryTableData} />
        <BulkRequestMobileViewSummary summaryData={checkoutSummaryTableData} />
      </div>
    </GlobalModal>
  );
};

export default CompleteCheckoutModal;
