import React from 'react';
import GlobalModal from '../../common/common-modal/common-modal';

const ScannerErrorModal = (props: any) => {
  const {
    setShowScanModal,
    setShowScannerErrorModal,
    manualCheckout,
    statusText,
  } = props;
  const scanAgainHandler = () => {
    setShowScannerErrorModal(false);
    setShowScanModal(true);
  };
  const cancelHandler = () => {
    setShowScannerErrorModal(false);
    setShowScanModal(false);
  };
  return (
    <GlobalModal
      toggleModal={true}
      isIcon={true}
      closeBtn={true}
      onCloseBtnClicked={cancelHandler}
      title='Barcode not detected!'
      message='Try to place the barcode within the square while scanning.
    Please try again, or cancel.'
      cancelButton={true}
      onCancelClicked={manualCheckout}
      cancelButtonText={`Manual ${statusText}`}
      submitButton={true}
      submitButtonText='Scan Again'
      onSubmitClicked={scanAgainHandler}
      className='yk-commonModalWrapper yk-barcodeModalWrapper'></GlobalModal>
  );
};

export default ScannerErrorModal;
