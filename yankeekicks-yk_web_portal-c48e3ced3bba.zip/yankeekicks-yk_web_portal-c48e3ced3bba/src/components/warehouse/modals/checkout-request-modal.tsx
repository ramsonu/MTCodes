import React, { useState } from 'react';
import Image from 'next/image';
import Box from '@mui/material/Box';
import TabContext from '@mui/lab/TabContext';
import TabPanel from '@mui/lab/TabPanel';
import ImageLoader from 'components/common/image-loader';
import CopyToClipboardComponent from 'components/common/copyToClipboard';
import GlobalModal from 'components/common/common-modal/common-modal';
import binIcon from 'assets/images/bin-icon.svg';
import rackIcon from 'assets/images/rack-icon.svg';

const CheckOutRequestModal = (props: any) => {
  const { data, setShowCheckOutRequestModal, getActionStatus, scannerHandler } =
    props;

  const onCloseHandler = () => {
    setShowCheckOutRequestModal(false);
  };
  return (
    <>
      <GlobalModal
        toggleModal={true}
        closeButton={true}
        onCloseClicked={onCloseHandler}
        scanButton={true}
        scanButtonText={`SCAN TO ${getActionStatus(
          data['WarehouseProductList.eventType']
        )?.toUpperCase()} `}
        onScanButtonClicked={scannerHandler}
        requestId={true}
        requestIdText={data['WarehouseProductList.RequestNumber']}
        title={`${getActionStatus(
          data['WarehouseProductList.eventType']
        )} Request`}
        className='yk-commonModalWrapper yk-checkOutRequestModalWrapper'>
        <div className='tabs-wrapper'>
          <div className='product-tabs-wrapper'>
            <Box sx={{ width: '100%', typography: 'body1' }}>
              <TabContext value={'1'}>
                <div className='yk-tabContentWrapper'>
                  <div className='row'>
                    <div className='col-lg-12 col-md-12 col-sm-12 col-12'>
                      <TabPanel className='p-0' value='1'>
                        <div className='yk-InfoWrapper'>
                          <div className='row'>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-12'>
                              <p className='yk-fieldTitleWrapper yk-badge-f17'>
                                <span className='yk-fieldTitle'>
                                  Associate&nbsp;:&nbsp;
                                </span>
                                <span className='yk-fieldValue'>
                                  {data['WarehouseProductList.userName'] || '-'}
                                </span>
                              </p>
                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-12'>
                              <p className='yk-fieldTitleWrapper yk-badge-f17'>
                                <span className='yk-fieldTitle'>
                                  Consignor&nbsp;:&nbsp;
                                </span>
                                <span className='yk-fieldValue'>
                                  {data['WarehouseProductList.consignorName'] ||
                                    '-'}
                                </span>
                              </p>
                            </div>
                          </div>
                        </div>
                        <div className='row align-items-center'>
                          <div className='col-lg-6 col-md-6 col-sm-12 col-12'>
                            <div className='product-img-wrapper dFlexCenter'>
                              <ImageLoader
                                src={data['WarehouseProductList.imageUrl']}
                                alt='productImg'
                                className='img-fluid'
                              />
                            </div>
                          </div>
                          <div className='col-lg-6 col-md-6 col-sm-12 col-12'>
                            <div className='yk-locationContentWrapper'>
                              <h3 className='tab-subtitle yk-badge-h14'>
                                Location:
                              </h3>
                              <div className='product-location-details-info'>
                                <div className='yk-cardImgWrapper'>
                                  <div className='card-img-wrapper dFlexCenter cardImgWrapper'>
                                    <Image
                                      src={binIcon}
                                      alt='bin-icon'
                                      className='img-fluid'
                                    />
                                    <div className='product-count-info-wrapper'>
                                      <span className='location-type-title yk-badge-h16'>
                                        Bin:
                                      </span>
                                      <span className='product-count-info yk-badge-h16'>
                                        {data['WarehouseProductList.bin'] ||
                                          '-'}
                                      </span>
                                    </div>
                                  </div>
                                </div>
                                <div>
                                  <div className='card-img-wrapper dFlexCenter'>
                                    <Image
                                      src={rackIcon}
                                      alt='bin-icon'
                                      className='img-fluid'
                                    />
                                    <div className='product-count-info-wrapper'>
                                      <span className='location-type-title yk-badge-h16'>
                                        Rack:
                                      </span>
                                      <span className='product-count-info yk-badge-h16'>
                                        {data['WarehouseProductList.rack'] ||
                                          '-'}
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className='product-content-wrapper pt-3'>
                            <h3 className='yk-product-title yk-badge-h11'>
                              {data['WarehouseProductList.itemName'] || '-'}
                            </h3>
                            <div className='product-details-wrapper'>
                              <div className='row'>
                                <div className='col-lg-12 col-md-12 col-sm-12'>
                                  <div className='row'>
                                    <div className='col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12'>
                                      <div className='product-details yk-badge-h16'>
                                        <span className='brand-text yk-badge-h16'>
                                          Brand:
                                        </span>
                                        <span className='brand-value yk-badge-h16'>
                                          {data['WarehouseProductList.Brand'] ||
                                            '-'}
                                        </span>
                                      </div>
                                    </div>
                                    <div className='col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12'>
                                      <div className='product-details yk-badge-h16'>
                                        <span className='brand-text yk-badge-h16'>
                                          Size:
                                        </span>
                                        <span className='brand-value yk-badge-h16'>
                                          {data['WarehouseProductList.size'] ||
                                            '-'}
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                  <div className='row'>
                                    <div className='col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12'>
                                      <div className='product-details yk-badge-h16'>
                                        <span className='brand-text yk-badge-h16'>
                                          SKU:
                                        </span>
                                        <span
                                          className='brand-value yk-badge-h16'
                                          id='sku'>
                                          {data[
                                            'WarehouseProductList.inventory_sku'
                                          ] || '-'}
                                        </span>
                                        <CopyToClipboardComponent
                                          copyText={
                                            data[
                                              'WarehouseProductList.inventory_sku'
                                            ]
                                          }
                                        />
                                      </div>
                                    </div>
                                    <div className='col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12'>
                                      <div className='product-details yk-badge-h16'>
                                        <span className='brand-text yk-badge-h16'>
                                          Barcode:
                                        </span>
                                        <span
                                          className='brand-value yk-badge-h16'
                                          id='requestId'>
                                          {data[
                                            'WarehouseProductList.Barcode'
                                          ] || '-'}
                                        </span>
                                        <CopyToClipboardComponent
                                          copyText={
                                            data['WarehouseProductList.Barcode']
                                          }
                                        />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </TabPanel>
                    </div>
                  </div>
                </div>
              </TabContext>
            </Box>
          </div>
        </div>
      </GlobalModal>
    </>
  );
};

export default CheckOutRequestModal;
