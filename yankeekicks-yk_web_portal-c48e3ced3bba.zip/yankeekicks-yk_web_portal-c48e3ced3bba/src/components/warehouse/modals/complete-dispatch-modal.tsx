import React from 'react';
import GlobalModal from '../../common/common-modal/common-modal';

const CompleteDispatchModal = () => {
  return (
    <GlobalModal
      toggleModal={true}
      title='Complete Dispatch'
      message='Are you sure you want to dispatch this online order?'
      cancelButton={true}
      cancelButtonText='Cancel'
      submitButton={true}
      submitButtonText='Dispatch'
      className='yk-commonModalWrapper yk-completeDispatchModal'></GlobalModal>
  );
};

export default CompleteDispatchModal;
