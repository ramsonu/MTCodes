import React, { useState, useEffect } from 'react';
import type { NextPage } from 'next';
import Image from 'next/image';
import queueIcon from 'assets/images/queue-icon.svg';
import filterIcon from 'assets/images/filter-icon.png';
import modalCloseIcon from 'assets/images/modal-close-btn-icon.svg';
import AddIcon from 'assets/images/add-icon.png';
import productImg from 'assets/images/big-product-img.png';
import ImageLoader from 'components/common/image-loader';
import { Button, ClickAwayListener } from '@mui/material';
import catalogProductImage3 from 'assets/images/catalog-product-image-3.png';

const Inventory = () => {
  return (
    <>
      <div className='warehouse-inventory-page-wrapper app-wrapper w-100 catalog-page-wrapper'>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-sm-12 col- md-12 col-lg-12 col-xl-12'>
              <div className='heading-wrapper'>
                <div className='heading-inner-wrapper'>
                  <h3 className='yk-main-title'>Inventory</h3>
                </div>
              </div>
              <div className='search-btn-wrapper'>
                <div className='row'>
                  <div className='col-lg-4'>
                    <div className='search-bar-wrapper yk-search-bar'>
                      {/* COMMON SEARCH COMPONENT WILL GO HERE */}
                    </div>
                  </div>
                  <div className='col-lg-8'>
                    <div className='consignment-btn-wrapper'>
                      <button className='grid-bullet-icon' />
                      <button className='list-bullet-icon list-bullet-icon-active' />

                      <div className=''>
                        {/* <Sortings
                              handleChange={sortHandler}
                              itemKey='catalog'
                              defaultSelectedValue={selectedSort}
                            /> */}
                        {/* SORTING COMMON COMPONENT WILL GO HERE */}
                      </div>
                      <div className='filter-btn-wrapper'>
                        <div>
                          <button className='btn filter-btn '>
                            <Image
                              src={filterIcon}
                              alt='filter-btn-icon'
                              className='filter-btn-icon img-fluid'
                            />
                            <span className='filter-btn-text yk-badge-h15'>
                              Filter
                            </span>
                          </button>
                          <button className='btn import-btn yk-btn-primary-sm'>
                            import
                          </button>

                          {/* <ProductFilters
                                    itemKey='catalog'
                                    onDateChange={onDateChange}
                                    onAgeChange={ageChange}
                                    startDate={selectedStartDate}
                                    endDate={selectedEndDate}
                                    onApplyClick={onClick}
                                    onClearFilters={onClearFilters}
                                    clearDisable={clearDisable}
                                  /> */}
                          {/* PRODUCT FILTER WILL GO HERE */}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='products-catalog-wrapper'>
                <div className='row'>
                  <div className='col-sm-6 col-md-4 col-lg-3 col-xl-3'>
                    <div className='catalog-cards-wrapper'>
                      <div className='card'>
                        <div className='card-body'>
                          <div className='img-wrapper'>
                            <ImageLoader
                              src={catalogProductImage3}
                              fallbackImg={catalogProductImage3}
                              alt='table-img'
                              className='img-fluid'
                            />
                          </div>

                          <h4 className='yk-form-title-text'>
                            Adidas Yeezy QNTM
                          </h4>
                          <p className='yk-para-p2'>Hi-Res Coral</p>
                          <p className='yk-para-p3'>
                            SKU <span>#0125102022</span>
                          </p>
                        </div>
                        <div className='card-footer'>
                          <Button className='btn-transparent clear-filter-btn yk-badge-h7'>
                            ADD
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className='col-sm-6 col-md-4 col-lg-3 col-xl-3'>
                    <div className='catalog-cards-wrapper'>
                      <div className='card'>
                        <div className='card-body'>
                          <div className='img-wrapper'>
                            <ImageLoader
                              src={catalogProductImage3}
                              fallbackImg={catalogProductImage3}
                              alt='table-img'
                              className='img-fluid'
                            />
                          </div>

                          <h4 className='yk-form-title-text'>
                            Adidas Yeezy QNTM
                          </h4>
                          <p className='yk-para-p2'>Hi-Res Coral</p>
                          <p className='yk-para-p3'>
                            SKU <span>#0125102022</span>
                          </p>
                        </div>
                        <div className='card-footer'>
                          <Button className='btn-transparent clear-filter-btn yk-badge-h7'>
                            ADD
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className='col-sm-6 col-md-4 col-lg-3 col-xl-3'>
                    <div className='catalog-cards-wrapper'>
                      <div className='card'>
                        <div className='card-body'>
                          <div className='img-wrapper'>
                            <ImageLoader
                              src={catalogProductImage3}
                              fallbackImg={catalogProductImage3}
                              alt='table-img'
                              className='img-fluid'
                            />
                          </div>

                          <h4 className='yk-form-title-text'>
                            Adidas Yeezy QNTM
                          </h4>
                          <p className='yk-para-p2'>Hi-Res Coral</p>
                          <p className='yk-para-p3'>
                            SKU <span>#0125102022</span>
                          </p>
                        </div>
                        <div className='card-footer'>
                          <Button className='btn-transparent clear-filter-btn yk-badge-h7'>
                            ADD
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className='col-sm-6 col-md-4 col-lg-3 col-xl-3'>
                    <div className='catalog-cards-wrapper'>
                      <div className='card'>
                        <div className='card-body'>
                          <div className='img-wrapper'>
                            <ImageLoader
                              src={catalogProductImage3}
                              fallbackImg={catalogProductImage3}
                              alt='table-img'
                              className='img-fluid'
                            />
                          </div>

                          <h4 className='yk-form-title-text'>
                            Adidas Yeezy QNTM
                          </h4>
                          <p className='yk-para-p2'>Hi-Res Coral</p>
                          <p className='yk-para-p3'>
                            SKU <span>#0125102022</span>
                          </p>
                        </div>
                        <div className='card-footer'>
                          <Button className='btn-transparent clear-filter-btn yk-badge-h7'>
                            ADD
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className='col-sm-6 col-md-4 col-lg-3 col-xl-3'>
                    <div className='catalog-cards-wrapper'>
                      <div className='card'>
                        <div className='card-body'>
                          <div className='img-wrapper'>
                            <ImageLoader
                              src={catalogProductImage3}
                              fallbackImg={catalogProductImage3}
                              alt='table-img'
                              className='img-fluid'
                            />
                          </div>

                          <h4 className='yk-form-title-text'>
                            Adidas Yeezy QNTM
                          </h4>
                          <p className='yk-para-p2'>Hi-Res Coral</p>
                          <p className='yk-para-p3'>
                            SKU <span>#0125102022</span>
                          </p>
                        </div>
                        <div className='card-footer'>
                          <Button className='btn-transparent clear-filter-btn yk-badge-h7'>
                            ADD
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className='col-sm-6 col-md-4 col-lg-3 col-xl-3'>
                    <div className='catalog-cards-wrapper'>
                      <div className='card'>
                        <div className='card-body'>
                          <div className='img-wrapper'>
                            <ImageLoader
                              src={catalogProductImage3}
                              fallbackImg={catalogProductImage3}
                              alt='table-img'
                              className='img-fluid'
                            />
                          </div>

                          <h4 className='yk-form-title-text'>
                            Adidas Yeezy QNTM
                          </h4>
                          <p className='yk-para-p2'>Hi-Res Coral</p>
                          <p className='yk-para-p3'>
                            SKU <span>#0125102022</span>
                          </p>
                        </div>
                        <div className='card-footer'>
                          <Button className='btn-transparent clear-filter-btn yk-badge-h7'>
                            ADD
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className='col-sm-6 col-md-4 col-lg-3 col-xl-3'>
                    <div className='catalog-cards-wrapper'>
                      <div className='card'>
                        <div className='card-body'>
                          <div className='img-wrapper'>
                            <ImageLoader
                              src={catalogProductImage3}
                              fallbackImg={catalogProductImage3}
                              alt='table-img'
                              className='img-fluid'
                            />
                          </div>

                          <h4 className='yk-form-title-text'>
                            Adidas Yeezy QNTM
                          </h4>
                          <p className='yk-para-p2'>Hi-Res Coral</p>
                          <p className='yk-para-p3'>
                            SKU <span>#0125102022</span>
                          </p>
                        </div>
                        <div className='card-footer'>
                          <Button className='btn-transparent clear-filter-btn yk-badge-h7'>
                            ADD
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className='col-sm-6 col-md-4 col-lg-3 col-xl-3'>
                    <div className='catalog-cards-wrapper'>
                      <div className='card'>
                        <div className='card-body'>
                          <div className='img-wrapper'>
                            <ImageLoader
                              src={catalogProductImage3}
                              fallbackImg={catalogProductImage3}
                              alt='table-img'
                              className='img-fluid'
                            />
                          </div>

                          <h4 className='yk-form-title-text'>
                            Adidas Yeezy QNTM
                          </h4>
                          <p className='yk-para-p2'>Hi-Res Coral</p>
                          <p className='yk-para-p3'>
                            SKU <span>#0125102022</span>
                          </p>
                        </div>
                        <div className='card-footer'>
                          <Button className='btn-transparent clear-filter-btn yk-badge-h7'>
                            ADD
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Inventory;
