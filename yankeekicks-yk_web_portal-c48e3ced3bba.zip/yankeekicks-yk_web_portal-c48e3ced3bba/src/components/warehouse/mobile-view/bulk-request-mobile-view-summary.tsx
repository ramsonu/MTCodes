import CircleLoader from 'components/common/loader/circular-loader';
import React from 'react';

const BulkRequestMobileViewSummary = (props: any) => {
  const { summaryData } = props;

  return (
    <div className='parent-table-wrapper warehouse-table-wrapper YKCH-buldMobilePopup'>
      <div className='mobile-table-wrapper'>
        <div className='products-cards-wrapper'>
          {summaryData && summaryData?.length < 0 ? (
            <div className='circular-loader-wrapper yk-mobile-modal-loader'>
              <CircleLoader />
            </div>
          ) : (
            <ul className='cards-list'>
              {summaryData?.map((item: any, index: any) => {
                return (
                  <li
                    className='mb-4'
                    key={index}>
                    <div className='products-data-wrapper'>
                      <div className='product-img-name'>
                        <p className='name'>
                          {item['WarehouseTab.itemName']
                            ? item['WarehouseTab.itemName']
                            : '-'}
                          <div className='d-flex mt-1'>
                            <div className='size'>
                              {item['WarehouseTab.Option1']
                                ? item['WarehouseTab.Option1']
                                : '-'}
                            </div>
                          </div>
                        </p>
                      </div>

                      <div className='descriptions-wrapper'>
                        <p className='description-title'>Size</p>
                        <p className='description'>
                          {item['WarehouseTab.Option1']
                            ? item['WarehouseTab.Option1']
                            : '-'}
                        </p>
                      </div>
                      <div className='descriptions-wrapper'>
                        <p className='description-title'>SKU</p>
                        <p className='description'>
                          {item['WarehouseTab.sku']
                            ? item['WarehouseTab.sku']
                            : '-'}
                        </p>
                      </div>
                      <div className='descriptions-wrapper'>
                        <p className='description-title'>Barcode</p>
                        <p className='description'>
                          {item['WarehouseTab.barcode']
                            ? item['WarehouseTab.barcode']
                            : '-'}
                        </p>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
};

export default BulkRequestMobileViewSummary;
