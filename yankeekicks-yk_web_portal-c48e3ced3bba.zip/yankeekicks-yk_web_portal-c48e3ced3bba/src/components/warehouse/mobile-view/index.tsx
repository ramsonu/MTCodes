import React, { useState, useEffect } from 'react';
import NoDataFound from 'components/common/no-data-found';
import ImageLoader from 'components/common/image-loader';
import CircleLoader from 'components/common/loader/circular-loader';
import { getTime } from 'utils/util';
import {
  WAREHOUSE_STATUS,
  WARE_HOUSE_TABLE_TAB_QUERY_STATUS,
} from '../../warehouse/constants';
import productImg from 'assets/images/big-product-img.svg';

const WarehouseMobileViewCard = (props: any) => {
  const {
    setIsVisibleMessage,
    setSeverityType,
    setMessage,
    getRowData,
    data,
    getStatus,
    getActionStatus,
    isDataLoading,
    setShowScanModal,
    setRequestNumber,
    setBarCodeScanResult,
    setRowData,
    checkInCheckoutHandler,
  } = props;

  const scanRequestHandler = (event: any) => {
    checkInCheckoutHandler(
      event?.['WarehouseProductList.RequestNumber'],
      event
    );
  };

  return (
    <>
      <div className='mobile-table-wrapper'>
        {isDataLoading ? (
          <div className='circular-loader-wrapper yk-mobile-tab-loader'>
            <CircleLoader />
          </div>
        ) : (
          <>
            {data?.length > 0 &&
              data?.map((row: any, index: any) => {
                return (
                  <div
                    className='products-cards-wrapper'
                    key={index}
                    // onClick={
                    //   row['WarehouseProductList.request_count'] > 1 &&
                    //   getRowData(
                    //     Number(row['WarehouseProductList.RequestNumber'])
                    //   )
                    // }
                  >
                    <ul className='cards-list'>
                      <li>
                        <div className='products-data-wrapper'>
                          <div className='product-img-name'>
                            <ImageLoader
                              src={row['WarehouseProductList.imageUrl']}
                              fallbackImg={productImg}
                              alt='cart-img'
                              className='img-fluid'
                            />

                            <p
                              className='name'
                              onClick={() =>
                                getRowData(
                                  row['WarehouseProductList.RequestNumber']
                                )
                              }>
                              {row['WarehouseProductList.itemName']
                                ? row['WarehouseProductList.itemName']
                                : '--'}

                              <div className='d-flex mt-1'>
                                <div className='size'>
                                  {row['WarehouseProductList.size']
                                    ? row['WarehouseProductList.size']
                                    : '--'}
                                </div>
                                <div className='ms-auto'>
                                  <span
                                    className={`yk-color-badge ${
                                      row['WarehouseProductList.eventType'] ===
                                        WAREHOUSE_STATUS.PENDING ||
                                      row['WarehouseProductList.eventType'] ===
                                        WAREHOUSE_STATUS.MISSING ||
                                      row['WarehouseProductList.eventType'] ===
                                        WAREHOUSE_STATUS.SOLD
                                        ? 'red'
                                        : 'green'
                                    } `}>
                                    {getStatus(
                                      row['WarehouseProductList.eventType']
                                    )}
                                  </span>
                                </div>
                              </div>
                            </p>
                          </div>
                          <div className='descriptions-wrapper'>
                            <p className='description-title'>request</p>
                            <p className='description'>
                              {row['WarehouseProductList.RequestNumber']
                                ? row['WarehouseProductList.RequestNumber']
                                : '--'}
                            </p>
                          </div>
                          <div className='descriptions-wrapper'>
                            <p className='description-title'>SKU</p>
                            <p className='description'>
                              {row['WarehouseProductList.inventory_sku']
                                ? row['WarehouseProductList.inventory_sku']
                                : '--'}
                            </p>
                          </div>
                          <div className='descriptions-wrapper'>
                            <p className='description-title'>Barcode</p>
                            <p className='description'>
                              {row['WarehouseProductList.Barcode']
                                ? row['WarehouseProductList.Barcode']
                                : '--'}
                            </p>
                          </div>

                          <div className='descriptions-wrapper'>
                            <p className='description-title'>Bin-shelf</p>
                            <p className='description'>
                              <p className='description'>
                                {row['WarehouseProductList.bin'] &&
                                row['WarehouseProductList.rack']
                                  ? `${row['WarehouseProductList.bin']}-${row['WarehouseProductList.rack']}`
                                  : '--'}
                              </p>
                            </p>
                          </div>
                          <div className='descriptions-wrapper'>
                            <p className='description-title'>Requested By</p>
                            <p className='description'>
                              {row['WarehouseProductList.userName']
                                ? row['WarehouseProductList.userName']
                                : '--'}
                            </p>
                          </div>
                          <div className='descriptions-wrapper'>
                            <p className='description-title'>Time</p>
                            <p className='description'>
                              {row['WarehouseProductList.eventTime']
                                ? getTime(row['WarehouseProductList.eventTime'])
                                : '--'}
                            </p>
                          </div>
                          <div className='text-center'>
                            {row['WarehouseProductList.request_count'] > 1 ? (
                              <>
                                <span
                                  className='table-actions ms-2'
                                  onClick={() =>
                                    getRowData(
                                      row['WarehouseProductList.RequestNumber']
                                    )
                                  }>
                                  <span className='yk-table-count-collapse'>
                                    {`+${row['WarehouseProductList.request_count']} more`}
                                  </span>
                                </span>
                              </>
                            ) : (
                              <>
                                {(row['WarehouseProductList.eventType'] ===
                                  WARE_HOUSE_TABLE_TAB_QUERY_STATUS.PENDING ||
                                  row['WarehouseProductList.eventType'] ===
                                    WARE_HOUSE_TABLE_TAB_QUERY_STATUS.CHECK_OUT) && (
                                  <button
                                    className='btn primary-mobile-btn'
                                    onClick={() => scanRequestHandler(row)}>
                                    {getActionStatus(
                                      row['WarehouseProductList.eventType']
                                    )}
                                  </button>
                                )}
                              </>
                            )}
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                );
              })}
          </>
        )}
      </div>
      <>{!data?.length && !isDataLoading && <NoDataFound />}</>
    </>
  );
};

export default WarehouseMobileViewCard;
