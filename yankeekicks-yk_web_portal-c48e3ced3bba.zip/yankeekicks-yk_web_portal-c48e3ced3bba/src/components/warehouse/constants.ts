export const STATUS_TYPE: any = {
  CHECK_OUT_PENDING: 'Check Outs Pending',
  CHECK_IN_PENDING: 'Check Ins Pending',
};

export const WAREHOUSE_STATUS = {
  CHECKIN: 'CheckIn',
  CHECKOUT: 'CheckOut',
  CHECK__IN: 'Check In',
  CHECK__OUT: 'Check Out',
  CHECKED_IN: 'Checked In',
  CHECKED_OUT: 'Checked Out',
  MISSING: 'Missing',
  PENDING: 'Pending',
  SOLD: 'Sold',
  FOUND: 'Found',
};

export const SUCCESS_MESSAGE = {
  CHECK_OUT_SUCCESS_MSG: 'Shoes Checked Out',
  CHECK_IN_SUCCESS_MSG: 'Shoes Checked In',
  ERROR_MSG: 'Something went wrong.',
  REQUEST_WARNING: 'Bulk Checkout Canceled',
};

export const WARE_HOUSE_TABLE_TAB_QUERY_STATUS = {
  CHECK_IN: 'CheckIn',
  CHECK_OUT: 'CheckOut',
  PENDING: 'Pending',
  MISSING:'Missing',
  SOLD: 'Sold',
};

export const WARNING_MODAL = {
  COMPLETE_BUTTON_TITLE: 'Complete Request',
  LEAVE_BUTTON_TITLE: 'Leave',
  TITLE: 'Request Incomplete',
  MSG: ` Check out is not complete for all shoes. Request will not be
  complete if you go back. Are you sure you want to leave?`,
};

export const SHELF_BIN_NOTIFICATION = {
  SUCCESS_MESSAGE: 'Shoes Location Updated!',
  UPLOAD_MESSAGE: 'File uploaded successfully,it will take 4-5 mins to update!',
  ERROR_MESSAGE: 'Something went wrong.',
  FILE_ERROR_MESSAGE: 'Error While Uploading!',
  INVALID_FILE_ERROR_MESSAGE: 'Invalid file data!',
};

export const UPLOAD_ERROR_POP_UP = {
  TITLE: 'Upload Error',
  MESSAGE: `Download the sheet with errors and try again.`,
  BUTTON_TITLE: 'Download',
  UPLOADING: 'Upload in progress...',
};

export const STATUS_POLLING_TIME = 10000;
export const BIN_SHELF_DISCLAIMER = `Please check the sheet carefully before uploading.`;
export const FILE_UPLOAD = `Please wait while we process the uploaded file.`;
