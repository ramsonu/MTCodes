import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { useDispatch } from 'react-redux';
import { actions } from 'store/reducers/auth';
import dynamic from 'next/dynamic';
import { useIsAuthenticated } from '@azure/msal-react';
import { doRequest } from 'utils/request';
import { USER_DETAILS, USER_VALIDATION } from 'services/apiUrl';
import jwt_decode from 'jwt-decode';
import {
  checkPermission,
  checkPermissionForLayout,
  displayNoResultsFound,
  displayUnauthorized,
  navigateTo,
} from 'utils/util';
import TryOutNotification from 'components/common/notification/tryout-notifications';
import TopHeader from 'components/common/top-header';
import CircleLoader from 'components/common/loader/circular-loader';
import { USER_ROLES } from 'utils/constants';

const CommonLayout = dynamic(
  () => import('./common').then((mod) => mod.default),
  {
    ssr: false,
  }
);

const Layout = ({ children }: any) => {
  const [isJwtTokenAvailable, setIsJwtTokenAvailable] = useState(false);
  const [isJwtTokenInvalid, setJwtTokenInvalid] = useState(false);
  const [authData, setAuthData] = useState<any>({});
  const isAuthenticated = useIsAuthenticated();

  const router = useRouter();
  const dispatch = useDispatch();
  const shoeSizePath = /^\/shoesize.*$/.test(router.pathname);

  const renderHeader = () => {
    if (shoeSizePath) {
      return <TryOutNotification />;
    }
    return null;
  };

  useEffect(() => {
    const userRole = localStorage.getItem('user-role');
    if (router.pathname === '/' && userRole) {
      const pathName = navigateTo(userRole);
      const roles = [
        USER_ROLES?.SALES_ASSOCIATE,
        USER_ROLES?.WAREHOUSE_PERSONAL,
        USER_ROLES?.STORE_ADMIN,
        USER_ROLES?.WAREHOUSE_ADMIN,
        USER_ROLES?.YK_ADMIN,
      ];
      if (pathName) {
        if (pathName === '/' && !roles?.includes(userRole)) {
          router.push('/unauthorized', undefined, { shallow: true });
        }
        router.push(pathName, undefined, { shallow: true });
      } else {
        return;
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [router.pathname, isJwtTokenAvailable]);

  useEffect(() => {
    const fetchToken = async () => {
      if (isAuthenticated || localStorage.getItem('access-token')) {
        try {
          const payload = {
            accessToken: localStorage.getItem('access-token'),
          };
          const response: any = await doRequest(
            USER_VALIDATION,
            'post',
            payload,
            ''
          );
          setAuthData(response);
        } catch (error: any) {
          console.log('error: ', error);
          setAuthData({});
          if (
            error?.response?.status === 401 ||
            error?.response?.status === 403
          ) {
            setJwtTokenInvalid(true); // to display unauthorized page
          } else {
            setJwtTokenInvalid(false);
          }
          setIsJwtTokenAvailable(false); // don't give access to application
        }
      }
    };

    if (!localStorage.getItem('jwt-token')) {
      fetchToken();
    } else {
      setIsJwtTokenAvailable(true);
    }
  }, [isAuthenticated, isJwtTokenAvailable, router.pathname]);

  useEffect(() => {
    const storeUserInfo = async () => {
      setIsJwtTokenAvailable(true);
      localStorage.setItem('jwt-token', authData?.data?.token);
      const decodedToken: any = jwt_decode(authData?.data?.token);
      try {
        const userInfoResponse = await doRequest(
          `${USER_DETAILS}/${decodedToken?.sub}`,
          'get',
          '',
          ''
        );
        if (userInfoResponse?.data) {
          const locations = userInfoResponse?.data?.map((item: any) => {
            return item?.location;
          });
          const locationIds = userInfoResponse?.data?.map((item: any) => {
            return item?.locationId;
          });

          localStorage.setItem('storeLocation', locations[0]);
          localStorage.setItem('totalLocation', locations?.join(','));
          localStorage.setItem('totalLocationIds', locationIds?.join(','));
          localStorage.setItem('storeLocationId', locationIds[0]);
          localStorage.setItem('user-Id', decodedToken?.user_id);
          localStorage.setItem('user-role', userInfoResponse?.data[0]?.role);
          localStorage.setItem('user-name', decodedToken?.name);

          // Check user has permission for current path
          const currentPathPermission = checkPermissionForLayout(
            router.pathname
          );
          if (!currentPathPermission) {
            // Navigate user to respective portal
            const pathName: any = navigateTo(userInfoResponse?.data[0]?.role);
            router.push(pathName);
          }
          dispatch(actions.setUserDetails(authData.data.token));
        }
      } catch (error: any) {
        console.log('error: ', error);
      }
    };

    if (
      localStorage.getItem('access-token') &&
      !localStorage.getItem('jwt-token') &&
      Object.keys(authData)?.length > 0
    ) {
      // when oAuth api has data of jwt-token and already jwt token is not set -> then store userInfo
      storeUserInfo();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authData, isJwtTokenAvailable]);

  const renderApplication = (
    <div className='layout'>
      {renderHeader()}
      {(() => {
        return <CommonLayout>{children}</CommonLayout>;
      })()}
    </div>
  );

  const displayLoader = (
    <div className='circular-loader-wrapper'>
      <CircleLoader />
    </div>
  );

  const checkPathnames =
    router.pathname?.includes('/shoesize') ||
    router.pathname?.includes('/warehouse') ||
    router.pathname?.includes('/unauthorized');

  const displayUnauthorizedPage = (
    <>
      <TopHeader></TopHeader>
      {displayUnauthorized()}
    </>
  );

  const displayNoResultsFoundPage = (
    <>
      <TopHeader></TopHeader>
      {displayNoResultsFound()}
    </>
  );

  return (
    <>
      {(() => {
        if (isJwtTokenAvailable && localStorage.getItem('jwt-token')) {
          // if current user roles has access for portal then move further
          if (
            checkPermission('SHOESIZE_PORTAL') ||
            checkPermission('WAREHOUSE_PORTAL')
          ) {
            if (checkPermissionForLayout(router.pathname)) {
              return renderApplication;
            } else if (router.pathname === '/') {
              return displayLoader; // no permission yet, instead of showing no results found, display loader
            } else if (checkPathnames) {
              return displayUnauthorizedPage; // no permission and accessing valid pages
            } else {
              return displayNoResultsFoundPage; // no permission and accessing invalid pages
            }
          } else {
            if (
              localStorage?.getItem('user-role') ||
              (isJwtTokenAvailable &&
                localStorage?.getItem('user-Id') &&
                !localStorage?.getItem('user-role')) ||
              isJwtTokenInvalid ||
              !isJwtTokenAvailable
            ) {
              return displayUnauthorizedPage; // current user role don't have the access
            } else {
              return displayLoader; // when user role is not yet available (api is in pending state)
            }
          }
        } else {
          // When JWT is not available or oAuth api has error
          if (isJwtTokenInvalid) {
            return displayUnauthorizedPage; // when oauth gives error
          } else {
            return displayLoader; // when application renders first time
          }
        }
      })()}
    </>
  );
};

export default Layout;
