import { doRequest } from 'utils/request';
import {
  CATALOG_GET_S3_IMAGE,
  NOTIFICATION_UPDATE,
  INV_GET_SHOE_INFO_FROM_SHOPIFY,
  INV_CHECK_IN_CHECK_OUT_REQUEST,
  DOWNLOAD_BIN_SHELF_INVENTORY,
  UPDATE_BIN_SHELF,
  GET_BIN_SHELF_UPDATE_STATUS,
  RETAIL_PRODUCT_SELL,
} from '../apiUrl';

const getImage = async (param: any) => {
  return doRequest(`${CATALOG_GET_S3_IMAGE}?path=${param}`, 'get');
};

const putNotificationUpdate = async (param: any) => {
  return doRequest(NOTIFICATION_UPDATE, 'put', param);
};
const getStoreInfoFromShopify = async (param: any) => {
  return doRequest(INV_GET_SHOE_INFO_FROM_SHOPIFY, 'get', param);
};

const checkInCheckOutRequest = async (param: any) => {
  return doRequest(INV_CHECK_IN_CHECK_OUT_REQUEST, 'post', param);
};

const downloadBinShelfInventory = async () => {
  return doRequest(
    `${
      process.env.NEXT_PUBLIC_APP_INVENTORY_REST_API_DOMAIN
    }/inventory/export/excel/${localStorage?.getItem('storeLocationId')}`,
    'get',
    {},
    'application/vnd.ms-excel',
    false,
    false,
    true
  );
};

const updateBinShelf = async (param: any) => {
  return doRequest(UPDATE_BIN_SHELF, 'post', param);
};

const getBinShelfUpdateStatus = async () => {
  return doRequest(
    GET_BIN_SHELF_UPDATE_STATUS,
    'get',
    {},
    '',
    false,
    false,
    true
  );
};
const retailSellOfProduct = async (orderNumber: any, param: any) => {
  const retailSellUrl = `${RETAIL_PRODUCT_SELL}?orderNumber=${orderNumber}`;
  return doRequest(retailSellUrl, 'put', param);
};
export {
  getImage,
  putNotificationUpdate,
  getStoreInfoFromShopify,
  checkInCheckOutRequest,
  downloadBinShelfInventory,
  updateBinShelf,
  getBinShelfUpdateStatus,
  retailSellOfProduct,
};
