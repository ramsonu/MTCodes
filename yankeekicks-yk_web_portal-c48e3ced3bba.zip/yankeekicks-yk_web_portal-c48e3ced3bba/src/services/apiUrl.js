//Kiosk api
export const KIOSK_GET_FEATURES = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/kiosk-feature`;
export const KIOSK_GET_PRODUCT_BROWSE = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/kiosk-product-browse`;
export const KIOSK_GET_SEARCH = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/kiosk-search`;
export const KIOSK_GET_SEARCH_WITH_FILTERS = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/kiosk-search-with-filters`;
export const KIOSK_GET_PRODUCTS = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/kiosk-products`;
export const KIOSK_GET_PRODUCT_DETAILS = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/kiosk-product-details`;
export const KIOSK_GET_PRODUCT_VARIANT_DETAILS = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/kiosk-product-variants`;
export const KIOSK_REQUEST_TO_TRY = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/kiosk-tryout-item-master`;

//Cube api
export const Cube_API_URL = `${process.env.NEXT_PUBLIC_APP_CUBE_API_DOMAIN}/cubejs-api/v1`;

//Inventory api
export const INV_GET_SHOE_INFO_FROM_SHOPIFY = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/shoesize-get-shoe-info-from-shopify`;
export const INV_CHECK_IN_CHECK_OUT_REQUEST = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/shoesize-checkIn-checkOut-request`;
export const BARCODE_SCAN_CHECKOUT = `${process.env.NEXT_PUBLIC_APP_INVENTORY_REST_API_DOMAIN}/getDataByBarcodeAndRequestId`;
export const MARK_MISSING = `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/barcode/missing`;
export const DOWNLOAD_BIN_SHELF_INVENTORY = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/shoesize-download-inventory-for-bin-shelf`;
export const UPDATE_BIN_SHELF = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/shoesize-update-bin-shelf`;
export const GET_BIN_SHELF_UPDATE_STATUS = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/shoesize-check-bin-shelf-status`;

//Catalog
export const CATALOG_GET_S3_IMAGE = `${process.env.NEXT_PUBLIC_APP_CATALOGE_S3_API_DOMAIN}/document/downloadS3ImageUrl`;
export const GET_BRAND_NAME_FROM_SKU = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/consignment/consignee-get-brandName-from-sku`;

//Validation api
export const USER_VALIDATION = `${process.env.NEXT_PUBLIC_APP_USER_VALIDATION}/authenticate/oauth`;

//Notification APis
export const COMMON_NOTIFICATION = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/notifications`;
export const TRYOUT_NOTIFICATION = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/notifications/tryout`;
export const TRYOUT_NOTIFICATION_UPDATE = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/notifications/tryout-update`;
export const GET_PRODUCT_IMAGE_DATA = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/get-product-image-info-from-sku`;
export const NOTIFICATION_UPDATE = `${process.env.NEXT_PUBLIC_APP_API_PORT}/notification_dev/notificationupdate/`;
export const SETTINGS_NOTIFICATION_UPDATE = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/notifications/notification-update`;
export const NOTIFICATION_UPDATE_FLAG = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/notifications/notification-update-flag`;

//Store
export const GET_STORE = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/store-location`;
export const GET_STORE_BY_LOC = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/store-by-location`;

//Users
export const GET_USER_BY_ID = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/shoesize-get-user-by-id`;

//User details
export const USER_DETAILS = `${process.env.NEXT_PUBLIC_APP_USER_VALIDATION}/user/role`;

//Retail sell of products
export const RETAIL_PRODUCT_SELL = `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/update/sold`;

//To get barcode of products for check-in-check-out and retail sell 
export const GET_BARCODE_OF_PRODUCT = `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}`;
