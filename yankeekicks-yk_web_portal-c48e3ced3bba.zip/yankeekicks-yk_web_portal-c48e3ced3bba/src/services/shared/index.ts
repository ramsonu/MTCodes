import { doRequest } from 'utils/request';
import {
  GET_STORE,
  GET_STORE_BY_LOC,
  GET_USER_BY_ID,
  SETTINGS_NOTIFICATION_UPDATE,
} from '../apiUrl';

const getStore = async () => {
  return doRequest(GET_STORE, 'get');
};

const getStoreByLoc = async (params: any) => {
  return doRequest(GET_STORE_BY_LOC, 'post', params);
};

const getUser = async (id: any) => {
  return doRequest(`${GET_USER_BY_ID}?id=${id}`, 'get', '', '', true, true);
};
const getNotification = async (email: any) => {
  return doRequest(
    `${SETTINGS_NOTIFICATION_UPDATE}?email=${email}`,
    'get',
    '',
    '',
    true,
    true
  );
};

const getSalesAssociate = async (id: any) => {
  return doRequest(`${GET_USER_BY_ID}?id=${id}`, 'get', '', '', false, false);
};
export {
  getStore,
  getStoreByLoc,
  getUser,
  getNotification,
  getSalesAssociate,
};
