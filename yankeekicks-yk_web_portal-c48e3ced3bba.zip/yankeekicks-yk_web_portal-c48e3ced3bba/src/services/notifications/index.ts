import { doRequest } from 'utils/request';
import {
  COMMON_NOTIFICATION,
  GET_PRODUCT_IMAGE_DATA,
  NOTIFICATION_UPDATE_FLAG,
  TRYOUT_NOTIFICATION,
  TRYOUT_NOTIFICATION_UPDATE,
} from '../apiUrl';
export const getCommonNotification = async () => {
  const req = await doRequest(COMMON_NOTIFICATION);
  return req.data;
};
export const getTryoutNotification = async (storeId: any) => {
  const req = await doRequest(
    `${TRYOUT_NOTIFICATION}?storeId=${storeId}&locationId=${localStorage?.getItem(
      'storeLocationId'
    )}`
  );
  return req.data;
};
export const getSkuDetails = async (sku: string) => {
  const req = await doRequest(`${GET_PRODUCT_IMAGE_DATA}?sku=${sku}`);
  return req.data;
};

export const postUpdateTryOutData = async (params: any) => {
  const req = await doRequest(TRYOUT_NOTIFICATION_UPDATE, 'post', params);
  return req.data;
};

export const putUpdateNotifications = async (params: any, email: any) => {
  const req = await doRequest(
    `${NOTIFICATION_UPDATE_FLAG}?email=${email}`,
    'put',
    params
  );
  return req.data;
};
