import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  storeLocations: [],
  selected: {},
  loading: false,
};

const slice = createSlice({
  name: 'shared',
  initialState,
  reducers: {
    init(state, action) {
      state.loading = true;
    },
    set(state, action) {
      state.storeLocations = action.payload;
      state.selected = action.payload && action.payload[0];
      state.loading = false;
    },
    selected(state, action) {
      state.selected = action.payload;
    },
    error(state, action) {
      state.loading = false;
    },
  },
});

export default slice.reducer;
export const { reducer, actions } = slice;
export { initialState };
