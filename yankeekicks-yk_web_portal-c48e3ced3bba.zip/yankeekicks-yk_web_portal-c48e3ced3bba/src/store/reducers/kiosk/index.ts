import { createSlice } from '@reduxjs/toolkit';
import { HYDRATE } from 'next-redux-wrapper';

const initialState = {
  products: [] as any,
  featuredProducts: [],
  brandProducts: [],
  product: {},
  filterTypes: {
    type: [],
    color: [],
    size: [],
    brand: [],
    model: [],
    date: [],
    availability: [],
    price: [0, 0],
    title: '',
  } as any,
  filterTypesForCube: {
    type: [],
    color: [],
    size: [],
    brand: [],
    model: [],
    date: [],
    availability: [],
    price: [0, 0],
    title: '',
  } as any,
  loading: false,
  error: {},
  searchText: '',
  isFilteredDataloading: false,
  isBrandsLoading: false,
  isBrandsError: {},
  cart: [] as Array<any>,
  requestToTryData: [] as Array<any>,
  cursorData: null as any,
  isProductsLoading: false,
};

const slice = createSlice({
  name: 'kiosk',
  initialState,
  reducers: {
    init(state, action) {
      state.loading = true;
      state.error = {};
    },
    set(state, action) {
      state.featuredProducts = action.payload;
      state.loading = false;
    },
    setProductsLoading(state, action) {
      const stopLoading = action.payload === 'stop loading' ? false : true;
      state.isProductsLoading = stopLoading;
    },
    setProducts(state, action) {
      state.products = action.payload;
      state.loading = false;
      state.isProductsLoading = false;
      state.error = {};
    },
    setProductsWhileScroll(state, action) {
      state.products = [...state.products, action.payload];
      state.loading = false;
    },
    setBrandsLoading(state, action) {
      state.isBrandsLoading = true;
      state.loading = false;
    },
    setBrandsError(state, action) {
      state.isBrandsLoading = false;
      state.isBrandsError = action.payload;
    },
    setBrandProducts(state, action) {
      state.brandProducts = action.payload;
      state.isBrandsLoading = false;
      state.loading = false;
    },
    error(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
    setError(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
    setSearch(state, action) {
      return {
        ...state,
        filterTypes: {
          ...state.filterTypes,
          type: action.payload,
        },
      };
    },
    setSearchForCube(state, action) {
      return {
        ...state,
        filterTypes: {
          ...state.filterTypesForCube,
          type: action.payload,
        },
      };
    },
    initFilteredData(state, action) {
      state.isFilteredDataloading = true;
    },
    setFilteredData(state, action) {
      // state.products = action.payload;
      state.isFilteredDataloading = false;
    },
    setFilters(state, action) {
      let { filterItem, filterType } = action.payload;
      const isTitle = filterType === 'title';
      let item =
        !isTitle &&
        (state.filterTypes[filterType]?.includes(filterItem)
          ? state.filterTypes[filterType].filter(
              (item: any) => item !== filterItem
            )
          : [...state.filterTypes[action.payload.filterType], filterItem]);
      state.filterTypes = {
        ...state.filterTypes,
        [filterType]: !isTitle ? item : filterItem,
      };
    },
    setFiltersForCube(state, action) {
      let { filterItem, filterType } = action.payload;
      const isTitle = filterType === 'title';
      let item =
        !isTitle &&
        (state.filterTypesForCube[filterType]?.includes(filterItem)
          ? state.filterTypesForCube[filterType].filter(
              (item: any) => item !== filterItem
            )
          : [
              ...state.filterTypesForCube[action.payload.filterType],
              filterItem,
            ]);
      state.filterTypesForCube = {
        ...state.filterTypesForCube,
        [filterType]: !isTitle ? item : filterItem,
      };
    },
    setFilterValueBasedOnKey(state, action) {
      state.filterTypes = {
        ...state.filterTypes,
        [action.payload.filterKey]: action.payload.filterValue,
      };
    },
    setFilterValueBasedOnKeyForCube(state, action) {
      state.filterTypesForCube = {
        ...state.filterTypesForCube,
        [action.payload.filterKey]: action.payload.filterValue,
      };
    },
    clearFiltersByKey(state, action) {
      state.filterTypes = {
        ...state.filterTypes,
        [action.payload.filterType]: Array.isArray(action.payload.filterItem)
          ? []
          : '',
      };
    },
    setSelectedFiltersForCube(state, action) {
      state.filterTypesForCube = action.payload;
    },
    clearFiltersByKeyForCube(state, action) {
      state.filterTypesForCube = {
        ...state.filterTypesForCube,
        [action.payload.filterType]: Array.isArray(action.payload.filterItem)
          ? []
          : '',
      };
    },
    clearAllFilters(state, action) {
      state.filterTypes = {
        ...initialState.filterTypes,
      };
    },
    clearAllFiltersForCube(state, action) {
      state.filterTypesForCube = {
        ...initialState.filterTypesForCube,
      };
    },
    clearFiltersExceptTitle(state, action) {
      state.filterTypes = {
        ...state.filterTypes,
        type: [],
        color: [],
        size: [],
        brand: [],
        model: [],
        date: [],
        availability: [],
        price: [0, 0],
      };
    },
    clearFiltersExceptTitleForCube(state, action) {
      state.filterTypesForCube = {
        ...state.filterTypesForCube,
        type: [],
        color: [],
        size: [],
        brand: [],
        model: [],
        date: [],
        availability: [],
        price: [0, 0],
      };
    },
    addToCart(state, action) {
      const itemInCart = state.cart.find(
        (item: any) => item.variantId === action.payload.variantId
      );
      if (itemInCart) {
        itemInCart.quantity++;
      } else {
        state.cart.push({ ...action.payload, quantity: 1 });
      }
    },
    incrementQuantity(state, action) {
      const item: any = state.cart.find(
        (item: any) => item.id === action.payload
      );
      item.quantity++;
    },
    decrementQuantity(state, action) {
      const item: any = state.cart.find(
        (item: any) => item.id === action.payload
      );
      if (item.quantity === 1) {
        item.quantity = 1;
      } else {
        item.quantity--;
      }
    },
    removeItem(state, action) {
      const removeItem = state.cart.filter(
        (item: any) => item.variantId !== action.payload
      );
      state.cart = removeItem;
    },
    clearCart(state, action) {
      state.cart = [];
    },
    setRequestToTryData(state, action) {
      state.requestToTryData = action.payload;
      state.loading = false;
    },
    setCursorData(state, action) {
      state.cursorData = action.payload;
    },
  },
  extraReducers: {
    [HYDRATE]: (state, action) => {
      return {
        ...state,
        searchText: action.payload,
      };
    },
  },
});

export default slice.reducer;
export const { reducer, actions } = slice;
export { initialState };
