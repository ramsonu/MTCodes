import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  requestDetails: [] as Array<any>,
  status: 'request',
  requestDetailsToggle: false as any,
  wareHouseFilters: {
    bin: [],
    size: [],
    brand: [],
    requestBy: [],
  } as any,
  binShelfRecord: [] as Array<any>,
};

const slice = createSlice({
  name: 'warehouse',
  initialState,
  reducers: {
    setRequestDetails(state, action) {
      state.requestDetails = action.payload;
    },
    setRequestDetailsToggle(state, warehouseAction) {
      state.requestDetailsToggle = warehouseAction.payload;
    },
    setWareHouseFilters(state, action) {
      let { filterItem, filterType } = action.payload;
      let item = state.wareHouseFilters[filterType]?.includes(filterItem)
        ? state.wareHouseFilters[filterType].filter(
            (item: any) => item !== filterItem
          )
        : [...state.wareHouseFilters[action.payload.filterType], filterItem];
      state.wareHouseFilters = {
        ...state.wareHouseFilters,
        [filterType]: item,
      };
    },
    clearWareHouseFilters(state, action) {
      state.wareHouseFilters = {
        ...initialState.wareHouseFilters,
      };
    },
    setBinShelfRecord(state, action) {
      state.binShelfRecord = action.payload;
    },
    removeBinShelfRecord(state, action) {
      const removeItem = state.binShelfRecord.filter(
        (item: any) => item.rowId !== action.payload
      );
      state.binShelfRecord = removeItem;
    },
  },
});

export default slice.reducer;
export const { reducer, actions } = slice;
export { initialState };
