import { combineReducers } from 'redux';
import kiosk from './kiosk';
import shoesize from './shoesize';
import warehouse from './warehouse';
import auth from './auth';
import consignment from './consignment';
import shared from './shared';

const allReducers = combineReducers({
  kiosk,
  shoesize,
  warehouse,
  auth,
  consignment,
  shared,
});

const rootReducer = (state: any, action: any) => {
  return allReducers(state, action);
};

export default rootReducer;
