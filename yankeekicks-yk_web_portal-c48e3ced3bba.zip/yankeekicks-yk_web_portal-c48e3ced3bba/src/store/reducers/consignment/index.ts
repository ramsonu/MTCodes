import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  queue: [] as Array<any>,
  bulkRecord: [] as Array<any>,
};

const slice = createSlice({
  name: 'consignment',
  initialState,
  reducers: {
    setQueue(state, action) {
      state.queue = action.payload;
    },
    setBulkRecord(state, action) {
      state.bulkRecord = action.payload;
    },
  },
});

export default slice.reducer;
export const { reducer, actions } = slice;
export { initialState };
