import { spawn } from '@redux-saga/core/effects';
import {
  watchGetFeature,
  watchGetBrands,
  watchGetProducts,
  watchGetSearchWithFilters,
  watchRequestToTry,
} from './kiosk/index';
import { watchGetStoreLocation } from './shared/index';

export default function* rootSaga() {
  yield spawn(watchGetFeature);
  yield spawn(watchGetBrands);
  yield spawn(watchGetSearchWithFilters);
  yield spawn(watchGetProducts);
  yield spawn(watchRequestToTry);
  yield spawn(watchGetStoreLocation);
}
