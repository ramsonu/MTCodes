import { call, put, takeEvery } from 'redux-saga/effects';
import { STORE_LOCATION_REQUEST } from 'actions/shared';
import { actions } from 'store/reducers/shared';
import { getStore } from 'services/shared';

export function* getStoreLocationSaga(action) {
  try {
    yield put(actions.init());
    const payload = yield call(getStore);
    if (payload?.data) {
      const store = payload?.data;
      if (localStorage?.getItem('graphStoreLocation') == null) {
        localStorage?.setItem('storeId', store[0].id);
        localStorage?.setItem('locationId', store[0].id);
        localStorage?.setItem('storeLocation', store[0].location);
      }
      yield put(actions.set(payload.data));
    } else if (payload?.errors) {
      yield put(actions.error(payload.errors));
    }
  } catch (e) {
    yield put(actions.error(e));
  }
}

export function* watchGetStoreLocation() {
  yield takeEvery(STORE_LOCATION_REQUEST, getStoreLocationSaga);
}
