import { call, put, takeEvery } from 'redux-saga/effects';
import {
  FEATURE_REQUEST,
  BRANDS_REQUEST,
  PRODUCTS_REQUEST,
  SEARCH_WTIH_FILTERS_REQUEST,
  REQUEST_TO_TRY_REQUEST,
} from 'actions/kiosk';
import { actions } from 'store/reducers/kiosk';
import {
  getFeature,
  getBrands,
  getSearchWithFilters,
  getProducts,
  postRequestToTry,
} from 'services/kiosk';

export function* getFeatureSaga(action) {
  try {
    yield put(actions.init());
    const payload = yield call(getFeature);
    if (payload?.data) {
      yield put(actions.set(payload.data.data.products.nodes));
    } else if (payload?.errors) {
      yield put(actions.error(payload.errors));
    }
  } catch (e) {
    yield put(actions.error(e));
  }
}

export function* getBrandsSaga(action) {
  try {
    yield put(actions.init());
    const payload = yield call(getBrands);
    if (payload?.data) {
      yield put(actions.setBrandProducts(payload.data));
    } else if (payload?.errors) {
      yield put(actions.error(payload.errors));
    }
  } catch (e) {
    yield put(actions.error(e));
  }
}
export function* getProductsSaga(action) {
  try {
    actions.init();
    actions.setProductsLoading();
    const payload = yield call(getProducts, action.payload.params);
    if (payload?.data) {
      yield put(actions.setProducts(payload.data?.data?.products?.edges));
      yield put(actions.setCursorData(payload.data?.data?.products?.pageInfo));
    } else if (payload?.errors) {
      yield put(actions.error(payload.errors));
    }
  } catch (e) {
    yield put(actions.error(e));
  }
}

export function* getSearchWithFiltersSaga(action) {
  try {
    actions.init();
    actions.setProductsLoading();
    const payload = yield call(getSearchWithFilters, action.payload.params);
    if (payload?.data) {
      yield put(actions.setProducts(payload.data?.data?.products?.edges));
      yield put(actions.setCursorData(payload.data?.data?.products?.pageInfo));
    } else if (payload?.errors) {
      yield put(actions.error(payload.errors));
    }
  } catch (e) {
    yield put(actions.error(e));
  }
}

export function* requestToTrySaga(action) {
  try {
    const payload = yield call(postRequestToTry, action.payload.params);
    if (payload?.data) {
      yield put(actions.setRequestToTryData(payload?.data));
    } else if (payload?.errors) {
      yield put(actions.error(payload.errors));
    }
  } catch (e) {
    yield put(actions.error(e));
  }
}

export function* watchGetFeature() {
  yield takeEvery(FEATURE_REQUEST, getFeatureSaga);
}

export function* watchGetBrands() {
  yield takeEvery(BRANDS_REQUEST, getBrandsSaga);
}

export function* watchGetSearchWithFilters() {
  yield takeEvery(SEARCH_WTIH_FILTERS_REQUEST, getSearchWithFiltersSaga);
}

export function* watchGetProducts() {
  yield takeEvery(PRODUCTS_REQUEST, getProductsSaga);
}

export function* watchRequestToTry() {
  yield takeEvery(REQUEST_TO_TRY_REQUEST, requestToTrySaga);
}
