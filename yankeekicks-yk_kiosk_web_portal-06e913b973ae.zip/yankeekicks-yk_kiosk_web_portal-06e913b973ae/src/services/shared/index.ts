import { doRequest } from 'utils/request';
import { GET_STORE } from '../apiUrl';

const getStore = async () => {
  return doRequest(GET_STORE, 'get');
};
export { getStore };
