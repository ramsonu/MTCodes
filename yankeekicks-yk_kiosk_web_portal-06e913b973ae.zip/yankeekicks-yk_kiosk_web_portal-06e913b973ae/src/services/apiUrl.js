//Kiosk api
export const KIOSK_GET_FEATURES = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/kiosk-feature`;
export const KIOSK_GET_PRODUCT_BROWSE = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/kiosk-product-browse`;
export const KIOSK_GET_SEARCH = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/kiosk-search`;
export const KIOSK_GET_SEARCH_WITH_FILTERS = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/kiosk-search-with-filters`;
export const KIOSK_GET_PRODUCTS = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/kiosk-products`;
export const KIOSK_GET_PRODUCT_DETAILS = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/kiosk-product-details`;
export const KIOSK_GET_PRODUCT_VARIANT_DETAILS = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/kiosk-product-variants`;
export const KIOSK_REQUEST_TO_TRY = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/kiosk-tryout-item-master`;

//Store
export const GET_STORE = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/store-location`;

//Catalog
export const CATALOG_GET_S3_IMAGE = `${process.env.NEXT_PUBLIC_APP_CATALOGE_S3_API_DOMAIN}/document/downloadS3ImageUrl`;

//Cube api
export const Cube_API_URL = `${process.env.NEXT_PUBLIC_APP_CUBE_API_DOMAIN}/cubejs-api/v1`;
