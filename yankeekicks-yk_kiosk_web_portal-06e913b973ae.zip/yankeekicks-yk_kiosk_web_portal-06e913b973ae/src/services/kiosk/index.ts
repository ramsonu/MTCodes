import { doRequest } from 'utils/request';
import {
  KIOSK_GET_FEATURES,
  KIOSK_GET_SEARCH,
  KIOSK_GET_PRODUCT_DETAILS,
  KIOSK_GET_PRODUCT_BROWSE,
  KIOSK_GET_PRODUCTS,
  KIOSK_GET_SEARCH_WITH_FILTERS,
  KIOSK_GET_PRODUCT_VARIANT_DETAILS,
  KIOSK_REQUEST_TO_TRY,
  CATALOG_GET_S3_IMAGE,
} from '../apiUrl';

const getFeature = async () => {
  return doRequest(KIOSK_GET_FEATURES, 'get');
};

const getBrands = async () => {
  return doRequest(KIOSK_GET_PRODUCT_BROWSE, 'get');
};

const getProducts = async (param: any) => {
  let dataParam = {
    brandName: param.brandName,
    limitForQuery: param.limitForQuery,
    cursorValue: param.cursorData,
  };
  return doRequest(KIOSK_GET_PRODUCTS, 'post', dataParam);
};

const getSearch = async (param: any, applyAll = false) => {
  let dataParam = applyAll
    ? {
        title: param?.title,
        color: param?.color.join(),
        type: param?.type.join(),
        size: param?.size.join(),
      }
    : {
        title: param?.title,
      };

  return doRequest(KIOSK_GET_SEARCH, 'post', dataParam);
};

const getSearchWithFilters = async (param: any) => {
  let dataParam = {
    title: param.title,
    color: param.color.join(),
    type: param.type.join(),
    size: param.size.join(),
    brand: param.brand.join(),
    availability: param.availability.join(),
    limitForQuery: param.limitForQuery,
    cursorValue: param.cursorData,
  };
  return doRequest(KIOSK_GET_SEARCH_WITH_FILTERS, 'post', dataParam);
};

const getProductDetails = async (param: any) => {
  return doRequest(KIOSK_GET_PRODUCT_DETAILS, 'post', param);
};
const getProductVariantDetails = async (param: any) => {
  return doRequest(KIOSK_GET_PRODUCT_VARIANT_DETAILS, 'post', param);
};

const postRequestToTry = async (param: any) => {
  return doRequest(KIOSK_REQUEST_TO_TRY, 'post', param);
};

const getLocation = async (param: any) => {
  return doRequest(KIOSK_GET_PRODUCTS, 'post', param);
};

const getImage = async (param: any) => {
  return doRequest(`${CATALOG_GET_S3_IMAGE}?path=${param}`, 'get');
};

export {
  getFeature,
  getBrands,
  getProducts,
  getSearch,
  getSearchWithFilters,
  getProductDetails,
  getProductVariantDetails,
  postRequestToTry,
  getLocation,
  getImage,
};
