import React from 'react';
import InfiniteScroll from 'react-infinite-scroll-component';
import CircleLoader from 'components/common/loader/circular-loader';
import ImageLoader from 'components/common/image-loader';
import NoShoeFound from './no-shoe-found';
import { convertPriceToUSFormat } from 'utils/util';
import Dummy from 'assets/images/big-product-img.svg';

const FilteredProducts = (props: any) => {
  const {
    inventoryProductsLoading,
    kioskInventoryProducts,
    loadMoreData,
    totalProductsCount,
    options,
    productsHandler,
    inventoryProductsResultSet,
    searchValue,
    setSearchValue,
  } = props;

  const limitForInfiniteScroll = 50;

  return (
    <div className='filtered-data-wrapper' id='infiniteScrollTarget'>
      {inventoryProductsLoading && kioskInventoryProducts?.length === 0 ? (
        <CircleLoader />
      ) : (
        <>
          <InfiniteScroll
            dataLength={kioskInventoryProducts?.length}
            next={loadMoreData}
            hasMore={
              kioskInventoryProducts?.length < totalProductsCount &&
              kioskInventoryProducts?.length > 0
                ? true
                : false
            }
            loader={
              options?.length === 0 && inventoryProductsLoading ? (
                <CircleLoader />
              ) : (
                <p
                  style={{
                    visibility: 'hidden',
                    display: 'none',
                  }}>
                  Loading...
                </p>
              )
            }
            endMessage={
              kioskInventoryProducts?.length > limitForInfiniteScroll ? (
                <p style={{ textAlign: 'center' }}>
                  <b>Yay! You have seen it all</b>
                </p>
              ) : (
                ''
              )
            }
            scrollableTarget='infiniteScrollTarget'
            style={{ overflow: 'hidden' }}>
            {kioskInventoryProducts?.length > 0 && (
              <div className='filtered-search-results-wrapper products-cards-wrapper'>
                {kioskInventoryProducts?.map((item: any, index: any) => (
                  <div className='col-lg-4 col-xl-4' key={index}>
                    <div
                      className='card yk-search-result-card'
                      onClick={() =>
                        productsHandler(item['KioskInventory.productId'])
                      }>
                      <div className='card-body text-center'>
                        <div className='product-image-wrapper'>
                          <ImageLoader
                            src={item['KioskInventory.imageUrl']}
                            fallbackImg={Dummy}
                            className='img-fluid'
                            alt='kiosk-product-Image'
                            imgWidth={300}
                            imgHeight={200}
                          />
                        </div>

                        <p className='product-description yk-textTransformCapitalize'>
                          {item?.['KioskInventory.title']}
                        </p>
                        <p className='yk-lowestPriceTitle'>
                          {item?.['KioskInventory.minPrice']
                            ? convertPriceToUSFormat(
                                item?.['KioskInventory.minPrice']
                              )
                            : '$0.00'}
                        </p>
                        <p className='yk-productSizeTitle'>
                          {item['KioskInventory.variantCount'] > 1
                            ? `${item?.['KioskInventory.variantCount']} sizes`
                            : `${item?.['KioskInventory.variantCount']} size`}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </InfiniteScroll>
        </>
      )}
      {inventoryProductsResultSet?.loadResponses[0]?.data?.length === 0 &&
        inventoryProductsLoading === false && (
          <NoShoeFound
            searchValue={searchValue}
            setSearchValue={setSearchValue}></NoShoeFound>
        )}
    </div>
  );
};

export default FilteredProducts;
