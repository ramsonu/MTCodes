/* eslint-disable @next/next/no-img-element */
import React, { useEffect, useState } from 'react';
import type { NextPage } from 'next';
import Image from 'next/image';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import { useSelector, useDispatch } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import { actions as sharedActions } from 'store/reducers/shared';
import {
  getAllLocations,
  getKioskInventory,
  getKioskInventoryTotalCount,
  getSuggestionsFromCube,
  getMinMaxPriceFromInventory,
} from 'middleware/cubejs-wrapper/cubejs-query';
import SearchComp from 'components/common/search';
import Notification from 'components/common/notification';
import ProductDetailsModal from '../details/ProductDetailsModal';
import KioskFilters from './kiosk-filters';
import SelectedChips from './selected-chips';
import FilteredProducts from './filtered-products';
import filterIcon from 'assets/images/filter-icon.png';

const SearchResults: NextPage = () => {
  const { filterTypes, selectedFilterTypes, goBackTrigger, triggerFilter } =
    useSelector((state: any) => state.kiosk);
  const { selected } = useSelector((state: any) => state.shared);
  const router = useRouter();
  const dispatch = useDispatch();
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [productId, setProductId] = useState<any>('');
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);
  const [showAutoComplete, setShowAutoComplete] = useState(false);
  const [expanded, setExpanded] = useState<string | false>(false);
  const [searchValue, setSearchValue] = useState(filterTypes?.title || '');
  const [options, setOptions] = useState([]);
  const [allLocations, setAllLocations] = useState([]);
  const [isClearFilters, setIsClearFilters] = useState(false);
  const [showFilterInMobileView, setShowFilterInMobileView] = useState(false);

  const [kioskInventoryProducts, setKioskInventoryProducts] = useState([]);
  const [currentOffset, setCurrentOffset] = useState(0);
  const [totalProductsCount, setTotalProductsCount] = useState(0);
  const [titleForCube, setTitleForCube] = useState('');
  const [typeAhead, setTypeAhead] = useState([]);
  const [locId, setLocId] = useState<any>('');
  const [shouldResultsFetch, setShouldResultsFetch] = useState(false);
  const [shouldMinMaxResultsFetch, setShouldMinMaxResultsFetch] =
    useState(false);
  const [shouldSuggestionsFetch, setShouldSuggestionsFetch] = useState(false);
  const [shouldFetchALLLocationData, setShouldFetchALLLocationData] =
    useState(false);
  const locationsQuery: any = getAllLocations();
  const [minMax, setMinMax] = useState<any>({ min: 0, max: 0 });
  const [userPriceInput, setUserPriceInput] = useState<any>({
    first: filterTypes?.price[0],
    second: filterTypes?.price[1],
  });
  const [chipsToShow, setChipsToShow] = useState<any>([]);

  useEffect(() => {
    if (
      Object.keys(router.query).length &&
      Object.keys(router.query).includes('locationId') &&
      Object.keys(router.query).includes('productId')
    ) {
      const routerProductId = router.query.productId;
      const shopifyIdText = `gid://shopify/Product/${routerProductId}`;
      setProductId(shopifyIdText);
    } else setShowDetailsModal(false);
    if (Object.keys(router.query).includes('locationId')) {
      setShouldFetchALLLocationData(true);
    } else setShouldFetchALLLocationData(false);
  }, [router.query]);

  const {
    resultSet: locationsResultSet,
    isLoading: locationsLoading,
    error: locationsError,
  }: any = useCubeQuery(locationsQuery, { skip: !shouldFetchALLLocationData });

  useEffect(() => {
    const data = locationsResultSet?.loadResponses[0]?.data;
    if (data) {
      setAllLocations(data);
      setShowDetailsModal(true);
    } else {
      setAllLocations([]);
    }
  }, [locationsResultSet]);

  useEffect(() => {
    if (allLocations?.length > 0) {
      if (
        router.query.locationId?.toString() !==
          localStorage?.getItem('locationId')?.toString() ||
        !localStorage?.getItem('storeId')
      ) {
        setLocations();
      }
    }
  }, [allLocations]);

  const setLocations = () => {
    const selectedItem: any = allLocations?.find(
      (location: any) =>
        location?.['Locations.locationID_D'] === router.query.locationId
    );
    if (selectedItem) {
      localStorage?.setItem('storeId', selectedItem?.['Store.id']);
      localStorage?.setItem(
        'locationId',
        selectedItem?.['Locations.locationID_D']
      );
      localStorage?.setItem('storeLocation', selectedItem?.['Locations.name']);
      dispatch(sharedActions.selected(selectedItem));
    }
  };

  useEffect(() => {
    if (localStorage?.getItem('locationId')) {
      setLocId(localStorage?.getItem('locationId'));
      setShouldResultsFetch(true);
    } else {
      setLocId('');
      setShouldResultsFetch(false);
    }
  }, [selected]);

  useEffect(() => {
    if (locId) {
      setShouldMinMaxResultsFetch(true);
    } else {
      setShouldMinMaxResultsFetch(false);
    }
  }, [locId]);

  const limit: number = 50;

  const kioskInventoryQuery: any = getKioskInventory(
    selectedFilterTypes,
    locId,
    limit,
    currentOffset
  );
  const kioskInventoryCountQuery: any = getKioskInventoryTotalCount(
    selectedFilterTypes,
    locId,
    currentOffset
  );
  const kioskInventoryMinMaxPriceQuery: any =
    getMinMaxPriceFromInventory(locId);
  const kioskInventorySuggestionQuery: any = getSuggestionsFromCube(
    titleForCube,
    locId
  );

  const {
    resultSet: inventoryProductsResultSet,
    isLoading: inventoryProductsLoading,
    error: inventoryProductsError,
  }: any = useCubeQuery(kioskInventoryQuery, { skip: !shouldResultsFetch });

  const { resultSet: inventoryProductsCountResultSet }: any = useCubeQuery(
    kioskInventoryCountQuery,
    {
      skip: !shouldResultsFetch,
    }
  );
  const {
    resultSet: inventoryMinMaxResultSet,
    isLoading: inventoryMinMaxLoading,
  }: any = useCubeQuery(kioskInventoryMinMaxPriceQuery, {
    skip: !shouldMinMaxResultsFetch,
  });
  const {
    resultSet: inventorySuggestionsResultSet,
    isLoading: inventorySuggestionsLoading,
    error: inventorySuggestionsError,
  }: any = useCubeQuery(kioskInventorySuggestionQuery, {
    skip: !shouldSuggestionsFetch,
  });

  const isArrayEquals = (a: any, b: any) => {
    return (
      Array.isArray(a) &&
      Array.isArray(b) &&
      a.length === b.length &&
      a.every(
        (val, index) =>
          val?.['KioskInventory.productId'] ===
          b[index]?.['KioskInventory.productId']
      )
    );
  };

  useEffect(() => {
    const data = inventoryProductsResultSet?.loadResponses[0]?.data;
    if (data) {
      if (!isArrayEquals(kioskInventoryProducts, data)) {
        const combineData: any = [...kioskInventoryProducts, ...data];
        setKioskInventoryProducts(combineData);
        setShouldResultsFetch(false);
      }
    } else {
      if (currentOffset === 0) {
        setKioskInventoryProducts([]);
      }
    }
  }, [inventoryProductsResultSet]);

  useEffect(() => {
    const data: any =
      inventoryProductsCountResultSet?.loadResponses[0]?.data[0];
    if (data) {
      const count = parseInt(data['KioskInventory.rowCount']);
      setTotalProductsCount(count);
    } else {
      setTotalProductsCount(0);
    }
  }, [inventoryProductsCountResultSet]);

  //useEffect for Min Max price
  useEffect(() => {
    const minMaxData: any = inventoryMinMaxResultSet?.loadResponses[0]?.data[0];
    if (minMaxData) {
      setMinMax({
        min: minMaxData['KioskInventory.minPrice'],
        max: minMaxData['KioskInventory.maxPrice'],
      });
      setShouldMinMaxResultsFetch(false);
    } else {
      setMinMax({
        min: 0,
        max: 100000,
      });
    }
  }, [inventoryMinMaxResultSet]);

  useEffect(() => {
    const data: any = inventorySuggestionsResultSet?.loadResponses[0]?.data;
    if (data) {
      setTypeAhead(data);
      setShouldSuggestionsFetch(false);
    } else {
      setTypeAhead([]);
    }
  }, [inventorySuggestionsResultSet]);

  useEffect(() => {
    setKioskInventoryProducts([]);
  }, [goBackTrigger]);

  useEffect(() => {
    setIsClearFilters(triggerFilter);
  }, [triggerFilter]);

  // useEffect to set Price Inputs
  useEffect(() => {
    if (
      userPriceInput?.first?.toString() ||
      userPriceInput?.second?.toString()
    ) {
      dispatch(
        actions.setFilterValueBasedOnKey({
          filterKey: 'price',
          filterValue: [userPriceInput?.first, userPriceInput?.second],
        })
      );
    } else {
      dispatch(
        actions.setFilterValueBasedOnKey({
          filterKey: 'price',
          filterValue: [0, 0],
        })
      );
    }
  }, [userPriceInput]);

  useEffect(() => {
    let minValue = Math.min(
      Number(userPriceInput?.first),
      Number(userPriceInput?.second)
    );
    let maxValue = Math.max(
      Number(userPriceInput?.first),
      Number(userPriceInput?.second)
    );

    dispatch(
      actions.setFilterValueBasedOnKey({
        filterKey: 'price',
        filterValue: [minValue, maxValue],
      })
    );
  }, [userPriceInput]);

  const onClickApplyFilters = () => {
    dispatch(actions.setProductsLoading({}));
    dispatch(actions.setSelectedFilterTypes(filterTypes));
    setExpanded(false);
    setIsClearFilters(true);

    if (JSON.stringify(filterTypes) !== JSON.stringify(selectedFilterTypes)) {
      setKioskInventoryProducts([]);
      setCurrentOffset(0);
      setTotalProductsCount(0);
    }
    setShowFilterInMobileView(false);
    setShouldResultsFetch(true);
  };

  const onClickClearAllFilters = () => {
    setIsClearFilters(false);
    dispatch(actions.setProductsLoading({}));
    dispatch(actions.clearFiltersExceptTitle({}));
    dispatch(actions.clearFiltersExceptTitleForCube({}));
    setExpanded(false);
    setKioskInventoryProducts([]);
    setCurrentOffset(0);
    setTotalProductsCount(0);
    setShowFilterInMobileView(false);
    setShouldResultsFetch(true);
    // setValue([0, 0]);
    setUserPriceInput({ first: 0, second: 0 });
  };

  // To handle uncheck of checkbox when filterTypes are empty
  (() => {
    if (
      !filterTypes?.type?.length &&
      !filterTypes?.color?.length &&
      !filterTypes?.size?.length &&
      !filterTypes?.brand?.length &&
      !filterTypes?.date?.length &&
      !filterTypes?.model?.length &&
      filterTypes?.price[0] === 0 &&
      filterTypes?.price[1] === 0 &&
      isClearFilters
    ) {
      onClickClearAllFilters();
    }
  })();

  const productsHandler = (pId: any) => {
    setShowDetailsModal(true);
    const shopifyIdText = 'gid://shopify/Product/';
    const proId = shopifyIdText.concat(pId);
    setProductId(proId);
  };

  const handleSnackbarClose = () => {
    setShowSuccessPopup(false);
  };

  const autoCompleteSearch = async (value: string) => {
    setTitleForCube(value);
    setShowAutoComplete(true);
    setShouldSuggestionsFetch(true);
    setShouldResultsFetch(false);
  };

  const onChangeHandler = (value: any) => {
    autoCompleteSearch(value);
    setSearchValue(value);
    if (value === '') {
      dispatch(actions.clearAllFilters({}));
      dispatch(actions.clearAllSelectedFilters({}));
      setOptions([]);
      setShowAutoComplete(false);
      setKioskInventoryProducts([]);
      setCurrentOffset(0);
      setTotalProductsCount(0);
      setShouldResultsFetch(true);
    }
  };

  const onSelectHandler = (
    e: any,
    selectedItem: any = '',
    isInnerText: any = false,
    doApiCall: any = false
  ) => {
    const selectedValue = isInnerText ? selectedItem : e?.target?.value;
    setSearchValue(selectedValue);
    setShowAutoComplete(false);
    dispatch(
      actions.setFilters({ filterItem: selectedValue, filterType: 'title' })
    );
    if (doApiCall) {
      fetchSelectedItem(selectedValue);
    }
    setCurrentOffset(0);
  };

  const fetchSelectedItem = (selectedItem: any) => {
    setKioskInventoryProducts([]);
    dispatch(
      actions.setSelectedFilters({
        filterItem: selectedItem,
        filterType: 'title',
      })
    );
    dispatch(actions.clearFiltersExceptTitle({}));
    dispatch(actions.clearFiltersExceptTitleForCube({}));
    router.push({
      pathname: '/results',
      query: {
        searchTitle: selectedItem,
      },
    });
    setShouldResultsFetch(true);
  };

  const handlePriceChange = (event: any, type: any) => {
    const position = type === 'min' ? 'first' : 'second';
    const priceValue: any = event?.target?.value;
    if (priceValue?.length <= 5) {
      if (priceValue?.length === 0) {
        let valueAsZero = { ...userPriceInput, ...{ [position]: 0 } };
        setUserPriceInput(valueAsZero);
      } else if (priceValue?.length > 1 && priceValue?.startsWith('0')) {
        let removeZero = {
          ...userPriceInput,
          ...{ [position]: priceValue.replace(/^0/, '') },
        };
        setUserPriceInput(removeZero);
      } else {
        let value = {
          ...userPriceInput,
          ...{ [position]: priceValue },
        };
        setUserPriceInput(value);
      }
    }
  };

  const message = (
    <h3 className='notification-heading'>
      Item Added to cart
      <span className='notification-subtitle'>
        <br />
        You can go to cart or continue browsing
      </span>
    </h3>
  );

  const loadMoreData = () => {
    if (kioskInventoryProducts?.length < totalProductsCount) {
      setCurrentOffset(currentOffset + limit);
      setShouldResultsFetch(true);
    } else {
      return;
    }
  };

  return (
    <>
      <div className='search-results-page-wrapper'>
        <div className='page-wrapper search-result-wrapper'>
          <div className='container-fluid yk-container-fluid ykch-containerFluid'>
            <div className='row'>
              <div className='col-8 col-lg-12 col-sm-12'>
                <div className='search-bar-wrapper kiosk-search'>
                  <div className='search-bar-inner-wrapper'>
                    <div className='input-wrapper '>
                      <label
                        htmlFor='staticsearch2'
                        className='visually-hidden'>
                        search
                      </label>
                      <div className='input-group input-prepend'>
                        <SearchComp
                          userInput={searchValue}
                          placeholder='Search for brand, color etc.'
                          options={typeAhead}
                          isApiCall={true}
                          onSelectHandler={onSelectHandler}
                          onChangeHandler={onChangeHandler}
                          setUserInput={setSearchValue}
                          showAutoComplete={showAutoComplete}
                          setShowAutoComplete={setShowAutoComplete}
                          suggestionsLoading={inventorySuggestionsLoading}
                          suggestionsHasError={inventorySuggestionsError}
                          onClearFIlterData={setKioskInventoryProducts}
                          setShouldResultsFetch={setShouldResultsFetch}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='col-4 d-block d-sm-none'>
                <button
                  type='button'
                  className='btn yk-btn-filter'
                  onClick={() =>
                    setShowFilterInMobileView(!showFilterInMobileView)
                  }>
                  <Image src={filterIcon} alt='' className='Image-fluid me-2' />
                  Filter
                </button>
              </div>

              <SelectedChips
                chipsToShow={chipsToShow}
                setChipsToShow={setChipsToShow}
                setUserPriceInput={setUserPriceInput}
              />

              <div className='col-lg-12 col-md-12 col-sm-12 col-12'>
                <div
                  className={`${
                    chipsToShow?.length > 0
                      ? 'ykch-filterWithCard'
                      : 'search-results-outer-wrapper'
                  }`}>
                  <KioskFilters
                    minMax={minMax}
                    expanded={expanded}
                    setExpanded={setExpanded}
                    userPriceInput={userPriceInput}
                    setUserPriceInput={setUserPriceInput}
                    handlePriceChange={handlePriceChange}
                    totalProductsCount={totalProductsCount}
                    onClickApplyFilters={onClickApplyFilters}
                    showFilterInMobileView={showFilterInMobileView}
                    kioskInventoryProducts={kioskInventoryProducts}
                    inventoryMinMaxLoading={inventoryMinMaxLoading}
                    onClickClearAllFilters={onClickClearAllFilters}
                  />

                  <FilteredProducts
                    loadMoreData={loadMoreData}
                    inventoryProductsLoading={inventoryProductsLoading}
                    kioskInventoryProducts={kioskInventoryProducts}
                    inventoryProductsResultSet={inventoryProductsResultSet}
                    totalProductsCount={totalProductsCount}
                    productsHandler={productsHandler}
                    options={options}
                    searchValue={searchValue}
                    setSearchValue={setSearchValue}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Notification
        showSuccessPopup={showSuccessPopup}
        handleSnackbarClose={handleSnackbarClose}
        severityType='success'
        message={message}
        className='yk-kiosk-alert-wrapper'
      />

      {showDetailsModal && (
        <ProductDetailsModal
          showDetailsModal={showDetailsModal}
          setShowDetailsModal={setShowDetailsModal}
          id={productId}
          setShowSuccessPopup={setShowSuccessPopup}
        />
      )}
    </>
  );
};
export default SearchResults;
