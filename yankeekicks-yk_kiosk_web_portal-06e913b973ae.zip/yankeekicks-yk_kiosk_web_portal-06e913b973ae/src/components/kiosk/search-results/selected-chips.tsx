import React, { Fragment, useEffect } from 'react';
import Image from 'next/image';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';
import { convertNumberToNotation } from 'utils/util';
import closeIcon from 'assets/images/red-close-icon.svg';

const SelectedChips = (props: any) => {
  const { chipsToShow, setChipsToShow, setUserPriceInput } = props;

  const dispatch = useDispatch();

  const { filterTypes } = useSelector((state: any) => state.kiosk);

  //useEffect to add chips
  useEffect(() => {
    const filtersChipToShow: any = [];
    Object.keys(filterTypes).forEach(function (key, index) {
      if (key !== 'title') {
        if (key === 'price') {
          if (filterTypes?.price[0] >= 0 && filterTypes?.price[1] > 0) {
            filtersChipToShow.push({
              key: 'price',
              value: `${convertNumberToNotation(
                filterTypes?.price[0]
              )} - ${convertNumberToNotation(filterTypes?.price[1])}`,
            });
          }
        } else {
          filterTypes[key].map((items: any, index: any) => {
            filtersChipToShow.push({ key: key, value: items });
          });
        }
      }
    });
    setChipsToShow(filtersChipToShow);
  }, [filterTypes]);

  //method to remove the chips
  const handleRemoveFilterChips = (selectedFilter: any) => {
    let filterToRemove: any = [];
    Object.keys(filterTypes).forEach(function (key, index) {
      if (key === selectedFilter?.key) {
        if (selectedFilter?.key === 'price') {
          filterToRemove = [0, 0];
          setUserPriceInput({ first: 0, second: 0 });
        } else {
          filterToRemove = filterTypes[key]?.filter(
            (element: any) => element !== selectedFilter?.value
          );
        }
      }
    });
    dispatch(
      actions.setFilterValueBasedOnKey({
        filterKey: selectedFilter?.key,
        filterValue: filterToRemove,
      })
    );
  };

  return (
    <div className='col-lg-12 col-md-12 col-sm-12 col-12'>
      {chipsToShow && chipsToShow?.length > 0 && (
        <div className='ykch-filtersApplied'>
          <h2 className='ykch-filtersAppliedTitle'>Filters Applied</h2>
          <div className='ykch-filterAppliedWrapper'>
            {chipsToShow?.map((selectedProducts: any, ind: any) => {
              return (
                <Fragment key={ind}>
                  <Stack
                    direction='row'
                    spacing={1}
                    className='ykch-applied-filters'
                  >
                    <Chip
                      className='filter-chip'
                      label={selectedProducts?.value}
                      variant='outlined'
                      onDelete={() => handleRemoveFilterChips(selectedProducts)}
                      deleteIcon={
                        <Image
                          src={closeIcon}
                          className='chip-close-btn'
                          alt=''
                        />
                      }
                    />
                  </Stack>
                </Fragment>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default SelectedChips;
