import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import Slider from '@mui/material/Slider';
import {
  Button,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import DynamicFilter from 'components/common/filters/dynamic-filter';
import { convertNumberToNotation } from 'utils/util';
import {
  SEARCH_BY_MODEL_ADIDAS,
  SEARCH_BY_MODEL_AIR_JORDAN,
  SEARCH_BY_MODEL_NEW_BALANCE,
  SEARCH_BY_MODEL_NIKE,
  SEARCH_BY_MODEL_YEEZY,
  SIZE_MATRIX_GRADESCHOOL,
  SIZE_MATRIX_MENWOMEN,
  SIZE_MATRIX_PRESCHOOL,
  SIZE_MATRIX_TODDLER,
} from 'components/common/filters/constants';
import sizeMatrix from 'utils/sizeMatrix.json';

const KioskFilters = (props: any) => {
  const {
    minMax,
    expanded,
    setExpanded,
    userPriceInput,
    setUserPriceInput,
    handlePriceChange,
    totalProductsCount,
    onClickApplyFilters,
    showFilterInMobileView,
    kioskInventoryProducts,
    inventoryMinMaxLoading,
    onClickClearAllFilters,
  } = props;

  const dispatch = useDispatch();

  const { filterTypes } = useSelector((state: any) => state.kiosk);

  useEffect(() => {
    if (filterTypes?.brand?.length === 0) {
      dispatch(
        actions.clearFiltersByKey({ filterType: 'model', filterItem: [] })
      );
      dispatch(
        actions.clearSelectedFiltersByKey({
          filterType: 'model',
          filterItem: [],
        })
      );
    } else {
      let valuesToHold: any = [];
      filterTypes?.brand?.map((brandName: any) => {
        let constantsToUse: any = [];
        switch (brandName) {
          case 'nike':
            constantsToUse = SEARCH_BY_MODEL_NIKE;
            break;
          case 'jordan':
            constantsToUse = SEARCH_BY_MODEL_AIR_JORDAN;
            break;
          case 'adidas':
            constantsToUse = SEARCH_BY_MODEL_ADIDAS;
            break;
          case 'supreme':
            constantsToUse = [];
            break;
          case 'puma':
            constantsToUse = [];
            break;
          case 'new balance':
            constantsToUse = SEARCH_BY_MODEL_NEW_BALANCE;
            break;
          case 'yeezy':
            constantsToUse = SEARCH_BY_MODEL_YEEZY;
            break;
        }

        constantsToUse?.map((item: any) => {
          filterTypes?.model?.map((subItem: any) => {
            if (item?.key === subItem) {
              return valuesToHold?.push(subItem);
            }
          });
        });
      });

      dispatch(
        actions.setFilterValueBasedOnKey({
          filterKey: 'model',
          filterValue: valuesToHold,
        })
      );
    }
  }, [filterTypes?.brand]);

  useEffect(() => {
    // to handle sizes selected without selecting types from feature page or search results page
    if (filterTypes?.type?.length) {
      if (filterTypes.type?.length === 0) {
        dispatch(
          actions.clearFiltersByKey({ filterType: 'size', filterItem: [] })
        );
        dispatch(
          actions.clearSelectedFiltersByKey({
            filterType: 'size',
            filterItem: [],
          })
        );
      } else {
        let valuesToHold: any = [];

        filterTypes.type?.map((typeName: any, index: number) => {
          let constantsToUse: any = [];

          switch (typeName) {
            case 'men / women':
              constantsToUse = sizeMatrix[SIZE_MATRIX_MENWOMEN].sizeList;
              break;
            case 'grade school':
              constantsToUse = sizeMatrix[SIZE_MATRIX_GRADESCHOOL].sizeList;
              break;
            case 'pre school':
              constantsToUse = sizeMatrix[SIZE_MATRIX_PRESCHOOL].sizeList;
              break;
            case 'toddler':
              constantsToUse = sizeMatrix[SIZE_MATRIX_TODDLER].sizeList;
              break;
          }

          constantsToUse?.map((item: any) => {
            filterTypes?.size?.map((subItem: any) => {
              if (item?.value === subItem) {
                return valuesToHold?.push(subItem);
              }
            });
          });
        });

        dispatch(
          actions.setFilterValueBasedOnKey({
            filterKey: 'size',
            filterValue: valuesToHold,
          })
        );
      }
    }
  }, [filterTypes?.type]);

  const valuetext = (value: number) => {
    return `${value}`;
  };

  const priceChangeHandler = (event: Event, newValue: any) => {
    dispatch(
      actions.setFilterValueBasedOnKey({
        filterKey: 'price',
        filterValue: newValue,
      })
    );
    setUserPriceInput({ first: newValue[0], second: newValue[1] });
  };

  const handleChange =
    (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
      setExpanded(isExpanded ? panel : false);
    };

  const isButtonsShow =
    filterTypes?.type?.length ||
    filterTypes?.color?.length ||
    filterTypes?.size?.length ||
    filterTypes?.brand?.length ||
    filterTypes?.date?.length ||
    filterTypes?.model?.length ||
    filterTypes?.price[1] > 0;

  return (
    <div
      className={`filter-products-wrapper ${
        showFilterInMobileView ? 'show' : ''
      }`}>
      <div className='filter-card-wrapper'>
        <div className='card yk-search-filter-card'>
          <div className='card-body'>
            <p className='show-result-text'>
              {kioskInventoryProducts?.length > 0
                ? `Showing ${kioskInventoryProducts?.length} of ${totalProductsCount} results`
                : `Showing ${totalProductsCount} Results`}
            </p>
            <h3 className='heading'>Filter by </h3>
            <Accordion
              expanded={expanded === 'panel1'}
              onChange={handleChange('panel1')}
              className='yk-search-filter-card-wrapper'>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls='panel1a-content'
                id='panel1a-header'
                className='yk-search-filter-text'>
                <Typography className='yk-search-filter-typography'>
                  User Type{' '}
                </Typography>
                <span className='yk-user-type-count'>
                  {filterTypes.type?.length > 0 ? filterTypes.type?.length : ''}
                </span>
              </AccordionSummary>
              <AccordionDetails className='yk-search-filter-list-wrapper'>
                <div className='list-wrapper'>
                  <DynamicFilter itemKey={'type'} />
                </div>
              </AccordionDetails>
            </Accordion>
            <Accordion
              expanded={expanded === 'panel2'}
              onChange={handleChange('panel2')}
              className='yk-search-filter-card-wrapper'>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls='panel2a-content'
                id='panel2a-header'
                className='yk-search-filter-text'>
                <Typography className='yk-search-filter-typography'>
                  Size{' '}
                </Typography>
                <span className='yk-user-type-count'>
                  {filterTypes.size?.length > 0 ? filterTypes.size?.length : ''}
                </span>
              </AccordionSummary>
              <AccordionDetails className='yk-search-filter-list-wrapper'>
                <div className='list-wrapper yk-sizeListWrapper'>
                  <DynamicFilter itemKey={'size'} />
                </div>
              </AccordionDetails>
            </Accordion>
            <Accordion
              expanded={expanded === 'panel3'}
              onChange={handleChange('panel3')}
              className='yk-search-filter-card-wrapper'>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls='panel2a-content'
                id='panel2a-header'
                className='yk-search-filter-text'>
                <Typography className='yk-search-filter-typography'>
                  Brand{' '}
                </Typography>
                <span className='yk-user-type-count'>
                  {filterTypes.brand?.length > 0
                    ? filterTypes.brand?.length
                    : ''}
                </span>
              </AccordionSummary>
              <AccordionDetails className='yk-search-filter-list-wrapper'>
                <div className='list-wrapper'>
                  <DynamicFilter itemKey={'brand'} />
                </div>
              </AccordionDetails>
            </Accordion>
            {/* for model filter */}
            {((filterTypes?.brand &&
              filterTypes?.brand?.length > 0 &&
              !(
                filterTypes?.brand?.includes('supreme') ||
                filterTypes?.brand?.includes('puma')
              )) ||
              filterTypes?.brand?.includes('nike') ||
              filterTypes?.brand?.includes('jordan') ||
              filterTypes?.brand?.includes('adidas') ||
              filterTypes?.brand?.includes('new balance') ||
              filterTypes?.brand?.includes('yeezy')) && (
              <Accordion
                expanded={expanded === 'panel4'}
                onChange={handleChange('panel4')}
                className='yk-search-filter-card-wrapper'>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls='panel2a-content'
                  id='panel2a-header'
                  className='yk-search-filter-text'>
                  <Typography className='yk-search-filter-typography'>
                    Model{' '}
                  </Typography>
                  <span className='yk-user-type-count'>
                    {filterTypes.model?.length > 0
                      ? filterTypes.model?.length
                      : ''}
                  </span>
                </AccordionSummary>
                <AccordionDetails className='yk-search-filter-list-wrapper'>
                  <div className='list-wrapper'>
                    <DynamicFilter itemKey={'model'} />
                  </div>
                </AccordionDetails>
              </Accordion>
            )}
            <Accordion
              expanded={expanded === 'panel5'}
              onChange={handleChange('panel5')}
              className='yk-search-filter-card-wrapper'>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls='panel2a-content'
                id='panel2a-header'
                className='yk-search-filter-text'>
                <Typography className='yk-search-filter-typography'>
                  Colorway{' '}
                </Typography>
                <span className='yk-user-type-count'>
                  {filterTypes.color?.length > 0
                    ? filterTypes.color?.length
                    : ''}
                </span>
              </AccordionSummary>
              <AccordionDetails className='yk-search-filter-list-wrapper'>
                <div className='list-wrapper'>
                  <DynamicFilter itemKey={'color'} />
                </div>
              </AccordionDetails>
            </Accordion>
            <Accordion
              expanded={expanded === 'panel6'}
              onChange={handleChange('panel6')}
              className='yk-search-filter-card-wrapper'>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls='panel2a-content'
                id='panel2a-header'
                className='yk-search-filter-text'>
                <Typography className='yk-search-filter-typography'>
                  Release year{' '}
                </Typography>
                <span className='yk-user-type-count'>
                  {filterTypes.date?.length > 0 ? filterTypes.date?.length : ''}
                </span>
              </AccordionSummary>
              <AccordionDetails className='yk-search-filter-list-wrapper'>
                <div className='list-wrapper'>
                  <DynamicFilter itemKey={'date'} />
                </div>
              </AccordionDetails>
            </Accordion>
            <Accordion
              expanded={expanded === 'panel8'}
              onChange={handleChange('panel8')}
              className='yk-search-filter-card-wrapper'>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls='panel2a-content'
                id='panel2a-header'
                className='yk-search-filter-text yk-search-filter-text-bordered'>
                <Typography className='yk-search-filter-typography'>
                  Price Range
                </Typography>
              </AccordionSummary>
              <AccordionDetails className='yk-search-filter-list-wrapper'>
                <div className='list-wrapper ykch-priceFilter'>
                  <div className='yk-priceText'>
                    <span className='price-min'>
                      ${convertNumberToNotation(filterTypes?.price[0])}
                    </span>
                    <span className='price-space'>-</span>
                    <span className='price-max'>
                      ${convertNumberToNotation(filterTypes?.price[1])}
                    </span>
                  </div>
                  <div className='yk-sliderWrapper'>
                    {!inventoryMinMaxLoading && (
                      <Slider
                        className='ykch-sliderPriceFilter'
                        getAriaLabel={() => 'Temperature range'}
                        value={filterTypes?.price}
                        onChange={priceChangeHandler}
                        max={minMax?.max}
                        valueLabelDisplay='auto'
                        getAriaValueText={valuetext}
                      />
                    )}
                  </div>
                  <div className='yk-sliderInputWrapper'>
                    <input
                      type='number'
                      name='min'
                      value={userPriceInput?.first}
                      placeholder='Min'
                      onChange={(e) => handlePriceChange(e, 'min')}
                    />
                    <input
                      type='number'
                      name='max'
                      value={userPriceInput?.second}
                      placeholder='Max'
                      onChange={(e) => handlePriceChange(e, 'max')}
                    />
                  </div>
                </div>
              </AccordionDetails>
            </Accordion>
            {isButtonsShow ? (
              <div className='search-filter-button-wrapper'>
                <div className='row'>
                  <div className='col-6 col-lg-6'>
                    <Button
                      variant='contained'
                      onClick={onClickApplyFilters}
                      className='apply-btn '>
                      Apply
                    </Button>
                  </div>
                  <div className='col-6 col-lg-6 search-kiosk-clear-btn'>
                    <Button
                      className='btn-transparent clear-filter-btn yk-badge-h7'
                      onClick={onClickClearAllFilters}>
                      Clear All
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              ''
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default KioskFilters;
