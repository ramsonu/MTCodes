import React from 'react';
import Image from 'next/image';
import { useDispatch } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import noResultImg from 'assets/images/no-result-img.png';

const NoShoeFound = ({ searchValue, setSearchValue }: any) => {
  const dispatch = useDispatch();
  const onClickClearAllFilters = () => {
    dispatch(actions.clearAllFilters({}));
    dispatch(actions.clearAllSelectedFilters({}));
    setSearchValue('');
  };
  return (
    <>
      {searchValue !== '' ? (
        <div className='no-result-found-card-wrapper'>
          <div className='card'>
            <div className='card-body text-center'>
              <Image
                src={noResultImg}
                alt='filter-btn-icon'
                className='no-result-img img-fluid'
              />
              <p className='yk-subtitle mb-4'>
                You searched for{' '}
                <span className='yk-section-title'>{searchValue}</span>
              </p>
              <h4 className='yk-title'>We couldnt find a match!</h4>
              <p className='yk-subtitle mb-4'>
                Please check the spelling or try searching for something else
              </p>
              <button
                className='btn-transparent clear-filter-btn yk-badge-h7'
                onClick={onClickClearAllFilters}
              >
                Clear All filters
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className='no-result-found-card-wrapper'>
          <div className='card'>
            <div className='card-body text-center'>
              <Image
                src={noResultImg}
                alt='filter-btn-icon'
                className='no-result-img img-fluid'
              />
              <h4 className='yk-title mb-4'>No shoes found</h4>
              <p className='yk-subtitle mb-4'>
                We found no results for the filters selected. Try using
                different filters
              </p>
              <button
                className='btn-transparent clear-filter-btn yk-badge-h7'
                onClick={onClickClearAllFilters}
              >
                Clear All filters
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default NoShoeFound;
