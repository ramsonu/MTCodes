/* eslint-disable @next/next/no-img-element */
import React, { useEffect, useState } from 'react';
import type { NextPage } from 'next';
import { actions } from 'store/reducers/kiosk';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import ProductDetailsModal from '../details/ProductDetailsModal';
import Notification from 'components/common/notification';
import FeaturedProducts from './featured-products';
import Brands from './brands';
import BasicFilters from './basic-filters';
import KioskSearch from './kiosk-search';

const Feature: NextPage = () => {
  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const { selected } = useSelector((state: any) => state.shared);

  const dispatch = useDispatch();
  const router = useRouter();

  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [productId, setProductId] = useState('');
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);
  const [locId, setLocId] = useState<any>('');
  const [shouldFeaturedFetch, setShouldFeaturedFetch] = useState(false);
  const [shouldFetchBrands, setShouldFetchBrands] = useState(false);

  useEffect(() => {
    if (localStorage?.getItem('locationId')) {
      setLocId(localStorage?.getItem('locationId'));
      setShouldFeaturedFetch(true);
      setShouldFetchBrands(true);
    } else {
      setLocId('');
      setShouldFeaturedFetch(false);
      setShouldFetchBrands(false);
    }
  }, [selected]);

  const getSearchResults = async () => {
    if (
      !filterTypes?.brand?.length &&
      !filterTypes?.color?.length &&
      !filterTypes?.size?.length &&
      !filterTypes?.type?.length
    ) {
      dispatch(actions.setFilterTrigger(false));
    } else {
      dispatch(actions.setFilterTrigger(true));
    }
    dispatch(actions.setSelectedFilterTypes(filterTypes));
    router.push('/results');
  };

  const productsHandler = (pId: any) => {
    setShowDetailsModal(true);
    const shopifyIdText = 'gid://shopify/Product/';
    const proId = shopifyIdText.concat(pId);
    setProductId(proId);
  };

  const handleSnackbarClose = () => {
    setShowSuccessPopup(false);
  };

  const message = (
    <h3 className='notification-heading'>
      Item Added to cart
      <span className='notification-subtitle'>
        <br />
        You can go to cart or continue browsing
      </span>
    </h3>
  );

  return (
    <>
      <div className='app-wrapper w-100 kiosk-product-details-page-wrapper'>
        <div className='container-fluid yk-container-fluid'>
          <div className='row'>
            <div className='col-lg-12'>
              <div className='product-details-wrapper container-fluid'>
                <div className='row'>
                  <FeaturedProducts
                    locId={locId}
                    shouldFeaturedFetch={shouldFeaturedFetch}
                    setShouldFeaturedFetch={setShouldFeaturedFetch}
                    productsHandler={productsHandler}
                  />

                  <Brands
                    shouldFetchBrands={shouldFetchBrands}
                    setShouldFetchBrands={setShouldFetchBrands}
                  />
                  <div className='products-search-wrapper mt-3'>
                    <div className='heading-wrapper'>
                      <h3 className='heading'>Search</h3>
                      <div className='products-search-wrapper'>
                        <div className='btn-wrapper'>
                          <button
                            className='btn yk-primaryButton yk-showResultsBtn'
                            onClick={() => getSearchResults()}
                          >
                            Show Results
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className='search-bar-wrapper'>
                      <KioskSearch locId={locId} />
                    </div>
                  </div>

                  <BasicFilters />
                </div>
              </div>

              <div className='app-page-container'></div>
            </div>
          </div>
        </div>
      </div>

      <Notification
        showSuccessPopup={showSuccessPopup}
        handleSnackbarClose={handleSnackbarClose}
        severityType='success'
        message={message}
        className='yk-kiosk-alert-wrapper'
      />

      {showDetailsModal && (
        <ProductDetailsModal
          showDetailsModal={showDetailsModal}
          setShowDetailsModal={setShowDetailsModal}
          id={productId}
          setShowSuccessPopup={setShowSuccessPopup}
        />
      )}
    </>
  );
};

export default Feature;
