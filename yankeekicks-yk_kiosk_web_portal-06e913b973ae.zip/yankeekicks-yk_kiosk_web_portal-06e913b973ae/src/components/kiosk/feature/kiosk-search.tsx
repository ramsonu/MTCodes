import React, { useState, useEffect } from 'react';
import { useCubeQuery } from '@cubejs-client/react';
import { getSuggestionsFromCube } from 'middleware/cubejs-wrapper/cubejs-query';
import { useDispatch } from 'react-redux';
import { useRouter } from 'next/router';
import { actions } from 'store/reducers/kiosk';
import SearchComp from 'components/common/search';

const KioskSearch = (props: any) => {
  const { locId } = props;

  const dispatch = useDispatch();
  const router = useRouter();

  const [searchValue, setSearchValue] = useState('');
  const [titleForCube, setTitleForCube] = useState('');
  const [typeAhead, setTypeAhead] = useState([]);
  const [showAutoComplete, setShowAutoComplete] = useState(false);
  const [shouldFetchSuggestions, setShouldFetchSuggestions] = useState(false);

  const kioskInventorySuggestionQuery: any = getSuggestionsFromCube(
    titleForCube,
    locId
  );

  const {
    resultSet: inventorySuggestionsResultSet,
    isLoading: inventorySuggestionsLoading,
    error: inventorySuggestionsError,
  }: any = useCubeQuery(kioskInventorySuggestionQuery, {
    skip: !shouldFetchSuggestions,
  });

  useEffect(() => {
    const data: any = inventorySuggestionsResultSet?.loadResponses[0]?.data;
    if (data) {
      setTypeAhead(data);
      setShouldFetchSuggestions(false);
    } else {
      setTypeAhead([]);
      setShouldFetchSuggestions(false);
    }
  }, [inventorySuggestionsResultSet]);

  const autoCompleteSearch = async (value: string) => {
    setTitleForCube(value);
    setShowAutoComplete(true);
    setShouldFetchSuggestions(true);
  };

  const onChangeHandler = (value: any) => {
    autoCompleteSearch(value);
    setSearchValue(value);
  };

  const onSelectHandler = (
    e: any,
    selectedItem: any = '',
    isInnerText: any = false,
    doApiCall: any = false
  ) => {
    const selectedValue = isInnerText ? selectedItem : e?.target?.value;
    setSearchValue(selectedValue);
    setShowAutoComplete(false);
    dispatch(
      actions.setFilters({ filterItem: selectedValue, filterType: 'title' })
    );
    dispatch(
      actions.setSelectedFilters({
        filterItem: selectedValue,
        filterType: 'title',
      })
    );
    if (doApiCall) {
      fetchSelectedItem(selectedValue);
    }
  };

  const fetchSelectedItem = (selectedItem: any) => {
    router.push({
      pathname: '/results',
      query: {
        searchTitle: selectedItem,
      },
    });
  };

  return (
    <div className='search-bar-inner-wrapper'>
      <div className='input-wrapper input-prepend'>
        <SearchComp
          userInput={searchValue}
          placeholder='Search for brand, color etc.'
          options={typeAhead}
          isApiCall={true}
          setUserInput={setSearchValue}
          onSelectHandler={onSelectHandler}
          onChangeHandler={onChangeHandler}
          showAutoComplete={showAutoComplete}
          setShowAutoComplete={setShowAutoComplete}
          suggestionsLoading={inventorySuggestionsLoading}
          suggestionsHasError={inventorySuggestionsError}
        />
      </div>
    </div>
  );
};

export default KioskSearch;
