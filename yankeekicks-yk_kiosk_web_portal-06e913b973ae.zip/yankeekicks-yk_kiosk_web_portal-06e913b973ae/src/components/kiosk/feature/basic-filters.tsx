import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useDispatch } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import {
  SEARCH_BY_TYPES,
  SEARCH_COLOURS,
  SIZE_MATRIX_GRADESCHOOL,
  SIZE_MATRIX_MENWOMEN,
  SIZE_MATRIX_PRESCHOOL,
  SIZE_MATRIX_TODDLER,
} from 'components/common/filters/constants';
import sizeMatrix from 'utils/sizeMatrix.json';

const BasicFilters = () => {
  const dispatch = useDispatch();
  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const [searchSizes, setSearchSizes] = useState<any>([]);

  useEffect(() => {
    if (filterTypes.type?.length === 0) {
      setSearchSizes(sizeMatrix[0]?.sizeList);
      dispatch(
        actions.clearFiltersByKey({ filterType: 'size', filterItem: [] })
      );
      dispatch(
        actions.clearSelectedFiltersByKey({
          filterType: 'size',
          filterItem: [],
        })
      );
    } else {
      let searchSizesTemp: any = [];
      let valuesToHold: any = [];

      filterTypes.type?.forEach((type: any, index: number) => {
        let constantsToUse: any = [];

        if (type == 'men / women') {
          searchSizesTemp = searchSizesTemp.concat(
            sizeMatrix[SIZE_MATRIX_MENWOMEN].sizeList
          );
          constantsToUse = sizeMatrix[SIZE_MATRIX_MENWOMEN].sizeList;
          setSearchSizes(searchSizesTemp);
        } else if (type == 'grade school') {
          searchSizesTemp = searchSizesTemp.concat(
            sizeMatrix[SIZE_MATRIX_GRADESCHOOL].sizeList
          );
          constantsToUse = sizeMatrix[SIZE_MATRIX_GRADESCHOOL].sizeList;
          setSearchSizes(searchSizesTemp);
        } else if (type == 'pre school') {
          searchSizesTemp = searchSizesTemp.concat(
            sizeMatrix[SIZE_MATRIX_PRESCHOOL].sizeList
          );
          constantsToUse = sizeMatrix[SIZE_MATRIX_PRESCHOOL].sizeList;
          setSearchSizes(searchSizesTemp);
        } else if (type == 'toddler') {
          searchSizesTemp = searchSizesTemp.concat(
            sizeMatrix[SIZE_MATRIX_TODDLER].sizeList
          );
          constantsToUse = sizeMatrix[SIZE_MATRIX_TODDLER].sizeList;
          setSearchSizes(searchSizesTemp);
        }

        constantsToUse?.map((item: any) => {
          filterTypes?.size?.map((subItem: any) => {
            if (item?.value === subItem) {
              return valuesToHold?.push(subItem);
            }
          });
        });
      });

      dispatch(
        actions.setFilterValueBasedOnKey({
          filterKey: 'size',
          filterValue: valuesToHold,
        })
      );
    }
  }, [filterTypes?.type]);

  const setFilters = (filterItem: string, filterType: string) => {
    dispatch(
      actions.setFilters({ filterItem: filterItem, filterType: filterType })
    );
    dispatch(
      actions.setSelectedFilters({
        filterItem: filterItem,
        filterType: filterType,
      })
    );
  };

  const clearAll = (filterType: string) => {
    dispatch(
      actions.clearFiltersByKey({ filterType: filterType, filterItem: [] })
    );
    dispatch(
      actions.clearSelectedFiltersByKey({
        filterType: filterType,
        filterItem: [],
      })
    );
  };

  const renderSearchTypes = () => {
    return (
      <>
        {SEARCH_BY_TYPES.map((obj: any, index: any) => {
          const { key, value } = obj;
          return (
            <button
              className={`btn product-type-btn ${
                filterTypes.type?.includes(value?.toLowerCase())
                  ? 'selected'
                  : ''
              }`}
              type='button'
              key={key}
              onClick={() => setFilters(value?.toLowerCase(), 'type')}
            >
              {key}
            </button>
          );
        })}
      </>
    );
  };
  const renderSearchColors = () => {
    return (
      <>
        {SEARCH_COLOURS?.map((obj: any, index: any) => {
          const { key, value } = obj;
          return (
            <button
              className={`btn product-color-btn color-${key} ${
                filterTypes.color?.includes(value?.toLowerCase())
                  ? 'selected'
                  : ''
              }`}
              type='button'
              key={key}
              onClick={() => setFilters(value?.toLowerCase(), 'color')}
            ></button>
          );
        })}
      </>
    );
  };
  const renderSearchSizes = () => {
    return (
      <>
        {searchSizes?.map((obj: any, index: any) => {
          const { key, value } = obj;
          return (
            <button
              className={`btn product-size-btn ${
                filterTypes.size?.includes(value) ? 'selected' : ''
              }`}
              type='button'
              key={key}
              onClick={() => setFilters(value, 'size')}
            >
              {value}
            </button>
          );
        })}
      </>
    );
  };

  return (
    <>
      <div className='products-type-btn-wrapper'>
        <div className='heading-wrapper'>
          <h3 className='heading'>By Type</h3>
          {filterTypes?.type?.length ? (
            <button
              className='btn-transparent clear-filter-btn yk-badge-h7'
              onClick={() => clearAll('type')}
            >
              Clear Filter
            </button>
          ) : (
            ''
          )}
        </div>
        <div className='product-type-btn-details'>{renderSearchTypes()}</div>
      </div>
      <div className='products-color-btn-wrapper'>
        <div className='heading-wrapper'>
          <h3 className='heading'>By Color</h3>
          {filterTypes?.color?.length ? (
            <button
              className='btn-transparent clear-filter-btn yk-badge-h7'
              onClick={() => clearAll('color')}
            >
              Clear Filter
            </button>
          ) : (
            ''
          )}
        </div>
        <div className='product-color-btn-wrapper'>{renderSearchColors()}</div>
      </div>
      <div className='products-size-wrapper'>
        <div className='heading-wrapper'>
          <h3 className='heading'>By Size</h3>
          {filterTypes?.size?.length ? (
            <button
              className='btn-transparent clear-filter-btn yk-badge-h7'
              onClick={() => clearAll('size')}
            >
              Clear Filter
            </button>
          ) : (
            ''
          )}
        </div>
        <div className='product-size-btn-wrapper'>{renderSearchSizes()}</div>
      </div>
    </>
  );
};

export default BasicFilters;
