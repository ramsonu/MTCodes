import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import { useDispatch } from 'react-redux';
import { getBrandsList } from 'middleware/cubejs-wrapper/cubejs-query';
import { actions } from 'store/reducers/kiosk';
import ImageLoader from 'components/common/image-loader';
import CircleLoader from 'components/common/loader/circular-loader';
import Dummy from 'assets/images/big-product-img.svg';

const Brands = (props: any) => {
  const { shouldFetchBrands, setShouldFetchBrands } = props;
  const dispatch = useDispatch();
  const router = useRouter();

  const [brands, setBrands] = useState([]);

  const brandsQuery: any = getBrandsList();

  const {
    resultSet: brandsResultSet,
    isLoading: brandsIsLoading,
    error: brandsError,
  }: any = useCubeQuery(brandsQuery, { skip: !shouldFetchBrands });

  useEffect(() => {
    const data = brandsResultSet?.loadResponses[0]?.data;
    if (data) {
      setBrands(data);
      setShouldFetchBrands(false);
    } else {
      setBrands([]);
    }
  }, [brandsResultSet]);

  const getProducts = (brandName: string) => {
    dispatch(
      actions.setFilters({
        filterItem: brandName?.toLocaleLowerCase(),
        filterType: 'brand',
      })
    );
    dispatch(
      actions.setSelectedFilters({
        filterItem: brandName?.toLocaleLowerCase(),
        filterType: 'brand',
      })
    );
    dispatch(actions.setFilterTrigger(true));
    router.push('/results');
  };

  return (
    <div className='browse-products-wrapper'>
      <div className='heading-wrapper'>
        <h3 className='heading'>Browse</h3>
      </div>
      <div className='products-cards-wrapper'>
        {brandsError ? (
          <p>Something went wrong!</p>
        ) : brandsIsLoading ? (
          <CircleLoader />
        ) : (
          brands?.map((item: any, index: any) => (
            <div className='card kiosk-brand-card' key={index}>
              <div
                className='card-body'
                onClick={() => getProducts(item?.['Brand.brandName'])}
              >
                <div className='product-image-wrapper'>
                  <ImageLoader
                    src={item?.['Brand.brandImageUrl']}
                    fallbackImg={Dummy}
                    className='img-fluid'
                    alt='kiosk-product-Image'
                    width='200'
                    height='200'
                    isPresignedURL={true}
                  />
                </div>
                <h5 className='yk-brandTitle yk-badge-h3'>
                  {item?.['Brand.brandName']}
                </h5>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Brands;
