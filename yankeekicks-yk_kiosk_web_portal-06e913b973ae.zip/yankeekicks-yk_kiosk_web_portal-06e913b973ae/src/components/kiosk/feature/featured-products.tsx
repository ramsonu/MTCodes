import React, { useState, useEffect } from 'react';
import { useCubeQuery } from '@cubejs-client/react';
import { getFeatureCards } from 'middleware/cubejs-wrapper/cubejs-query';
import CircleLoader from 'components/common/loader/circular-loader';
import ImageLoader from 'components/common/image-loader';
import Dummy from 'assets/images/big-product-img.svg';

const FeaturedProducts = (props: any) => {
  const {
    locId,
    shouldFeaturedFetch,
    setShouldFeaturedFetch,
    productsHandler,
  } = props;

  const [featuredCardsData, setFeaturedCardsData] = useState([]);

  const featureCardsQuery: any = getFeatureCards(locId);

  const {
    resultSet: featureCardsResultSet,
    isLoading: featureCardsLoading,
    error: featureCardsError,
  }: any = useCubeQuery(featureCardsQuery, { skip: !shouldFeaturedFetch });

  useEffect(() => {
    const data: any = featureCardsResultSet?.loadResponses[0]?.data;
    if (data && locId) {
      setFeaturedCardsData(data);
      setShouldFeaturedFetch(false);
    } else {
      setFeaturedCardsData([]);
    }
  }, [featureCardsResultSet]);

  return (
    <div className='featured-products-wrapper'>
      <div className='heading-wrapper'>
        <h3 className='heading'>Featured Products</h3>
      </div>
      <div className='products-cards-wrapper'>
        {featureCardsError ? (
          <p>Something went wrong!</p>
        ) : featureCardsLoading ? (
          <CircleLoader />
        ) : (
          featuredCardsData?.map((item: any, index: any) => (
            <div className='card kiosk-product-card' key={index}>
              <div
                className='card-body'
                onClick={() =>
                  productsHandler(item?.['KioskInventory.productId'])
                }
              >
                <div className='product-image-wrapper'>
                  <ImageLoader
                    src={item?.['KioskInventory.imageUrl']}
                    fallbackImg={Dummy}
                    className='card-Image-top'
                    alt='kiosk-product-Image'
                    imgWidth={500}
                    imgHeight={200}
                  />
                </div>

                <h5
                  className='card-title yk-badge-h3'
                  title={item?.['KioskInventory.title'] || '--'}
                >
                  {item?.['KioskInventory.title'] || '--'}
                </h5>
                <p className='card-text yk-badge-h7'>
                  {item?.['KioskInventory.variantCount'] > 1
                    ? `${item?.['KioskInventory.variantCount']} sizes`
                    : `${item?.['KioskInventory.variantCount']} size`}
                </p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default FeaturedProducts;
