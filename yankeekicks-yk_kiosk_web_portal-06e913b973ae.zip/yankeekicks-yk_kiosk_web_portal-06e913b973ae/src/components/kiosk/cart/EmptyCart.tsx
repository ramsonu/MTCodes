import React from 'react';
import Image from 'next/image';
import { useRouter } from 'next/router';
import emptyCartImg from 'assets/images/empty-cart-img.png';

const EmptyCart = () => {
  const router = useRouter();
  return (
    <>
      <div className='app-wrapper empty-cart-page-wrapper'>
        <div className='container-fluid'>
          <div className='empty-cart-page-inner-wrapper'>
            <div className='row'>
              <div className='col-lg-12'>
                <div className='empty-cart-img-wrapper'>
                  <Image
                    src={emptyCartImg}
                    className='img-fluid'
                    alt='empty-cart-img'
                  />
                </div>
                <div className='cart-info-wrapper'>
                  <h3 className='empty-cart-heading yk-badge-h13'>
                    Your cart is empty
                  </h3>
                  <p className='empty-cart-info yk-badge-h12'>
                    <span className='cart-info-text'>
                      Looks like you haven&apos;t added anything to cart yet.
                    </span>
                    <br />
                    <span className='cart-info-text'>
                      Go ahead and explore our inventory.
                    </span>
                  </p>
                </div>
                <div className='btn-action-wrapper'>
                  <button
                    type='button'
                    className='btn btn-explore yk-badge-h5'
                    onClick={() => router.push('/features')}
                  >
                    Explore
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EmptyCart;
