/* eslint-disable @next/next/no-img-element */
import React, { useState } from 'react';
import type { NextPage } from 'next';
import Image from 'next/image';
import { useSelector, useDispatch } from 'react-redux';
import { Snackbar } from '@mui/material';
import MuiAlert, { AlertProps } from '@mui/material/Alert';
import { actions } from 'store/reducers/kiosk';
import Footer from 'components/footer';
import EmptyCart from './EmptyCart';
import ClearCartModal from './ClearCartModal';
import ImageLoader from 'components/common/image-loader';
import closeIcon from 'assets/images/close-icon-1.png';
import Dummy from 'assets/images/big-product-img.svg';

const Alert = React.forwardRef<HTMLDivElement, AlertProps>(function Alert(
  props,
  ref
) {
  return <MuiAlert elevation={6} ref={ref} variant='filled' {...props} />;
});

const CartPage: NextPage = () => {
  const { cart } = useSelector((state: any) => state.kiosk);
  const dispatch = useDispatch();
  const [open, setOpen] = useState<any>(false);
  const [clearCartModalOpen, setClearCartModalOpen] = useState<any>(false);

  const removeItem = (id: string) => {
    dispatch(actions.removeItem(id));
    setOpen(true);
  };
  const handleClearCartModal = () => {
    setClearCartModalOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  return (
    <>
      {cart.length > 0 ? (
        <>
          <div className='app-wrapper cart-page-wrapper'>
            <div className='heading-wrapper cart-heading-wrapper d-flex yk-cartHeader'>
              <div className='yk-cartHeadingWrapper'>
                <h2 className='cart-heading yk-badge-h13 mb-0'>
                  My Cart ({cart?.length})
                </h2>
                <button
                  className='btn-transparent clear-cart-btn mt-1'
                  onClick={handleClearCartModal}
                >
                  Clear Cart
                </button>
              </div>
              <Footer />
            </div>
            <div className='d-block  d-sm-none d-lg-none'>
              <p className='items-added-text'>Items you have added to cart</p>
            </div>
            <div className='d-none d-sm-block d-lg-block'>
              <div className='cart-body-wrapper'>
                {cart?.map((item: any, index: any) => (
                  <div className='product-info-card' key={index}>
                    <div className='product-img-wrapper'>
                      <ImageLoader
                        src={item?.images}
                        fallbackImg={Dummy}
                        alt='product-img'
                        className='img-fluid'
                        height='92'
                        width='152'
                      />
                    </div>
                    <div className='product-info-wrapper'>
                      <h5 className='product-info-text yk-badge-h11'>
                        {item?.title}
                      </h5>
                    </div>
                    <div className='style-info-wrapper'>
                      <span className='style-info-para'>
                        <h6 className='style-code-text yk-badge-h14'>
                          Style code:
                        </h6>
                        <h5 className='style-code yk-badge-h11'>
                          {item?.styleCode || '--'}
                        </h5>
                      </span>
                    </div>
                    <div className='size-info-wrapper'>
                      <p className='size-info yk-badge-h11'>{item?.size}</p>
                    </div>
                    <div className='btn-wrapper'>
                      <button
                        className='close-button btn-transparent'
                        onClick={() =>
                          removeItem(item.variantId ? item.variantId : item?.id)
                        }
                      >
                        <Image
                          src={closeIcon}
                          alt='close-icon'
                          className='Image-fluid'
                        />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className='d-block  d-sm-none d-lg-none'>
              <div className='mobile-cart-body-wrapper'>
                {cart?.map((item: any, index: any) => (
                  <div className='mobile-product-info-card' key={index}>
                    <div className='d-flex'>
                      <div className='mobile-product-img-wrapper'>
                        <img
                          src={item?.images}
                          alt='product-img'
                          className='img-fluid'
                          height='92'
                          width='152'
                        />
                      </div>
                      <div>
                        <div className='mobile-product-info-wrapper'>
                          {item?.title}
                        </div>
                        <div className='mobile-style-info-wrapper'>
                          <span className='mobile-style-info-para'>
                            <h6 className='style-code-text'>Style code:</h6>
                            <h5 className='style-code'>
                              {item?.styleCode || '--'}
                            </h5>
                          </span>
                        </div>
                        <div className='size-info-wrapper'>
                          <h6 className='style-code-text'>Style code:</h6>
                          <h5 className='style-code'>{item?.size}</h5>
                        </div>
                        <button
                          className='close-button btn-transparent'
                          onClick={() =>
                            removeItem(
                              item.variantId ? item.variantId : item?.id
                            )
                          }
                        >
                          <Image
                            src={closeIcon}
                            alt='close-icon'
                            className='Image-fluid'
                          />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      ) : (
        <EmptyCart />
      )}

      <Snackbar
        open={open}
        autoHideDuration={3000}
        onClose={handleClose}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        className='yk-toast-message yk-cart-toast-msg'
      >
        <Alert onClose={handleClose} severity='success' sx={{ width: '100%' }}>
          <h3 className='notification-heading'>Removed from cart</h3>
        </Alert>
      </Snackbar>
      {clearCartModalOpen && (
        <ClearCartModal
          clearCartModalOpen={clearCartModalOpen}
          setClearCartModalOpen={setClearCartModalOpen}
        ></ClearCartModal>
      )}
    </>
  );
};
export default CartPage;
