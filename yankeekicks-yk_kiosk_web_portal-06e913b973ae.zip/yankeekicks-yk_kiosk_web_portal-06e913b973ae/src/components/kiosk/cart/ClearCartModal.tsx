import React from 'react';
import type { NextPage } from 'next';
import Modal from '@mui/material/Modal';
import { useDispatch } from 'react-redux';
import { actions } from 'store/reducers/kiosk';

interface Props {
  clearCartModalOpen?: any;
  setClearCartModalOpen?: any;
}

const ClearCartModal: NextPage<Props> = ({
  clearCartModalOpen,
  setClearCartModalOpen,
}) => {
  const dispatch = useDispatch();
  const clearCart = () => {
    dispatch(actions.clearCart([]));
    setClearCartModalOpen(false);
  };
  const handleModalClose = () => {
    setClearCartModalOpen(false);
  };
  return (
    <>
      <div className='app-wrapper w-100 landing-page-wrapper'>
        <Modal
          open={clearCartModalOpen}
          onClose={handleModalClose}
          className='yk-clear-cart-modal-wrapper'
          aria-labelledby='modal-modal-title'
          aria-describedby='modal-modal-description'
        >
          <div className='app-wrapper clear-cart-modal-wrapper'>
            <div className='yk-modal-body'>
              <div className='modal-heading-wrapper'>
                <h3 className='modal-title yk-badge-h13'>Clear cart</h3>
                <p className='modal-sub-title yk-badge-h12'>
                  Are you sure you want to remove these items from your cart?
                </p>
              </div>
              <div className='btn-action-wrapper'>
                <button
                  type='button'
                  className='btn modal-no-btn'
                  onClick={clearCart}
                >
                  <h6 className='btn-text yk-badge-h12'>Yes</h6>
                </button>
                <button
                  type='button'
                  className='btn yk-btn-primary modal-yes-btn'
                  onClick={handleModalClose}
                >
                  <h6 className='btn-text yk-badge-h12'>No</h6>
                </button>
              </div>
            </div>
          </div>
        </Modal>
      </div>
    </>
  );
};
export default ClearCartModal;
