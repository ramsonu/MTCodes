import React from 'react';
import Modal from '@mui/material/Modal';
import { useRouter } from 'next/router';
import { useDispatch } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import { CART_MESSAGES } from 'utils/constants';

const CustomerSuccessModal = (props: any) => {
  const router = useRouter();
  const dispatch = useDispatch();
  const goBackToLandingPage = () => {
    router.push('/');
    dispatch(actions.clearCart([]));
  };
  return (
    <Modal
      open={props?.open}
      className='yk-customer-cart-modal'
      aria-labelledby='modal-modal-title'
      aria-describedby='modal-modal-description'
    >
      <div className='app-wrapper customer-cart-modal-overlay-wrapper success-modal w-100'>
        <div className='yk-modal-body text-center'>
          <div className='yk-modal-title'>
            {' '}
            {CART_MESSAGES?.SUCCESS_MODAL_TITLE}
          </div>
          <div className='yk-modal-content'>
            {CART_MESSAGES?.SUCCESS_MODAL_CONTENT}
          </div>
          <button
            className='btn yk-btn-primary yk-modal-button great-modal-btn'
            type='button'
            onClick={goBackToLandingPage}
          >
            {CART_MESSAGES?.GREAT_BUTTON}
          </button>
        </div>
      </div>
    </Modal>
  );
};

export default CustomerSuccessModal;
