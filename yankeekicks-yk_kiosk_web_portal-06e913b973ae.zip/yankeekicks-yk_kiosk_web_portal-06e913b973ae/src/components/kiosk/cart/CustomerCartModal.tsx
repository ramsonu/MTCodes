import React, { useState, useRef } from 'react';
import Image from 'next/image';
import Modal from '@mui/material/Modal';
import { useDispatch, useSelector } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import CustomerSuccessModal from './CustomerSuccessModal';
import Notification from 'components/common/notification';
import { doRequest } from 'utils/request';
import { CART_MESSAGES, SOMETHING_WENT_WRONG } from 'utils/constants';
import alertImg from 'assets/images/alert-circle.png';

const CustomerCartModal = ({ isVisible, setIsVisible }: any) => {
  const { cart } = useSelector((state: any) => state.kiosk);

  const dispatch = useDispatch();
  const applyRef = useRef<HTMLButtonElement>(null);

  const [username, setUsername] = useState('');
  const [error, setError] = useState('');
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showSuccessPopup, setShowSuccessPopup] = useState<boolean>(false);

  const currentDate = new Date().toISOString();

  const getRequestToTryResults = async () => {
    let tryoutItemPayload: any = cart.map((item: any) => {
      return {
        createdAt: currentDate,
        createdBy: 0,
        customerId: 'c130',
        inventoryItemId: item?.variantId,
        name: username,
        size: item?.size,
        sku: item?.styleCode,
        updatedAt: '0',
        updatedBy: 0,
        userId: 15,
        storeId: localStorage?.getItem('storeId'),
        locationId: localStorage?.getItem('locationId'),
        price: item?.price,
      };
    });

    try {
      const response: any = await doRequest(
        `${process.env.NEXT_PUBLIC_APP_STOREFRONT_REST_API_DOMAIN}/tryoutItem-master`,
        'post',
        tryoutItemPayload
      );
      if (response) {
        setIsVisible(false);
        setShowSuccessModal(true);
      }
    } catch (error: any) {
      console.log('error: ', error);
      setShowSuccessPopup(true);
      setIsVisible(false);
    }
    dispatch(actions.clearAllFilters({}));
    dispatch(actions.clearAllSelectedFilters({}));
  };

  const handleClose = (event: Event | React.SyntheticEvent) => {
    if (
      applyRef.current &&
      applyRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }

    setIsVisible(false);
  };
  const inputHandler = (e: any) => {
    const nameRegex = /^[a-zA-Z\s]*$/;
    const nameTyped = e?.target?.value;

    if (nameTyped.match(nameRegex) && nameTyped !== '') {
      if (nameTyped.length < 15) {
        setUsername(nameTyped);
        setError('');
      } else {
        setError('Please enter valid name');
      }
    } else {
      setError('Please enter valid name');
      setUsername(nameTyped);
    }
  };

  const handleSnackbarClose = () => {
    setShowSuccessPopup(false);
  };

  const isConfirm = error === '' && username !== '' ? true : false;
  return (
    <>
      <Modal
        open={isVisible}
        onClose={handleClose}
        className='yk-customer-cart-modal'
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'>
        <div className='app-wrapper customer-cart-modal-overlay-wrapper w-100'>
          <div className='yk-modal-body text-center'>
            <div className='yk-modal-title'>
              <Image
                src={alertImg}
                className='img-fluid me-3'
                alt='alert-img'
              />
              {CART_MESSAGES?.CUSTOMER_MODAL_TITLE}
            </div>
            <div className='yk-modal-content'>
              {CART_MESSAGES?.CUSTOMER_MODAL_CONTENT}
            </div>
            <input
              type='text'
              className='yk-modal-input'
              placeholder='Enter Your Name'
              value={username}
              onChange={(e) => inputHandler(e)}></input>
            <p className='yk-modal-content'>{error}</p>
            <button
              className='btn yk-btn-primary yk-modal-button mb-5 whiteSpaceNoWrap'
              type='button'
              onClick={getRequestToTryResults}
              disabled={!isConfirm}>
              {CART_MESSAGES?.CONFIRM_REQUEST_BUTTON}
            </button>
          </div>
        </div>
      </Modal>
      <CustomerSuccessModal open={showSuccessModal} />
      <Notification
        showSuccessPopup={showSuccessPopup}
        handleSnackbarClose={handleSnackbarClose}
        severityType='error'
        message={SOMETHING_WENT_WRONG}
        className='yk-shoesize-alert-wrapper'
      />
    </>
  );
};

export default CustomerCartModal;
