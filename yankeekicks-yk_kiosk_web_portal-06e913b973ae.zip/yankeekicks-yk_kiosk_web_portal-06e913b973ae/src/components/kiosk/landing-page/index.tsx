/* eslint-disable @next/next/no-img-element */
import React, { useEffect, useState } from 'react';
import type { NextPage } from 'next';
import { useSelector } from 'react-redux';
import Image from 'next/image';
import Logo from 'assets/images/yk-logo.svg';
import Dummy from 'assets/images/big-product-img.svg';
import { useRouter } from 'next/router';
import ProductDetailsModal from '../details/ProductDetailsModal';
import Notification from 'components/common/notification';
import { getTime } from 'utils/util';
import { format } from 'date-fns';
import { useSwipeable } from 'react-swipeable';
import { getFeatureCards } from 'middleware/cubejs-wrapper/cubejs-query';
import { useCubeQuery } from '@cubejs-client/react';
import CircleLoader from 'components/common/loader/circular-loader';
import ImageLoader from 'components/common/image-loader';
import arrowRight from 'assets/images/white-arrowRight.svg';
import rightArrow from 'assets/images/right-arrow-icon.svg';
import leftArrow from 'assets/images/left-arrow-icon.svg';

const LandingPage: NextPage = () => {
  const { selected } = useSelector((state: any) => state.shared);

  const router = useRouter();
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [productId, setProductId] = useState('');
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);
  const [currentStoreLocation, setCurrentLocation] = useState<any>('');
  const [currentIndex, setCurrentIndex] = useState<any>(0);
  const [featuredCardsData, setFeaturedCardsData] = useState<any>([]);
  const [locId, setLocId] = useState<any>('');
  const [shouldFeaturedFetch, setShouldFeaturedFetch] = useState(false);
  const [currentDateTime, setCurrentDateTime] = useState<any>({
    date: '',
    time: '',
  });

  const lengthOfProducts: number = featuredCardsData?.length || 0;

  useEffect(() => {
    const loc = localStorage.getItem('storeLocation');
    setCurrentLocation(loc);
  }, [selected]);

  useEffect(() => {
    if (localStorage?.getItem('locationId')) {
      setLocId(localStorage?.getItem('locationId'));
      setShouldFeaturedFetch(true);
    } else {
      setLocId('');
    }
  }, [selected]);

  // to display date and time
  useEffect(() => {
    if (localStorage?.getItem('locationId')) {
      const currentDate = new Date();
      const cTime = currentDate && getTime(currentDate);
      const cDate = currentDate && format(currentDate, 'dd MMM yyyy');
      setCurrentDateTime({ date: cDate, time: cTime });
    } else {
      setCurrentDateTime({ date: '', time: '' });
    }
  }, [selected]);

  const featureCardsQuery: any = getFeatureCards(locId);

  const {
    resultSet: featureCardsResultSet,
    isLoading: featureCardsLoading,
    error: featureCardsError,
  }: any = useCubeQuery(featureCardsQuery, { skip: !shouldFeaturedFetch });

  useEffect(() => {
    const data: any = featureCardsResultSet?.loadResponses[0]?.data;
    if (data && locId) {
      setFeaturedCardsData(data);
      setShouldFeaturedFetch(false);
    } else {
      setFeaturedCardsData([]);
    }
  }, [featureCardsResultSet]);

  useEffect(() => {
    const intervalId = setInterval(() => {
      if (lengthOfProducts) {
        setCurrentIndex((currentIndex + 1) % lengthOfProducts);
      }
    }, 2000);

    return () => clearInterval(intervalId);
  }, [currentIndex, lengthOfProducts, selected]);

  const handlers: any = useSwipeable({
    onSwipedLeft: () => {
      setCurrentIndex((currentIndex + 1) % lengthOfProducts);
    },
    onSwipedRight: () => {
      setCurrentIndex((currentIndex + lengthOfProducts - 1) % lengthOfProducts);
    },
    preventDefaultTouchmoveEvent: true,
    trackMouse: true,
  } as any);

  // displayImages -> to display first five images
  // remainingImages -> to concat rest of the images
  const displayImages = featuredCardsData?.slice(
    currentIndex,
    currentIndex + 5
  );
  const remainingImages = featuredCardsData?.slice(0, 5 - displayImages.length);

  const onFindHandler = () => {
    router.push('/features');
  };

  const productsHandler = (pId: any) => {
    setShowDetailsModal(true);
    const shopifyIdText = 'gid://shopify/Product/';
    const proId = shopifyIdText.concat(pId);
    setProductId(proId);
  };

  const handleSnackbarClose = () => {
    setShowSuccessPopup(false);
  };

  const message = (
    <h3 className='notification-heading'>
      Item Added to cart
      <span className='notification-subtitle'>
        <br />
        You can go to cart or continue browsing
      </span>
    </h3>
  );

  // Based upon total length of product decide middle card to open product details modal
  const decideClassNameAndLength = (index: any) => {
    const indexToUse: any =
      lengthOfProducts === 1 || lengthOfProducts === 2
        ? 0
        : lengthOfProducts === 3
        ? 1
        : 2;
    let firstClass = 'firstImg';
    let secondClass = 'totalFive';
    switch (index) {
      case 0:
        firstClass = 'firstImg';
        break;
      case 1:
        firstClass = 'secondImg';
        break;
      case 2:
        firstClass = 'thirdImg';
        break;
      case 3:
        firstClass = 'fourthImg';
        break;
      case 4:
        firstClass = 'fifthImg';
        break;
    }
    switch (lengthOfProducts) {
      case 1:
        secondClass = 'totalOne';
        break;
      case 2:
        secondClass = 'totalTwo';
        break;
      case 3:
        secondClass = 'totalThree';
        break;
      case 4:
        secondClass = 'totalFour';
        break;
      case 5:
        secondClass = 'totalFive';
        break;
      default:
        secondClass = 'totalFive';
        break;
    }
    // Dynamic class to decide transform in css for ex. firstImg totalFive
    const classNameForImage = `${firstClass} ${secondClass}`;
    return { classNameForImage, indexToUse };
  };

  const displayLocationName = `welcome to ${
    currentStoreLocation?.toLowerCase()?.includes('store')
      ? `${currentStoreLocation || ''}!`
      : `${currentStoreLocation || ''} Store!`
  }`;

  //left and right arrow clicks
  const handleLeftClick = () => {
    setCurrentIndex((currentIndex + 1) % lengthOfProducts);
  };

  const handleRightClick = () => {
    setCurrentIndex((currentIndex + lengthOfProducts - 1) % lengthOfProducts);
  };

  const imgArPlaceholder =
    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAATCAQAAADhPk8cAAAAEUlEQVR42mNkwAkYR6VGgBQAFgsAFI9FzTkAAAAASUVORK5CYII=';
  return (
    <>
      <div className='app-wrapper w-100 landing-page-wrapper'>
        <header>
          <div className='yk-logo-wrapper'>
            <Image src={Logo} alt='' className='img-fluid' />
            <div className='date-time-wrapper'>
              <div className='date-time-inner-wrapper'>
                <p className='time'>
                  {currentDateTime && currentDateTime?.time
                    ? currentDateTime?.time
                    : '--'}
                </p>
                <p className='date'>
                  {currentDateTime && currentDateTime?.date
                    ? currentDateTime?.date
                    : '--'}
                </p>
                <p className='separator'></p>
                <p className='location'>{currentStoreLocation}</p>
              </div>
            </div>
            <div className='heading-wrapper'>
              <div className='heading-inner-wrapper yk-newHeadline'>
                <h1 className='heading'>{displayLocationName}</h1>
                <p>Discover the latest trends with our collection</p>
                <button
                  className='btn yk-primaryButton yk-exploreBtn'
                  onClick={onFindHandler}>
                  Find your next pair of kicks
                  <Image
                    src={arrowRight}
                    alt=''
                    className='img-fluid arrow-rightIcon'
                  />
                </button>
              </div>
            </div>
          </div>
        </header>
        <div className='container'>
          <div className='row'>
            <div className='col-12'>
              <div className='slider-wrapper h-100'>
                <div className='slider h-100'>
                  {featureCardsLoading ? (
                    <CircleLoader />
                  ) : (
                    <div
                      className='carousel'
                      id='yk-landing-carousel'
                      {...handlers}>
                      {displayImages?.length > 0 ? (
                        displayImages
                          ?.concat(remainingImages)
                          ?.map((image: any, index: any) => {
                            const { classNameForImage, indexToUse } =
                              decideClassNameAndLength(index);
                            if (index < lengthOfProducts) {
                              return (
                                <div key={index} className={classNameForImage}>
                                  <div className='yk-sliderImgWrapper position-relative'>
                                    <img
                                      src={imgArPlaceholder}
                                      alt=''
                                      className='img-fluid w-100 yk-ARImg'
                                    />
                                    <ImageLoader
                                      src={image?.['KioskInventory.imageUrl']}
                                      fallbackImg={Dummy}
                                      className='img-fluid w-100 h-100 position-absolute top-0 left-0 yk-sliderImg'
                                      alt='kiosk-feature-product'
                                      imgWidth={592}
                                      imgHeight={600}
                                      onClickHandler={() =>
                                        index === indexToUse &&
                                        productsHandler(
                                          image?.['KioskInventory.productId']
                                        )
                                      }
                                    />
                                  </div>
                                  <h2
                                    onClick={() =>
                                      index === indexToUse &&
                                      productsHandler(
                                        image?.['KioskInventory.productId']
                                      )
                                    }>
                                    {' '}
                                    {index === indexToUse &&
                                      image?.['KioskInventory.title']}
                                  </h2>
                                </div>
                              );
                            }
                          })
                      ) : (
                        <ImageLoader
                          fallbackImg={Dummy}
                          className='img-fluid yk-dummyLogoImg'
                          alt='kiosk-feature-product'
                          imgWidth={592}
                          imgHeight={600}
                        />
                      )}
                    </div>
                  )}
                  {featuredCardsData?.length > 1 && (
                    <div className='yk-arrowImgWrapper'>
                      <div className='yk-imgWrapper d-flex justify-content-between'>
                        <Image
                          src={leftArrow}
                          alt=''
                          className='img-fluid left-arrow-icon'
                          onClick={() => handleLeftClick()}
                        />
                        <Image
                          src={rightArrow}
                          alt=''
                          className='img-fluid right-arrow-icon'
                          onClick={() => handleRightClick()}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Notification
        showSuccessPopup={showSuccessPopup}
        handleSnackbarClose={handleSnackbarClose}
        severityType='success'
        message={message}
        className='yk-shoesize-alert-wrapper'
      />

      {showDetailsModal && (
        <ProductDetailsModal
          showDetailsModal={showDetailsModal}
          setShowDetailsModal={setShowDetailsModal}
          id={productId}
          setShowSuccessPopup={setShowSuccessPopup}
        />
      )}
    </>
  );
};
export default LandingPage;
