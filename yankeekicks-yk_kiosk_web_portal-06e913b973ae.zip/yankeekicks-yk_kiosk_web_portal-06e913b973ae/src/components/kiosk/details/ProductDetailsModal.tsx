/* eslint-disable @next/next/no-img-element */
import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import { useDispatch } from 'react-redux';
import Modal from '@mui/material/Modal';
import { actions } from 'store/reducers/kiosk';
import { convertPriceToUSFormat } from 'utils/util';
import { getProductAndVariantDetailsById } from 'middleware/cubejs-wrapper/cubejs-query';
import CircleLoader from 'components/common/loader/circular-loader';
import leftArrowIcon from 'assets/images/back-arrow.svg';
import Dummy from 'assets/images/big-product-img.svg';
import ImageLoader from 'components/common/image-loader';
import modalCloseIcon from 'assets/images/modal-close-img.svg';

const ProductDetailsModal = (props: any) => {
  const { id, setShowDetailsModal, setShowSuccessPopup, showDetailsModal } =
    props;

  const [totalVariants, setTotalVariants] = useState<any>([]);
  const [currentIndex, setCurrentIndex] = useState<any>(0);
  const [selectedVariants, setSelectedVariants] = useState<any>([]);
  const [availableVariants, setAvailableVariants] = useState<any>([]);
  const [showLess, setShowLess] = useState(true);
  const [conditions, setConditions] = useState<any>([]);
  const [selectedCondition, setSelectedCondition] = useState<any>(null);
  const [sku, setSku] = useState<any>('');
  const [productDetails, setProductDetails] = useState<any>([]);
  const [productImages, setProductImages] = useState<any>([]);
  const [shouldFetchProductDetails, setShouldFetchProductDetails] =
    useState<any>(false);

  const dispatch = useDispatch();
  const router = useRouter();

  const locId: any = localStorage.getItem('locationId');

  useEffect(() => {
    if (id && locId) {
      setShouldFetchProductDetails(true);
    }
  }, []);

  const productAndVariantDetailsByIdQuery: any =
    getProductAndVariantDetailsById(id, locId);

  const {
    resultSet: productsAndVariantsDetailsResultSet,
    isLoading: productsAndVariantsDetailsLoading,
    error: productsAndVariantsDetailsError,
  }: any = useCubeQuery(productAndVariantDetailsByIdQuery, {
    skip: !shouldFetchProductDetails,
  });

  useEffect(() => {
    const data = productsAndVariantsDetailsResultSet?.loadResponses[0]?.data;
    if (data) {
      setProductDetails(data);
      setShouldFetchProductDetails(false);
    } else {
      setProductDetails([]);
    }
  }, [productsAndVariantsDetailsResultSet]);

  useEffect(() => {
    if (productDetails?.length > 0 && !productsAndVariantsDetailsLoading) {
      const uniqueItemsByVariantId: any = [];
      productDetails.map((item: any) => {
        var findItem = uniqueItemsByVariantId.find(
          (x: any) =>
            x?.['InventoryLineItem.variantId'] ===
            item?.['InventoryLineItem.variantId']
        );
        if (!findItem) uniqueItemsByVariantId.push(item);
      });

      const uniqueImages = productDetails
        ?.map((item: any) => item?.['InventoryLineItem.imageUrl'])
        ?.filter(
          (variant: any, i: any, ar: any) =>
            ar.indexOf(variant) === i && !!variant
        );

      if (uniqueItemsByVariantId?.length) {
        const uniqueConditions = uniqueItemsByVariantId[0]?.[
          'ProdutsShopifyOptions.values'
        ]
          ? uniqueItemsByVariantId[0]?.['ProdutsShopifyOptions.values']?.split(
              ','
            )
          : [''];

        const defaultCondition =
          uniqueConditions[0] === 'New' ? 'New' : uniqueConditions[0];

        setTotalVariants(uniqueItemsByVariantId);
        setConditions(uniqueConditions);
        setSelectedCondition(defaultCondition);
        setProductImages(uniqueImages);
      }
    } else {
      setAvailableVariants([]);
      setTotalVariants([]);
      setConditions([]);
      setSelectedCondition([]);
      setProductImages([]);
    }
  }, [productDetails, productsAndVariantsDetailsLoading]);

  useEffect(() => {
    if (
      (selectedCondition !== null && selectedCondition !== undefined) ||
      selectedCondition === ''
    ) {
      let availableSizes: any = [];
      if (selectedCondition === '') {
        availableSizes = totalVariants
          ?.filter(
            (item: any) =>
              Number(item?.['InventoryLineItem.inventoryQuantity']) !== 0 &&
              // item?.['InventoryLineItem.Title']?.split(' / ')
              !!item?.['InventoryLineItem.Title']
          )
          ?.map((size: any) => {
            return {
              variantId: size?.['InventoryLineItem.variantId'],
              variantSize: size?.['InventoryLineItem.Option1'],
              variantPrice: parseInt(size?.['InventoryLineItem.Price']),
              variantInventoryId: size?.['InventoryLineItem.inventoryitemId'],
            };
          });
      } else {
        availableSizes = totalVariants
          ?.filter(
            (item: any) =>
              Number(item?.['InventoryLineItem.inventoryQuantity']) !== 0 &&
              // item?.['InventoryLineItem.Title']?.split(' / ')?.includes(selectedCondition)
              !!item?.['InventoryLineItem.Title'] &&
              item?.['InventoryLineItem.Option2']?.trim()?.toLowerCase() ===
                selectedCondition?.trim()?.toLowerCase()
          )
          ?.map((size: any) => {
            return {
              variantId: size?.['InventoryLineItem.variantId'],
              variantSize: size?.['InventoryLineItem.Option1'],
              variantPrice: parseInt(size?.['InventoryLineItem.Price']),
              variantInventoryId: size?.['InventoryLineItem.inventoryitemId'],
            };
          });
      }

      const skuOfProduct = totalVariants
        ?.map((item: any) => item?.['InventoryLineItem.sku'])
        ?.filter((variant: any, i: any, ar: any) => ar.indexOf(variant) === i)
        ?.filter((skuItem: any) => !skuItem?.includes('('));

      setSku(skuOfProduct.join(', '));

      setAvailableVariants(availableSizes);
    }
  }, [selectedCondition, totalVariants]);

  const addToCart = () => {
    let itemsForCart: any = [];
    if (selectedVariants.length) {
      selectedVariants.map((option: any) => {
        itemsForCart.push({
          id: totalVariants[0]?.['InventoryLineItem.productId'],
          title: totalVariants[0]?.['ProdutsShopify.title'],
          images: productImages[0],
          size: option.variantSize,
          variantId: option.variantId,
          styleCode: sku,
          inventoryItemId:
            totalVariants[0]?.['InventoryLineItem.inventoryitemId'],
          price: option?.variantPrice,
        });
      });

      itemsForCart.map((productDetails: any) => {
        dispatch(actions.addToCart(productDetails));
        handleModalClose();
        setShowSuccessPopup(true);
      });
      if (router.pathname === '/') {
        setTimeout(() => router.push('/features'), 2000);
      }
    }
  };

  const goToPrevSlide = () => {
    const newPointer =
      currentIndex === 0 ? productImages?.length - 1 : currentIndex - 1;
    setCurrentIndex(newPointer);
  };

  const goToNextSlide = () => {
    const newPointer =
      currentIndex === productImages?.length - 1 ? 0 : currentIndex + 1;
    setCurrentIndex(newPointer);
  };

  const variantHandler = (value: any) => {
    if (selectedVariants.includes(value)) {
      let tempVariants = [];
      tempVariants = selectedVariants.filter((data: any) => data !== value);
      setSelectedVariants(tempVariants);
    } else {
      setSelectedVariants([...selectedVariants, value]);
    }
  };

  const handleModalClose = () => {
    setShowDetailsModal(false);
    if (
      Object.keys(router.query).includes('locationId') &&
      Object.keys(router.query).includes('productId')
    ) {
      router.push('/results');
    }
  };

  return (
    <>
      <Modal
        open={showDetailsModal}
        onClose={() => handleModalClose()}
        className='yk-kiosk-modal-wrapper'
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'>
        <div>
          <div className='app-wrapper card-overlay-wrapper w-100'>
            {' '}
            <button type='button' className='btn btn-link modalCloseBtn'>
              <Image
                src={modalCloseIcon}
                className='img-fluid close-btn-img'
                alt=''
                onClick={() => handleModalClose()}
              />
            </button>
            <div className='container-fluid yk-modalContainer'>
              <div className='d-block d-sm-none d-lg-none yk-modalBackBtnWrapper'>
                <div
                  className='ykch-modalBackBtn'
                  onClick={() => handleModalClose()}>
                  <Image
                    src={leftArrowIcon}
                    className='back-arrow me-1'
                    alt='back-arrow'
                  />
                  <Link href='#' className='back-text-link'>
                    Back
                  </Link>
                </div>
              </div>
              <div className='yk-modalMobileScroll'>
                <div className='d-flex justify-content-space-between align-items-center yk-modalOverlay'>
                  <div>
                    <div className='yk-title yk-textTransformCapitalize yk-modalTitle'>
                      {productsAndVariantsDetailsLoading
                        ? ''
                        : totalVariants[0]?.['ProdutsShopify.title'] || '--'}
                    </div>
                    <div className='yk-subtitle'>
                      {productsAndVariantsDetailsLoading
                        ? ''
                        : totalVariants[0]?.['Catalogue.colorway'] || ''}
                    </div>
                  </div>
                  {productsAndVariantsDetailsLoading ? (
                    ''
                  ) : (
                    <button
                      className='btn yk-primaryButton yk-addToCartBtn'
                      type='button'
                      onClick={addToCart}
                      disabled={!selectedVariants.length || !sku}>
                      ADD TO CART
                    </button>
                  )}
                </div>

                {productsAndVariantsDetailsError ? (
                  <p>Something went wrong!</p>
                ) : productsAndVariantsDetailsLoading ? (
                  <CircleLoader />
                ) : (
                  <div className='ykch-overflowScroll h-100'>
                    <div className='kiosk-products-details-wrapper'>
                      <div
                        id='carouselExampleIndicators'
                        className='carousel slide carousel-fade'
                        data-mdb-ride='carousel'>
                        <div className='carousel-inner'>
                          <div className='carousel-item active'>
                            {(productImages?.length > 0 ||
                              productDetails?.length > 0) &&
                              (productDetails?.length > 0 &&
                              productImages?.length === 0 ? (
                                <img
                                  src={Dummy?.src}
                                  alt='fallback logo image'
                                  width={500}
                                  height={100}
                                  className='img-fluid d-block w-100 overlay-image'
                                />
                              ) : (
                                <ImageLoader
                                  src={productImages[currentIndex]}
                                  fallbackImg={Dummy}
                                  className='img-fluid w-100 overlay-image'
                                  alt='yk-product-1'
                                  width={500}
                                  height={100}
                                />
                              ))}
                          </div>
                        </div>
                        <button
                          className='carousel-control-prev'
                          type='button'
                          data-mdb-target='#carouselExampleIndicators'
                          data-mdb-slide='prev'
                          onClick={goToPrevSlide}>
                          <span className='' aria-hidden='true'></span>
                          <span className='visually-hidden'>Previous</span>
                        </button>
                        <button
                          className='carousel-control-next btn'
                          type='button'
                          data-mdb-target='#carouselExampleIndicators'
                          data-mdb-slide='next'
                          onClick={goToNextSlide}>
                          <span className='' aria-hidden='true'></span>
                          <span className='visually-hidden'>Next</span>
                        </button>
                        {productImages?.length > 1 && (
                          <div className='carousel-indicators'>
                            {productImages?.map((imageUrl: any, index: any) => {
                              return (
                                <button
                                  type='button'
                                  key={index}
                                  data-mdb-target='#carouselExampleIndicators'
                                  data-mdb-slide-to='0'
                                  className='active yk-carousel-buttons'
                                  aria-current='true'
                                  aria-label='Slide 1'>
                                  <ImageLoader
                                    src={imageUrl}
                                    fallbackImg={Dummy}
                                    className='img-fluid'
                                    alt='kiosk-product-Image'
                                    width='200'
                                    height='100'
                                    onClickHandler={() =>
                                      setCurrentIndex(index)
                                    }
                                  />
                                </button>
                              );
                            })}
                          </div>
                        )}
                      </div>

                      <div className='yk-section-title'>Select Size</div>
                      <p className='yk-section-subtitle'>
                        You can select more than one shoe size
                      </p>
                      <div className='yk-price-card-wrapper'>
                        <div className='row'>
                          {availableVariants &&
                            availableVariants?.length > 0 &&
                            availableVariants?.map((item: any, index: any) => {
                              return (
                                <div
                                  className='col-lg-2 col-md-3 col-6 kiosk-modal-cards-align'
                                  key={index}
                                  onClick={() => variantHandler(item)}>
                                  <div
                                    className={`card ${
                                      selectedVariants.includes(item)
                                        ? 'selected'
                                        : ''
                                    }`}>
                                    <div className='card-body'>
                                      <h2 className='ykch-selectSize'>
                                        {item?.variantSize}
                                      </h2>
                                      <p className='ykch-selectPrice'>
                                        {convertPriceToUSFormat(
                                          item?.variantPrice?.toFixed(2)
                                        ) || '--'}
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                        </div>
                      </div>

                      <div className='yk-shoes-condition-card-wrapper'>
                        {!!conditions[0] && (
                          <div className='yk-section-title'>
                            Select Condition
                            <p className='yk-section-subtitle'>
                              You can select the condition
                            </p>
                          </div>
                        )}
                        {!!conditions[0] && (
                          <div className='yk-price-card-wrapper yk-condition-card-wrapper'>
                            <div className='row'>
                              {conditions &&
                                conditions?.length > 0 &&
                                conditions?.map((name: any, index: any) => {
                                  return (
                                    <div
                                      className='condition-modal-cards'
                                      key={index}
                                      onClick={() =>
                                        setSelectedCondition(name)
                                      }>
                                      <div
                                        className={`card ${
                                          selectedCondition === name
                                            ? 'selected'
                                            : ''
                                        }`}>
                                        <div className='card-body'>
                                          <h2 className='ykch-condition'>
                                            {!!name ? name : 'No Condition'}
                                          </h2>
                                        </div>
                                      </div>
                                    </div>
                                  );
                                })}
                            </div>
                          </div>
                        )}
                      </div>

                      <div className='row'>
                        <div className='col-lg-6'>
                          <h2 className='yk-section-title'>Style</h2>
                          <p className='yk-section-subtitle'>{sku || '--'}</p>
                        </div>
                        <div className='col-lg-6'>
                          <h2 className='yk-section-title'>Colorway</h2>
                          <p className='yk-section-subtitle'>
                            {totalVariants[0]?.['Catalogue.colorway'] || '--'}
                          </p>
                        </div>
                      </div>
                      <h2 className='yk-section-title mt-4'>
                        Product Description
                      </h2>
                      <p className='yk-section-subtitle'>
                        {totalVariants[0]?.['Catalogue.shortDescription']
                          ? totalVariants[0]?.['Catalogue.shortDescription']
                              ?.length < 65
                            ? totalVariants[0]?.['Catalogue.shortDescription']
                            : showLess
                            ? totalVariants[0]?.['Catalogue.shortDescription']
                                ?.substring(0, 65)
                                ?.concat('...')
                            : totalVariants[0]?.['Catalogue.shortDescription']
                          : '--'}
                        {totalVariants[0]?.['Catalogue.shortDescription']
                          ?.length > 65 && (
                          <button
                            className='btn btn-transparent btn-view-more'
                            onClick={() => setShowLess(!showLess)}>
                            {showLess ? 'View More' : 'View Less'}
                          </button>
                        )}
                      </p>
                      <h4 className='yk-subtitle-h2 yk-modalSubTitle-h2'>
                        Cannot find the size you want? Ask our sales guy
                      </h4>
                      {!selectedVariants.length && (
                        <p className='yk-modal-msg'>
                          Please select at least one shoe size before adding to
                          cart.
                        </p>
                      )}
                      {!sku && (
                        <p className='yk-modal-msg'>
                          Size cannot be requested as SKU is missing.
                        </p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default ProductDetailsModal;
