import React, { useEffect, useState } from 'react';
import { KioskHeader } from 'components/header';
import { useRouter } from 'next/router';
import { useSelector, useDispatch } from 'react-redux';
import IdleTimerContainer from 'components/common/idle-timer';
import { getAllLocations } from 'middleware/cubejs-wrapper/cubejs-query';
import { useCubeQuery } from '@cubejs-client/react';
import { actions } from 'store/reducers/shared';
import { APP_KEYWORDS, APP_TITLE } from 'utils/constants';
import Head from 'next/head';

const Layout = ({ children }: any) => {
  const { selected } = useSelector((state: any) => state.shared);

  const [allLocations, setAllLocations] = useState([]);
  const [shouldFetchLocations, setShouldFetchLocations] = useState(false);

  const router = useRouter();
  const dispatch = useDispatch();

  const locationsQuery: any = getAllLocations();

  const checkRoutes =
    router.pathname === '/' ||
    router.pathname?.includes('/features') ||
    router?.pathname?.includes('/results');

  useEffect(() => {
    if (
      Object?.keys(selected)?.length === 0 &&
      !localStorage?.getItem('storeId') &&
      checkRoutes
    ) {
      setShouldFetchLocations(true);
    } else {
      setShouldFetchLocations(false);
    }
  }, []);

  const { resultSet: locationsResultSet }: any = useCubeQuery(locationsQuery, {
    skip: !shouldFetchLocations,
  });

  useEffect(() => {
    const data = locationsResultSet?.loadResponses[0]?.data;
    if (data) {
      setAllLocations(data);
      setShouldFetchLocations(false);
    } else {
      setAllLocations([]);
    }
  }, [locationsResultSet]);

  useEffect(() => {
    if (allLocations?.length > 0) {
      // if some location is already not set then only call setLocations
      if (
        Object?.keys(selected)?.length === 0 &&
        !localStorage?.getItem('storeId') &&
        checkRoutes
      ) {
        setLocations();
      }
    }
  }, [allLocations]);

  const setLocations = () => {
    const selectedItem = allLocations[0];
    localStorage?.setItem('storeId', selectedItem?.['Store.id']);
    localStorage?.setItem(
      'locationId',
      selectedItem?.['Locations.locationID_D']
    );
    localStorage?.setItem('storeLocation', selectedItem?.['Locations.name']);
    dispatch(actions.selected(selectedItem));
  };

  const renderHeader = () => {
    if (router.pathname !== '/') {
      return <KioskHeader />;
    }
    return null;
  };

  useEffect(() => {
    document.body.className =
      router.pathname == '/results' ? 'yk-searchResultsWrapper' : '';
  }, [router]);

  return (
    <>
      <Head>
        <title>{APP_TITLE}</title>
        <meta charSet='UTF-8' />
        <meta name='keywords' content={APP_KEYWORDS} />
        <meta name='author' content='MOURI Tech' />
        <meta name='viewport' content='width=device-width, initial-scale=1.0' />
      </Head>
      <div className='layout'>
        {renderHeader()}
        <IdleTimerContainer>{children}</IdleTimerContainer>
      </div>
    </>
  );
};

export default Layout;
