import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';

const CircleLoader = () => {
  return (
    <div className='YKCH-loader'>
      <Box sx={{ display: 'flex' }}>
        <CircularProgress />
      </Box>
    </div>
  );
};

export default CircleLoader;
