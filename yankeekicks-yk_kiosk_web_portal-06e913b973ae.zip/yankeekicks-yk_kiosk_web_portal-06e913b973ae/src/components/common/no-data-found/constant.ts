export const NO_RESULT_FOUND = {
  title: 'No results found',
  msg: "We couldn't find anything for what you are looking.",
};
