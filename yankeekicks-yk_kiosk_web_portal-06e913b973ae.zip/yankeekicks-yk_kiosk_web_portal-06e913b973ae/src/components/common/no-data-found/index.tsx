import React from 'react';
import Image from 'next/image';
import { NO_RESULT_FOUND } from './constant';
import noRecordImg from 'assets/images/no-table-record-img.png';

const NoDataFound = () => {
  return (
    <div className='no-record-found-wrapper text-center'>
      <Image
        src={noRecordImg}
        alt='filter-btn-icon'
        className='no-result-img img-fluid'
      />
      <h4 className='yk-title'>{NO_RESULT_FOUND.title}</h4>
      <p className='yk-subtitle'>{NO_RESULT_FOUND.msg}</p>
    </div>
  );
};
export default NoDataFound;
