import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { useDispatch, useSelector } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import { Checkbox, InputAdornment } from '@mui/material';
import { TextField } from '@mui/material';
import { getPreviousFullYear } from 'utils/util';
import {
  SEARCH_BRAND,
  SEARCH_COLOURS,
  SEARCH_BY_TYPES,
  SEARCH_BY_AVAILABILITY,
  SEARCH_RELEASE_NO_OF_YEARS,
  SIZE_MATRIX_TODDLER,
  SIZE_MATRIX_MENWOMEN,
  SIZE_MATRIX_PRESCHOOL,
  SIZE_MATRIX_GRADESCHOOL,
  SEARCH_BY_MODEL_NIKE,
  SEARCH_BY_MODEL_YEEZY,
  SEARCH_BY_MODEL_ADIDAS,
  SEARCH_BY_MODEL_AIR_JORDAN,
  SEARCH_BY_MODEL_NEW_BALANCE,
} from './constants';
import sizeMatrix from 'utils/sizeMatrix.json';
import searchIcon from 'assets/images/search-icon.png';

const DynamicFilter = ({ itemKey }: any) => {
  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const [items, setItems] = useState([]);
  const dispatch = useDispatch();
  const filterlabel = { inputProps: { 'aria-label': itemKey } };
  useEffect(() => {
    renderFilters();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  let searchSizes: any = [];
  // useEffect(() => {}, [filterTypes?.type]);

  useEffect(() => {
    renderFilters();
  }, [filterTypes?.brand, filterTypes?.type]); // eslint-disable-line react-hooks/exhaustive-deps

  const applyFilters = (objectItems: any, val: any) =>
    objectItems.filter((obj: any) =>
      obj.value.toLowerCase().includes(val?.toLowerCase())
    );

  const applySizes = () => {
    if (filterTypes.type == '') {
      sizeMatrix.forEach((type: any, index: number) => {
        searchSizes = searchSizes.concat(type.sizeList);
      });
    } else {
      filterTypes.type?.forEach((type: any, index: number) => {
        if (type == 'men / women') {
          searchSizes = searchSizes.concat(
            sizeMatrix[SIZE_MATRIX_MENWOMEN].sizeList
          );
        } else if (type == 'grade school') {
          searchSizes = searchSizes.concat(
            sizeMatrix[SIZE_MATRIX_GRADESCHOOL].sizeList
          );
        } else if (type == 'pre school') {
          searchSizes = searchSizes.concat(
            sizeMatrix[SIZE_MATRIX_PRESCHOOL].sizeList
          );
        } else if (type == 'toddler') {
          searchSizes = searchSizes.concat(
            sizeMatrix[SIZE_MATRIX_TODDLER].sizeList
          );
        }
      });
    }
  };
  applySizes();
  let tempArray: any = [];
  filterTypes?.brand?.map((obj: any, index: any) => {
    if (obj === 'nike') {
      tempArray.push(SEARCH_BY_MODEL_NIKE);
    } else if (obj === 'jordan') {
      tempArray.push(SEARCH_BY_MODEL_AIR_JORDAN);
    } else if (obj === 'adidas') {
      tempArray.push(SEARCH_BY_MODEL_ADIDAS);
    } else if (obj === 'new balance') {
      tempArray.push(SEARCH_BY_MODEL_NEW_BALANCE);
    } else if (obj === 'yeezy') {
      tempArray.push(SEARCH_BY_MODEL_YEEZY);
    } else {
      tempArray.push([]);
    }
  });

  const flatDepth = filterTypes?.brand?.length;
  const latestArray = tempArray.flat(flatDepth);
  const renderFilters = (value: any = '') => {
    let items: any = [];
    switch (itemKey) {
      case 'brand':
        items = value !== '' ? applyFilters(SEARCH_BRAND, value) : SEARCH_BRAND;
        break;
      case 'size':
        items = value !== '' ? applyFilters(searchSizes, value) : searchSizes;
        break;
      case 'color':
        items =
          value !== '' ? applyFilters(SEARCH_COLOURS, value) : SEARCH_COLOURS;
        break;
      case 'date':
        const year = getPreviousFullYear(SEARCH_RELEASE_NO_OF_YEARS);
        items = value !== '' ? applyFilters(year, value) : year;
        break;
      case 'type':
        items =
          value !== '' ? applyFilters(SEARCH_BY_TYPES, value) : SEARCH_BY_TYPES;
        break;
      case 'availability':
        items =
          value !== ''
            ? applyFilters(SEARCH_BY_AVAILABILITY, value)
            : SEARCH_BY_AVAILABILITY;
        break;
      case 'model':
        items = value !== '' ? applyFilters(latestArray, value) : latestArray;
        break;
      default:
        break;
    }
    setItems(items);
  };

  const filterHandler = (filterItem: string, filterType: string) => {
    dispatch(
      actions.setFilters({
        filterItem: filterItem,
        filterType: filterType,
      })
    );
  };

  const onChange = (e: any) => {
    renderFilters(e.target.value);
  };

  return (
    <div>
      <TextField
        id='outlined-search'
        label=''
        type='search'
        onChange={onChange}
        InputProps={{
          type: 'search',
          placeholder: 'Search',
          startAdornment: (
            <InputAdornment position='start'>
              <Image src={searchIcon} alt='search-icon' />
            </InputAdornment>
          ),
        }}
      />
      <ul className='sub-filter-list'>
        {items?.map((obj: any, index: any) => {
          const { key, value } = obj;
          const valueToPass =
            itemKey?.toLowerCase() === 'model'
              ? key?.toString()?.toLowerCase()
              : itemKey?.toLowerCase() === 'size'
              ? value?.toString()
              : value?.toString()?.toLowerCase();
          return (
            <div className='list-wrapper' key={`${itemKey}-${index}`}>
              <li>
                {itemKey === 'color' && (
                  <span
                    className='yk-color-badge'
                    style={{
                      background: `var(--bs-${value})`,
                    }}></span>
                )}
                <span>{value}</span>
                <Checkbox
                  {...filterlabel}
                  checked={filterTypes[itemKey]?.includes(valueToPass)}
                  className='filter-sidebar-checkbox'
                  onClick={() => filterHandler(valueToPass, itemKey)}
                />
              </li>
            </div>
          );
        })}
      </ul>
    </div>
  );
};

export default DynamicFilter;
