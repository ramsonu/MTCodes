export const SEARCH_BY_TYPES = [
  { key: 'Men / Women', value: 'Men / Women' },
  { key: 'Toddler', value: 'Toddler' },
  { key: 'Pre school', value: 'Pre school' },
  { key: 'Grade School', value: 'Grade School' },
];

export const SEARCH_BY_AVAILABILITY = [
  { key: 'InStock', value: 'In Stock' },
  { key: 'OutOfStock', value: 'Out Of Stock' },
];

export const SEARCH_BY_COLOURS = [
  { btn1: 'btn1' },
  { btn2: 'btn2' },
  { btn3: 'btn3' },
  { btn4: 'btn4' },
  { btn5: 'btn5' },
  { btn6: 'btn6' },
  { btn7: 'btn7' },
  { btn8: 'btn8' },
  { btn9: 'btn9' },
  { btn10: 'btn10' },
];

export const SEARCH_COLOURS = [
  { key: 'btn1', value: 'white' },
  { key: 'btn2', value: 'black' },
  { key: 'btn3', value: 'blue' },
  { key: 'btn4', value: 'navyblue' },
  { key: 'btn5', value: 'red' },
  { key: 'btn6', value: 'green' },
  { key: 'btn7', value: 'yellow' },
  { key: 'btn8', value: 'gray' },
  { key: 'btn9', value: 'lightyellow' },
  { key: 'btn10', value: 'pink' },
  { key: 'btn11', value: 'brown' },
];

export const SEARCH_BY_SIZES = [
  { key: 1, value: '1' },
  { key: '3.5 / 5W', value: '3.5 / 5W' },
  { key: '4 / 5.5W', value: '4 / 5.5W' },
  { key: '4.5 / 6W', value: '4.5 / 6W' },
  { key: '5 / 6.5W', value: '5 / 6.5W' },
  { key: '5.5 / 7W', value: '5.5 / 7W' },
  { key: '6 / 7.5W', value: '6 / 7.5W' },
  { key: '6.5 / 8W', value: '6.5 / 8W' },
  { key: '7 / 8.5W', value: '7 / 8.5W' },
  { key: '7.5 / 9W', value: '7.5 / 9W' },
  { key: '8 / 9.5W', value: '8 / 9.5W' },
  { key: '8.5 / 10W', value: '8.5 / 10W' },
  { key: '9 / 10.5W', value: '9 / 10.5W' },
  { key: '9.5 / 11W', value: '9.5 / 11W' },
  { key: '10 / 11.5W', value: '10 / 11.5W' },
  { key: '10.5 / 12W', value: '10.5 / 12W' },
  { key: 11, value: '11' },
  { key: 11.5, value: '11.5' },
  { key: 12, value: '12' },
  { key: 12.5, value: '12.5' },
  { key: 13, value: '13' },
  { key: 13.5, value: '13.5' },
  { key: 14, value: '14' },
  { key: 14.5, value: '14.5' },
  { key: 15, value: '15' },
  { key: 16, value: '16' },
  { key: 17, value: '17' },
  { key: 18, value: '18' },
  { key: 19, value: '19' },
  { key: 20, value: '20' },
];

export const SEARCH_AGE = [
  { key: '1week', value: '1 week' },
  { key: '1month', value: '1 month' },
  { key: '3months', value: '3 months' },
  { key: '6months', value: '6 months' },
  { key: '9months', value: '9 months' },
  { key: '1year', value: '1 year' },
];

export const SEARCH_BRAND = [
  { key: 'nike', value: 'Nike' },
  { key: 'jordan', value: 'Jordan' },
  { key: 'adidas', value: 'Adidas' },
  { key: 'new balance', value: 'New Balance' },
  { key: 'yeezy', value: 'Yeezy' },
  { key: 'puma', value: 'Puma' },
  // { key: 'supreme', value: 'Supreme' },
];

export const SEARCH_BY_MODEL_AIR_JORDAN = [
  { key: 'jordan 1', value: 'Air Jordan 1' },
  { key: 'jordan 2', value: 'Air Jordan 2' },
  { key: 'jordan 3', value: 'Air Jordan 3' },
  { key: 'jordan 4', value: 'Air Jordan 4' },
  { key: 'jordan 5', value: 'Air Jordan 5' },
  { key: 'jordan 6', value: 'Air Jordan 6' },
  { key: 'jordan 11', value: 'Air Jordan 11' },
  { key: 'jordan 12', value: 'Air Jordan 12' },
  { key: 'jordan 13', value: 'Air Jordan 13' },
];

export const SEARCH_BY_MODEL_NIKE = [
  { key: 'air force', value: 'Air Force 1' },
  { key: 'air max 1', value: 'Nike Air Max 1' },
  { key: 'air max 90', value: 'Nike Air Max 90' },
  { key: 'air max plus', value: 'Nike Air Max Plus' },
  { key: 'dunk', value: 'Nike Dunk' },
  { key: 'sacai', value: 'Nike Sacai' },
];

export const SEARCH_BY_MODEL_ADIDAS = [
  { key: 'adidas', value: 'Adidas' },
  { key: 'forum', value: 'Adidas FORUM' },
  { key: 'futurecraft 4d', value: 'Adidas FUTURECRAFT 4D' },
  { key: 'nmd', value: 'Adidas NMD' },
  { key: 'samba', value: 'Adidas SAMBA' },
  { key: 'superstar', value: 'Adidas SUPERSTAR' },
];

export const SEARCH_BY_MODEL_NEW_BALANCE = [
  { key: 'new balance', value: 'New Balance' },
];

export const SEARCH_BY_MODEL_YEEZY = [
  { key: 'yeezy', value: 'Yeezy' },
  { key: 'yeezy 350', value: 'Yeezy Boost 350' },
  { key: 'yeezy 380', value: 'Yeezy Boost 380' },
  { key: 'yeezy 450', value: 'Yeezy Boost 450' },
  { key: 'yeezy 500', value: 'Yeezy Boost 500' },
  { key: 'yeezy 700', value: 'Yeezy Boost 700' },
  { key: 'foam rnnr', value: 'Yeezy Foam RNNR' },
  { key: 'knit rnr', value: 'Yeezy KNIT RNR' },
  { key: 'nsltd boot', value: 'Yeezy NSLTD BOOT' },
  { key: 'slides', value: 'Yeezy Slides' },
];

export const SEARCH_RELEASE_NO_OF_YEARS = 10;

export const filterByInventory = ['Brand', 'Date Range', 'Age'];
export const filterByCatalog = ['Brand', 'Date Range', 'Age'];
export const filterByOrder = ['Payout status', 'Date Range'];
export const filterByConsignmentDetails = ['Status', 'SKU', 'Product'];
export const filterBySkuDetails = ['Status', 'Size'];
export const filterByConsignment = ['Status', 'Date Range'];
export const filterByInventorySkuDetails = ['Status', 'Age'];
export const SIZE_MATRIX_MENWOMEN = 0;
export const SIZE_MATRIX_TODDLER = 1;
export const SIZE_MATRIX_PRESCHOOL = 2;
export const SIZE_MATRIX_GRADESCHOOL = 3;
