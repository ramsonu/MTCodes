
import memoize from 'lodash.memoize';
import { doRequest } from 'utils/request';

const cacheImage = async (imageUrl: any) => {
  try {
    const result: any = await doRequest(
      `${process.env.NEXT_PUBLIC_APP_CATALOGE_S3_API_DOMAIN}/document/downloadS3ImageUrl?path=${imageUrl}`,
      'get'
    );

    if (result?.data) return result?.data;
  } catch (e) {
    return imageUrl;
  }
};

export default memoize(cacheImage);
