/* eslint-disable @next/next/no-img-element */
import React, { useState, useEffect } from 'react';
import cachingImage from './caching-image';
import { doRequest } from 'utils/request';
import Dummy from 'assets/images/products/dummy.svg';

const ImageLoader = ({
  src,
  alt = '',
  fallbackImg = '',
  isCaching = true,
  className = '',
  imgWidth = 500,
  imgHeight = 100,
  onClickHandler = () => {},
  isPresignedURL = false,
}: any) => {
  const [imageData, setImageData] = useState<any>(src);

  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (isStockxUrl(src)) {
      const newSrc = `${src.split('?')[0]}?auto=compress&w=200&q=90&dpr=2`;

      setImageData(newSrc);
    } else if (isHttps(src)) setImageData(src);
    else if (!!src) loadImage();
  }, [src]); //eslint-disable-line

  const isStockxUrl = (value: any) =>
    /^(http|https):\/\/images.stockx.com/i.test(value);

  const isHttps = (value: any) => /^(http|https):\/\//i.test(value);

  const loadImage = async () => {
    //caching Image to reduce endpoints calls

    if (isCaching) {
      let img: any = await cachingImage(src);

      if (img?.data) {
        setImageData(img.data);
      } else {
        setImageData(fallbackImg?.src);
      }
    } else {
      try {
        const result: any = await doRequest(
          `${process.env.NEXT_PUBLIC_APP_CATALOGE_S3_API_DOMAIN}/document/downloadS3ImageUrl?path=${src}`,
          'get'
        );

        if (result?.data?.data) {
          setImageData(result.data.data);
        }
      } catch (e) {
        setImageData(fallbackImg?.src);
      }
    }
  };

  const handleImageLoad = () => {
    setIsLoading(false);
  };

  const handleImageError = (event: any) => {
    if (!isPresignedURL) {
      event.currentTarget.src = fallbackImg?.src;
    }
  };

  // to handle error on console caused by presigned url (brand/Nike.png -> https://etc)
  let imageToRender =
    isPresignedURL && !isStockxUrl(imageData) && !isHttps(imageData)
      ? Dummy?.src
      : imageData; // image src

  if (!imageData) {
    imageToRender = fallbackImg?.src; // Logo
  }

  return (
    <>
      {isLoading && (
        <img src={Dummy?.src} alt='fallback image' className={className} />
      )}
      <img
        src={imageToRender}
        alt={alt}
        onLoad={handleImageLoad}
        onError={handleImageError}
        width={imgWidth}
        height={imgHeight}
        className={className}
        onClick={onClickHandler}
        style={{ display: isLoading ? 'none' : 'block' }}
      />
    </>
  );
};

export default ImageLoader;
