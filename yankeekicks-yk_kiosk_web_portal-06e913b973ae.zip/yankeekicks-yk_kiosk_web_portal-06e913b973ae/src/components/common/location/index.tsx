import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import { useDispatch } from 'react-redux';
import { actions } from 'store/reducers/shared';
import { getAllLocations } from 'middleware/cubejs-wrapper/cubejs-query';
import {
  FormControl,
  FormControlLabel,
  Radio,
  RadioGroup,
} from '@mui/material';
import CircleLoader from '../loader/circular-loader';

const Locations = () => {
  const dispatch = useDispatch();

  const [selectedLocation, setSelectedLocation] = useState('');
  const [allLocations, setAllLocations] = useState([]);
  const [shouldFetchLocations, setShouldFetchLocations] = useState<any>(false);

  const router = useRouter();

  const locationsQuery: any = getAllLocations();

  useEffect(() => {
    setShouldFetchLocations(true);
  }, []);

  const {
    resultSet: locationsResultSet,
    isLoading: locationsLoading,
    error: locationsError,
  }: any = useCubeQuery(locationsQuery, { skip: !shouldFetchLocations });

  useEffect(() => {
    const data = locationsResultSet?.loadResponses[0]?.data;
    if (data) {
      setAllLocations(data);
    } else {
      setAllLocations([]);
    }
  }, [locationsResultSet]);

  // const handleButtonClick = (onRequest: any) => {
  const handleButtonClick = () => {
    const selectedItem: any = allLocations?.find(
      (store: any) => store?.['Locations.name'] === selectedLocation
    );
    localStorage?.setItem('storeId', selectedItem?.['Store.id']);
    localStorage?.setItem(
      'locationId',
      selectedItem?.['Locations.locationID_D']
    );
    localStorage?.setItem('storeLocation', selectedItem?.['Locations.name']);
    dispatch(actions.selected(selectedItem));
    setSelectedLocation(selectedItem?.['Locations.name']);
    router.push('/');
    let element: any = document.body;
    if (element?.requestFullScreen) {
      element?.requestFullscreen(); //Chrome
    } else if (element?.mozRequestFullScreen) {
      element?.mozRequestFullScreen(); // Firefox
    } else if (element?.webkitRequestFullScreen) {
      element?.webkitRequestFullScreen(); // Safari
    } else if (element?.msRequestFullscreen) {
      element?.msRequestFullscreen(); // IE/Edge
    }
  };
  const locationSelectionHandler = (event: any) => {
    setSelectedLocation(event?.target?.value);
  };

  return (
    <>
      <div className='app-wrapper w-100 kiosk-location-page-wrapper'>
        <div className='container-fluid yk-container-fluid'>
          <div className='row'>
            <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
              <div className='YKCH-kioskStoreLocation'>
                <div className='heading-wrapper yk-selectStoreTitle text-center'>
                  <h2 className='store-heading yk-badge-h12'>Select Store</h2>
                  <p>
                    Pick a store location to see what products are available
                  </p>
                </div>
                {locationsError ? (
                  <p>Something went wrong!</p>
                ) : locationsLoading ? (
                  <CircleLoader />
                ) : (
                  <div className='location-search-bar-wrapper yk-locationWrapperr'>
                    <FormControl>
                      <RadioGroup
                        sx={{
                          color: '#b1afb6',
                          '& .MuiSvgIcon-root': {
                            fontSize: 28,
                          },
                        }}
                        aria-labelledby='demo-radio-buttons-group-label'
                        defaultValue='female'
                        name='radio-buttons-group'
                        value={selectedLocation}
                        onChange={(event: any) =>
                          locationSelectionHandler(event)
                        }
                      >
                        {allLocations.length > 0 &&
                          allLocations?.map((locationName: any, index: any) => {
                            if (locationName?.['Locations.name']) {
                              return (
                                <FormControlLabel
                                  sx={{
                                    border: `${
                                      locationName?.['Locations.name'] ===
                                      selectedLocation
                                        ? '4px solid #C92626 !important'
                                        : '1px solid #F2F2F3'
                                    }`,
                                    boxShadow: `${
                                      locationName?.['Locations.name'] ===
                                      selectedLocation
                                        ? '0px 4px 24px rgba(0, 0, 0, 0.12) !important'
                                        : '0px 0px 6px rgba(0, 0, 0, 0.02), 0px 1px 4px rgba(0, 0, 0, 0.08)'
                                    }`,
                                  }}
                                  value={locationName?.['Locations.name']}
                                  control={<Radio />}
                                  label={locationName?.['Locations.name']}
                                  key={index}
                                  labelPlacement='start'
                                />
                              );
                            }
                          })}
                      </RadioGroup>
                    </FormControl>
                  </div>
                )}
              </div>
            </div>
            <footer>
              <div className='container-fluid yk-container-fluid'>
                <div className='btn-wrapper'>
                  <button
                    className='btn yk-btn-primary yk-locationSelectBtn'
                    onClick={() => handleButtonClick()}
                    disabled={!selectedLocation}
                  >
                    SELECT STORE
                  </button>
                </div>
              </div>
            </footer>
          </div>
        </div>
      </div>
    </>
  );
};

export default Locations;
