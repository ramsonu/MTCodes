import React from 'react';
import debounce from 'lodash.debounce';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import Autocomplete from '@mui/material/Autocomplete';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import searchIcon from 'assets/images/search-icon.png';
import Image from 'next/image';
import InputAdornment from '@mui/material/InputAdornment';
import { Paper } from '@mui/material';
import CircleLoader from '../loader/circular-loader';
import { actions } from 'store/reducers/kiosk';
/**
 * This component is using for search the real time api
 * @returns product with title
 */
const Search = (props: any) => {
  const {
    userInput = '',
    placeholder = '',
    options = [],
    optionType = 'default',
    isApiCall = false,
    setUserInput,
    onSelectHandler = () => {},
    onChangeHandler = () => {},
    showAutoComplete,
    setShowAutoComplete,
    suggestionsLoading = false,
    suggestionsHasError = false,
    onClearFIlterData = () => {},
    setShouldResultsFetch = () => {},
  } = props;
  const router = useRouter();
  const renderOptions = () => {
    let optionsToShow: any = [];
    switch (optionType) {
      case 'default':
        optionsToShow = options?.map((option: any) => {
          return option?.['KioskInventory.title'];
        });
        break;
      case 'change':
        optionsToShow = options?.map((option: any) => {
          return option['InventoryLineItem.name'];
        });
        break;
      case 'no suggestions':
        optionsToShow = [];
        break;
    }
    return optionsToShow;
  };

  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const dispatch = useDispatch();

  const showAllHandler = () => {
    enterKeyHandler();
    setShowAutoComplete(false);
  };

  const enterKeyHandler = () => {
    onClearFIlterData([]);
    setShowAutoComplete(false);
    if (router.pathname?.includes('/results')) {
      dispatch(
        actions.setFilterValueBasedOnKeyForCube({
          filterKey: 'title',
          filterValue: filterTypes?.title,
        })
      );
      dispatch(actions.clearFiltersExceptTitle({}));
      dispatch(actions.clearFiltersExceptTitleForCube({}));
    } else {
      dispatch(actions.setSelectedFilterTypes(filterTypes));
    }
    router.push({
      pathname: '/results',
      query: {
        searchTitle: userInput,
      },
    });
    setShouldResultsFetch(true);
  };

  const itemSelectHandler = (event: any) => {
    onSelectHandler(event, event?.target?.innerText, true, true);
  };

  const showMore = ({ children, ...other }: any) => (
    <Paper {...other} className='search-box-wrapper'>
      {suggestionsHasError ? (
        <p className='no-result-text'>Something went wrong!</p>
      ) : suggestionsLoading ? (
        <CircleLoader />
      ) : (
        <>
          {renderOptions()?.length === 0 ? (
            <p className='no-result-text'>No results found!</p>
          ) : (
            renderOptions()?.map((item: any, index: any) => {
              return (
                <p
                  className='search-options yk-textTransformCapitalize'
                  key={index}
                  onClick={itemSelectHandler}
                >
                  {item}
                </p>
              );
            })
          )}
        </>
      )}
      {options?.length > 0 && options?.length >= 5 && !suggestionsLoading && (
        <button
          type='button'
          className='btn-transparent show-all-btn yk-badge-20'
          onClick={showAllHandler}
        >
          Show All
        </button>
      )}
    </Paper>
  );

  const debounceResult = React.useRef(
    debounce((event: any) => {
      onChangeHandler(event);
    }, 500)
  ).current;

  return (
    <Stack spacing={2} sx={{ width: '100%' }}>
      <ClickAwayListener
        onClickAway={() => {
          setShowAutoComplete(false);
        }}
      >
        <div>
          <Autocomplete
            freeSolo
            open={showAutoComplete}
            id='searcth-autocomplete'
            disableClearable
            value={userInput}
            options={renderOptions()}
            onSelect={onSelectHandler}
            onChange={(event, value) => {
              // event is required parameter in order to pass value
              setUserInput(value);
              setShowAutoComplete(false);
            }}
            renderInput={(params) => (
              <TextField
                className='custom-search-field'
                {...params}
                onChange={(event) => debounceResult(event?.target?.value)}
                placeholder={placeholder}
                onKeyDown={(e: any) => {
                  if (e.keyCode === 13 && e.target.value && isApiCall) {
                    enterKeyHandler();
                  }
                }}
                InputProps={{
                  ...params.InputProps,
                  type: 'search',
                  startAdornment: (
                    <InputAdornment position='start'>
                      <Image src={searchIcon} alt='search-icon' />
                    </InputAdornment>
                  ),
                  inputProps: { ...params.inputProps, maxLength: 50 },
                }}
              />
            )}
            PaperComponent={showMore}
          />
        </div>
      </ClickAwayListener>
    </Stack>
  );
};

export default Search;
