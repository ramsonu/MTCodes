export const LOGOUT_TIME = {
    IN_MINS: 1000 * 60,
  };
  