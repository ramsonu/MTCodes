import { useRouter } from 'next/router';
import React, { useState, useEffect } from 'react';
import { useIdleTimer } from 'react-idle-timer';
import { useDispatch } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import { LOGOUT_TIME } from './constant';
const IdleTimerContainer = (props: any) => {
  const router = useRouter();
  const dispatch = useDispatch();
  const [requiredTime, setRequiredTime] = useState(0);
  const currentPath = router.pathname;

  useEffect(() => {
    switch (currentPath) {
      case '/features':
        setRequiredTime(LOGOUT_TIME.IN_MINS * 1);
        break;
      case '/cart':
        setRequiredTime(LOGOUT_TIME.IN_MINS * 3);
        break;
    }
    return () => {
      setRequiredTime(0);
    };
  }, [currentPath]);

  const onIdle = () => {
    if (requiredTime !== 0) {
      if (currentPath.includes('/cart')) {
        dispatch(actions.clearCart([]));
        dispatch(actions.clearAllFilters({}));
        dispatch(actions.clearAllSelectedFilters({}));
        router.push('/');
      }
      if (currentPath.includes('/features')) {
        dispatch(actions.clearAllFilters({}));
        dispatch(actions.clearAllSelectedFilters({}));
        router.push('/');
      }
    }
  };

  const idleTimer = useIdleTimer({ onIdle, timeout: requiredTime });
  return <>{props.children}</>;
};
export default IdleTimerContainer;
