import React, { useState } from 'react';
import Image from 'next/image';
import ykLogo from 'assets/images/yankeekicks-black-logo.png';
import pendingImg from 'assets/images/pending.png';
import checkedInImg from 'assets/images/checked-in.png';
import CheckedOutImg from 'assets/images/checked-out.png';
import soldOutImg from 'assets/images/sold-out.png';
import addIcon from 'assets/images/add-icon.png';
import closeIcon from 'assets/images/close-circle.svg';
import thumbnailIcon1 from 'assets/images/thumbnail/thumbnail-1.png';
import thumbnailIcon2 from 'assets/images/thumbnail/thumbnail-2.png';
import thumbnailIcon3 from 'assets/images/thumbnail/thumbnail-3.png';
import passwdIcon from 'assets/images/password-icon.svg';
import viewPasswdIcon from 'assets/images/view-icon.svg';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';

/**
 * This component is using for search the real time api
 * @returns product with title
 */
const YkTheme = () => {
  const [value, setValue] = React.useState('1');

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };
  return (
    <>
      <div className='login-wrapper'>
        <div className='login-bg'>
          <div className='container h-100'>
            <div className='row h-100 align-items-center'>
              <div className='col-lg-6'>
                <div className='welcome-wrapper'>
                  <Image src={ykLogo} alt='Yankeekicks' className='img-fluid' />
                  <h1 className='login-title'>
                    Hello ! <br />
                    Welcome back...
                  </h1>
                  <p className='description'>
                    Login with you credentials that are provided by Yankeekicks
                  </p>
                </div>
              </div>
              <div className='col-lg-6'>
                <div className='card login-card'>
                  <div className='card-body'>
                    <div className='form-wrapper'>
                      <h2 className='form-title'>Sign In</h2>
                      <p className='description'>
                        Please fill in the following details to sign into your
                        account
                      </p>

                      <form method='POST' action="{{ route('login') }}">
                        <div className='form-group'>
                          <label className='form-label'>use name</label>
                          <input
                            type='email'
                            className='form-control'
                            id='login-id'
                            name='email'
                            placeholder='name@example.com'
                          />
                        </div>
                        <div className='form-group'>
                          <label className='form-label'>Password</label>
                          <div className='input-group input-append input-prepend'>
                            <span className='input-group-text'>
                              <Image
                                src={passwdIcon}
                                alt=''
                                className='img-fluid'
                              />
                            </span>
                            <input
                              type='password'
                              className='form-control'
                              placeholder='Password'
                              aria-label='Username'
                              aria-describedby='passwd'
                              id='passwd'
                              name='password'
                            />
                            <span className='input-group-text'>
                              <Image
                                src={viewPasswdIcon}
                                alt=''
                                className='img-fluid'
                              />
                            </span>
                          </div>
                        </div>
                        <div className='form-group forgot-link-wrapper'>
                          <a href='#' className='forgot-passwd-link'>
                            Forgot Password&nbsp;&#63;
                          </a>
                        </div>
                        {/* <div className='form-group'>
                          <input
                            className='form-check-input'
                            type='checkbox'
                            value=''
                            id='defaultCheck1'
                          />
                          <label className='form-check-label'>
                            Remember Me
                          </label>
                          <label className='register-label'>
                            <a href='#'>Register</a>
                          </label>
                        </div> */}
                        <div className='form-group'>
                          <button type='submit' className='btn btn-login'>
                            Login
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className='container'>
        <div className='row'>
          <div className='col-lg-12'>
            <div className='status-wrapper'>
              <div className='row'>
                <div className='col-sm-12 col-md-3 col-lg-3'>
                  <div className='card status-card pending'>
                    <div className='card-body'>
                      <div className='card-heading-wrapper'>
                        <h5 className='card-title'>10</h5>
                        <div className='icon-wrapper'>
                          <Image
                            src={pendingImg}
                            alt=''
                            className='img-fluid'
                          />
                        </div>
                      </div>
                      <p className='card-text'>Pending</p>
                    </div>
                  </div>
                </div>
                <div className='col-sm-12 col-md-3 col-lg-3'>
                  <div className='card status-card pending'>
                    <div className='card-body'>
                      <div className='card-heading-wrapper'>
                        <h5 className='card-title'>10</h5>
                        <div className='icon-wrapper'>
                          <Image
                            src={CheckedOutImg}
                            alt=''
                            className='img-fluid'
                          />
                        </div>
                      </div>
                      <p className='card-text'>Checked Out</p>
                    </div>
                  </div>
                </div>
                <div className='col-sm-12 col-md-3 col-lg-3'>
                  <div className='card status-card checked-in'>
                    <div className='card-body'>
                      <div className='card-heading-wrapper'>
                        <h5 className='card-title'>10</h5>
                        <div className='icon-wrapper'>
                          <Image
                            src={checkedInImg}
                            alt=''
                            className='img-fluid'
                          />
                        </div>
                      </div>
                      <p className='card-text'>Checked In</p>
                    </div>
                  </div>
                </div>
                <div className='col-sm-12 col-md-3 col-lg-3'>
                  <div className='card status-card sold-out'>
                    <div className='card-body'>
                      <div className='card-heading-wrapper'>
                        <h5 className='card-title'>10</h5>
                        <div className='icon-wrapper'>
                          <Image
                            src={soldOutImg}
                            alt=''
                            className='img-fluid'
                          />
                        </div>
                      </div>
                      <p className='card-text'>Sold</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className='status-tabs-wrapper'>
              <Box sx={{ width: '100%', typography: 'body1' }}>
                <TabContext value={value}>
                  <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                    <TabList
                      onChange={handleChange}
                      aria-label='lab API tabs example'
                    >
                      <Tab label='Request' value='1' />
                      <Tab label='Pending' value='2' />
                      <Tab label='Checked-Out' value='3' />
                    </TabList>
                  </Box>
                  <TabPanel value='1'>
                    <div className='tab-content-inner-wrapper'>
                      <div className='add-shoes-wrapper'>
                        <div className='empty-list'>
                          <Image src={addIcon} alt='' className='img-fluid' />
                          <p>Add shoes to request from warehouse</p>
                        </div>
                      </div>
                      <div className='button-action-wrapper'>
                        <button className='btn btn-place-request'>
                          place request
                        </button>
                      </div>
                    </div>
                  </TabPanel>
                  <TabPanel value='2'>
                    <div className='tab-content-inner-wrapper'>
                      <div className='add-shoes-wrapper pending-tab-wrapper'>
                        <ul className='pending-list list-all'>
                          <li>
                            <div className='img-thumbnail-icon'>
                              <Image
                                src={thumbnailIcon1}
                                alt=''
                                className='img-fluid'
                              />
                            </div>
                            <div className='product-details'>
                              <p className='product-name'>Air Jordan 1 Retro</p>
                              <p className='price'>
                                <span>&#36;419.00</span> <span>9.5/11w</span>{' '}
                              </p>
                            </div>
                            <div className='close-btn-wrapper'>
                              <button className='btn prod-close'>
                                <Image
                                  src={closeIcon}
                                  alt=''
                                  className='img-fluid'
                                />
                              </button>
                            </div>
                          </li>
                          <li>
                            <div className='img-thumbnail-icon'>
                              <Image
                                src={thumbnailIcon2}
                                alt=''
                                className='img-fluid'
                              />
                            </div>
                            <div className='product-details'>
                              <p className='product-name'>Nike Air Presto</p>
                              <p className='price'>
                                <span>&#36;325.00</span> <span>0.5/2w</span>{' '}
                              </p>
                            </div>
                            <div className='close-btn-wrapper'>
                              <button className='btn prod-close'>
                                <Image
                                  src={closeIcon}
                                  alt=''
                                  className='img-fluid'
                                />
                              </button>
                            </div>
                          </li>
                          <li>
                            <div className='img-thumbnail-icon'>
                              <Image
                                src={thumbnailIcon3}
                                alt=''
                                className='img-fluid'
                              />
                            </div>
                            <div className='product-details'>
                              <p className='product-name'>Addidas Yeezy...</p>
                              <p className='price'>
                                <span>&#36;325.00</span> <span>0.5/2w</span>{' '}
                              </p>
                            </div>
                            <div className='close-btn-wrapper'>
                              <button className='btn prod-close'>
                                <Image
                                  src={closeIcon}
                                  alt=''
                                  className='img-fluid'
                                />
                              </button>
                            </div>
                          </li>
                        </ul>
                      </div>
                      <div className='button-action-wrapper'>
                        <button className='btn btn-place-request'>
                          place request
                        </button>
                      </div>
                    </div>
                  </TabPanel>
                  <TabPanel value='3'>
                    <div className='tab-content-inner-wrapper'>
                      <div className='add-shoes-wrapper'></div>
                      <div className='button-action-wrapper'>
                        <button className='btn btn-place-request'>
                          place request
                        </button>
                      </div>
                    </div>
                  </TabPanel>
                </TabContext>
              </Box>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default YkTheme;
