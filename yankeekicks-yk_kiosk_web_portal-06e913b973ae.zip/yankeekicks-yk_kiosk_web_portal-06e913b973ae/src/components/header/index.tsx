export { default as KioskHeader } from './kiosk';
