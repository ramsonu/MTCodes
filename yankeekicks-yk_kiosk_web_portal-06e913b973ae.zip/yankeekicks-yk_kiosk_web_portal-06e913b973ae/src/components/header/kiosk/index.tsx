import React from 'react';
import Image from 'next/image';
import type { NextPage } from 'next';
import { useRouter } from 'next/router';
import { useSelector, useDispatch } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import { Badge } from '@mui/material';
import YKStdLogo from 'assets/images/yk-std-logo.svg';
import cartIcon from 'assets/images/cart-icon.svg';
import leftArrowIcon from 'assets/images/left-arrow-icon.png';

const Header: NextPage = () => {
  const { cart, filterTypes, goBackTrigger } = useSelector(
    (state: any) => state.kiosk
  );
  const router = useRouter();
  const dispatch = useDispatch();
  const isLandingPage = ['/'].includes(router.pathname);
  const isLocationPage = ['/location'].includes(router.pathname);
  const isKioskFeaturePage = ['/features'].includes(router.pathname);
  if (isLandingPage) {
    return null;
  }
  if (isLocationPage) {
    return (
      <div className='app-wrapper'>
        <header>
          <div className='yk-logo-wrapper'>
            <Image src={YKStdLogo} alt='' className='img-fluid' />
          </div>
        </header>
      </div>
    );
  }
  const goBackHandler = () => {
    if (router.pathname === '/cart' || router.pathname?.includes('/results')) {
      router.push('/features');
    } else {
      router.back();
    }
    if (filterTypes?.title !== '') {
      dispatch(
        actions.setFilters({
          filterItem: '',
          filterType: 'title',
        })
      );
      dispatch(
        actions.setSelectedFilters({
          filterItem: '',
          filterType: 'title',
        })
      );
    }
    if (router.pathname?.includes('/results')) {
      dispatch(actions.clearAllFilters({}));
      dispatch(actions.setGoBackTrigger(!goBackTrigger));
      dispatch(actions.setFilterTrigger(false));
    }
  };

  return (
    <>
      <div className='d-none d-sm-block d-lg-block'>
        <div className='container-fluid yk-container-fluid'>
          <div className='row'>
            <div className='col-lg-12 col-md-12'>
              <div className='kiosk-top-header-wrapper'>
                {!isKioskFeaturePage && (
                  <div className='back-btn-wrapper'>
                    <button
                      className='btn btn-transparent arrow-icon-wrapper'
                      onClick={goBackHandler}
                    >
                      <Image
                        src={leftArrowIcon}
                        alt='left-arrow-icon'
                        className='Image-fluid'
                      />
                    </button>
                  </div>
                )}
                <div className='top-logo-wrapper'>
                  <a className='navbar-brand'>
                    <Image
                      src={YKStdLogo}
                      priority={true}
                      alt='yk-kiosk-logo'
                      className='Image-fluid'
                    />
                  </a>
                </div>
                <div className='cart-icon-wrapper'>
                  <div
                    className='shopping-cart-wrapper d-flex'
                    onClick={() => router.push('/cart')}
                  >
                    <a className='navbar-brand'>
                      <Badge
                        badgeContent={cart?.length}
                        className='cart-count-badge'
                        overlap='circular'
                      >
                        <Image
                          src={cartIcon}
                          alt='yk-shopping-cart-logo'
                          className='Image-fluid yk-shopping-cart-logo'
                        />
                      </Badge>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className='d-block d-sm-none d-lg-none'>
        <div className='kiosk-top-header-wrapper'>
          {!isKioskFeaturePage && (
            <div className='back-btn-wrapper'>
              <button
                className='btn btn-transparent arrow-icon-wrapper'
                onClick={goBackHandler}
              >
                <Image
                  src={leftArrowIcon}
                  alt='left-arrow-icon'
                  className='Image-fluid'
                />
              </button>
            </div>
          )}
          <div className='top-logo-wrapper'>
            <a className='navbar-brand'>
              <Image
                src={YKStdLogo}
                alt='yk-kiosk-logo'
                className='Image-fluid'
              />
            </a>
          </div>
          <div className='cart-icon-wrapper'>
            <div
              className='shopping-cart-wrapper d-flex'
              onClick={() => router.push('/cart')}
            >
              <a className='navbar-brand'>
                <Badge
                  badgeContent={cart?.length}
                  className='cart-count-badge'
                  overlap='circular'
                >
                  <Image
                    src={cartIcon}
                    alt='yk-shopping-cart-logo'
                    className='Image-fluid yk-shopping-cart-logo'
                  />
                </Badge>
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Header;
