import React, { useState } from 'react';
import type { NextPage } from 'next';
import { useSelector } from 'react-redux';
import CustomerCartModal from 'components/kiosk/cart/CustomerCartModal';

const Footer: NextPage = () => {
  const { cart } = useSelector((state: any) => state.kiosk);
  const [isVisible, setIsVisible] = useState(false);
  return (
    <>
      <footer>
        <div className='btn-wrapper'>
          {cart?.length > 0 && (
            <button
              className='btn yk-primaryButton yk-cartBtn'
              onClick={() => setIsVisible(true)}
            >
              REQUEST TO TRY
            </button>
          )}
        </div>
      </footer>
      <CustomerCartModal
        isVisible={isVisible}
        setIsVisible={setIsVisible}
      ></CustomerCartModal>
    </>
  );
};
export default Footer;
