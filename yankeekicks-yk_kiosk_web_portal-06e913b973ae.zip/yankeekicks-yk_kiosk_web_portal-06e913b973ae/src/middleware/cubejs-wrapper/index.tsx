import cubejs from '@cubejs-client/core';
import { CubeProvider } from '@cubejs-client/react';
import React from 'react';
import { Cube_API_URL } from 'services/apiUrl';

const CubeWrapper = (props: any) => {
  const authToken = process.env.NEXT_PUBLIC_APP_CUBE_JWT_TOKEN;
  const cubejsAPI = cubejs({
    apiUrl: Cube_API_URL,
    headers: {
      Authorization: authToken || '',
      'Content-Type': 'application/json',
      // 'skip-auth-for-kiosk': true as any,
    },
  });
  return <CubeProvider cubejsApi={cubejsAPI}>{props.children}</CubeProvider>;
};

export default CubeWrapper;
