export const getBrandsList = () => {
  return {
    dimensions: ['Brand.brandName', 'Brand.brandImageUrl'],
    order: { 'Brand.brandName': 'asc' },
  };
};

export const getAllLocations = () => {
  return {
    dimensions: [
      'Locations.name',
      'Locations.locationID_D',
      'Store.location',
      'Store.id',
    ],
    order: { 'Locations.name': 'asc' },
  };
};

export const getKioskInventory = (
  filterTypes: any,
  locationId: any,
  limitToFetch: any,
  currentOffset: any
) => {
  let filterPayload = [];

  const specialChars = ['@', '$', '&', '_', '(', ')'];
  let modifiedUserInput = filterTypes?.title;

  specialChars?.map((item: any) => {
    if (modifiedUserInput?.includes(item)) {
      modifiedUserInput = modifiedUserInput?.replaceAll(item, `\\${item}`);
    }
  });

  let splitUserInput = modifiedUserInput?.trim();
  splitUserInput = splitUserInput?.split(' ');

  let payloadForTitle = splitUserInput?.map((EachWord: any) => {
    return {
      or: [
        {
          member: 'KioskInventory.title',
          operator: 'contains',
          values: [EachWord],
        },
        {
          member: 'KioskInventory.brand',
          operator: 'contains',
          values: [EachWord],
        },
        {
          member: 'KioskInventory.sku',
          operator: 'contains',
          values: [EachWord],
        },
        {
          member: 'KioskInventory.colorway',
          operator: 'contains',
          values: [EachWord],
        },
        {
          member: 'KioskInventory.tags',
          operator: 'contains',
          values: [EachWord],
        },
      ],
    };
  });

  filterPayload.push({ and: payloadForTitle });
  filterPayload.push({
    member: 'KioskInventory.locationId',
    operator: 'contains',
    values: [locationId],
  });
  filterPayload.push({
    member: 'KioskInventory.availableQuantity',
    operator: 'gt',
    values: ['0'],
  });
  if (filterTypes?.type?.length > 0) {
    const types = [
      { userType: 'men / women', member: 'KioskInventory.men' },
      { userType: 'men / women', member: 'KioskInventory.women' },
      { userType: 'grade school', member: 'KioskInventory.child' },
      { userType: 'toddler', member: 'KioskInventory.infant' },
      { userType: 'pre school', member: 'KioskInventory.preschool' },
      { userType: 'toddler', member: 'KioskInventory.toddler' },
    ];
    let userTypesArray: any = [];
    types?.map((item: any) => {
      if (filterTypes?.type?.includes(item?.userType)) {
        return userTypesArray?.push({
          member: item?.member,
          operator: 'equals',
          values: ['true'],
        });
      }
    });
    const userTypeObj = { or: userTypesArray };
    filterPayload.push(userTypeObj);
  }
  if (filterTypes?.brand?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.brand',
      operator: 'contains',
      values: filterTypes?.brand,
    });
  }
  if (filterTypes?.size?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.option1',
      operator: 'equals',
      values: filterTypes?.size,
    });
  }
  if (filterTypes?.color?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.colorway',
      operator: 'contains',
      values: filterTypes?.color,
    });
  }
  if (filterTypes?.date?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.releaseYear',
      operator: 'contains',
      values: filterTypes?.date,
    });
  }
  if (filterTypes?.model?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.Model',
      operator: 'contains',  //keeping contains for model to fetch the records of yeezy
      values: filterTypes?.model,
    });
  }
  if (
    filterTypes?.price?.length > 0 &&
    filterTypes?.price[0] >= 0 &&
    filterTypes?.price[1] > 0
  ) {
    filterPayload?.push({
      and: [
        {
          member: 'KioskInventory.shopifyPrice',
          operator: 'gte',
          values: [`${filterTypes?.price[0]}`],
        },
        {
          member: 'KioskInventory.shopifyPrice',
          operator: 'lte',
          values: [`${filterTypes?.price[1]}`],
        },
      ],
    });
  }

  return {
    measures: ['KioskInventory.minPrice'], // to show on card
    dimensions: [
      'KioskInventory.productId',
      'KioskInventory.productType',
      'KioskInventory.tags',
      'KioskInventory.title',
      'KioskInventory.vendor',
      'KioskInventory.imageUrl',
      'KioskInventory.locationId',
      'KioskInventory.releaseYear',
      'KioskInventory.variantCount',
      'KioskInventory.colorway',
      'KioskInventory.brand',
      'KioskInventory.sku',
      // 'KioskInventory.avgPrice',
      'KioskInventory.releaseDate', // to check in inspect mode
    ],
    order: [
      // ['KioskInventory.releaseYear', 'desc'],
      // ['KioskInventory.avgPrice', 'asc'],
      ['KioskInventory.releaseDate', 'desc'],
    ],
    filters: filterPayload,
    limit: limitToFetch,
    offset: currentOffset,
  };
};

export const getKioskInventoryTotalCount = (
  filterTypes: any,
  locationId: any,
  currentOffset: any
) => {
  let filterPayload = [];

  const specialChars = ['@', '$', '&', '_', '(', ')'];
  let modifiedUserInput = filterTypes?.title;

  specialChars?.map((item: any) => {
    if (modifiedUserInput?.includes(item)) {
      modifiedUserInput = modifiedUserInput?.replaceAll(item, `\\${item}`);
    }
  });

  let splitUserInput = modifiedUserInput?.trim();
  splitUserInput = splitUserInput?.split(' ');

  let payloadForTitle = splitUserInput?.map((EachWord: any) => {
    return {
      or: [
        {
          member: 'KioskInventory.title',
          operator: 'contains',
          values: [EachWord],
        },
        {
          member: 'KioskInventory.brand',
          operator: 'contains',
          values: [EachWord],
        },
        {
          member: 'KioskInventory.sku',
          operator: 'contains',
          values: [EachWord],
        },
        {
          member: 'KioskInventory.colorway',
          operator: 'contains',
          values: [EachWord],
        },
        {
          member: 'KioskInventory.tags',
          operator: 'contains',
          values: [EachWord],
        },
      ],
    };
  });

  filterPayload.push({ and: payloadForTitle });

  filterPayload.push({
    member: 'KioskInventory.locationId',
    operator: 'contains',
    values: [locationId],
  });
  filterPayload.push({
    member: 'KioskInventory.availableQuantity',
    operator: 'gt',
    values: ['0'],
  });
  if (filterTypes?.type?.length > 0) {
    const types = [
      { userType: 'men / women', member: 'KioskInventory.men' },
      { userType: 'men / women', member: 'KioskInventory.women' },
      { userType: 'grade school', member: 'KioskInventory.child' },
      { userType: 'toddler', member: 'KioskInventory.infant' },
      { userType: 'pre school', member: 'KioskInventory.preschool' },
      { userType: 'toddler', member: 'KioskInventory.toddler' },
    ];
    let userTypesArray: any = [];
    types?.map((item: any) => {
      if (filterTypes?.type?.includes(item?.userType)) {
        return userTypesArray?.push({
          member: item?.member,
          operator: 'equals',
          values: ['true'],
        });
      }
    });
    const userTypeObj = { or: userTypesArray };
    filterPayload.push(userTypeObj);
  }
  if (filterTypes?.brand?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.brand',
      operator: 'contains',
      values: filterTypes?.brand,
    });
  }
  if (filterTypes?.size?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.option1',
      operator: 'equals',
      values: filterTypes?.size,
    });
  }
  if (filterTypes?.color?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.colorway',
      operator: 'contains',
      values: filterTypes?.color,
    });
  }
  if (filterTypes?.date?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.releaseYear',
      operator: 'contains',
      values: filterTypes?.date,
    });
  }
  if (filterTypes?.model?.length > 0) {
    filterPayload?.push({
      member: 'KioskInventory.Model',
      operator: 'contains', //keeping contains for model to fetch the records of yeezy
      values: filterTypes?.model,
    });
  }
  if (
    filterTypes?.price?.length > 0 &&
    filterTypes?.price[0] >= 0 &&
    filterTypes?.price[1] > 0
  ) {
    filterPayload?.push({
      and: [
        {
          member: 'KioskInventory.shopifyPrice',
          operator: 'gte',
          values: [`${filterTypes?.price[0]}`],
        },
        {
          member: 'KioskInventory.shopifyPrice',
          operator: 'lte',
          values: [`${filterTypes?.price[1]}`],
        },
      ],
    });
  }
  return {
    measures: ['KioskInventory.rowCount'],
    filters: filterPayload,
  };
};

export const getMinMaxPriceFromInventory = (locationId: any) => {
  let filterPayload = [];

  filterPayload.push(
    {
      member: 'KioskInventory.locationId',
      operator: 'contains',
      values: [locationId],
    },
    {
      member: 'KioskInventory.availableQuantity',
      operator: 'gt',
      values: ['0'],
    }
  );

  return {
    measures: ['KioskInventory.minPrice', 'KioskInventory.maxPrice'],
    filters: filterPayload,
  };
};

export const getSuggestionsFromCube = (userInput: any, locationId: any) => {
  const specialChars = ['@', '$', '&', '_', '(', ')'];
  let modifiedUserInput = userInput;

  specialChars?.map((item: any) => {
    if (modifiedUserInput?.includes(item)) {
      modifiedUserInput = modifiedUserInput?.replaceAll(item, `\\${item}`);
    }
  });

  let userInputArray = modifiedUserInput?.trim();
  userInputArray = userInputArray?.split(' ');
  let wordsArray: any = [];

  userInputArray?.map((word: any) => {
    wordsArray?.push({
      or: [
        {
          member: 'KioskInventory.title',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.sku',
          operator: 'contains',
          values: [word],
        },
        {
          member: 'KioskInventory.colorway',
          operator: 'contains',
          values: [word],
        },
      ],
    });
  });

  return {
    dimensions: ['KioskInventory.title'],
    order: { 'KioskInventory.title': 'asc' },
    filters: [
      {
        and: wordsArray,
      },
      {
        member: 'KioskInventory.locationId',
        operator: 'contains',
        values: [locationId],
      },
      {
        member: 'KioskInventory.availableQuantity',
        operator: 'gt',
        values: ['0'],
      },
    ],
    limit: 5,
    offset: 0,
  };
};

export const getFeatureCards = (locationId: any) => {
  return {
    dimensions: [
      'KioskInventory.productId',
      'KioskInventory.title',
      'KioskInventory.imageUrl',
      'KioskInventory.locationId',
      'KioskInventory.variantCount',
    ],
    filters: [
      {
        member: 'KioskInventory.tags',
        operator: 'contains',
        values: ['featured'],
      },
      {
        member: 'KioskInventory.locationId',
        operator: 'contains',
        values: [locationId],
      },
      {
        member: 'KioskInventory.availableQuantity',
        operator: 'gt',
        values: ['0'],
      },
    ],
    limit: 10,
    offset: 0,
  };
};

export const getProductAndVariantDetailsById = (
  productId: any,
  locationId: any
) => {
  const numericProductId = productId.split('/').pop('');

  return {
    dimensions: [
      'InventoryLineItem.productId',
      'InventoryLineItem.variantId',
      'InventoryLineItem.Title',
      'InventoryLineItem.Price',
      'InventoryLineItem.sku',
      'InventoryLineItem.Option1',
      'InventoryLineItem.Option2',
      'InventoryLineItem.Option3',
      'InventoryLineItem.createdAt',
      'InventoryLineItem.updatedAt',
      'InventoryLineItem.inventoryitemId',
      'InventoryLineItem.inventoryQuantity',
      'InventoryLineItem.imageUrl',
      'ProdutsShopifyOptions.values',
      'ProdutsShopify.title',
      'Catalogue.style',
      'Catalogue.colorway',
      'Catalogue.itemName',
      'Catalogue.shortDescription',
    ],
    order: {
      'InventoryLineItem.productId': 'asc',
    },
    filters: [
      {
        member: 'InventoryLineItem.productId',
        operator: 'equals',
        values: [numericProductId],
      },
      {
        member: 'InventoryLineItem.locationId',
        operator: 'equals',
        values: [locationId],
      },
      {
        member: 'InventoryLineItem.inventoryQuantity',
        operator: 'gt',
        values: ['0'],
      },
    ],
  };
};
