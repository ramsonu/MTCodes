import { combineReducers } from 'redux';
import kiosk from './kiosk';
import shared from './shared';
const allReducers = combineReducers({
  kiosk,
  shared,
});

const rootReducer = (state: any, action: any) => {
  return allReducers(state, action);
};

export default rootReducer;
