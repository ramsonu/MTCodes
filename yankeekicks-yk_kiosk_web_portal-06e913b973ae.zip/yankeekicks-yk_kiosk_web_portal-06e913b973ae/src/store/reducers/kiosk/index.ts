import { createSlice } from '@reduxjs/toolkit';
import { HYDRATE } from 'next-redux-wrapper';

const initialState = {
  products: [] as any,
  featuredProducts: [],
  brandProducts: [],
  product: {},
  filterTypes: {
    type: [],
    color: [],
    size: [],
    brand: [],
    date: [],
    availability: [],
    model: [],
    price: [0, 0],
    title: '',
  } as any,
  selectedFilterTypes: {
    type: [],
    color: [],
    size: [],
    brand: [],
    date: [],
    availability: [],
    model: [],
    price: [0, 0],
    title: '',
  } as any,
  loading: false,
  error: {},
  searchText: '',
  isFilteredDataloading: false,
  isBrandloading: false,
  cart: [] as Array<any>,
  requestToTryData: [] as Array<any>,
  cursorData: null as any,
  goBackTrigger: false,
  isProductsLoading: false,
  triggerFilter: false,
};

const slice = createSlice({
  name: 'kiosk',
  initialState,
  reducers: {
    init(state, action) {
      state.loading = true;
    },
    set(state, action) {
      state.featuredProducts = action.payload;
      state.loading = false;
    },
    setProductsLoading(state, action) {
      state.isProductsLoading = true;
    },
    setProducts(state, action) {
      state.products = action.payload;
      state.loading = false;
      state.isProductsLoading = false;
    },
    setBrandProducts(state, action) {
      state.brandProducts = action.payload;
      state.isBrandloading = false;
    },
    error(state, action) {
      state.loading = false;
    },
    setSearch(state, action) {
      return {
        ...state,
        filterTypes: {
          ...state.filterTypes,
          type: action.payload,
        },
      };
    },
    initFilteredData(state, action) {
      state.isFilteredDataloading = true;
    },
    setFilteredData(state, action) {
      state.isFilteredDataloading = false;
    },
    setFilters(state, action) {
      let { filterItem, filterType } = action.payload;
      const isTitle = filterType === 'title';
      let item =
        !isTitle &&
        (state.filterTypes[filterType]?.includes(filterItem)
          ? state.filterTypes[filterType].filter(
              (item: any) => item !== filterItem
            )
          : [...state.filterTypes[action.payload.filterType], filterItem]);
      state.filterTypes = {
        ...state.filterTypes,
        [filterType]: !isTitle ? item : filterItem,
      };
    },
    setFilterValueBasedOnKey(state, action) {
      state.filterTypes = {
        ...state.filterTypes,
        [action.payload.filterKey]: action.payload.filterValue,
      };
    },
    setFilterValueBasedOnKeyForCube(state, action) {
      state.selectedFilterTypes = {
        ...state.selectedFilterTypes,
        [action.payload.filterKey]: action.payload.filterValue,
      };
    },
    clearFiltersByKey(state, action) {
      state.filterTypes = {
        ...state.filterTypes,
        [action.payload.filterType]: Array.isArray(action.payload.filterItem)
          ? []
          : '',
      };
    },
    clearFiltersExceptTitle(state, action) {
      state.filterTypes = {
        ...state.filterTypes,
        type: [],
        color: [],
        size: [],
        brand: [],
        date: [],
        availability: [],
        model: [],
        price: [0, 0],
      };
    },
    clearFiltersExceptTitleForCube(state, action) {
      state.selectedFilterTypes = {
        ...state.selectedFilterTypes,
        type: [],
        color: [],
        size: [],
        brand: [],
        date: [],
        availability: [],
        model: [],
        price: [0, 0],
      };
    },
    clearAllFilters(state, action) {
      state.filterTypes = {
        ...initialState.filterTypes,
      };
    },
    addToCart(state, action) {
      const itemInCart = state.cart.find(
        (item: any) => item.variantId === action.payload.variantId
      );
      if (itemInCart) {
        itemInCart.quantity++;
      } else {
        state.cart.push({ ...action.payload, quantity: 1 });
      }
    },
    incrementQuantity(state, action) {
      const item: any = state.cart.find(
        (item: any) => item.id === action.payload
      );
      item.quantity++;
    },
    decrementQuantity(state, action) {
      const item: any = state.cart.find(
        (item: any) => item.id === action.payload
      );
      if (item.quantity === 1) {
        item.quantity = 1;
      } else {
        item.quantity--;
      }
    },
    removeItem(state, action) {
      const removeItem = state.cart.filter(
        (item: any) => item.variantId !== action.payload
      );
      state.cart = removeItem;
    },
    clearCart(state, action) {
      state.cart = [];
    },
    setRequestToTryData(state, action) {
      state.requestToTryData = action.payload;
      state.loading = false;
    },
    setCursorData(state, action) {
      state.cursorData = action.payload;
    },
    setGoBackTrigger(state, action) {
      state.goBackTrigger = action.payload;
    },
    setFilterTrigger(state, action) {
      state.triggerFilter = action.payload;
    },
    setSelectedFilterTypes(state, action) {
      state.selectedFilterTypes = action.payload;
    },
    setSelectedFilters(state, action) {
      let { filterItem, filterType } = action.payload;
      const isTitle = filterType === 'title';
      let item =
        !isTitle &&
        (state.selectedFilterTypes[filterType]?.includes(filterItem)
          ? state.selectedFilterTypes[filterType].filter(
              (item: any) => item !== filterItem
            )
          : [
              ...state.selectedFilterTypes[action.payload.filterType],
              filterItem,
            ]);
      state.selectedFilterTypes = {
        ...state.selectedFilterTypes,
        [filterType]: !isTitle ? item : filterItem,
      };
    },
    clearAllSelectedFilters(state, action) {
      state.selectedFilterTypes = {
        ...initialState.selectedFilterTypes,
      };
    },
    setSelectedFiltersSearch(state, action) {
      return {
        ...state,
        filterTypes: {
          ...state.selectedFilterTypes,
          type: action.payload,
        },
      };
    },
    clearSelectedFiltersByKey(state, action) {
      state.selectedFilterTypes = {
        ...state.selectedFilterTypes,
        [action.payload.filterType]: Array.isArray(action.payload.filterItem)
          ? []
          : '',
      };
    },
  },
  extraReducers: {
    [HYDRATE]: (state, action) => {
      return {
        ...state,
        searchText: action.payload,
      };
    },
  },
});

export default slice.reducer;
export const { reducer, actions } = slice;
export { initialState };
