import createSagaMiddleware from 'redux-saga';

import { configureStore, getDefaultMiddleware } from '@reduxjs/toolkit';
import { createWrapper } from 'next-redux-wrapper';

import rootSaga from '../sagas';
import reducer from './reducers';
const sagaMiddleware = createSagaMiddleware();
const middleware = [...getDefaultMiddleware({ thunk: false }), sagaMiddleware];

export const makeStore = () => {
  const store = configureStore({
    reducer,
    middleware,
    //preloadedState,
  });
  sagaMiddleware.run(rootSaga);

  return store;
};

export const wrapper = createWrapper(makeStore);
