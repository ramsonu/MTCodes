import Image from 'next/image';
import { subDays, format } from 'date-fns';
import { NO_RESULT_FOUND } from './constants';
import noRecordImg from 'assets/images/no-table-record-img.png';

export const getPreviousFullYear = (noOfYears) => {
  const date = new Date();
  let years = [];
  for (let i = 0; i < noOfYears; i++) {
    const year = date.getFullYear() - i;
    const yrkey = { key: year, value: year };
    years = [...years, yrkey];
  }
  return years;
};

export const getTime = (date) => {
  let currentTime = new Date(date);
  return currentTime.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });
};

export const getDate = (date) => {
  let currentDate = new Date(date);
  return currentDate.toLocaleDateString();
};

export const getTrimmedText = (data, length) => {
  const formattedText = data?.substring(0, length).concat('...');
  return formattedText;
};

export const getAllUpperCase = (data) => {
  const words = data?.split(' ');
  const formattedText = words
    ?.map((word) => {
      return word[0]?.toUpperCase() + word.substring(1);
    })
    .join(' ');
  return formattedText;
};

export const capitalizeFirstLetter = (data) => {
  return data.charAt(0).toUpperCase() + data.slice(1);
};

export const capitalizeWords = (value) => {
  return value.replace(/(?:^|\s)\S/g, function (a) {
    return a.toUpperCase();
  });
};

export const copyContentToClipBoard = (text) => {
  var copyText = document.getElementById(text);
  navigator.clipboard.writeText(copyText?.innerText);
};

export const getDifferenceDate = (currentDate, numberOfDays) => {
  return subDays(currentDate, numberOfDays);
};

export const getFormattedDate = (dateToFormat, formatToApply) => {
  return format(dateToFormat, formatToApply);
};

export const navigateTo = (role) => {
  let path = '/kiosk';
  return path;
};

export const getDifferenceFromDates = (currentDate, toDate) => {
  const date1 = new Date(toDate);
  const date2 = new Date(currentDate);
  const diffTime = Math.abs(date2 - date1);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
};

export const getBase64 = (file) => {
  return new Promise((resolve) => {
    let fileInfo;
    let baseURL = '';
    // Make new FileReader
    let reader = new FileReader();

    // Convert the file to base64 text
    reader.readAsDataURL(file);

    // on reader load somthing...
    reader.onload = () => {
      // Make a fileInfo Object
      baseURL = reader.result;
      resolve(baseURL);
    };
  });
};

export const displayNoResultsFound = () => {
  return (
    <div className='no-record-found-wrapper text-center'>
      <Image
        src={noRecordImg}
        alt='filter-btn-icon'
        className='no-result-img img-fluid'
      />
      <h4 className='yk-title'>{NO_RESULT_FOUND.title}</h4>
      <p className='yk-subtitle'>{NO_RESULT_FOUND.msg}</p>
    </div>
  );
};

export const getMaskedNumber = (number, start, end) => {
  let maskedNumber = number?.toString().substring(start, end);
  maskedNumber = '**********' + maskedNumber;
  return maskedNumber;
};

export const convertNumberToNotation = (num) => {
  if (num > 999 && num < 1000000) {
    return (num / 1000).toFixed(1) + 'K'; // convert to K for number from > 1000 < 1 million
  } else if (num > 1000000) {
    return (num / 1000000).toFixed(1) + 'M'; // convert to M for number from > 1 million
  } else if (num <= 999) {
    return num; // if value < 1000, nothing to do
  }
};

export const convertPriceToUSFormat = (
  number,
  withDollar = true,
  prefix = '$',
  suffix = ''
) => {
  let instanceToUse = '';

  // format number to US dollar
  if (withDollar) {
    instanceToUse = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  } else {
    instanceToUse = new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }

  let isNum = /^[0-9.]+$/.test(number);
  // To apply the format value must be number/float and either prefix or suffix must be dollar
  if (isNum && instanceToUse && (prefix === '$' || suffix === '$')) {
    return instanceToUse?.format(number) || '';
  } else {
    return number;
  }
};
