export const FNS_DATE_FORMAT = 'MMM dd, yyyy';
export const KPI_DATE_FORMAT = 'yyyy-MM-dd';
export const FNS_TIME_FORMAT = 'HH:mm a';

export const NO_RESULT_FOUND: any = {
  title: 'No results found',
  msg: "We couldn't find anything for what you are looking.",
};

export const SOMETHING_WENT_WRONG = 'Something went wrong,Please try again';

export const CART_MESSAGES = {
  SUCCESS_MODAL_TITLE: 'Sit back and relax!!',
  SUCCESS_MODAL_CONTENT: 'Our sales guy will reachout to you in a moment.',
  GREAT_BUTTON: ' Great!',
  CUSTOMER_MODAL_TITLE: 'Is that all you wish to see?',
  CUSTOMER_MODAL_CONTENT: 'What would you like us to call you?',
  CONFIRM_REQUEST_BUTTON: 'YES, CONFIRM REQUEST',
};

export const START_WITH_NUMBER: any = /^[0-9].*$/;
export const APP_TITLE =
  'Yankeekicks Kiosk | Footwear | Apparel | Sneaker Care';
export const APP_KEYWORDS =
  'Yankeekicks Store | Footwear | Apparel | Sneaker Care';
