import axios from 'axios';

export async function doRequest(
  url: any,
  method = 'get',
  dataOrParams = {},
  contentType = '',
  authorizeFrom = false,
  isConsignment = false
) {
  let headers = {
    Accept: 'application/json',
    'Content-type': contentType || 'application/json',
    Authorization: authorizeFrom
      ? isConsignment
        ? `Bearer ${localStorage.getItem('token')}`
        : `Bearer ${localStorage.getItem('jwt-token')}`
      : '',
    From: authorizeFrom ? 'Consginee' : '',
    'g-store-location': localStorage?.getItem('graphStoreLocation') || '',
    'r-store-location': localStorage?.getItem('restStoreLocation') || '',
    'x-shopify-access-token': localStorage?.getItem('shopifyAccessToken') || '',
  };

  const params = method === 'get' ? dataOrParams : {};
  const data = method !== 'get' ? dataOrParams : undefined;
  return await axios({
    url,
    method,
    data,
    params,
    headers,
  });
}
