// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';

type Data = {
  name: string;
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  const { id } = req.body;
  const data = `{
    product(id: "${id}") {
      id
      description
      images(first: 4) {
        edges {
          node {
            id
            src
            url
            altText
            height
            originalSrc
            width
          }
        }
      }
      options {
        id
        name
        values
        position
      }
      priceRange {
        maxVariantPrice {
          amount
          currencyCode
        }
        minVariantPrice {
          amount
          currencyCode
        }
      }
      priceRangeV2 {
        maxVariantPrice {
          amount
          currencyCode
        }
        minVariantPrice {
          amount
          currencyCode
        }
      }
      productType
      status
      tags
      title
      totalInventory
      totalVariants
      vendor
      variants(first: 25) {
        edges {
          node {
            id
          }
        }
      }
    }
}`;
  const response = await axios({
    method: 'post',
    url: `${req?.headers['g-store-location']}`,
    data: data,
    headers: {
      'X-Shopify-Access-Token': `${req?.headers['x-shopify-access-token']}`,
      'Content-Type': 'application/graphql',
    },
  });

  res.status(200).json({ ...response.data });
}
