// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';

type Data = {
  name: string;
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  const response = await axios({
    method: 'GET',
    url: `${process.env.NEXT_PUBLIC_APP_INVENTORY_REST_API_DOMAIN}/getAllStores`,
  });
  res.status(200).json(response.data);
}
