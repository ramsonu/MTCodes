// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';

type Data = {
  name: string;
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  const data = `{
    products(query: "tag:featured AND product_type:sneakers",first: 10) {
      nodes {
        id
        productType
        title
        totalVariants
        images(first: 1) {
          edges {
            node {
              url
            }
          }
        }
        variants(first: 1) {
          edges {
            node {
              title
              sku
            }
          }
        }
        
      }
    }
  }`;

  const response = await axios({
    method: 'post',
    url: `${req?.headers['g-store-location']}`,
    data: data,
    headers: {
      'X-Shopify-Access-Token': `${req?.headers['x-shopify-access-token']}`,
      'Content-Type': 'application/graphql',
    },
  });
  res.status(200).json({ ...response.data });
}
