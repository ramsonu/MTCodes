// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';

type Data = {
  name: string;
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  const data = `{
    collections(query: "product_type:sneakers",first: 50) {
      edges {
        node {
          id
          image {
            src
            id
            url
          }
          productsCount
          title
  
        }
      }
    }
}`;

  const response = await axios({
    method: 'GET',
    url: `${process.env.NEXT_PUBLIC_APP_INVENTORY_REST_API_DOMAIN}/inventory-Brand`, //${req?.headers['g-store-location']}
    // data: data,
    headers: {
      'X-Shopify-Access-Token': `${req?.headers['x-shopify-access-token']}`,
      'Content-Type': 'application/graphql',
    },
  });
  res.status(200).json(response.data);
}
