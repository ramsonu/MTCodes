// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';

type Data = {
  name: string;
};

export const PRODUCT_TYPES = [
  { value: 'sneakers' },
  { value: 'Shoes' },
  // { value: 'Snowboard' },
  // { value: 'streetwear' },
  // { value: 'Accesory' },
  // { value: 'Backpack' },
  // { value: 'Default' },
  // { value: 'accesories' },
  // { value: 'clothing' },
  // { value: 'collectibles' },
  // { value: 'handbag' },
  // { value: 'ntwrk' },
  // { value: 'puma' },
];
const productTypesList = () => {
  let productTypes: any = [];
  PRODUCT_TYPES?.map((obj: any) => {
    const { value } = obj;
    productTypes.push(`product_type:${value}`);
  });
  return productTypes.join(' OR ');
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  const { brandName, limitForQuery, cursorValue } = req.body;
  let query = productTypesList();
  if (brandName !== '') {
    query = query.concat(` AND title:*${brandName}*`);
  }
  query = query.concat(` AND (status:ACTIVE)`);

  const limit = limitForQuery || 50;
  const endCursor = cursorValue?.endCursor
    ? `"${cursorValue?.endCursor}"`
    : null;

  const data = `{
    products(query: "${query}", first: ${limit}, after: ${endCursor}, reverse: true) {
      edges {
        node {
          id
          productType
          tags
          title
          totalVariants
          vendor
          images(first: 1) {
            edges {
              node {
                src
                url
                transformedSrc(maxWidth: 500, maxHeight: 200)
              }
            }
          }
        }
      }
      pageInfo {
        hasPreviousPage
        hasNextPage
        endCursor
        startCursor
      }
    }
  }`;
  const response = await axios({
    method: 'POST',
    url: `${req?.headers['g-store-location']}`,
    data: data,
    headers: {
      'X-Shopify-Access-Token': `${req?.headers['x-shopify-access-token']}`,
      'Content-Type': 'application/graphql',
    },
  });

  res.status(200).json({ ...response.data });
}
