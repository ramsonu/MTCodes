import { NextPage } from 'next';
import SearchResultsComp from 'components/kiosk/search-results';

const SearchResults: NextPage = () => {
  return (
    <>
      <SearchResultsComp />
    </>
  );
};

export default SearchResults;
