import { useCubeQuery } from '@cubejs-client/react';
import CircleLoader from 'components/common/loader/circular-loader';
import NoDataFound from 'components/common/no-data-found';
import { getAllLocations } from 'middleware/cubejs-wrapper/cubejs-query';
import { useRouter } from 'next/router';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { actions } from 'store/reducers/shared';
import { START_WITH_NUMBER } from 'utils/constants';

const LocationId = () => {
  const router = useRouter();
  const { query } = router;
  const dispatch = useDispatch();

  const { locationId: locId } = query;

  const { selected } = useSelector((state: any) => state.shared);
  const [allLocations, setAllLocations] = useState([]);
  const [isNoResults, setIsNoResults] = useState(false);

  const locationsQuery: any = getAllLocations();

  const {
    resultSet: locationsResultSet,
    isLoading: locationsLoading,
    error: locationsError,
  }: any = useCubeQuery(locationsQuery);

  useEffect(() => {
    const data = locationsResultSet?.loadResponses[0]?.data;
    if (data) {
      setAllLocations(data);
    } else {
      setAllLocations([]);
    }
  }, [locationsResultSet]);

  useEffect(() => {
    if (allLocations?.length > 0) {
      if (
        Object?.keys(selected)?.length === 0 &&
        (locId === localStorage?.getItem('locationId') ||
          !localStorage?.getItem('storeId'))
      ) {
        setLocations();
      } else {
        setIsNoResults(true);
      }
    }
  }, [allLocations]);

  const setLocations = () => {
    const selectedItem: any = allLocations?.find(
      (location: any) => location?.['Locations.locationID_D'] === locId
    );
    if (selectedItem && START_WITH_NUMBER.test(query?.locationId)) {
      localStorage?.setItem('storeId', selectedItem?.['Store.id']);
      localStorage?.setItem(
        'locationId',
        selectedItem?.['Locations.locationID_D']
      );
      localStorage?.setItem('storeLocation', selectedItem?.['Locations.name']);
      dispatch(actions.selected(selectedItem));
      setIsNoResults(false);
      router.push('/');
    } else {
      setIsNoResults(true);
    }
  };

  return <>{isNoResults ? <NoDataFound /> : <CircleLoader />}</>;
};

export default LocationId;
