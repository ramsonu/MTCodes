import LocationComp from 'components/common/location';
import CubeWrapper from 'middleware/cubejs-wrapper';
const Location = () => {
  return (
    <CubeWrapper>
      <LocationComp />
    </CubeWrapper>
  );
};

export default Location;
