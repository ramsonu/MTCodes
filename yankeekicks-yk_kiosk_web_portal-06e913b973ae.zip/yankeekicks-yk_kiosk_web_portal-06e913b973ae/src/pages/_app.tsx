import React from 'react';
import 'assets/scss/global.scss';
import type { AppProps } from 'next/app';
import { Provider as StoreProvider } from 'react-redux';
import { wrapper } from 'store/createStore';
import ErrorBoundary from 'components/common/error';
import Layout from 'components/laylout';
import CubeWrapper from 'middleware/cubejs-wrapper';

function MyApp({ Component, ...rest }: AppProps) {
  const { store, props } = wrapper.useWrappedStore(rest);

  return (
    <StoreProvider store={store}>
      <ErrorBoundary>
        <CubeWrapper>
          <Layout>
            <Component {...props.pageProps} />
          </Layout>
        </CubeWrapper>
      </ErrorBoundary>
    </StoreProvider>
  );
}

export default MyApp;
