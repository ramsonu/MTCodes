import { NextPage } from 'next';
import FeatureComp from 'components/kiosk/feature';
import CubeWrapper from 'middleware/cubejs-wrapper';

const Features: NextPage = () => {
  return (
    <>
      <CubeWrapper>
        <FeatureComp />
      </CubeWrapper>
    </>
  );
};

export default Features;
