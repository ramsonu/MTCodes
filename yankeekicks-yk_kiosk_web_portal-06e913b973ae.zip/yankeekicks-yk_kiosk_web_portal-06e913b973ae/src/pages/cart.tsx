import { NextPage } from 'next';
import CartComp from 'components/kiosk/cart';

const Cart: NextPage = () => {
  return (
    <>
      <CartComp />
    </>
  );
};

export default Cart;
