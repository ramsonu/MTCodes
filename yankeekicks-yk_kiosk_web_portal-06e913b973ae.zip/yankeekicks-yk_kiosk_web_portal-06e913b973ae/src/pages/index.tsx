import React from 'react';
import KioskLandingPage from 'components/kiosk/landing-page';

const LandingPage = () => {
  return (
    <>
      <KioskLandingPage />
    </>
  );
};

export default LandingPage;
