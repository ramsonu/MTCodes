
![Logo](https://pbs.twimg.com/profile_images/1125582842568818693/oS4QKGQ8_400x400.jpg)


# YANKEE KICKS 
## Consignment Admin & YK Admin

YankeeKicks is the online and retail marketplace for authentic premium sneakers. Here, sellers can sell premium his sneakers through his YankeeKicks account. 


## Installation

Install yk_admin_web_portal with npm

```bash
    git clone https://bitbucket.org/yankeekicks/yk_admin_web_portal.git
    cd yk_admin_web_portal
    npm install
    npm run dev
```
    
## Deployment

To Build this project run

```bash
    npm install
    npm run build
```


## Authors

[@mouritech](https://www.mouritech.com/)

