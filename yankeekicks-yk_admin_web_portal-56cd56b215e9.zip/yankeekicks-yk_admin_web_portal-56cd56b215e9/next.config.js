/** @type {import('next').NextConfig} */
const path = require('path');
const nextConfig = {
  reactStrictMode: true,
  swcMinify: false,
  sassOptions: {
    includePaths: [path.join(__dirname, 'styles')],
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'cdn.shopify.com',
      },
      {
        protocol: 'https',
        hostname: 'yankeekics-dev.s3.amazonaws.com',
      },
      {
        protocol: 'https',
        hostname: 'images.stockx.com',
      },
      {
        protocol: 'https',
        hostname: 'stockx-assets.imgix.net',
      },
      {
        protocol: 'https',
        hostname: 'yk-seller-doc-dev.s3.amazonaws.com',
      },
    ],
  },
};

module.exports = nextConfig;
