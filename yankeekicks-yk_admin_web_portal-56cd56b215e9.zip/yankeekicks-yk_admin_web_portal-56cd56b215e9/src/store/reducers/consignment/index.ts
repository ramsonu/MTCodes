import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  queue: [] as Array<any>,
  bulkRecord: [] as Array<any>,
  filteredData: [] as Array<any>,
  bulkRecordRes: [] as Array<any>,
  filteredDataRes: [] as Array<any>,
  transfers: [] as Array<any>,
  transferFilteredData: [] as Array<any>,
  uploadFile: [] as Array<any>,
};

const slice = createSlice({
  name: 'consignment',
  initialState,
  reducers: {
    setQueue(state, action) {
      state.queue = action.payload;
    },
    setBulkRecord(state, action) {
      state.bulkRecord = action.payload;
      state.filteredData = action.payload;
    },
    setBulkFile(state, action) {
      state.uploadFile = action.payload;
    },
    setBulkRecordRes(state, action) {
      state.bulkRecord = [];
      state.filteredData = [];
      state.bulkRecordRes = action.payload;
      state.filteredDataRes = action.payload;
    },
    setFilters(state, action) {
      const { size, brand, text } = action.payload;
      state.filteredData =
        text || size.length > 0 || brand.length > 0
          ? state.bulkRecord.filter(
              (o: any) =>
                o?.sku?.toLowerCase()?.includes(text) ||
                o?.brand?.toLowerCase()?.includes(text) ||
                size?.includes(o.size) ||
                brand?.includes(o.brand) ||
                o?.storeName?.toLowerCase()?.includes(text)
            )
          : state.bulkRecord;
    },
    clearFilters(state, action) {
      state.filteredData = state.bulkRecord;
    },
    removeBulkRecord(state, action) {
      const removeItem = state.bulkRecord.filter(
        (item: any) => item.rowId !== action.payload
      );
      state.bulkRecord = removeItem;
    },
    removeQueue(state, action) {
      const remove = state.queue.filter(
        (item: any) => item.size !== action.payload
      );
      state.queue = remove;
    },
    setTransfersData(state, action) {
      state.transfers = action.payload;
    },
    setTransferFilters(state, action) {
      const { brand, text } = action.payload;
      state.transferFilteredData =
        !!text || brand.length > 0
          ? state.transfers.filter(
              (o: any) =>
                o?.sku?.toLowerCase()?.includes(text) ||
                o?.quantityToTransfer == parseInt(text) ||
                o?.nameOfProduct?.toLowerCase()?.includes(text) ||
                o?.brandName?.toLowerCase()?.includes(text) ||
                brand?.includes(o?.brandName?.toLowerCase())
            )
          : state.transfers;
    },
    updateTransfersData(state, action) {
      state.transfers = [...state.transfers, ...action.payload];
    },
    clearAllTransfersData(state, action) {
      state.transfers = [];
    },
    setTransferFilteredData(state, action) {
      state.transferFilteredData = action.payload;
    },
    removeSelectedItemFromTransfers(state, action) {
      const removedItems = state.transfers?.filter(
        (item: any) => JSON.stringify(item) !== JSON.stringify(action.payload)
      );
      state.transfers = removedItems;
    },
  },
});

export default slice.reducer;
export const { reducer, actions } = slice;
export { initialState };
