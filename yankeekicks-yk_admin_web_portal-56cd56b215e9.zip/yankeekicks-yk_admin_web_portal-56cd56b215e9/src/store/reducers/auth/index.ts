import { createSlice } from '@reduxjs/toolkit';
import jwtDecode from 'jwt-decode';
type userType = {
  name: string;
  role: string;
  sub: string;
  exp: string;
  iat: string;
};
const initialState = {
  user: {} as userType,
  token: '' as string,
  status: false as boolean,
};

const slice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setUserDetails(state, action) {
      state.user = jwtDecode(action.payload);
      state.token = action.payload;
      state.status = true;
    },
    clearUserDetails(state) {
      state = initialState;
    },
  },
});

export default slice.reducer;
export const { reducer, actions } = slice;
export { initialState };
