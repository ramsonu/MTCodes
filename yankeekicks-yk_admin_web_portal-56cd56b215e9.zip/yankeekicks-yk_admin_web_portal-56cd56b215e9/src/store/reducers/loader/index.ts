import { createSlice } from '@reduxjs/toolkit';
const initialState = {
  loading: false,
  reload: 0,
};
const slice = createSlice({
  name: 'loader',
  initialState,
  reducers: {
    enableLoading(state) {
      state.loading = true;
    },
    diableLoading(state) {
      state.loading = false;
    },
    toggleLoading(state) {
      if (state.loading) {
        state.loading = false;
      } else {
        state.loading = true;
      }
    },
    reload(state) {
      let randamValue = Math.random();
      state.reload = randamValue;
    },
  },
});
export default slice.reducer;
export const { reducer, actions } = slice;
export { initialState };
