import { createSlice } from '@reduxjs/toolkit';
import { HYDRATE } from 'next-redux-wrapper';

const initialState = {
  products: [] as any,
  featuredProducts: [],
  brandProducts: [],
  product: {},
  filterTypes: {
    type: [],
    color: [],
    size: [],
    brand: [],
    date: [],
    transferType: [],
    title: '',
    inventoryDetailsAge: '',
    inventoryAge: '',
  } as any,
  loading: false,
  error: {},
  searchText: '',
  isFilteredDataloading: false,
  isBrandsLoading: false,
  cart: [] as Array<any>,
  requestToTryData: [] as Array<any>,
  cursorData: null as any,
  goBackTrigger: false,
};

const slice = createSlice({
  name: 'kiosk',
  initialState,
  reducers: {
    init(state, action) {
      state.loading = true;
    },
    set(state, action) {
      state.featuredProducts = action.payload;
      state.loading = false;
    },
    setProducts(state, action) {
      state.products = action.payload;
      state.loading = false;
    },
    setProductsWhileScroll(state, action) {
      state.products = [...state.products, action.payload];
      state.loading = false;
    },
    setBrandsLoading(state, action) {
      state.isBrandsLoading = true;
    },
    setBrandProducts(state, action) {
      state.brandProducts = action.payload;
      state.isBrandsLoading = false;
      // state.loading = false;
    },
    error(state, action) {
      state.loading = false;
    },
    setSearch(state, action) {
      return {
        ...state,
        filterTypes: {
          ...state.filterTypes,
          type: action.payload,
        },
      };
    },
    initFilteredData(state, action) {
      state.isFilteredDataloading = true;
    },
    setFilteredData(state, action) {
      state.isFilteredDataloading = false;
    },
    setFilters(state, action) {
      let { filterItem, filterType } = action.payload;
      const isTitle =
        filterType === 'title' ||
        filterType === 'inventoryDetailsAge' ||
        filterType === 'inventoryAge';
      let item =
        !isTitle &&
        (state.filterTypes[filterType]?.includes(filterItem)
          ? state.filterTypes[filterType].filter(
              (item: any) => item !== filterItem
            )
          : [...state.filterTypes[action.payload.filterType], filterItem]);
      state.filterTypes = {
        ...state.filterTypes,
        [filterType]: !isTitle ? item : filterItem,
      };
    },
    clearFiltersByKey(state, action) {
      state.filterTypes = {
        ...state.filterTypes,
        [action.payload.filterType]: Array.isArray(action.payload.filterItem)
          ? []
          : '',
      };
    },
    clearAllFilters(state, action) {
      state.filterTypes = {
        ...initialState.filterTypes,
      };
    },
    addToCart(state, action) {
      const itemInCart = state.cart.find(
        (item: any) => item.variantId === action.payload.variantId
      );
      if (itemInCart) {
        itemInCart.quantity++;
      } else {
        state.cart.push({ ...action.payload, quantity: 1 });
      }
    },
    incrementQuantity(state, action) {
      const item: any = state.cart.find(
        (item: any) => item.id === action.payload
      );
      item.quantity++;
    },
    decrementQuantity(state, action) {
      const item: any = state.cart.find(
        (item: any) => item.id === action.payload
      );
      if (item.quantity === 1) {
        item.quantity = 1;
      } else {
        item.quantity--;
      }
    },
    removeItem(state, action) {
      const removeItem = state.cart.filter(
        (item: any) => item.variantId !== action.payload
      );
      state.cart = removeItem;
    },
    clearCart(state, action) {
      state.cart = [];
    },
    setRequestToTryData(state, action) {
      state.requestToTryData = action.payload;
      state.loading = false;
    },
    setCursorData(state, action) {
      state.cursorData = action.payload;
    },
    setGoBackTrigger(state, action) {
      state.goBackTrigger = action.payload;
    },
  },
  extraReducers: {
    [HYDRATE]: (state, action) => {
      return {
        ...state,
        searchText: action.payload,
      };
    },
  },
});

export default slice.reducer;
export const { reducer, actions } = slice;
export { initialState };
