import { createSlice } from '@reduxjs/toolkit';
import { ALL_LOCATIONS } from 'utils/constants';

const initialState = {
  storeLocations: [],
  selected: {},
  loading: false,
  selectedLocation: ALL_LOCATIONS,
};

const slice = createSlice({
  name: 'shared',
  initialState,
  reducers: {
    init(state, action) {
      state.loading = true;
    },
    set(state, action) {
      state.storeLocations = action.payload;
      state.selected = action.payload && action.payload[0];
      state.loading = false;
    },
    selected(state, action) {
      state.selected = action.payload;
    },
    error(state, action) {
      state.loading = false;
    },
    setSelectedLocation(state, action) {
      state.selectedLocation = action?.payload || '';
    },
  },
});

export default slice.reducer;
export const { reducer, actions } = slice;
export { initialState };
