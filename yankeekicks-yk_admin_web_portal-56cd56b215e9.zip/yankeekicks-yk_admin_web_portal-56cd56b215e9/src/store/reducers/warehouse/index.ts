import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  requestDetails: [] as Array<any>,
  status: 'request',
  requestDetailsToggle:false as any
};

const slice = createSlice({
  name: 'warehouse',
  initialState,
  reducers: {
    setRequestDetails(state, action) {
      state.requestDetails = action.payload;
    },
    setRequestDetailsToggle(state, warehouseAction) {
      state.requestDetailsToggle = warehouseAction.payload;
    },
  },
});

export default slice.reducer;
export const { reducer, actions } = slice;
export { initialState };
