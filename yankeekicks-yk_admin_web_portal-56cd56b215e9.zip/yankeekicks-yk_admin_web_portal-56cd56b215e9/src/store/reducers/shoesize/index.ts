import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  cart: [] as Array<any>,
  activeStatus: 'request',
  filteredCart: [] as Array<any>,
  isShoeSizeBackButtonVisible: false,
  goBackTrigger: false,
};

const slice = createSlice({
  name: 'shoesize',
  initialState,
  reducers: {
    setCart(state, action) {
      state.cart = action.payload;
    },
    addToCart(state, action) {
      const itemInCart = state.cart.find(
        (item: any) =>
          item.inventoryLineItemId === action.payload.inventoryLineItemId
      );
      if (itemInCart) {
        itemInCart.quantity++;
      } else {
        state.cart.push({ ...action.payload, quantity: 1 });
      }
      state.filteredCart = state.cart;
    },
    filterByStatus(state, action) {
      state.activeStatus = action.payload;
    },
    removeItem(state, action) {
      const removeItem = state.cart.filter(
        (item: any) => item.inventoryLineItemId !== action.payload
      );
      state.cart = removeItem;
      state.filteredCart = removeItem;
    },
    setBackButtonVisibility(state, action) {
      state.isShoeSizeBackButtonVisible = action.payload;
    },
    setBackButtonTrigger(state, action) {
      state.goBackTrigger = action.payload;
    },
    clearRequestCart(state, action) {
      state.filteredCart = [];
      state.cart = [];
    },
  },
});

export default slice.reducer;
export const { reducer, actions } = slice;
export { initialState };
