export const msalConfig: any = {
  auth: {
    authority: process.env.NEXT_PUBLIC_APP_AUTHORITY,
    clientId: process.env.NEXT_PUBLIC_APP_CLIENT_ID as any,
    redirectUri: process.env.NEXT_PUBLIC_APP_REDIRECT_URI,
  },
  cache: {
    cacheLocation: 'sessionStorage',
    storeAuthStateInCookie: false,
  },
};

export const loginRequest = {
  scopes: ['User.Read'],
};
