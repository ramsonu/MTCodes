import { spawn } from '@redux-saga/core/effects';
import { loaderActions } from './loader';

import { watchGetStoreLocation, watchGetStoreByLocation } from './shared/index';

export default function* rootSaga() {
  // yield spawn(watchGetStoreLocation);
  yield spawn(watchGetStoreByLocation);
  yield spawn(loaderActions);
}
