import { call, put, takeEvery } from 'redux-saga/effects';
import {
  STORE_BY_LOCATION_REQUEST,
  STORE_LOCATION_REQUEST,
} from 'actions/shared';
import { actions } from 'store/reducers/shared';
import { getStore, getStoreByLoc } from 'services/shared';

// To get all location regardless of user
export function* getStoreLocationSaga(action) {
  try {
    yield put(actions.init());
    const payload = yield call(getStore);
    if (payload?.data) {
      const locationIds = payload?.data?.map((item) =>
        item?.locations?.map((location) => location.id)
      );
      const flatLocationIds = locationIds.flat();
      const totalLocIds = flatLocationIds?.toString() || '';
      localStorage?.setItem('totalLocationIds', totalLocIds);
      yield put(actions.set(payload.data));
      // yield put(actions.setSelectedLocation(ALL_LOCATIONS));
    } else if (payload?.errors) {
      yield put(actions.error(payload.errors));
    }
  } catch (e) {
    yield put(actions.error(e));
  }
}

export function* getStoreByLocationSaga(action) {
  try {
    yield put(actions.init());
    const payloadForApi = localStorage.getItem('totalLocationIds')
    ? { locations: localStorage.getItem('totalLocationIds') }
    : action.payload.params;
    
    
    const payload = yield call(getStoreByLoc, payloadForApi);
    if (payload?.data) {
      yield put(actions.set(payload.data));
    } else if (payload?.errors) {
      yield put(actions.error(payload.errors));
    }
  } catch (e) {
    yield put(actions.error(e));
  }
}

// export function* watchGetStoreLocation() {
//   yield takeEvery(STORE_LOCATION_REQUEST, getStoreLocationSaga);
// }

export function* watchGetStoreByLocation() {
  yield takeEvery(STORE_BY_LOCATION_REQUEST, getStoreByLocationSaga);
}
