import { call, put, takeEvery } from 'redux-saga/effects';
import { DISABLE_LOADER, ENABLE_LOADER, TOGGLE_LOADER } from 'actions/loader';
import { actions } from 'store/reducers/loader';

export function* hideLoader() {
  try {
    yield put(actions.diableLoading());
  } catch (e) {
    console.log('loader Error');
  }
}
export function* showLoader() {
  try {
    yield put(actions.enableLoading());
  } catch (e) {
    console.log('loader Error');
  }
}
export function* toggleLoader() {
  try {
    yield put(actions.toggleLoading());
  } catch (e) {
    console.log('loader Error');
  }
}

export function* loaderActions() {
  yield takeEvery(DISABLE_LOADER, hideLoader);
  yield takeEvery(ENABLE_LOADER, showLoader);
  yield takeEvery(TOGGLE_LOADER, toggleLoader);
}
