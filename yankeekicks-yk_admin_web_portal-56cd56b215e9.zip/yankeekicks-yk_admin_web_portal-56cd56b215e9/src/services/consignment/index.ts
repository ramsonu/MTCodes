import { SORTINGS_KEYS } from 'components/consignment-admin/constants';
import { doRequest } from 'utils/request';
import { getUserDetails } from 'utils/util';
import {
  CONSIGNEE_GET_PROFIT_RATIO,
  CONSIGNEE_UPDATE_RETAIL_PRICE,
  DOWNLOAD_TEMPLATE,
  ADD_TO_INVENTORY,
  GET_BRAND_NAME_FROM_SKU,
  DOWNLOAD_ORDER_PDF,
  DOWNLOAD_SIZE_INFO_TEMPLATE,
  PRINT_SUMMARY,
} from '../apiUrl';

export interface bulkuploadResponse {
  Success: any[];
  Failed: any[];
  consignor: {
    consignmentId: number;
    email: string;
    name: string;
    phoneNumber: string;
  };
}
const postUpdateRetailPrice = async (param: any) => {
  return doRequest(
    CONSIGNEE_UPDATE_RETAIL_PRICE,
    'post',
    param,
    '',
    true,
    true
  );
};

const getProfitRatio = async (param: any) => {
  return { data: { profitRatio: '0', minimumFee: '0' } }; // admin don't have profit
  //return doRequest(CONSIGNEE_GET_PROFIT_RATIO, 'get', param, '', true, true);
};

const downloadTemplate = async () => {
  return doRequest(DOWNLOAD_TEMPLATE, 'get', {}, 'text/csv', true, true);
};

const addToInventory = async (param: any) => {
  return doRequest(ADD_TO_INVENTORY, 'post', param, '', true, true);
};

const getBrandNameFromSku = async (param: any) => {
  return doRequest(GET_BRAND_NAME_FROM_SKU, 'get', param, '', true, true);
};

const downloadPDF = async (params: any) => {
  const { fileName, queryPayload } = params;
  const { currentLocId } = getUserDetails();
  const { filterInput, selectedSort, userInput, consigneeId, sku } =
    queryPayload;
  const { ORDER_BY_TYPE = '', ORDER_BY = '' }: any = Object(
    SORTINGS_KEYS[fileName.toUpperCase()]?.[selectedSort]
  );

  let paramsData = '';
  const tempQuery = `locationId=${currentLocId || ''}&brand=${
    filterInput?.brand?.join(',') || ''
  }&searchString=${userInput}&transferType=${
    filterInput?.type?.join(',') || ''
  }&transferStatus=${filterInput?.status?.join(',') || ''}&fromDate=${
    filterInput?.startDate || ''
  }&toDate=${filterInput?.endDate || ''}&startDate=${
    filterInput?.createdDate || ''
  }&endDate=${filterInput?.currentDate || ''}&status=${
    filterInput?.status?.join(',') || ''
  }&size=${
    filterInput?.size?.join(',') || ''
  }&orderBy=${ORDER_BY}&orderByType=${ORDER_BY_TYPE}&Commission=${
    filterInput?.commission || ''
  }`;

  switch (fileName) {
    case 'orders':
      paramsData = `admin/export/order?${tempQuery}`;
      break;
    case 'inventory':
      paramsData = `admin/export/inventory?${tempQuery}`;
      break;
    case 'inventoryDetails':
      paramsData = `admin/export/consignor/inventorySkuDetails?${
        !!consigneeId ? `consigneeId=${consigneeId}&` : ''
      }sku=${sku}&${tempQuery}`;
      break;
    case 'payouts':
      paramsData = `admin/export/payout/history?${tempQuery}`;
      break;
    case 'consignors':
      paramsData = `admin/export/consingnor?${tempQuery}`;
      break;
    case 'users':
      paramsData = `ykadmin/export/users?${tempQuery}`;
      break;
    case 'locations':
      paramsData = `ykadmin/export/locations?${tempQuery}`;
      break;
    case 'transfers':
      paramsData = `ykadmin/export/transfers?${tempQuery}`;
      break;
    default:
      break;
  }
  const paramsOrData = { query: paramsData };
  await doRequest(
    `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/${paramsOrData.query}`,
    'GET',
    '',
    '',
    false,
    false,
    'blob'
  ).then((response) => {
    let fileURL = window.URL.createObjectURL(new Blob([response.data]));
    let fileLink = document.createElement('a');

    fileLink.href = fileURL;
    fileLink.setAttribute('download', `${fileName}.pdf`);
    document.body.appendChild(fileLink);

    fileLink.click();
  });
};
const downloadPrintApprovedLabelsPDF = async (
  fileName: any,
  consignmentId: any
) => {
  await doRequest(
    `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/print/qr/labels?consigmentId=${consignmentId}`,
    'GET',
    '',
    '',
    false,
    false,
    'blob'
  ).then((response) => {
    let fileURL = window.URL.createObjectURL(new Blob([response.data]));
    let fileLink = document.createElement('a');

    fileLink.href = fileURL;
    fileLink.setAttribute('download', `${fileName}.pdf`);
    document.body.appendChild(fileLink);

    fileLink.click();
  });
};

const downloadPrintQRPDF = async (
  locationId: any,
  productId: any,
  barcode: any,
  isMobile = false
) => {
  await doRequest(
    `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/products/qr?locationId=${locationId}&productId=${productId}`,
    'GET',
    '',
    '',
    false,
    false,
    'blob'
  ).then((response) => {
    try {
      if (isMobile) {
        let fileURL = window.URL.createObjectURL(new Blob([response.data]));
        let fileLink = document.createElement('a');

        fileLink.href = fileURL;
        fileLink.setAttribute('download', `${barcode}.pdf`);
        document.body.appendChild(fileLink);
        fileLink.click();
      } else {
        const myFile = new File([response.data], `${barcode}.pdf`, {
          type: response.data.type,
        });
        let fileURL = URL.createObjectURL(myFile);
        const iframe = document.createElement('iframe');
        iframe.src = fileURL;
        iframe.style.display = 'none';
        document.body.appendChild(iframe);
        iframe.onload = () => {
          if (iframe.contentWindow !== null) {
            iframe.contentWindow.focus();
            iframe.contentWindow.print();
          }
        };
      }
    } catch (e: any) {
      console.log();
    }
  });
};

const postConsignmentReview = (
  consignmentId: number,
  locations: any,
  status: string,
  consignorName: string,
  sku: any,
  rejectMessage = ''
) => {
  let payload = {
    consignmentId: consignmentId,
    locationAndStore: locations,
    rejectMessage: rejectMessage,
    status: status,
    vendorName: consignorName,
    sku: sku,
  };

  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/update/consignment-status`,
    apiMethod: `post`,
    data: payload,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};

export const getLocationDetails = () => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_INVENTORY_REST_API_DOMAIN}/getAllStores`,
    apiMethod: `get`,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};

const downloadPrintLabels = (payload: any) => {
  doRequest(
    `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/print/qr/labels?consigmentId=282`,
    'GET',
    payload,
    '',
    false,
    false,
    'blob'
  ).then((response) => {
    let fileURL = window.URL.createObjectURL(new Blob([response.data]));
    let fileLink = document.createElement('a');
    fileLink.href = fileURL;
    fileLink.setAttribute('download', `printLabels.pdf`);
    document.body.appendChild(fileLink);
    fileLink.click();
  });
};

const downloadPrintQRBarcodeLabels = async (payload: any) => {
  const qrList = await doRequest(
    `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/bulk/qr/labels/barcode`,
    'POST',
    payload,
    '',
    false,
    false,
    'blob'
  ).then((response) => {
    let fileURL = window.URL.createObjectURL(new Blob([response.data]));
    let fileLink = document.createElement('a');
    fileLink.href = fileURL;
    fileLink.setAttribute('download', `qrLabels.pdf`);
    document.body.appendChild(fileLink);
    fileLink.click();
    return response;
  });

  return qrList;
};
const downloadPrintQRBarcodeLabelsAll = async (payload: any) => {
  const qrList = await doRequest(
    `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/bulk/qr/labels/print`,
    'POST',
    payload,
    '',
    false,
    false,
    'blob'
  ).then((response) => {
    let fileURL = window.URL.createObjectURL(new Blob([response.data]));
    let fileLink = document.createElement('a');
    fileLink.href = fileURL;
    fileLink.setAttribute('download', `qrLabels.pdf`);
    document.body.appendChild(fileLink);
    fileLink.click();
    return response;
  });

  return qrList;
};

const getConditionTypeList = async () => {
  const conditionList = await doRequest(
    `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/getAllConditions`,
    'get'
  );
  return conditionList?.data;
};
const downloadTemplateSheSizeData = async () => {
  return doRequest(
    DOWNLOAD_SIZE_INFO_TEMPLATE,
    'get',
    {},
    'text/csv',
    true,
    true
  );
};
const getPrintSummaryDetails = async (consignmentId: any) => {
  const req = await doRequest(
    `${PRINT_SUMMARY}?consignmentId=${consignmentId}`
  );
  return req.data;
};

const addBulFilekUpload = async (
  file: any,
  verified = false,
  locationId?: any
) => {
  let formData = new FormData();
  formData.append('file', file);
  formData.append('verified', <string>(<unknown>verified));
  if (!!locationId) formData.append('locationId', locationId);
  return doRequest(
    `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/yk/inventory/upload`,
    'post',
    formData,
    'multipart/form-data'
  );
};
const intiateWithdraw = async (payload: any) => {
  return doRequest(
    `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/withdraw/yk-products`,
    'post',
    payload
  );
};

export {
  getConditionTypeList,
  postUpdateRetailPrice,
  getProfitRatio,
  downloadTemplate,
  addToInventory,
  getBrandNameFromSku,
  downloadPDF,
  downloadPrintApprovedLabelsPDF,
  postConsignmentReview,
  downloadPrintQRPDF,
  downloadPrintLabels,
  downloadTemplateSheSizeData,
  getPrintSummaryDetails,
  downloadPrintQRBarcodeLabels,
  addBulFilekUpload,
  downloadPrintQRBarcodeLabelsAll,
  intiateWithdraw,
};
