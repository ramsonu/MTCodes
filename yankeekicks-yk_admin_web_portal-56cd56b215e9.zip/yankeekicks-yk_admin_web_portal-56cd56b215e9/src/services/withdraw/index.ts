import { doRequest } from 'utils/request';

export const handleApproveReject = async (payload: any) => {
  return doRequest(
    `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/withdraw/update-withdraw-status`,
    'put',
    payload
  );
};

export const MoveToYKInv = async (payload: any) => {
  return doRequest(
    `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/withdraw/move-to-yk`,
    'put',
    payload
  );
};

export const UpdateStatusPaid = async (payload: any) => {
  return doRequest(
    `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/withdraw/update-status-paid`,
    'put',
    payload
  );
};
