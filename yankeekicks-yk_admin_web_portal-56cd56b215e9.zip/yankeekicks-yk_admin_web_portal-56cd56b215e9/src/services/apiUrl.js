//Cube api
export const Cube_API_URL = `${process.env.NEXT_PUBLIC_APP_CUBE_API_DOMAIN}/cubejs-api/v1`;

//Catalog
export const CATALOG_GET_S3_IMAGE = `${process.env.NEXT_PUBLIC_APP_CATALOGE_S3_API_DOMAIN}/document/downloadS3ImageUrl`;
export const GET_BRAND_NAME_FROM_SKU = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/consignment/consignee-get-brandName-from-sku`;
//Validation api
export const USER_VALIDATION = `${process.env.NEXT_PUBLIC_APP_USER_VALIDATION}/authenticate/oauth`;

//consignment
export const CONSIGNEE_UPDATE_RETAIL_PRICE = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/consignment/consignee-update-retail-price`;
export const CONSIGNEE_GET_PROFIT_RATIO = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/consignment/consignee-profit-ratio`;
export const DOWNLOAD_TEMPLATE = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/consignment/consignee-download-template`;
export const ADD_TO_INVENTORY = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/consignment/consignee-add-to-inventory`;
export const DOWNLOAD_ORDER_PDF = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/consignment/consignee-export-pdf`;
export const DOWNLOAD_SIZE_INFO_TEMPLATE = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/consignment/consignee-download-template-size`;

//Notification APis
export const COMMON_NOTIFICATION = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/notifications`;
export const NOTIFICATION_UPDATE = `${process.env.NEXT_PUBLIC_APP_API_PORT}/notification_dev/notificationupdate/`;
export const SETTINGS_NOTIFICATION_UPDATE = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/notifications/notification-update`;
export const NOTIFICATION_UPDATE_FLAG = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/notifications/notification-update-flag`;
export const ADD_PUSH_NOTIFICATION = `${process.env.NEXT_PUBLIC_APP_API_PORT}/notification_dev/push-notification`;

//Store
export const GET_STORE = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/store-location`;
export const GET_STORE_BY_LOC = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/store-by-location`;

//Users
export const GET_USER_BY_ID = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/consignment/get-user-by-id`;
export const UPDATE_USER = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/consignment/update-user`;
export const ADD_CONTACT_US = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/consignment/contact-us-update`;
export const USER_EMAIL_EXISTS = `${process.env.NEXT_PUBLIC_APP_API_PORT}/api/consignment/user-email-exists`;

//User details
export const USER_DETAILS = `${process.env.NEXT_PUBLIC_APP_USER_VALIDATION}/user/role`;
export const PRINT_SUMMARY = `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/print/summary`;

//PBI URLS
export const PBI_REPORTS_INVENTORY_URL = `${process?.env?.NEXT_PUBLIC_PBI_REPORTS_INVENTORY}`;
export const PBI_REPORTS_SALES_URL = `${process?.env?.NEXT_PUBLIC_PBI_REPORTS_SALES}`;
export const PBI_REPORTS_TOP_URL = `${process?.env?.NEXT_PUBLIC_PBI_REPORTS_TOP}`;
export const PBI_REPORTS_USER_URL = `${process?.env?.NEXT_PUBLIC_PBI_REPORTS_USER}`;

// Transfer
export const INITIATE_TRANSFER_URL = `${process?.env?.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/initiate-transfer`;
export const ACCEPT_REJECT_TRANSFER_URL = `${process?.env?.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/update-transfer-status`;

// Dashboards
export const PENDING_TASKS_URL = `${process?.env?.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/pendingEvents`;

// Missing product
export const MISSING_PRODUCT_URL = `${process?.env?.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/barcode/found`;
