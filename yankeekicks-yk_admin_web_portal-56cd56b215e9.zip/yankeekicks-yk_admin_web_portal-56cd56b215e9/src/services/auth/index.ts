import { doRequest } from 'utils/request';
import {
  UPDATE_USER,
  GET_USER_BY_ID,
  USER_VALIDATION,
  USER_DETAILS,
} from '../apiUrl';
import jwt_decode from 'jwt-decode';
import { ALL_LOCATIONS, USER_ROLES } from 'utils/constants';

export const putUpdateUser = async (params: any, id: any) => {
  const req = await doRequest(
    `${UPDATE_USER}?id=${id}`,
    'put',
    params,
    '',
    true,
    true
  );
  return req.data;
};

export const getUser = async (id: any) => {
  return doRequest(`${GET_USER_BY_ID}?id=${id}`, 'get', '', '', true, true);
};

export const refreshToken = async () => {
  const res = await doRequest(
    `${process.env.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/authenticate/refreshtoken`,
    'get'
  );

  if (res.status === 201 || res.status === 200) {
    localStorage.setItem('jwt-token', res.data.token);
  }
};

export const validateUser = async () => {
  const data = {
    apiUrl: USER_VALIDATION,
    apiMethod: `post`,
    data: {
      accessToken: localStorage.getItem('access-token'),
    },
  };
  const response: any = await doRequest(
    `${process.env.NEXT_PUBLIC_APP_API_PORT}/api`,
    'post',
    data
  );
  if (response) {
    localStorage.setItem('jwt-token', response?.data?.token);
    const decodedToken: any = jwt_decode(response?.data?.token);
    const userInfoResponse: any = await doRequest(
      `${USER_DETAILS}/${decodedToken?.sub}`,
      'get',
      '',
      ''
    );
    const locations = userInfoResponse?.data?.map((item: any) => {
      return item?.location;
    });
    const locationIds = userInfoResponse?.data?.map((item: any) => {
      return item?.locationId;
    });

    //! This if else is for "All locations" option in sidebar
    //* storeLocation is equivalent to selectedLocName
    //* storeLocationId is equivalent to selectedLocIds
    /* selectedLocName & selectedLocIds can store All locations and its ids 
    but to not mess with already existing code we are creating this new states */
    // if (userInfoResponse?.data[0]?.role !== USER_ROLES?.CONSIGNMENT_ADMIN) {
      localStorage?.setItem('selectedLocName', ALL_LOCATIONS); // need this local storage because redux get restore when refresh
      localStorage?.setItem('selectedLocIds', locationIds?.join(',') || '');
    // } 
    // else {
    //   localStorage?.setItem('selectedLocName', locations[0]); // need this local storage because redux get restore when refresh
    //   localStorage?.setItem('selectedLocIds', locationIds[0] || '');
    // }

    localStorage.setItem('storeLocation', locations[0]);
    localStorage.setItem('totalLocation', locations?.join(','));
    localStorage.setItem('totalLocationIds', locationIds?.join(','));
    localStorage.setItem('storeLocationId', locationIds[0]);
    localStorage.setItem('userId', decodedToken?.user_id);
    localStorage.setItem('user-role', userInfoResponse?.data[0]?.role);
    localStorage.setItem('user-name', decodedToken?.name);
    return { response: response, userInfoResponse: userInfoResponse };
  } else return { response: null, userInfoResponse: null };
};
