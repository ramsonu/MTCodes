import { doRequest } from 'utils/request';
import {
  NOTIFICATION_INVALID_EMAIL_PWD,
  NOTIFICATION_LOGIN_SUCCESS,
  NOTIFICATION_PASSWORD_UPDATED_SUCCESS,
  NOTIFICATION_INVALID_OLD_PASSWORD,
  NOTIFICATION_SOMETHING_WENT_WRONG,
  NOTIFICATION_REGISTER_SUCCESS,
  NOTIFICATION_FORGET_PASSWORD_SUCCESS,
  NOTIFICATION_PASSWORD_RESET_SUCCESS,
  NOTIFICATION_PASSWORD_RESET_FAIl,
} from 'utils/constants';
import { UPDATE_USER } from 'services/apiUrl';
export type consignorType = {
  id: number;
  fullName: string | null;
  email: string | null;
  phoneNumber: string | null;
  documentType: string | null;
  documentName: string | null;
  documentImage: string | null;
  documentOldImage: string | null;
  documentImageInput: string | null;
  bankdetail: {
    bankName: string | null;
    routingNum: string | null;
    accountNo: string | null;
    accountNo2: string | null;
    typeOfTransfer: string | null;
    accountType: string | null;
    cardHolderName: string | null;
    cardNumber: string | null;
    cardExpDate: string | null;
    cardCvv: string | null;
  };
  address: {
    country: string | null;
    address: string | null;
    apartmentNumber: string | null;
    state: string | null;
    zipCode: string | null;
    city: string | null;
  };
  createdBy: string | null;
  profilePicture: string | null;
  enrollmentDate: string | null;
  consigneeTypeDTO?: any;
  commission?: any;
  status?: any;
  noOfItems?: any;
  consignmentValue?: any;
  commissionDetails?: {
    type?: any;
    NewCommission?: any;
    status?: any;
  };
  businessName?: string | null;
  ein?: string | null;
};
type responseType = {
  status: boolean;
  statusMessage?: string;
  data?: any;
};
export const getConsignorDetails = (consignorId: any) => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/user/${consignorId}`,
    apiMethod: `get`,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};
export const getUserRoles = () => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/users/role-types`,
    apiMethod: `get`,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};
export const updateConsignorStatus = (consignor: any) => {
  const data = {
    apiUrl: consignor?.active
      ? `${process.env.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/user/disable-user/${consignor?.id}`
      : `${process.env.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/user/enable-user/${consignor?.id}`,
    apiMethod: `post`,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};

export const getConsignors = () => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/consignee-user`,
    apiMethod: `get`,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};
export const putUpdateUser = async (params: any, id: any) => {
  params['phoneNumber'] = params?.phoneNumber?.replace(/\D/g, '');
  const req = await doRequest(
    `${UPDATE_USER}?id=${id}`,
    'put',
    params,
    '',
    true,
    true
  );
  return req.data;
};
export const putUpdateUserUpload = async (param: any, id: any) => {
  let formData = new FormData();
  formData.append('file', param?.documentImage);
  formData.append('documentName', param?.documentName);
  formData.append('documentType', param?.documentType);
  return doRequest(
    `${process.env.NEXT_PUBLIC_APP_USER_VALIDATION}/user/update/upload-document/${id}`,
    'post',
    formData,
    'multipart/form-data'
  );
};

export const postCommissionRequest = (payload: any) => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/add-commissionTypeChange`,
    apiMethod: `post`,
    data: payload,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};

export const getAllCommissionTypes = () => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/commissionTypes`,
    apiMethod: `get`,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};

export const putCommissionChangeRequest = (changeRequestPaload: any) => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/review-commissionTypeChange?comment=${changeRequestPaload?.comment}&commissionId=${changeRequestPaload?.commissionId}&isApproved=${changeRequestPaload?.isApproved}`,
    apiMethod: `put`,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};
export const updateConsignmentPayout = (payload: any) => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/update/consignment/payout`,
    apiMethod: `put`,
    data: [payload],
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};

export const addNewCommissionRequest = (
  consigneeId: any,
  newCommissionPayload: any
) => {
  const data = {
    apiUrl: consigneeId
      ? `${process.env.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/consigneetype/update/${consigneeId}`
      : `${process.env.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/add-consigneetype`,
    apiMethod: `post`,
    data: newCommissionPayload,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};

export const postAddLocationRequest = (locationId: any, payload: any) => {
  const data = {
    apiUrl: locationId
      ? `${process.env.NEXT_PUBLIC_APP_INVENTORY_REST_API_DOMAIN}/locations/${locationId}`
      : `${process.env.NEXT_PUBLIC_APP_INVENTORY_REST_API_DOMAIN}/locations`,
    apiMethod: `post`,
    data: payload,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};

export const putAddUserRequest = (payload: any) => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/user/add-user`,
    apiMethod: `post`,
    data: payload,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};

export const getLocationDetailsRequest = (locationId: any) => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_INVENTORY_REST_API_DOMAIN}/locations/${locationId}`,
    apiMethod: `get`,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};

export const getAllConsignors = () => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/consignors`,
    apiMethod: `get`,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};
