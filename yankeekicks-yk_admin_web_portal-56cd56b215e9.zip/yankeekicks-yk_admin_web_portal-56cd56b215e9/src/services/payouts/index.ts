import { doRequest } from 'utils/request';

export const postCompletePayout = (payload: any) => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_PAYOUT_REST_API_DOMAIN}/admin-approve-payout`,
    apiMethod: `post`,
    data: payload,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};

export const postPayoutShedular = () => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_PAYOUT_REST_API_DOMAIN}/payout-balance`,
    apiMethod: `post`,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};
