import { doRequest } from 'utils/request';
import {
  ADD_PUSH_NOTIFICATION,
  COMMON_NOTIFICATION,
  NOTIFICATION_UPDATE_FLAG,
} from '../apiUrl';
import jwt_decode from 'jwt-decode';
import { NOTIFICATION_SOMETHING_WENT_WRONG } from 'utils/constants';
export const getCommonNotification = async () => {
  const req = await doRequest(COMMON_NOTIFICATION);
  return req.data;
};

export const putUpdateNotifications = async (params: any, email: any) => {
  const req = await doRequest(
    `${NOTIFICATION_UPDATE_FLAG}?email=${email}`,
    'post',
    params
  );
  return req.data;
};

export const addPushNotifications = (payload: any) => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_API_PORT_NOTIFICATION}/push-notification`,
    apiMethod: `post`,
    data: payload,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};

export const cancelPushNotifications = (noticationId: any) => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_API_PORT_NOTIFICATION}/cancel-notification/${noticationId}`,
    apiMethod: `post`,
    data: {},
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};

export const getPushNotificationsRequestById = (tableId: any) => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_API_PORT_NOTIFICATION}/push-notification-history/${tableId}`,
    apiMethod: `get`,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};

export const getActivesubscribers = () => {
  const data = {
    apiUrl: `${process.env.NEXT_PUBLIC_APP_USER_VALIDATION}/user/subscriber-count`,
    apiMethod: `get`,
  };
  return doRequest(`${process.env.NEXT_PUBLIC_APP_API_PORT}/api`, 'post', data);
};
