import { doRequest } from 'utils/request';
import { CATALOG_GET_S3_IMAGE } from '../apiUrl';

const getImage = async (param: any) => {
  return doRequest(`${CATALOG_GET_S3_IMAGE}?path=${param}`, 'get');
};

export { getImage };
