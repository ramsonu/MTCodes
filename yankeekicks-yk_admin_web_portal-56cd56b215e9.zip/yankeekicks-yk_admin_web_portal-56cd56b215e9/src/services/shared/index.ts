import { doRequest } from 'utils/request';
import {
  ADD_CONTACT_US,
  GET_STORE,
  GET_STORE_BY_LOC,
  GET_USER_BY_ID,
  SETTINGS_NOTIFICATION_UPDATE,
  UPDATE_USER,
  USER_EMAIL_EXISTS,
} from '../apiUrl';

const getStore = async () => {
  return doRequest(GET_STORE, 'get');
};

const getStoreByLoc = async (params: any) => {
  return doRequest(GET_STORE_BY_LOC, 'post', params);
};

const getUser = async (id: any) => {
  return doRequest(`${GET_USER_BY_ID}?id=${id}`, 'get', '', '', true, true);
};
const getNotification = async (email: any) => {
  return doRequest(
    `${SETTINGS_NOTIFICATION_UPDATE}?email=${email}`,
    'get',
    '',
    '',
    true,
    true
  );
};
const putUpdateUser = async (params: any, id: any) => {
  const req = await doRequest(
    `${UPDATE_USER}?id=${id}`,
    'put',
    params,
    '',
    true,
    true
  );
  return req.data;
};
const postContactUs = async (params: any) => {
  const req = await doRequest(
    `${ADD_CONTACT_US}`,
    'post',
    params,
    '',
    true,
    true
  );
  return req.data;
};
const getUserEmail = async (email: any) => {
  return doRequest(
    `${USER_EMAIL_EXISTS}?email=${email}`,
    'get',
    '',
    '',
    true,
    true
  );
};
export {
  getStore,
  getStoreByLoc,
  getUser,
  getNotification,
  putUpdateUser,
  postContactUs,
  getUserEmail,
};
