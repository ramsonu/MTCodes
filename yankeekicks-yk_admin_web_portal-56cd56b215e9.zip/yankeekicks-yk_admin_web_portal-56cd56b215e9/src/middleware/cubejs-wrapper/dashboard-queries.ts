import { format } from 'date-fns';
import { KPI_DATE_FORMAT } from 'utils/constants';

// ! Apart from sales overview and weekly sales, all other queries will affect by date range filter
// * Location id filter is default for every query except user registration
// ! LocationIds could be single location id or multiple location ids with , separated.

// * For KPI's two queries present - one with creation date and other with order date filter
export const getAdminKPIsWithOrderDate = (
  locId: any,
  dateInput: any,
  monthStartDate: any,
  todaysDate: any
) => {
  const locationIds: any = locId?.split(',') || [''];

  // default location Id filter
  const filterPayload: any = [
    {
      member: 'AdminDashboardKPI.locationId',
      operator: 'equals',
      values: locationIds,
    },
    {
      member: 'AdminDashboardKPI.inventoryType',
      operator: 'equals',
      values: ['consignor'],
    },
  ];

  // * if dates are from date range filter then use them else use month start/end date as default
  if (dateInput?.startDate && dateInput?.endDate) {
    filterPayload?.push({
      member: 'AdminDashboardKPI.completedAtOrderDate',
      operator: 'inDateRange',
      values: [
        format(new Date(dateInput?.startDate), KPI_DATE_FORMAT),
        format(new Date(dateInput?.endDate), KPI_DATE_FORMAT),
      ],
    });
  } else {
    if (monthStartDate && todaysDate) {
      filterPayload?.push({
        member: 'AdminDashboardKPI.completedAtOrderDate',
        operator: 'inDateRange',
        values: [monthStartDate, todaysDate],
      });
    }
  }

  return {
    measures: [
      'AdminDashboardKPI.totalSales',
      'AdminDashboardKPI.totalProfits',
      'AdminDashboardKPI.pendingPayouts',
      'AdminDashboardKPI.onlineSales',
      'AdminDashboardKPI.retailSales',
    ],
    filters: filterPayload,
  };
};

export const getAdminKPIsWithCreationDate = (
  locId: any,
  dateInput: any,
  monthStartDate: any,
  todaysDate: any
) => {
  const locationIds: any = locId?.split(',') || [''];

  // default location Id filter
  const filterPayload: any = [
    {
      member: 'AdminDashboardKPI.locationId',
      operator: 'equals',
      values: locationIds,
    },
    {
      member: 'AdminDashboardKPI.inventoryType',
      operator: 'equals',
      values: ['consignor'],
    },
  ];

  // * if dates are from date range filter then use them else use month start/end date as default
  if (dateInput?.startDate && dateInput?.endDate) {
    filterPayload?.push({
      member: 'AdminDashboardKPI.creationDate',
      operator: 'inDateRange',
      values: [
        format(new Date(dateInput?.startDate), KPI_DATE_FORMAT),
        format(new Date(dateInput?.endDate), KPI_DATE_FORMAT),
      ],
    });
  } else {
    if (monthStartDate && todaysDate) {
      filterPayload?.push({
        member: 'AdminDashboardKPI.creationDate',
        operator: 'inDateRange',
        values: [monthStartDate, todaysDate],
      });
    }
  }

  return {
    measures: [
      'AdminDashboardKPI.listingCount',
      'AdminDashboardKPI.inventoryValues',
    ],
    filters: filterPayload,
  };
};

// This query is used for weekly sales as well as sales overview, based on props it will differ
export const getWeeklySalesQueryOrSalesOverview = (
  locId: any,
  purpose: any = 'weeklySales'
) => {
  const locationIds: any = locId?.split(',') || [''];

  let tDimension: any = [];
  let orderBy: any = [['WeeklyOrderData.totalSellingPrice', 'asc']];

  if (purpose === 'weeklySales') {
    orderBy = [['WeeklyOrderData.totalSellingPrice', 'asc']];
    tDimension = [
      {
        dimension: 'WeeklyOrderData.completedAt',
        dateRange: 'This week',
      },
    ];
  } else if (purpose === 'salesOverview') {
    orderBy = [['WeeklyOrderData.completedAt', 'asc']];
    tDimension = [
      {
        dimension: 'WeeklyOrderData.completedAt',
        granularity: 'month',
        dateRange: 'This year',
      },
    ];
  }

  const query = {
    measures: ['WeeklyOrderData.totalSellingPrice'],
    order: orderBy,
    timeDimensions: tDimension,
    filters: [
      {
        member: 'WeeklyOrderData.locationId',
        operator: 'equals',
        values: locationIds,
      },
      {
        member: 'WeeklyOrderData.inventoryType',
        operator: 'equals',
        values: ['consignor'],
      },
    ],
  };

  if (purpose === 'salesOverview') {
    return query;
  }

  return {
    ...query,
    dimensions: ['WeeklyOrderData.completedAtDate'],
  };
};

// For sales overview table data
export const getWeeklyOrdersTableQuery = (locId: any) => {
  const locationIds: any = locId?.split(',') || [''];

  return {
    order: [['WeeklyOrderData.completedAt', 'desc']],
    timeDimensions: [
      {
        dimension: 'WeeklyOrderData.completedAtDate',
        dateRange: 'This week',
      },
    ],
    filters: [
      {
        member: 'WeeklyOrderData.locationId',
        operator: 'equals',
        values: locationIds,
      },
      {
        member: 'WeeklyOrderData.inventoryType',
        operator: 'equals',
        values: ['consignor'],
      },
    ],
    dimensions: [
      'WeeklyOrderData.sellerorderId',
      'WeeklyOrderData.sku',
      'WeeklyOrderData.completedAt',
      'WeeklyOrderData.totalpriceUsd',
      'WeeklyOrderData.saleLocation',
      'WeeklyOrderData.countSku',
    ],
  };
};

export const getTopConsignorSales = (
  locId: any,
  dateInput: any,
  monthStartDate: any,
  todaysDate: any
) => {
  const locationIds: any = locId?.split(',') || [''];

  const filterPayload: any = [
    {
      member: 'TopConsignorSales.locationId',
      operator: 'equals',
      values: locationIds,
    },
    {
      member: 'TopConsignorSales.inventoryType',
      operator: 'equals',
      values: ['consignor'],
    },
  ];

  // * if dates are from date range filter then use them else use month start/end date as default
  if (dateInput?.startDate && dateInput?.endDate) {
    filterPayload?.push({
      member: 'TopConsignorSales.completedAtDate',
      operator: 'inDateRange',
      values: [
        format(new Date(dateInput?.startDate), KPI_DATE_FORMAT),
        format(new Date(dateInput?.endDate), KPI_DATE_FORMAT),
      ],
    });
  } else {
    if (monthStartDate && todaysDate) {
      filterPayload?.push({
        member: 'TopConsignorSales.completedAtDate',
        operator: 'inDateRange',
        values: [monthStartDate, todaysDate],
      });
    }
  }

  return {
    measures: ['TopConsignorSales.sellingPriceSum'],
    dimensions: ['TopConsignorSales.fullName', 'TopConsignorSales.consigneeId'],
    order: {
      'TopConsignorSales.sellingPriceSum': 'desc',
    },
    filters: filterPayload,
    limit: 15,
  };
};

// this don't require location id filter
export const getUserRegistrations = (
  dateInput: any,
  monthStartDate: any,
  todaysDate: any
) => {
  const filterPayload: any = [];

  // * if dates are from date range filter then use them else use month start/end date as default
  if (dateInput?.startDate && dateInput?.endDate) {
    filterPayload?.push({
      member: 'Users.createdDate',
      operator: 'inDateRange',
      values: [
        format(new Date(dateInput?.startDate), KPI_DATE_FORMAT),
        format(new Date(dateInput?.endDate), KPI_DATE_FORMAT),
      ],
    });
  } else {
    if (monthStartDate && todaysDate) {
      filterPayload?.push({
        member: 'Users.createdDate',
        operator: 'inDateRange',
        values: [monthStartDate, todaysDate],
      });
    }
  }

  return {
    measures: ['Users.sellerRegCount', 'Users.buyerRegCount'],
    order: {
      'Users.enrollmentDate': 'asc',
    },
    filters: filterPayload,
  };
};

export const getBestSellers = (
  locId: any,
  dateInput: any,
  monthStartDate: any,
  todaysDate: any,
  selectedMetric: string
) => {
  const locationIds: any = locId?.split(',') || [''];

  const filterPayload: any = [
    {
      member: 'TopSellerItem.locationId',
      operator: 'equals',
      values: locationIds,
    },
  ];
  let orderPayload: any = ['TopSellerItem.sellingPriceSum', 'desc'];

  // * if dates are from date range filter then use them else use month start/end date as default
  if (dateInput?.startDate && dateInput?.endDate) {
    filterPayload?.push({
      member: 'TopSellerItem.completedAtDate',
      operator: 'inDateRange',
      values: [
        format(new Date(dateInput?.startDate), KPI_DATE_FORMAT),
        format(new Date(dateInput?.endDate), KPI_DATE_FORMAT),
      ],
    });
  } else {
    if (monthStartDate && todaysDate) {
      filterPayload?.push({
        member: 'TopSellerItem.completedAtDate',
        operator: 'inDateRange',
        values: [monthStartDate, todaysDate],
      });
    }
  }

  if (selectedMetric === 'Gross') {
    orderPayload = ['TopSellerItem.sellingPriceSum', 'desc'];
  } else if (selectedMetric === 'Units') {
    orderPayload = ['TopSellerItem.count', 'desc'];
  }

  return {
    dimensions: ['TopSellerItem.productName', 'TopSellerItem.stockxUrl'],
    measures: ['TopSellerItem.sellingPriceSum', 'TopSellerItem.count'],
    order: [orderPayload],
    filters: filterPayload,
    limit: 15,
  };
};

export const getBestPerformerSalesAssociate = (
  locId: any,
  dateInput: any,
  monthStartDate: any,
  todaysDate: any
) => {
  const locationIds: any = locId?.split(',') || [''];

  const filterPayload: any = [
    {
      member: 'TopSalesAssociate.locationId',
      operator: 'equals',
      values: locationIds,
    },
  ];

  // * if dates are from date range filter then use them else use month start/end date as default
  if (dateInput?.startDate && dateInput?.endDate) {
    filterPayload?.push({
      member: 'TopSalesAssociate.completedAtDate',
      operator: 'inDateRange',
      values: [
        format(new Date(dateInput?.startDate), KPI_DATE_FORMAT),
        format(new Date(dateInput?.endDate), KPI_DATE_FORMAT),
      ],
    });
  } else {
    if (monthStartDate && todaysDate) {
      filterPayload?.push({
        member: 'TopSalesAssociate.completedAtDate',
        operator: 'inDateRange',
        values: [monthStartDate, todaysDate],
      });
    }
  }

  return {
    measures: ['TopSalesAssociate.totalPriceSum', 'TopSalesAssociate.count'],
    dimensions: ['TopSalesAssociate.userName'],
    order: {
      'TopSalesAssociate.totalPriceSum': 'desc',
    },
    filters: filterPayload,
    limit: 15,
  };
};
