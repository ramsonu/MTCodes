import React from 'react';
import cubejs from '@cubejs-client/core';
import { CubeProvider } from '@cubejs-client/react';
import { Cube_API_URL } from 'services/apiUrl';
import { useRouter } from 'next/router';

const CubeWrapper = (props: any) => {
  const router = useRouter();
  const { pathname } = router;

  const cubejsAPI = cubejs({
    apiUrl: Cube_API_URL,
    headers: {
      Authorization: localStorage.getItem('jwt-token') || '',
      'Content-Type': 'application/json',
    },
  });
  return <CubeProvider cubejsApi={cubejsAPI}>{props.children}</CubeProvider>;
};

export default CubeWrapper;
