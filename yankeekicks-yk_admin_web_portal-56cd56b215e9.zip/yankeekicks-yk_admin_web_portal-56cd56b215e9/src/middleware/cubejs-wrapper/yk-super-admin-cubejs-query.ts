export const getManageCommissionQuery = (
  userInput: any,
  selectedSort: any,
  filterInput: any,
  commissionOffset: any
) => {
  let manageCommissionSortPayload = [];
  switch (selectedSort) {
    case 'commissionNewest':
      manageCommissionSortPayload.push([
        'Managecomission.createdAt',
        'desc',
      ]);
      break;
    case 'comissionOldest':
      manageCommissionSortPayload.push([
        'Managecomission.createdAt',
        'asc',
      ]);
      break;
    case 'commissionAsc':
      manageCommissionSortPayload.push([
        'Managecomission.currentCommission',
        'asc',
      ]);
      break;
    case 'comissionDesc':
      manageCommissionSortPayload.push([
        'Managecomission.currentCommission',
        'desc',
      ]);
      break;
  }
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'Managecomission.userName',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'Managecomission.consigneeD',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];

  if (filterInput?.type?.length > 0) {
    appliedFiltersPayload.push({
      member: 'Managecomission.comissionType',
      operator: 'contains',
      values: filterInput.type,
    });
  }

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'Managecomission.Status',
      operator: 'contains',
      values: filterInput.status,
    });
  }

  return {
    dimensions: [
      'Managecomission.consigneeD',
      'Managecomission.userName',
      'Managecomission.UserEmail',
      'Managecomission.phoneNumber',
      'Managecomission.comissionType',
      'Managecomission.currentCommission',
      'Managecomission.newCommission',
      'Managecomission.newComissionName',
      'Managecomission.requestedByName',
      'Managecomission.reqUserEmail',
      'Managecomission.userId',
      'Managecomission.Status',
      'Managecomission.id',
      'Managecomission.createdAt',
    ],

    filters: appliedFiltersPayload,
    order: manageCommissionSortPayload,
    limit: 10,
    offset: commissionOffset,
  };
};

export const getPaginationCountForManageCommission = (
  userInput: any,
  selectedSort: any,
  filterInput: any
) => {
  let manageCommissionSortPayload = [];
  switch (selectedSort) {
    case 'commissionAsc':
      manageCommissionSortPayload.push([
        'Managecomission.currentCommission',
        'asc',
      ]);
      break;
    case 'comissionDesc':
      manageCommissionSortPayload.push([
        'Managecomission.currentCommission',
        'desc',
      ]);
      break;
  }
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'Managecomission.userName',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'Managecomission.consigneeD',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];

  if (filterInput?.commission?.length > 0) {
    appliedFiltersPayload.push({
      member: 'Managecomission.newComissionName',
      operator: 'contains',
      values: filterInput.commission,
    });
  }

  if (filterInput?.type?.length > 0) {
    appliedFiltersPayload.push({
      member: 'Managecomission.comissionType',
      operator: 'contains',
      values: filterInput.type,
    });
  }

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'Managecomission.Status',
      operator: 'contains',
      values: filterInput.status,
    });
  }

  return {
    measures: ['Managecomission.count'],
    order: manageCommissionSortPayload,
    filters: appliedFiltersPayload,
  };
};

export const getUserListPagination = (
  filterInput: any,
  selectedSort: any,
  searchInput: any
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'Manageuser.employeeId',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Manageuser.role',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Manageuser.userName',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Manageuser.status',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Manageuser.location',
          operator: 'contains',
          values: [searchInput],
        },
      ],
    },
    {
      member: 'Manageuser.isOauth',
      operator: 'equals',
      values: ['true'],
    },
  ];

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'Manageuser.status',
      operator: 'contains',
      values: filterInput.status,
    });
  }
  return {
    measures: ['Manageuser.count'],
    filters: appliedFiltersPayload,
  };
};
export const getUserList = (
  filterInput: any,
  searchInput: any,
  selectedSort: any,
  limitForQuery?: number,
  userOffset?: number
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'Manageuser.employeeId',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Manageuser.role',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Manageuser.userName',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Manageuser.status',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Manageuser.location',
          operator: 'contains',
          values: [searchInput],
        },
      ],
    },
    {
      member: 'Manageuser.isOauth',
      operator: 'equals',
      values: ['true'],
    },
  ];

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'Manageuser.status',
      operator: 'contains',
      values: filterInput.status,
    });
  }
  let manageUserSortPayload = [];
  switch (selectedSort) {
    case 'usersNewest':
      manageUserSortPayload.push(['Manageuser.createdAt', 'desc']);
      break;
    case 'usersOldest':
      manageUserSortPayload.push(['Manageuser.createdAt', 'asc']);
      break;
    case 'Emp.ID:Asc':
      manageUserSortPayload.push(['Manageuser.employeeId', 'asc']);
      break;
    case 'Emp.ID:Desc':
      manageUserSortPayload.push(['Manageuser.employeeId', 'desc']);
      break;
    case 'Name:Asc':
      manageUserSortPayload.push(['Manageuser.userName', 'asc']);
      break;
    case 'Name:Desc':
      manageUserSortPayload.push(['Manageuser.userName', 'desc']);
      break;
    case 'Status:Asc':
      manageUserSortPayload.push(['Manageuser.status', 'asc']);
      break;
    case 'Status:Desc':
      manageUserSortPayload.push(['Manageuser.status', 'desc']);
      break;
  }
  return {
    dimensions: [
      'Manageuser.employeeId',
      'Manageuser.role',
      'Manageuser.userName',
      'Manageuser.status',
      'Manageuser.location',
      'Manageuser.userId',
      'Manageuser.createdAt',
    ],
    order: manageUserSortPayload,
    filters: appliedFiltersPayload,
    limit: limitForQuery || undefined,
    offset: userOffset === 0 ? 0 : userOffset || undefined,
  };
};

export const getPushNotificationPagination = (
  filterInput: any,
  selectedSort: any,
  searchInput: any
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'pushNotification.notificationId',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'pushNotification.notificationType',
          operator: 'contains',
          values: [searchInput],
        },
      ],
    },
  ];

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'pushNotification.notificationStatus',
      operator: 'contains',
      values: filterInput.status,
    });
  }
  let  pushNotificationPayload = [];
  switch (selectedSort) {
    case 'notificationNewest':
       pushNotificationPayload.push(['pushNotification.notificationcreatedAt', 'desc']);
      break;
    case 'notificationOldest':
       pushNotificationPayload.push(['pushNotification.notificationcreatedAt', 'asc']);
      break;
    case 'Type:Asc':
       pushNotificationPayload.push(['pushNotification.notificationType', 'asc']);
      break;
    case 'Type:Desc':
       pushNotificationPayload.push(['pushNotification.notificationType', 'desc']);
      break;
    case 'NotificationId:Asc':
       pushNotificationPayload.push(['pushNotification.notificationId', 'asc']);
      break;
    case 'NotificationId:Desc':
       pushNotificationPayload.push(['pushNotification.notificationId', 'desc']);
      break;
  }
  return {
    measures: ['pushNotification.count'],
    filters: appliedFiltersPayload,
    order:  pushNotificationPayload,
  };
};
export const getPushNotificationsList = (
  filterInput: any,
  searchInput: any,
  selectedSort: any,
  limitForQuery?: number,
  userOffset?: number
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'pushNotification.notificationId',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'pushNotification.notificationType',
          operator: 'contains',
          values: [searchInput],
        },
      ],
    },
  ];

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'pushNotification.notificationStatus',
      operator: 'contains',
      values: filterInput.status,
    });
  }
  let  pushNotificationPayload = [];
  switch (selectedSort) {
    case 'notificationNewest':
       pushNotificationPayload.push(['pushNotification.notificationcreatedAt', 'desc']);
      break;
    case 'notificationOldest':
       pushNotificationPayload.push(['pushNotification.notificationcreatedAt', 'asc']);
      break;
    case 'Type:Asc':
       pushNotificationPayload.push(['pushNotification.notificationType', 'asc']);
      break;
    case 'Type:Desc':
       pushNotificationPayload.push(['pushNotification.notificationType', 'desc']);
      break;
    case 'NotificationId:Asc':
       pushNotificationPayload.push(['pushNotification.notificationId', 'asc']);
      break;
    case 'NotificationId:Desc':
       pushNotificationPayload.push(['pushNotification.notificationId', 'desc']);
      break;
  }
  return {
    dimensions: [
      "pushNotification.notificationId",
      "pushNotification.notificationType",
      "pushNotification.notificationcreatedAt",
      "pushNotification.notificationStatus",
      "pushNotification.notificationtypeId",
      "pushNotification.scheduleTimestamp",
      "pushNotification.id",
    ],
    order:  pushNotificationPayload,
    filters: appliedFiltersPayload,
    limit: limitForQuery || undefined,
    offset: userOffset === 0 ? 0 : userOffset || undefined,
  };
};


export const getViewCommissions = (
  userInput: any,
  filterInput: any,
  selectedSort: any,
  commissionsOffset: any,
  limitForQuery: any
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'ConsigneeType.name',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];
  if (filterInput?.name?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsigneeType.name',
      operator: 'equals',
      values: filterInput.name,
    });
  }

  let viewCommissionSortPayload = [];
  switch (selectedSort) {
    case 'percentageLow':
      viewCommissionSortPayload.push(['ConsigneeType.profitRatio', 'asc']);
      break;
    case 'percentageHigh':
      viewCommissionSortPayload.push(['ConsigneeType.profitRatio', 'desc']);
      break;
    case 'minimumFeeLow':
      viewCommissionSortPayload.push(['ConsigneeType.minimumFee', 'asc']);
      break;
    case 'minimumFeeHigh':
      viewCommissionSortPayload.push(['ConsigneeType.minimumFee', 'desc']);
      break;
    case 'flatFeeLow':
      viewCommissionSortPayload.push(['ConsigneeType.flatFee', 'asc']);
      break;
    case 'flatFeeHigh':
      viewCommissionSortPayload.push(['ConsigneeType.flatFee', 'desc']);
      break;
  }
  return {
    dimensions: [
      'ConsigneeType.name',
      'ConsigneeType.profitRatio',
      'ConsigneeType.minimumFee',
      'ConsigneeType.flatFee',
      'ConsigneeType.consigneeTypeId_D',
    ],
    filters: appliedFiltersPayload,
    order: viewCommissionSortPayload,
    limit: limitForQuery,
    offset: commissionsOffset,
  };
};

export const getPaginationViewCommissions = (
  userInput: any,
  filterInput: any,
  selectedSort: any,
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'ConsigneeType.name',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];
  if (filterInput?.name?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsigneeType.name',
      operator: 'equals',
      values: filterInput.name,
    });
  }

  let viewCommissionSortPayload = [];
  switch (selectedSort) {
    case 'percentageLow':
      viewCommissionSortPayload.push(['ConsigneeType.profitRatio', 'asc']);
      break;
    case 'percentageHigh':
      viewCommissionSortPayload.push(['ConsigneeType.profitRatio', 'desc']);
      break;
    case 'minimumFeeLow':
      viewCommissionSortPayload.push(['ConsigneeType.minimumFee', 'asc']);
      break;
    case 'minimumFeeHigh':
      viewCommissionSortPayload.push(['ConsigneeType.minimumFee', 'desc']);
      break;
    case 'flatFeeLow':
      viewCommissionSortPayload.push(['ConsigneeType.flatFee', 'asc']);
      break;
    case 'flatFeeHigh':
      viewCommissionSortPayload.push(['ConsigneeType.flatFee', 'desc']);
      break;
  }
  return {
    measures: ["ConsigneeType.count"],
    filters: appliedFiltersPayload,
    order: viewCommissionSortPayload,
  };
};



export const getViewLocations = (locationId: any) => {
  return {
    dimensions: [
      'ViewLocation.locationID_D',
      'ViewLocation.Status',
      'ViewLocation.userCount',
      'ViewLocation.inventoryValue',
    ],
    filters: [
      {
        member: 'ViewLocation.locationID_D',
        operator: 'contains',
        values: [locationId],
      },
    ],
  };
};

export const getPayoutListQuery = (
  userInput: any,
  selectedSort: string,
  filterInput: any,
  userOffset?: any,
  limitForQuery?: number
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'ConsigneePayout.transferMode',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ConsigneePayout.payoutStatus',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ConsigneePayout.payoutId',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];
  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsigneePayout.payoutStatus',
      operator: 'contains',
      values: filterInput.status,
    });
  }

  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsigneePayout.payoutDate',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }
  const payoutListPayload = [];

  switch (selectedSort) {
    case 'amountLow':
      payoutListPayload.push(['ConsigneePayout.payoutAmount', 'asc']);
      break;
    case 'amountHigh':
      payoutListPayload.push(['ConsigneePayout.payoutAmount', 'desc']);
      break;
    case 'dateNew':
      payoutListPayload.push(['ConsigneePayout.payoutDate', 'desc']);
      break;
    case 'dateOld':
      payoutListPayload.push(['ConsigneePayout.payoutDate', 'asc']);
      break;
    case 'payoutAsc':
      payoutListPayload.push(['ConsigneePayout.payoutId', 'asc']);
      break;
    case 'payoutDesc':
      payoutListPayload.push(['ConsigneePayout.payoutId', 'desc']);
      break;
  }
  return {
    dimensions: [
      'ConsigneePayout.payoutId',
      'ConsigneePayout.transferMode',
      'ConsigneePayout.payoutDate',
      'ConsigneePayout.transactionTraceId',
      'ConsigneePayout.payoutAmount',
      'ConsigneePayout.payoutStatus',
    ],
    order: payoutListPayload,
    filters: appliedFiltersPayload,
    limit: limitForQuery,
    offset: userOffset,
  };
};

export const getPaginationForPayoutList = (
  userInput: any,
  selectedSort: any,
  filterInput: any
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'ConsigneePayout.transferMode',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ConsigneePayout.payoutStatus',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ConsigneePayout.payoutId',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];
  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsigneePayout.payoutStatus',
      operator: 'contains',
      values: filterInput.status,
    });
  }

  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsigneePayout.payoutDate',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }
  const payoutListPayload = [];

  switch (selectedSort) {
    case 'amountLow':
      payoutListPayload.push(['ConsigneePayout.payoutAmount', 'asc']);
      break;
    case 'amountHigh':
      payoutListPayload.push(['ConsigneePayout.payoutAmount', 'desc']);
      break;
    case 'dateNew':
      payoutListPayload.push(['ConsigneePayout.payoutDate', 'desc']);
      break;
    case 'dateOld':
      payoutListPayload.push(['ConsigneePayout.payoutDate', 'asc']);
      break;
    case 'payoutAsc':
      payoutListPayload.push(['ConsigneePayout.payoutId', 'asc']);
      break;
    case 'payoutDesc':
      payoutListPayload.push(['ConsigneePayout.payoutId', 'desc']);
      break;
  }
  return {
    measures: ['ConsigneePayout.count'],
    order: payoutListPayload,
    filters: appliedFiltersPayload,
  };
};

export const getCommissionNames = () => {
  return {
    dimensions: [
      'ConsigneeType.name',
      'ConsigneeType.profitRatio',
      'ConsigneeType.minimumFee',
      'ConsigneeType.flatFee',
    ],
    filters: [
      {
        member: 'ConsigneeType.name',
        operator: 'contains',
        values: [''],
      },
    ],
    limit: 10,
    offset: 0,
  };
};
