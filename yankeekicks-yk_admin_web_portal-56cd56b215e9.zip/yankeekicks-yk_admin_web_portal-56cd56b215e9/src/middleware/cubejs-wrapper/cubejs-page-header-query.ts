// define the query here

export const getConsignmentDetailsHeader = (consignmentID: any) => {
  return {
    dimensions: [
      'ConsignmentviewDetails.consignmentID',
      'ConsignmentviewDetails.creationTime',
      'ConsignmentviewDetails.consignmentStatus',
      'ConsignmentviewDetails.numberofItems',
      'ConsignmentviewDetails.consignment_value',
      'ConsignmentviewDetails.userName',
      'ConsignmentviewDetails.emailId',
      'ConsignmentviewDetails.PhoneNumber',
      'ConsignmentviewDetails.consigneeId',
      'ConsignmentviewDetails.vendorId',
      'ConsignmentviewDetails.vendorName',
      'ConsignmentviewDetails.trackingId',
    ],
    order: [['ConsignmentviewDetails.sku', 'asc']],
    filters: [
      {
        member: 'ConsignmentviewDetails.consignmentID',
        operator: 'equals',
        values: [consignmentID],
      },
    ],
  };
};
export const getConsignmentSkuDetailsHeader = (
  consignmentID: any,
  sku: any
) => {
  return {
    dimensions: [
      'ConsignmentSkuDetails.consignmentID',
      'ConsignmentSkuDetails.itemName',
      'ConsignmentSkuDetails.description',
      'ConsignmentSkuDetails.Quantity',
      'ConsignmentSkuDetails.style',
      'ConsignmentSkuDetails.colorway',
      'ConsignmentSkuDetails.sizeType',
      'ConsignmentSkuDetails.releaseDate',
    ],
    order: [['ConsignmentSkuDetails.retailPrice_D', 'asc']],
    filters: [
      {
        member: 'ConsignmentSkuDetails.consignmentID',
        operator: 'equals',
        values: [consignmentID],
      },
      {
        member: 'ConsignmentSkuDetails.style',
        operator: 'contains',
        values: [sku],
      },
    ],
  };
};
export const getProductDetailsHeader = (skuId: any) => {
  return {
    dimensions: [
      'InventorySkuDetails.itemName',
      'InventorySkuDetails.brand',
      'InventorySkuDetails.style',
      'InventorySkuDetails.colorway',
      'InventorySkuDetails.actualReleaseDate',
    ],
    order: [['InventorySkuDetails.retailPrice_D', 'asc']],
    filters: [
      {
        member: 'InventorySkuDetails.style',
        operator: 'contains',
        values: [skuId],
      },
    ],
  };
};
export const getOrderDetailsHeader = (orderId: any) => {
  return {
    dimensions: ['OrdersViewData.orderId_D', 'OrdersViewData.LocationName'],
    measures: [
      'OrdersViewData.payoutAmount',
      'OrdersViewData.TotalpriceUsd',
      'OrdersViewData.orderQuantity',
      'OrdersViewData.count',
    ],
    filters: [
      {
        member: 'OrdersViewData.sellerorderId',
        operator: 'equals',
        values: [orderId],
      },
    ],
  };
};
