export const getMissingProducts = (
  missingPairSearch: any,
  missingPairSelectedSort: any,
  missingPairFilter: any,
  limitForQuery: any,
  userOffset: any
) => {
  const missingPairFilterValue = [];
  const sortOrder = [];

  //default status filter
  missingPairFilterValue?.push({
    member: 'InventorySkuDetails.status',
    operator: 'contains',
    values: ['Missing'],
  });

  //sorting
  switch (missingPairSelectedSort) {
    case 'dateNew':
      sortOrder?.push(['InventorySkuDetails.updatedAt', 'desc']);
      break;
    case 'dateOld':
      sortOrder?.push(['InventorySkuDetails.updatedAt', 'asc']);
      break;
    case 'skuAsc':
      sortOrder?.push(['InventorySkuDetails.style', 'asc']);
      break;
    case 'skuDesc':
      sortOrder?.push(['InventorySkuDetails.style', 'desc']);
      break;
    case 'sizeAsc':
      sortOrder?.push(['InventorySkuDetails.Size', 'asc']);
      break;
    case 'sizeDesc':
      sortOrder?.push(['InventorySkuDetails.Size', 'desc']);
      break;
  }

  //search
  if (missingPairSearch?.length > 0) {
    missingPairFilterValue?.push({
      or: [
        {
          member: 'InventorySkuDetails.itemName',
          operator: 'contains',
          values: [missingPairSearch],
        },
        {
          member: 'InventorySkuDetails.brand',
          operator: 'contains',
          values: [missingPairSearch],
        },
        {
          member: 'InventorySkuDetails.barcode',
          operator: 'contains',
          values: [missingPairSearch],
        },
        {
          member: 'InventorySkuDetails.Size',
          operator: 'contains',
          values: [missingPairSearch],
        },
      ],
    });
  }

  //size filter
  if (missingPairFilter?.size?.length > 0) {
    missingPairFilterValue?.push({
      member: 'InventorySkuDetails.Size',
      operator: 'equals',
      values: missingPairFilter?.size,
    });
  }

  //brand filter
  if (missingPairFilter?.brand?.length > 0) {
    missingPairFilterValue?.push({
      member: 'InventorySkuDetails.brand',
      operator: 'contains',
      values: missingPairFilter?.brand,
    });
  }

  return {
    dimensions: [
      'InventorySkuDetails.itemName',
      'InventorySkuDetails.brand',
      'InventorySkuDetails.Size',
      'InventorySkuDetails.status',
      'InventorySkuDetails.barcode',
      'InventorySkuDetails.locationName',
      'InventorySkuDetails.imageUrl',
      'InventorySkuDetails.style',
      'InventorySkuDetails.updatedAt',
    ],
    order: sortOrder,
    filters: missingPairFilterValue,
    limit: limitForQuery,
    offset: userOffset,
  };
};

export const getMissingProductsTotalCount = (
  missingPairSearch: any,
  missingPairSelectedSort: any,
  missingPairFilter: any
) => {
  const missingPairFilterValue = [];
  const sortOrder = [];

  //default status filter
  missingPairFilterValue?.push({
    member: 'InventorySkuDetails.status',
    operator: 'contains',
    values: ['Missing'],
  });

  //sorting
  switch (missingPairSelectedSort) {
    case 'dateNew':
      sortOrder?.push(['InventorySkuDetails.updatedAt', 'desc']);
      break;
    case 'dateOld':
      sortOrder?.push(['InventorySkuDetails.updatedAt', 'asc']);
      break;
    case 'skuAsc':
      sortOrder?.push(['InventorySkuDetails.style', 'asc']);
      break;
    case 'skuDesc':
      sortOrder?.push(['InventorySkuDetails.style', 'desc']);
      break;
    case 'sizeAsc':
      sortOrder?.push(['InventorySkuDetails.Size', 'asc']);
      break;
    case 'sizeDesc':
      sortOrder?.push(['InventorySkuDetails.Size', 'desc']);
      break;
  }

  //search
  if (missingPairSearch?.length > 0) {
    missingPairFilterValue?.push({
      or: [
        {
          member: 'InventorySkuDetails.itemName',
          operator: 'contains',
          values: [missingPairSearch],
        },
        {
          member: 'InventorySkuDetails.brand',
          operator: 'contains',
          values: [missingPairSearch],
        },
        {
          member: 'InventorySkuDetails.barcode',
          operator: 'contains',
          values: [missingPairSearch],
        },
        {
          member: 'InventorySkuDetails.Size',
          operator: 'contains',
          values: [missingPairSearch],
        },
      ],
    });
  }

  //size filter
  if (missingPairFilter?.size?.length > 0) {
    missingPairFilterValue?.push({
      member: 'InventorySkuDetails.Size',
      operator: 'equals',
      values: missingPairFilter?.size,
    });
  }

  //brand filter
  if (missingPairFilter?.brand?.length > 0) {
    missingPairFilterValue?.push({
      member: 'InventorySkuDetails.brand',
      operator: 'contains',
      values: missingPairFilter?.brand,
    });
  }

  return {
    measures: ['InventorySkuDetails.count'],
    order: sortOrder,
    filters: missingPairFilterValue,
  };
};
