// define the query here

export const getBrandsQuery = () => {
  return {
    dimensions: ['Brand.brandName', 'Brand.brandImageUrl'],
    order: {
      'Brand.brandName': 'asc',
    },
  };
};

export const getColorwaysQuery = (input: any, filterInput: any) => {
  const filterPayload = [];
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };

  const splitInput = input.split(' ');

  let appliedFiltersPayload = splitInput.map((item: any) => {
    return {
      or: [
        {
          member: 'InventoryLineItem.name',
          operator: 'contains',
          values: [item],
        },
        {
          member: 'Catalogue.colorway',
          operator: 'contains',
          values: [item],
        },
        {
          member: 'Brand.brandName',
          operator: 'contains',
          values: [item],
        },
      ],
    };
  });

  if (filterInput?.brands?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'Brand.brandName',
      operator: 'contains',
      values: filterInput.brands,
    });
  }

  if (filterPayload.length > 0) {
    appliedFiltersPayload.push({
      and: filterPayload,
    });
  }

  const payloadForFilter = [{ and: appliedFiltersPayload }];

  return {
    dimensions: ['Catalogue.colorway'],
    filters: payloadForFilter,
  };
};

export const getProductNames = (input: any) => {
  return {
    dimensions: ['InventoryLineItem.name'],
    timeDimensions: [],
    order: {
      'InventoryLineItem.name': 'asc',
    },
    filters: [
      {
        member: 'InventoryLineItem.name',
        operator: 'contains',
        values: [input],
      },
    ],
  };
};

export const getIndividualProduct = (input: any) => {
  return {
    dimensions: [
      'SKUBasedItems.sellingPrice_D',
      'SKUBasedItems.inventoryId',
      'SKUBasedItems.inventorySize',
      'SKUBasedItems.name',
      'SKUBasedItems.inventory_sku',
      'SKUBasedItems.imageUrl',
      'SKUBasedItems.colorway',
      'SKUBasedItems.availableFlag',
    ],
    order: {
      'SKUBasedItems.eventType': 'asc',
    },
    filters: [
      {
        member: 'SKUBasedItems.inventory_sku',
        operator: 'contains',
        values: [input],
      },
      {
        member: 'SKUBasedItems.storeId',
        operator: 'equals',
        values: ['1'],
      },
    ],
  };
};

export const getProductInfo = (input: any) => {
  return {
    dimensions: [
      'ProductInfo.itemName',
      'ProductInfo.inventorySize',
      'ProductInfo.colorway',
      'ProductInfo.style',
      'ProductInfo.retailPrice_D',
      'ProductInfo.imageUrl',
    ],
    order: {
      'ProductInfo.inventorySize': 'asc',
    },
    filters: [
      {
        member: 'ProductInfo.style',
        operator: 'contains',
        values: [input],
      },
    ],
  };
};

export const getShoesizeWarehouseKPIQuery = (
  userId: any,
  inDateRange: any,
  storeId: any
) => {
  return {
    measures: [
      'WarehouseKPICount.checkinCount',
      'WarehouseKPICount.checkoutCount',
      'WarehouseKPICount.pendingCount',
      'WarehouseKPICount.soldCount',
      'WarehouseKPICount.checkinPendingCount',
      'WarehouseKPICount.checkoutPendingCount',
    ],
    filters: [
      {
        member: 'WarehouseKPICount.eventTime',
        operator: 'inDateRange',
        values: [inDateRange],
      },
      {
        member: 'WarehouseKPICount.storeId',
        operator: 'equals',
        values: [storeId],
      },
    ],
    renewQuery: true,
  };
};

export const getAllShoeSizesKPI = () => {
  return {
    dimensions: ['InventoryLineSize.inventorySize'],
    timeDimensions: [],
    order: {
      'InventoryLineSize.inventorySize': 'asc',
    },
  };
};

export const getAllBrandsAPI = () => {
  return {
    dimensions: ['Brand.brandName'],
    timeDimensions: [],
    order: {
      'Brand.brandName': 'asc',
    },
  };
};

export const getAllAssociatesKPI = () => {
  return {
    dimensions: ['Users.userName'],
  };
};

export const getCountQuery = (userInput: any, filterInput: any) => {
  const filterPayload = [];
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };

  const splitInput = userInput.split(' ');

  let appliedFiltersPayload = splitInput.map((item: any) => {
    return {
      or: [
        {
          member: 'InventoryLineItem.name',
          operator: 'contains',
          values: [item],
        },
        {
          member: 'Catalogue.colorway',
          operator: 'contains',
          values: [item],
        },
        {
          member: 'Brand.brandName',
          operator: 'contains',
          values: [item],
        },
      ],
    };
  });

  if (filterInput?.brands?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'Brand.brandName',
      operator: 'contains',
      values: filterInput.brands,
    });
  }

  if (filterInput?.sizes?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'InventoryLineSize.inventorySize',
      operator: 'equals',
      values: filterInput.sizes,
    });
  }

  if (filterInput?.colorway?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'Catalogue.colorway',
      operator: 'contains',
      values: filterInput.colorway,
    });
  }

  if (filterInput?.releaseYear?.length > 0) {
    const yearsInString = filterInput?.releaseYear.map(String);
    filterPayload.push({
      ...filterObj,
      member: 'Catalogue.releaseYear',
      operator: 'equals',
      values: yearsInString,
    });
  }

  if (filterInput?.sizeTypes?.length > 0) {
    const sizeTypePayload = [];
    const sizeTypeObj = { member: '', operator: '', values: [] };

    if (filterInput?.sizeTypes?.includes('Him')) {
      sizeTypePayload.push({
        ...sizeTypeObj,
        member: 'Catalogue.men',
        operator: 'equals',
        values: ['true'],
      });
    }
    if (filterInput?.sizeTypes?.includes('Her')) {
      sizeTypePayload.push({
        ...sizeTypeObj,
        member: 'Catalogue.women',
        operator: 'equals',
        values: ['true'],
      });
    }
    if (filterInput?.sizeTypes?.includes('Infant')) {
      sizeTypePayload.push({
        ...sizeTypeObj,
        member: 'Catalogue.infant',
        operator: 'equals',
        values: ['true'],
      });
    }
    if (filterInput?.sizeTypes?.includes('Preschool')) {
      sizeTypePayload.push({
        ...sizeTypeObj,
        member: 'Catalogue.preschool',
        operator: 'equals',
        values: ['true'],
      });
    }
    if (filterInput?.sizeTypes?.includes('Toddler')) {
      sizeTypePayload.push({
        ...sizeTypeObj,
        member: 'Catalogue.toddler',
        operator: 'equals',
        values: ['true'],
      });
    }

    filterPayload.push({
      or: sizeTypePayload,
    });
  }

  if (filterPayload.length > 0) {
    appliedFiltersPayload.push({
      and: filterPayload,
    });
  }

  const payloadForFilter = [{ and: appliedFiltersPayload }];

  return {
    measures: ['InventoryLineItem.count'],
    filters: payloadForFilter,
    order: [
      ['InventoryLineItem.name', 'asc'],
      ['InventoryLineItem.sku', 'asc'],
      ['Brand.brandName', 'asc'],
    ],
  };
};

export const warehouseSearchQuery = (input: any) => {
  return {
    order: {
      'WarehouseProductList.RequestNumber': 'desc',
    },
    dimensions: [
      'WarehouseProductList.inventory_sku',
      'WarehouseProductList.itemName',
      'WarehouseProductList.imageUrl',
      'WarehouseProductList.size',
      'WarehouseProductList.eventType',
      'WarehouseProductList.eventTime',
      'WarehouseProductList.bin',
      'WarehouseProductList.rack',
      'WarehouseProductList.RequestNumber',
      'WarehouseProductList.request_count',
      'WarehouseProductList.UserId',
      'WarehouseProductList.user_name',
      'WarehouseProductList.pendingFlag',
      'WarehouseProductList.pendingStatus',
    ],
    filters: [
      {
        or: [
          {
            member: 'WarehouseProductList.RequestNumber',
            operator: 'contains',
            values: [input],
          },
          {
            member: 'WarehouseProductList.inventory_sku',
            operator: 'contains',
            values: [input],
          },
          {
            member: 'WarehouseProductList.itemName',
            operator: 'contains',
            values: [input],
          },
          {
            member: 'WarehouseProductList.size',
            operator: 'contains',
            values: [input],
          },
        ],
      },
    ],
  };
};

export const getInventoryProductDetails = (input: any) => {
  return {
    order: {
      'InventoryDetailsPopup.inventoryId': 'asc',
    },
    dimensions: [
      'InventoryDetailsPopup.bin',
      'InventoryDetailsPopup.rack',
      'InventoryDetailsPopup.brandName',
      'InventoryDetailsPopup.inventory_sku',
      'InventoryDetailsPopup.colorway',
      'InventoryDetailsPopup.releaseDate',
      'InventoryDetailsPopup.retailPrice_D',
      'InventoryDetailsPopup.Size',
      'InventoryDetailsPopup.Name',
      'InventoryDetailsPopup.imageUrl',
      'InventoryDetailsPopup.Compartment',
      'InventoryDetailsPopup.description',
      'InventoryDetailsPopup.inventoryId',
      'InventoryDetailsPopup.RequestNumber_D',
      'InventoryDetailsPopup.eventTime',
    ],
    filters: [
      {
        member: 'InventoryDetailsPopup.inventory_sku',
        operator: 'contains',
        values: [input],
      },
    ],
  };
};

export const getAllBins = () => {
  return {
    dimensions: ['InventoryLineItem.bin'],
    timeDimensions: [],
    order: {
      'InventoryLineItem.bin': 'asc',
    },
  };
};

export const getWithdrawQuery = (
  userInput: any,
  userOffset: any,
  selectedSort: any,
  filterInput: any,
  userDetails: any,
  limit = 8
) => {
  const consignmentSortPayload = [];

  switch (selectedSort) {
    case 'dateNew':
      consignmentSortPayload.push(
        ['ProductWithdrawal.createdAt', 'desc'],
        ['ProductWithdrawal.requestId', 'desc']
      );
      break;
    case 'dateOld':
      consignmentSortPayload.push(
        ['ProductWithdrawal.createdAt', 'asc'],
        ['ProductWithdrawal.requestId', 'asc']
      );
      break;
    case 'consigorIdAsc':
      consignmentSortPayload.push(['ProductWithdrawal.consigneeId', 'asc']);
      break;
    case 'consigorIdDsc':
      consignmentSortPayload.push(['ProductWithdrawal.consigneeId', 'desc']);
      break;
  }

  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'ProductWithdrawal.consignorName',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ProductWithdrawal.requestId',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ProductWithdrawal.consigneeId',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];

  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ProductWithdrawal.createdAt',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ProductWithdrawal.withdrawalStatus',
      operator: 'contains',
      values: filterInput.status,
    });
  }

  return {
    dimensions: [
      'ProductWithdrawal.requestId',
      'ProductWithdrawal.consigneeId',
      'ProductWithdrawal.consignorName',
      'ProductWithdrawal.createdAt',
      'ProductWithdrawal.withdrawalStatus',
    ],
    order: consignmentSortPayload,
    filters: appliedFiltersPayload,
    limit: limit,
    offset: userOffset,
  };
};

export const getPaginationCountForWithdraw = (
  userInput: any,
  filterInput: any
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'ProductWithdrawal.consignorName',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ProductWithdrawal.requestId',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ProductWithdrawal.consigneeId',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];

  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ProductWithdrawal.createdAt',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ProductWithdrawal.withdrawalStatus',
      operator: 'contains',
      values: filterInput.status,
    });
  }

  return {
    measures: ['ProductWithdrawal.count'],
    filters: appliedFiltersPayload,
  };
};
export const getWithdrawDetailsById = (
  withDrawId: any,
  userInput: any,
  selectedSort: any,
  filterInput: any,
  offset: any,
  limit: any
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'WithdrawalInventory.size',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'WithdrawalInventory.inventoryWithdrawalStatus',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'WithdrawalInventory.barcode',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
    {
      member: 'WithdrawalInventory.requestId',
      operator: 'equals',
      values: [withDrawId],
    },
  ];

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'WithdrawalInventory.inventoryWithdrawalStatus',
      operator: 'contains',
      values: filterInput.status,
    });
  }
  if (filterInput?.size?.length > 0) {
    appliedFiltersPayload.push({
      member: 'WithdrawalInventory.size',
      operator: 'contains',
      values: filterInput.size,
    });
  }
  const consignmentDetailsPayload = [];

  switch (selectedSort) {
    case 'sizeAsc':
      consignmentDetailsPayload.push(['WithdrawalInventory.size', 'asc']);
      break;
    case 'sizeDesc':
      consignmentDetailsPayload.push(['WithdrawalInventory.size', 'desc']);
      break;
    case 'priceLow':
      consignmentDetailsPayload.push([
        'WithdrawalInventory.retailPrice',
        'asc',
      ]);
      break;
    case 'priceHigh':
      consignmentDetailsPayload.push([
        'WithdrawalInventory.retailPrice',
        'desc',
      ]);
      break;
    case 'status: Asc':
      consignmentDetailsPayload.push([
        'WithdrawalInventory.inventoryWithdrawalStatus',
        'asc',
      ]);
      break;
    case 'status: Dsc':
      consignmentDetailsPayload.push([
        'WithdrawalInventory.inventoryWithdrawalStatus',
        'desc',
      ]);
      break;
  }
  return {
    dimensions: [
      'WithdrawalInventory.barcode',
      'WithdrawalInventory.sku',
      'WithdrawalInventory.stockxUrl',
      'WithdrawalInventory.brand',
      'WithdrawalInventory.productName',
      'WithdrawalInventory.size',
      'WithdrawalInventory.retailPrice',
      'WithdrawalInventory.inventoryWithdrawalStatus',
    ],
    order: consignmentDetailsPayload,
    filters: appliedFiltersPayload,
    offset: offset,
    limit: limit,
  };
};

export const getWithdrawDetailsByIdPaginationCount = (
  withDrawId: any,
  userInput: any,
  filterInput: any
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'WithdrawalInventory.size',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'WithdrawalInventory.inventoryWithdrawalStatus',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'WithdrawalInventory.barcode',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
    {
      member: 'WithdrawalInventory.requestId',
      operator: 'equals',
      values: [withDrawId],
    },
  ];

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'WithdrawalInventory.withdrawalStatus',
      operator: 'contains',
      values: filterInput.status,
    });
  }
  if (filterInput?.size?.length > 0) {
    appliedFiltersPayload.push({
      member: 'WithdrawalInventory.size',
      operator: 'contains',
      values: filterInput.size,
    });
  }
  return {
    measures: ['WithdrawalInventory.count'],
    filters: appliedFiltersPayload,
  };
};

export const getWithdrawDetailsHeaderById = (withDrawId: any) => {
  let appliedFiltersPayload: any = [
    {
      member: 'WithdrawalInventory.requestId',
      operator: 'equals',
      values: [withDrawId],
    },
  ];

  return {
    dimensions: [
      'WithdrawalInventory.consignorName',
      'WithdrawalInventory.consigneeId',
      'WithdrawalInventory.emailId',
      'WithdrawalInventory.phoneNumber',
      'WithdrawalInventory.withdrawalStatus',
      'WithdrawalInventory.numberOfItems',
    ],
    filters: appliedFiltersPayload,
  };
};
