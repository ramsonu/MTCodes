export const getTransfersRequestQuery = (
  locId: any = '',
  userInput: any = '',
  selectedSort: any = '',
  filterInput: any = {},
  transfersOffset?: any,
  limitForQuery?: any
) => {
  const userInputForSearch =
    userInput?.toLowerCase() === 'outgoing' ||
    userInput?.toLowerCase() === 'incoming'
      ? ''
      : userInput;

  // required objects
  let payloadForFilter: any = [
    {
      or: [
        {
          member: 'Transfers.transferId_D',
          operator: 'contains',
          values: [userInputForSearch],
        },
        {
          member: 'Transfers.fromLocation',
          operator: 'contains',
          values: [userInputForSearch],
        },
        {
          member: 'Transfers.toLocation',
          operator: 'contains',
          values: [userInputForSearch],
        },
        {
          member: 'Transfers.transferStatus',
          operator: 'contains',
          values: [userInputForSearch],
        },
      ],
    },
    {
      or: [
        {
          member: 'Transfers.fromlocationId',
          operator: 'equals',
          values: [locId],
        },
        {
          member: 'Transfers.tolocationId',
          operator: 'equals',
          values: [locId],
        },
      ],
    },
  ];

  // when user searching with type
  if (userInput?.length >= 5) {
    if (userInput?.toLowerCase() === 'outgoing') {
      payloadForFilter?.push({
        member: 'Transfers.fromlocationId',
        operator: 'equals',
        values: [locId],
      });
    } else if (userInput?.toLowerCase() === 'incoming') {
      payloadForFilter?.push({
        member: 'Transfers.tolocationId',
        operator: 'equals',
        values: [locId],
      });
    }
  }

  // filter by status
  if (filterInput?.status?.length > 0) {
    payloadForFilter?.push({
      member: 'Transfers.transferStatus',
      operator: 'contains',
      values: filterInput?.status,
    });
  }

  // filter by type
  if (filterInput?.type?.length > 0 && filterInput?.type?.length < 2) {
    if (filterInput?.type[0] === 'outgoing') {
      payloadForFilter?.push({
        member: 'Transfers.fromlocationId',
        operator: 'equals',
        values: [locId],
      });
    } else if (filterInput?.type[0] === 'incoming') {
      payloadForFilter?.push({
        member: 'Transfers.tolocationId',
        operator: 'equals',
        values: [locId],
      });
    }
  }

  // sorting
  const sortOrder: any = [];

  switch (selectedSort) {
    case 'transferIdAsc':
      sortOrder.push(['Transfers.transferId', 'asc']);
      break;
    case 'transferIdDesc':
      sortOrder.push(['Transfers.transferId', 'desc']);
      break;
    case 'toAsc':
      sortOrder.push(['Transfers.toLocation', 'asc']);
      break;
    case 'toDesc':
      sortOrder.push(['Transfers.toLocation', 'desc']);
      break;
    case 'statusAsc':
      sortOrder.push(['Transfers.transferStatus', 'asc']);
      break;
    case 'statusDesc':
      sortOrder.push(['Transfers.transferStatus', 'desc']);
      break;
  }

  return {
    dimensions: [
      'Transfers.transferId',
      'Transfers.fromLocation',
      'Transfers.toLocation',
      'Transfers.fromlocationId',
      'Transfers.tolocationId',
      'Transfers.quantity',
      'Transfers.transferStatus',
      'Transfers.createdAt',
    ],
    order: sortOrder,
    filters: payloadForFilter,
    limit: limitForQuery || undefined,
    offset: transfersOffset === 0 ? 0 : transfersOffset || undefined,
  };
};

export const getTransfersRequestCountQuery = (
  locId: any = '',
  userInput: any = '',
  filterInput: any = {}
) => {
  const userInputForSearch =
    userInput?.toLowerCase() === 'outgoing' ||
    userInput?.toLowerCase() === 'incoming'
      ? ''
      : userInput;

  // required objects
  let payloadForFilter: any = [
    {
      or: [
        {
          member: 'Transfers.transferId_D',
          operator: 'contains',
          values: [userInputForSearch],
        },
        {
          member: 'Transfers.fromLocation',
          operator: 'contains',
          values: [userInputForSearch],
        },
        {
          member: 'Transfers.toLocation',
          operator: 'contains',
          values: [userInputForSearch],
        },
        {
          member: 'Transfers.transferStatus',
          operator: 'contains',
          values: [userInputForSearch],
        },
      ],
    },
    {
      or: [
        {
          member: 'Transfers.fromlocationId',
          operator: 'equals',
          values: [locId],
        },
        {
          member: 'Transfers.tolocationId',
          operator: 'equals',
          values: [locId],
        },
      ],
    },
  ];

  // when user searching with type
  if (userInput?.length >= 5) {
    if (userInput?.toLowerCase() === 'outgoing') {
      payloadForFilter?.push({
        member: 'Transfers.fromlocationId',
        operator: 'equals',
        values: [locId],
      });
    } else if (userInput?.toLowerCase() === 'incoming') {
      payloadForFilter?.push({
        member: 'Transfers.tolocationId',
        operator: 'equals',
        values: [locId],
      });
    }
  }

  // filter by status
  if (filterInput?.status?.length > 0) {
    payloadForFilter?.push({
      member: 'Transfers.transferStatus',
      operator: 'contains',
      values: filterInput?.status,
    });
  }

  // filter by type
  if (filterInput?.type?.length > 0 && filterInput?.type?.length < 2) {
    if (filterInput?.type[0] === 'outgoing') {
      payloadForFilter?.push({
        member: 'Transfers.fromlocationId',
        operator: 'equals',
        values: [locId],
      });
    } else if (filterInput?.type[0] === 'incoming') {
      payloadForFilter?.push({
        member: 'Transfers.tolocationId',
        operator: 'equals',
        values: [locId],
      });
    }
  }

  return {
    measures: ['Transfers.count'],
    filters: payloadForFilter,
  };
};

export const getViewAcceptTransfersHeadersQuery = (transferId: any = '') => {
  return {
    dimensions: [
      'Transfers.transferId',
      'Transfers.fromLocation',
      'Transfers.toLocation',
      'Transfers.fromlocationId',
      'Transfers.tolocationId',
      'Transfers.quantity',
      'Transfers.transferStatus',
      'Transfers.createdAt',
    ],
    filters: [
      {
        member: 'Transfers.transferId',
        operator: 'equals',
        values: [transferId],
      },
    ],
  };
};

export const getProductsBasedOnRequestIdsQuery = (
  transferId: any,
  viewTransferSearch: any,
  viewTransferSelectedSort: any,
  viewTransferFilter: any
) => {
  const sortOrder = [];
  const viewTransferFilterValue = [];
  switch (viewTransferSelectedSort) {
    case 'skuAsc':
      sortOrder.push(['ViewTransfers.sku', 'asc']);
      break;
    case 'skuDesc':
      sortOrder.push(['ViewTransfers.sku', 'desc']);
      break;
    case 'sellingPriceLow':
      sortOrder.push(['ViewTransfers.retailPrice_D', 'asc']);
      break;
    case 'sellingPriceHigh':
      sortOrder.push(['ViewTransfers.retailPrice_D', 'desc']);
      break;
  }

  //required filter for query
  viewTransferFilterValue?.push({
    member: 'ViewTransfers.transferId',
    operator: 'equals',
    values: [transferId],
  });

  //size filter
  if (viewTransferFilter?.size?.length > 0) {
    viewTransferFilterValue?.push({
      member: 'ViewTransfers.size',
      operator: 'contains',
      values: viewTransferFilter?.size,
    });
  }

  //status filter
  if (viewTransferFilter?.status?.length > 0) {
    viewTransferFilterValue?.push({
      member: 'ViewTransfers.transferStatus',
      operator: 'contains',
      values: viewTransferFilter?.status,
    });
  }

  //search filter
  if (viewTransferSearch?.length > 0) {
    viewTransferFilterValue?.push({
      or: [
        {
          member: 'ViewTransfers.sku',
          operator: 'contains',
          values: [viewTransferSearch],
        },
        {
          member: 'ViewTransfers.barcode',
          operator: 'contains',
          values: [viewTransferSearch],
        },
        {
          member: 'ViewTransfers.size',
          operator: 'contains',
          values: [viewTransferSearch],
        },
      ],
    });
  }

  return {
    dimensions: [
      'ViewTransfers.sku',
      'ViewTransfers.barcode',
      'ViewTransfers.size',
      'ViewTransfers.retailPrice_D',
      'ViewTransfers.transferStatus',
      'ViewTransfers.transferId',
      'ViewTransfers.consignmentLineItemId_D',
      'ViewTransfers.conditionName',
    ],
    order: sortOrder,
    filters: viewTransferFilterValue,
  };
};

export const getMyInventoryProductsQuery = (
  userInput: any,
  selectedSort: string,
  filterInput: any,
  locId: any,
  userOffset?: any,
  limitForQuery?: number
) => {
  const filterPayload = [];
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };

  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'MyInventory.sku',
          operator: 'equals',
          values: [userInput],
        },
        {
          member: 'MyInventory.brand',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'MyInventory.itemName',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'MyInventory.barcode',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];

  appliedFiltersPayload?.push(
    {
      member: 'MyInventory.approvedStatus',
      operator: 'contains',
      values: ['Active'],
    },
    {
      member: 'MyInventory.locationId',
      operator: 'equals',
      values: [locId],
    }
  );

  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'MyInventory.creationDate',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }

  if (
    filterInput?.currentDate?.length > 0 &&
    filterInput?.createdDate?.length > 0
  ) {
    filterPayload.push({
      ...filterObj,
      member: 'MyInventory.creationDate',
      operator: 'inDateRange',
      values: [filterInput.createdDate, filterInput.currentDate],
    });
  }
  if (filterInput?.brand?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'MyInventory.brand',
      operator: 'contains',
      values: filterInput.brand,
    });
  }

  if (filterPayload.length > 0) {
    appliedFiltersPayload.push({
      and: filterPayload,
    });
  }

  const payloadForFilter: any = [{ and: appliedFiltersPayload }];

  const sortInventory = [];

  switch (selectedSort) {
    case 'skuAsc':
      sortInventory.push(['MyInventory.sku', 'asc']);
      break;
    case 'skuDesc':
      sortInventory.push(['MyInventory.sku', 'desc']);
      break;
    case 'brandAsc':
      sortInventory.push(['MyInventory.brand', 'asc']);
      break;
    case 'brandDesc':
      sortInventory.push(['MyInventory.brand', 'desc']);
      break;
    case 'qtyLow':
      sortInventory.push(['MyInventory.nonTransferQuantity', 'asc']);
      break;
    case 'qtyHigh':
      sortInventory.push(['MyInventory.nonTransferQuantity', 'desc']);
      break;
  }

  return {
    dimensions: [
      'MyInventory.sku',
      'MyInventory.brand',
      'MyInventory.itemName',
      'MyInventory.imageUrl',
      'MyInventory.productId',
      'MyInventory.nonTransferQuantity',
    ],
    order: sortInventory,
    filters: payloadForFilter,
    limit: limitForQuery || undefined,
    offset: userOffset === 0 ? 0 : userOffset || undefined,
  };
};

export const getPaginationCountForInventoryProducts = (
  userInput: any,
  filterInput: any,
  locId: any
) => {
  const filterPayload = [];
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };

  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'InventoryCount.sku',
          operator: 'equals',
          values: [userInput],
        },
        {
          member: 'InventoryCount.brand',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'InventoryCount.name',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'InventoryCount.Barcode',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];

  appliedFiltersPayload?.push(
    {
      member: 'InventoryCount.status',
      operator: 'contains',
      values: ['Active'],
    },
    {
      member: 'InventoryCount.locationId',
      operator: 'equals',
      values: [locId],
    }
  );

  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'InventoryCount.creationDate',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }

  if (
    filterInput?.currentDate?.length > 0 &&
    filterInput?.createdDate?.length > 0
  ) {
    filterPayload.push({
      ...filterObj,
      member: 'InventoryCount.creationDate',
      operator: 'inDateRange',
      values: [filterInput.createdDate, filterInput.currentDate],
    });
  }
  if (filterInput?.brand?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'InventoryCount.brand',
      operator: 'contains',
      values: filterInput.brand,
    });
  }

  if (filterPayload.length > 0) {
    appliedFiltersPayload.push({
      and: filterPayload,
    });
  }
  const payloadForFilter: any = [{ and: appliedFiltersPayload }];

  return {
    measures: ['InventoryCount.skuDistinctCount'],
    filters: payloadForFilter,
  };
};

export const sizeBasedOnProductId: any = (productId: any, locId: any) => {
  return {
    dimensions: [
      'ConsigneeSize.Size',
      'ConsignmentLineItem.barcode',
      'ConsignmentLineItem.availableQuantity',
      'ConsignmentLineItem.retailPrice_D',
      'ConsignmentLineItem.variantId',
      'ConsigneeCondition.conditionName',
    ],

    filters: [
      {
        member: 'ConsignmentLineItem.productId',
        operator: 'equals',
        values: [productId],
      },
      {
        member: 'ConsignmentLineItem.locationId',
        operator: 'equals',
        values: [locId],
      },
      {
        member: 'ConsignmentLineItem.status',
        operator: 'contains',
        values: ['Approved'],
      },
    ],
  };
};

export const getLocationsQuery = () => {
  return {
    dimensions: ['Locations.locationID_D', 'Locations.name'],
  };
};
