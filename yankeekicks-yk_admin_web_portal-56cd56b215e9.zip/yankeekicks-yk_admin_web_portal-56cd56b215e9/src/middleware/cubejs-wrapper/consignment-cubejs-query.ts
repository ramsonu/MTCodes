import { CONSIGNMENT_ADMIN_INNER_PATH } from 'components/consignment-admin/constants';
import { fi } from 'date-fns/locale';
import { FNS_DATE_FORMAT } from 'utils/constants';
import {
  getDifferenceDate,
  getFormattedDate,
  getUserDetails,
} from 'utils/util';

export const getConsignmentKPIQuery = (
  userId: any,
  startDate: any,
  endDate: any
) => {
  return {
    measures: [
      'ConsignmentLineItem.sellCount',
      'ConsignmentLineItem.ActiveCount',
      'ConsignmentLineItem.payoutAmount',
    ],
    filters: [
      {
        member: 'ConsignmentLineItem.consigneeId',
        operator: 'equals',
        values: [userId],
      },
    ],
  };
};

export const getPayoutHistoryQuery = (
  userDetails: any,
  userInput: any,
  selectedSort: string,
  filterInput: any,
  userOffset?: any,
  limitForQuery?: number
) => {
  const filterPayload = [];
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };

  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'PayoutHistory.transferMode',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'PayoutHistory.consigneePayoutId',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
    {
      member: 'PayoutHistory.consigneeId',
      operator: 'equals',
      values: [userDetails?.user_id?.toString()],
    },
  ];

  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    filterPayload.push({
      ...filterObj,

      member: 'PayoutHistory.payoutDate',

      operator: 'inDateRange',

      values: [filterInput.startDate, filterInput.endDate],
    });
  }

  if (filterInput?.status?.length > 0) {
    filterPayload.push({
      ...filterObj,

      member: 'PayoutHistory.payoutStatus',

      operator: 'equals',

      values: filterInput.status,
    });
  }

  if (filterPayload.length > 0) {
    appliedFiltersPayload.push({
      and: filterPayload,
    });
  }

  const payloadForFilter = [{ and: appliedFiltersPayload }];

  const payoutHistoryPayload = [];

  switch (selectedSort) {
    case 'amountLow':
      payoutHistoryPayload.push(['PayoutHistory.payoutAmount', 'asc']);

      break;

    case 'amountHigh':
      payoutHistoryPayload.push(['PayoutHistory.payoutAmount', 'desc']);

      break;

    case 'dateNew':
      payoutHistoryPayload.push(['PayoutHistory.payoutDate', 'desc']);

      break;

    case 'dateOld':
      payoutHistoryPayload.push(['PayoutHistory.payoutDate', 'asc']);

      break;

    case 'payoutAsc':
      payoutHistoryPayload.push(['PayoutHistory.consigneePayoutId', 'asc']);

      break;

    case 'payoutDesc':
      payoutHistoryPayload.push(['PayoutHistory.consigneePayoutId', 'desc']);

      break;
  }

  return {
    dimensions: [
      'PayoutHistory.consigneePayoutId',
      'PayoutHistory.transferMode',
      'PayoutHistory.payoutDate',
      'PayoutHistory.transactionTraceId',
      'PayoutHistory.orderId',
    ],
    measures: ['PayoutHistory.payoutAmount'],
    order: payoutHistoryPayload,
    filters: payloadForFilter,
    limit: limitForQuery || undefined,
    offset: userOffset === 0 ? 0 : userOffset || undefined,
  };
};

export const getPayoutTotalAmountQuery = (
  userDetails: any,
  userInput: any,
  limitForQuery: any,
  userOffset: any,
  selectedSort: string,

  filterInput: any
) => {
  const filterPayload = [];
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };

  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'PayoutHistory.transferMode',
          operator: 'contains',
          values: [userInput],
        },

        {
          member: 'PayoutHistory.consigneePayoutId',
          operator: 'set',
          values: [userInput],
        },
      ],
    },
    {
      member: 'PayoutHistory.consigneeId',
      operator: 'equals',
      values: [userDetails?.user_id?.toString()],
    },
  ];

  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    filterPayload.push({
      ...filterObj,

      member: 'PayoutHistory.payoutDate',

      operator: 'inDateRange',

      values: [filterInput.startDate, filterInput.endDate],
    });
  }

  if (filterInput?.status?.length > 0) {
    filterPayload.push({
      ...filterObj,

      member: 'PayoutHistory.payoutStatus',

      operator: 'equals',

      values: filterInput.status,
    });
  }

  if (filterPayload.length > 0) {
    appliedFiltersPayload.push({
      and: filterPayload,
    });
  }

  const payloadForFilter = [{ and: appliedFiltersPayload }];

  const payoutHistoryPayload = [];

  switch (selectedSort) {
    case 'amountLow':
      payoutHistoryPayload.push(['PayoutHistory.payoutAmount', 'asc']);

      break;

    case 'amountHigh':
      payoutHistoryPayload.push(['PayoutHistory.payoutAmount', 'desc']);

      break;

    case 'dateNew':
      payoutHistoryPayload.push(['PayoutHistory.payoutDate', 'desc']);

      break;

    case 'dateOld':
      payoutHistoryPayload.push(['PayoutHistory.payoutDate', 'asc']);

      break;

    case 'payoutAsc':
      payoutHistoryPayload.push(['PayoutHistory.consigneePayoutId', 'asc']);

      break;

    case 'payoutDesc':
      payoutHistoryPayload.push(['PayoutHistory.consigneePayoutId', 'desc']);

      break;
  }

  return {
    measures: ['PayoutHistory.payoutAmount'],
    order: payoutHistoryPayload,
    filters: payloadForFilter,
    // limit: limitForQuery || undefined,
    // offset: userOffset === 0 ? 0 : userOffset || undefined,
  };
};

export const getCatlogueTabQuery = (
  userInput: any,
  userOffset: any,
  selectedSort: any,
  limitForQuery: number,
  filterInput: any
) => {
  const filterPayload = [];
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };
  const splitInput = userInput?.split(' ');
  let appliedFiltersPayload = splitInput?.map((item: any) => {
    return {
      or: [
        {
          member: 'Catalogue.itemName',
          operator: 'contains',
          values: [item],
        },
        {
          member: 'Catalogue.style',
          operator: 'contains',
          values: [item],
        },
        {
          member: 'Catalogue.shortDescription',
          operator: 'contains',
          values: [item],
        },
      ],
    };
  });
  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'Catalogue.releaseDate',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }

  if (
    filterInput?.currentDate?.length > 0 &&
    filterInput?.createdDate?.length > 0
  ) {
    filterPayload.push({
      ...filterObj,
      member: 'Catalogue.releaseDate',
      operator: 'inDateRange',
      values: [filterInput.createdDate, filterInput.currentDate],
    });
  }
  if (filterInput?.brand?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'Catalogue.brand',
      operator: 'contains',
      values: filterInput.brand,
    });
  }
  if (filterPayload.length > 0) {
    appliedFiltersPayload.push({
      and: filterPayload,
    });
  }

  const payloadForFilter = [{ and: appliedFiltersPayload }];
  const sortCatalog = [];

  switch (selectedSort) {
    case 'skuAsc':
      sortCatalog.push(['Catalogue.style', 'asc']);
      break;
    case 'skuDesc':
      sortCatalog.push(['Catalogue.style', 'desc']);
      break;
    case 'brandAsc':
      sortCatalog.push(['Catalogue.brand', 'asc']);
      break;
    case 'brandDesc':
      sortCatalog.push(['Catalogue.brand', 'desc']);
      break;
  }
  return {
    dimensions: [
      'Catalogue.style',
      'Catalogue.stockxUrl',
      'Catalogue.brand',
      'Catalogue.itemName',
      'Catalogue.releaseDate',
      'Catalogue.shortDescription',
      'Catalogue.description',
      'Catalogue.men',
      'Catalogue.women',
      'Catalogue.child',
      'Catalogue.preschool',
      'Catalogue.infant',
      'Catalogue.toddler',
      'Catalogue.colorway',
    ],
    order: sortCatalog,
    filters: payloadForFilter,
    limit: limitForQuery,
    offset: userOffset,
  };
};
export const getPaginationCountForPayout = (
  userInput: any,
  filterInput: any
) => {
  const filterPayload = [];
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'ConsigneePayout.transferMode',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ConsigneePayout.payoutId',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];

  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'ConsigneePayout.payoutDate',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }

  if (filterInput?.status?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'ConsignmentLineItem.payoutStatus',
      operator: 'equals',
      values: filterInput.status,
    });
  }

  if (filterPayload.length > 0) {
    appliedFiltersPayload.push({
      and: filterPayload,
    });
  }

  const payloadForFilter = [{ and: appliedFiltersPayload }];
  return {
    measures: ['ConsigneePayout.count'],
    order: {
      'ConsigneePayout.payoutId': 'asc',
    },
    filters: payloadForFilter,
  };
};

export const getPaginationCountForCatlogue = (
  userInput: any,
  filterInput: any
) => {
  const filterPayload = [];
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };
  const splitInput = userInput?.split(' ');
  let appliedFiltersPayload = splitInput?.map((item: any) => {
    return {
      or: [
        {
          member: 'Catalogue.itemName',
          operator: 'contains',
          values: [item],
        },
        {
          member: 'Catalogue.style',
          operator: 'contains',
          values: [item],
        },
        {
          member: 'Catalogue.shortDescription',
          operator: 'contains',
          values: [item],
        },
      ],
    };
  });
  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'Catalogue.releaseDate',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }

  if (
    filterInput?.currentDate?.length > 0 &&
    filterInput?.createdDate?.length > 0
  ) {
    filterPayload.push({
      ...filterObj,
      member: 'Catalogue.releaseDate',
      operator: 'inDateRange',
      values: [filterInput.createdDate, filterInput.currentDate],
    });
  }
  if (filterInput?.brand?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'Catalogue.brand',
      operator: 'contains',
      values: filterInput.brand,
    });
  }

  if (filterPayload.length > 0) {
    appliedFiltersPayload.push({
      and: filterPayload,
    });
  }
  const payloadForFilter = [{ and: appliedFiltersPayload }];
  return {
    measures: ['Catalogue.count'],
    order: {
      'Catalogue.style': 'asc',
    },
    filters: payloadForFilter,
  };
};

export const getMyInventoryQuery = (
  userInput: any,
  selectedSort: string,
  filterInput: any,
  consignorId?: any,
  userOffset?: any,
  limitForQuery?: number
) => {
  const { userId }: any = getUserDetails();
  const filterPayload = [];
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };
  const consigneeIdFilter = {
    member: 'MyInventory.consigneeId',
    operator: 'equals',
    values: [`${consignorId}`],
  };

  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'MyInventory.sku',
          operator: 'equals',
          values: [userInput],
        },
        {
          member: 'MyInventory.brand',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'MyInventory.itemName',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'MyInventory.barcode',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];

  if (consignorId) {
    appliedFiltersPayload.push(consigneeIdFilter);
  }

  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'MyInventory.creationDate',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }

  if (
    filterInput?.currentDate?.length > 0 &&
    filterInput?.createdDate?.length > 0
  ) {
    filterPayload.push({
      ...filterObj,
      member: 'MyInventory.creationDate',
      operator: 'inDateRange',
      values: [filterInput.createdDate, filterInput.currentDate],
    });
  }
  if (filterInput?.brand?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'MyInventory.brand',
      operator: 'contains',
      values: filterInput.brand,
    });
  }

  if (filterPayload.length > 0) {
    appliedFiltersPayload.push({
      and: filterPayload,
    });
  }

  const payloadForFilter = [{ and: appliedFiltersPayload }];
  const sortInventory = [];

  switch (selectedSort) {
    case 'skuAsc':
      sortInventory.push(['MyInventory.sku', 'asc']);
      break;
    case 'skuDesc':
      sortInventory.push(['MyInventory.sku', 'desc']);
      break;
    case 'brandAsc':
      sortInventory.push(['MyInventory.brand', 'asc']);
      break;
    case 'brandDesc':
      sortInventory.push(['MyInventory.brand', 'desc']);
      break;
    case 'qtyLow':
      sortInventory.push([
        consignorId ? 'MyInventory.skuCount' : 'MyInventory.adminskuCount',
        'asc',
      ]);
      break;
    case 'qtyHigh':
      sortInventory.push([
        consignorId ? 'MyInventory.skuCount' : 'MyInventory.adminskuCount',
        'desc',
      ]);
      break;
  }

  return {
    dimensions: [
      'MyInventory.sku',
      'MyInventory.brand',
      'MyInventory.itemName',
      'MyInventory.imageUrl',
      consignorId ? 'MyInventory.skuCount' : 'MyInventory.adminskuCount',
    ],
    order: sortInventory,
    filters: payloadForFilter,
    limit: limitForQuery || undefined,
    offset: userOffset === 0 ? 0 : userOffset || undefined,
  };
};

export const getPaginationCountForInventory = (
  userInput: any,
  filterInput: any,
  consignorId: any
) => {
  const { userId }: any = getUserDetails();
  const filterPayload = [];
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };
  const consigneeIdFilter = {
    member: 'InventoryCount.consigneeId',
    operator: 'equals',
    values: [`${consignorId}`],
  };
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'InventoryCount.sku',
          operator: 'equals',
          values: [userInput],
        },
        {
          member: 'InventoryCount.brand',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'InventoryCount.name',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'InventoryCount.Barcode',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];
  if (consignorId) {
    appliedFiltersPayload.push(consigneeIdFilter);
  }
  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'InventoryCount.creationDate',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }

  if (
    filterInput?.currentDate?.length > 0 &&
    filterInput?.createdDate?.length > 0
  ) {
    filterPayload.push({
      ...filterObj,
      member: 'InventoryCount.creationDate',
      operator: 'inDateRange',
      values: [filterInput.createdDate, filterInput.currentDate],
    });
  }
  if (filterInput?.brand?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'InventoryCount.brand',
      operator: 'contains',
      values: filterInput.brand,
    });
  }

  if (filterPayload.length > 0) {
    appliedFiltersPayload.push({
      and: filterPayload,
    });
  }
  const payloadForFilter = [{ and: appliedFiltersPayload }];
  return {
    measures: ['InventoryCount.skuDistinctCount'],
    filters: payloadForFilter,
  };
};

export const getPaginationCountForSKU = (
  userInput: any,
  filterInput: any,
  skuId: any,
  userId?: any
) => {
  const filterPayload = [];
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'InventoryCount.sku',
          operator: 'equals',
          values: [userInput],
        },
        {
          member: 'InventoryCount.brand',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'InventoryCount.name',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'InventoryCount.Barcode',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'InventoryCount.conditionName',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'InventoryCount.Size',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
    { member: 'InventoryCount.sku', operator: 'equals', values: [skuId] },
  ];
  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'InventoryCount.creationDate',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }
  if (filterInput?.size?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'InventoryCount.Size',
      operator: 'contains',
      values: filterInput.size,
    });
  }
  if (!!userId) {
    filterPayload.push({
      ...filterObj,
      member: 'InventoryCount.consigneeId',
      operator: 'equals',
      values: [`${userId}`],
    });
  }
  if (
    filterInput?.currentDate?.length > 0 &&
    filterInput?.createdDate?.length > 0
  ) {
    filterPayload.push({
      ...filterObj,
      member: 'InventoryCount.creationDate',
      operator: 'inDateRange',
      values: [filterInput.createdDate, filterInput.currentDate],
    });
  }
  if (filterInput?.brand?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'InventoryCount.brand',
      operator: 'contains',
      values: filterInput.brand,
    });
  }
  if (filterInput?.status?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'InventoryCount.status',
      operator: 'contains',
      values: filterInput.status,
    });
  }

  if (filterPayload.length > 0) {
    appliedFiltersPayload.push({
      and: filterPayload,
    });
  }
  const payloadForFilter = [{ and: appliedFiltersPayload }];
  return !!userId
    ? {
        dimensions: [
          'InventoryCount.consigneeId',
          'InventoryCount.sku',
          userId
            ? 'InventoryCount.countBySku'
            : 'InventoryCount.countbyskuAdmin',
        ],
        measures: ['InventoryCount.count'],
        filters: payloadForFilter,
      }
    : {
        dimensions: ['InventoryCount.sku', 'InventoryCount.countbyskuAdmin'],
        measures: ['InventoryCount.count'],
        filters: payloadForFilter,
      };
};

export const getWeeklyOrders = (
  userInput: any,
  selectedSort: any,
  currentPath: any = '',
  filterInput: any,
  userOffset?: any,
  limitForQuery?: number,
  consignorId?: any,
  payoutDate?: any
) => {
  const { userId }: any = getUserDetails();
  const todaysDate = new Date();
  const sevenDaysPrevious = getDifferenceDate(todaysDate, 7);
  const endDate = getFormattedDate(todaysDate, FNS_DATE_FORMAT);
  const startDate = getFormattedDate(sevenDaysPrevious, FNS_DATE_FORMAT);

  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'WeeklyOrderData.orderId',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'WeeklyOrderData.sellerorderId',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'WeeklyOrderData.adminPayoutStatus',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];
  if (currentPath === CONSIGNMENT_ADMIN_INNER_PATH.CONSIGNMENT_PATH) {
    if (
      filterInput?.startDate?.length > 0 &&
      filterInput?.endDate?.length > 0
    ) {
      appliedFiltersPayload.push({
        member: 'WeeklyOrderData.completedAt',
        operator: 'inDateRange',
        values: [filterInput.startDate, filterInput.endDate],
      });
    } else {
      appliedFiltersPayload.push({
        member: 'WeeklyOrderData.completedAt',
        operator: 'inDateRange',
        values: [startDate, endDate],
      });
    }
  } else if (!consignorId && !payoutDate) {
    if (
      filterInput?.startDate?.length > 0 &&
      filterInput?.endDate?.length > 0
    ) {
      appliedFiltersPayload.push({
        member: 'WeeklyOrderData.completedAt',
        operator: 'inDateRange',
        values: [filterInput.startDate, filterInput.endDate],
      });
    }
  } else if (!!consignorId || !!payoutDate) {
    if (!!payoutDate)
      appliedFiltersPayload.push({
        member: 'WeeklyOrderData.completedAtDate',
        operator: 'equals',
        values: [payoutDate],
      });
    if (!!consignorId)
      appliedFiltersPayload.push({
        member: 'WeeklyOrderData.consigneeId',
        operator: 'equals',
        values: [consignorId],
      });
  }

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: !!consignorId
        ? 'WeeklyOrderData.payoutStatus'
        : 'WeeklyOrderData.adminPayoutStatus',
      operator: 'contains',
      values: filterInput.status,
    });
  }
  if (filterInput?.saleLocation?.length > 0) {
    appliedFiltersPayload.push({
      member: 'WeeklyOrderData.saleLocation',
      operator: 'equals',
      values: filterInput.saleLocation,
    });
  }

  const orderPayload = [];

  switch (selectedSort) {
    case 'amountLow':
      orderPayload.push(['WeeklyOrderData.totalpriceUsd', 'asc']);
      break;
    case 'amountHigh':
      orderPayload.push(['WeeklyOrderData.totalpriceUsd', 'desc']);
      break;
    case 'dateNew':
      orderPayload.push(['WeeklyOrderData.completedAt', 'desc']);
      break;
    case 'dateOld':
      orderPayload.push(['WeeklyOrderData.completedAt', 'asc']);
      break;
    case 'orderAsc':
      orderPayload.push(['WeeklyOrderData.orderId', 'asc']);
      break;
    case 'orderDesc':
      orderPayload.push(['WeeklyOrderData.orderId', 'desc']);
      break;
  }
  return {
    dimensions: !!consignorId
      ? [
          'WeeklyOrderData.orderId',
          'WeeklyOrderData.sellerorderId',
          'WeeklyOrderData.completedAt',
          //'WeeklyOrderData.adminPayoutStatus',
          'WeeklyOrderData.payoutStatus',
          'WeeklyOrderData.saleLocation',
          'WeeklyOrderData.processed',
        ]
      : [
          'WeeklyOrderData.orderId',
          'WeeklyOrderData.sellerorderId',
          'WeeklyOrderData.completedAt',
          'WeeklyOrderData.adminPayoutStatus',
          //'WeeklyOrderData.payoutStatus',
          'WeeklyOrderData.saleLocation',
        ],
    measures: [
      'WeeklyOrderData.weeklyOrderData',
      'WeeklyOrderData.totalSellingPrice',
      'WeeklyOrderData.quantitySum',
    ],
    filters: appliedFiltersPayload,
    order: orderPayload,
    limit: limitForQuery || undefined,
    offset: userOffset === 0 ? 0 : userOffset || undefined,
  };
};

export const getWeeklyOrdersTotalCount = (
  userInput: any,
  currentPath: any,
  filterInput: any,
  consignorId?: any
) => {
  const { userId }: any = getUserDetails();
  const todaysDate = new Date();
  const sevenDaysPrevious = getDifferenceDate(todaysDate, 7);
  const endDate = getFormattedDate(todaysDate, FNS_DATE_FORMAT);
  const startDate = getFormattedDate(sevenDaysPrevious, FNS_DATE_FORMAT);
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'WeeklyOrderData.orderId',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'WeeklyOrderData.adminPayoutStatus',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'WeeklyOrderData.sellerorderId',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];
  if (!!consignorId)
    appliedFiltersPayload.push({
      member: 'WeeklyOrderData.consigneeId',
      operator: 'equals',
      values: [consignorId],
    });
  if (currentPath === CONSIGNMENT_ADMIN_INNER_PATH.CONSIGNMENT_PATH) {
    if (
      filterInput?.startDate?.length > 0 &&
      filterInput?.endDate?.length > 0
    ) {
      appliedFiltersPayload.push({
        member: 'WeeklyOrderData.completedAt',
        operator: 'inDateRange',
        values: [filterInput.startDate, filterInput.endDate],
      });
    } else {
      appliedFiltersPayload.push({
        member: 'WeeklyOrderData.completedAt',
        operator: 'inDateRange',
        values: [startDate, endDate],
      });
    }
  } else {
    if (
      filterInput?.startDate?.length > 0 &&
      filterInput?.endDate?.length > 0
    ) {
      appliedFiltersPayload.push({
        member: 'WeeklyOrderData.completedAt',
        operator: 'inDateRange',
        values: [filterInput.startDate, filterInput.endDate],
      });
    }
  }

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: !!consignorId
        ? 'WeeklyOrderData.payoutStatus'
        : 'WeeklyOrderData.adminPayoutStatus',
      operator: 'contains',
      values: filterInput.status,
    });
  }
  if (filterInput?.saleLocation?.length > 0) {
    appliedFiltersPayload.push({
      member: 'WeeklyOrderData.saleLocation',
      operator: 'equals',
      values: filterInput.saleLocation,
    });
  }
  const orderPayload = [];

  return {
    measures: ['WeeklyOrderData.count'],
    filters: appliedFiltersPayload,
  };
};

export const getOrderDetailsById = (
  orderId: any,
  filterInput: any,
  selectedSort: any,
  userInput: any,
  payoutDate?: any,
  consignorId?: any
) => {
  const currentTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const isPayoutModuleFlag = !!payoutDate && !!consignorId ? true : false;

  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'OrdersViewData.userName',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'OrdersViewData.Barcode',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'OrdersViewData.sku',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'OrdersViewData.Name',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];
  if (!!orderId) {
    appliedFiltersPayload.push({
      member: 'OrdersViewData.sellerorderId',
      operator: 'equals',
      values: [`${orderId}`],
    });
    if (filterInput?.consignor?.length > 0) {
      appliedFiltersPayload.push({
        member: 'OrdersViewData.userName',
        operator: 'contains',
        values: filterInput.consignor,
      });
    }
  }

  if (!!consignorId) {
    appliedFiltersPayload.push({
      member: 'OrdersViewData.consigneeId',
      operator: 'equals',
      values: [`${consignorId}`],
    });
  }
  if (isPayoutModuleFlag) {
    appliedFiltersPayload.push({
      member: 'OrdersViewData.consigneeId',
      operator: 'equals',
      values: [`${consignorId}`],
    });

    appliedFiltersPayload.push({
      member: 'OrdersViewData.completedAtDate',
      operator: 'equals',
      values: [`${payoutDate}`],
    });
    if (filterInput?.saleLocation?.length > 0) {
      appliedFiltersPayload.push({
        member: 'OrdersViewData.LocationName',
        operator: 'contains',
        values: filterInput.saleLocation,
      });
    }
    if (filterInput?.brand?.length > 0) {
      appliedFiltersPayload.push({
        member: 'OrdersViewData.brandName',
        operator: 'contains',
        values: filterInput.brand,
      });
    }
  }

  const orderDetailsPayload = [];

  switch (selectedSort) {
    case 'sellingPriceHigh':
      orderDetailsPayload.push(['OrdersViewData.TotalpriceUsd', 'asc']);
      break;
    case 'sellingPriceLow':
      orderDetailsPayload.push(['OrdersViewData.TotalpriceUsd', 'desc']);
      break;
    case 'sizeAsc':
      orderDetailsPayload.push(['OrdersViewData.inventorySize', 'asc']);
      break;
    case 'sizeDesc':
      orderDetailsPayload.push(['OrdersViewData.inventorySize', 'desc']);
      break;
    case 'barcodeAsc':
      orderDetailsPayload.push(['OrdersViewData.Barcode', 'asc']);
      break;
    case 'barcodeDesc':
      orderDetailsPayload.push(['OrdersViewData.Barcode', 'desc']);
      break;
  }
  return isPayoutModuleFlag
    ? {
        dimensions: [
          'OrdersViewData.completedAt',
          'OrdersViewData.orderId_D',
          'OrdersViewData.userName',
          'OrdersViewData.LocationName',
          'OrdersViewData.sku',
          'OrdersViewData.Barcode',
          'OrdersViewData.brandName',
          'OrdersViewData.Name',
          'OrdersViewData.imageUrl',
          'OrdersViewData.transactiontraceId',
          'OrdersViewData.payoutStatus',
          'OrdersViewData.orderQuantity',
          'OrdersViewData.inventorySize',
          'OrdersViewData.conditionName',
          'OrdersViewData.consignmentlineitemId_D',
          'OrdersViewData.TotalpriceUsd',
          'OrdersViewData.payoutAmount',
          'OrdersViewData.consigneeId',
          'OrdersViewData.costperItem',
        ],
        measures: ['OrdersViewData.count', 'OrdersViewData.payoutTotal'],
        timeDimensions: [{ dimension: 'OrdersViewData.completedAt' }],
        filters: appliedFiltersPayload,
        order: orderDetailsPayload,
      }
    : {
        dimensions: [
          'OrdersViewData.orderId_D',
          'OrdersViewData.completedAt',
          'OrdersViewData.LocationName',
          'OrdersViewData.sku',
          'OrdersViewData.Barcode',
          'OrdersViewData.brandName',
          'OrdersViewData.Name',
          'OrdersViewData.userName',
          'OrdersViewData.imageUrl',
          'OrdersViewData.transactiontraceId',
          'OrdersViewData.payoutStatus',
          'OrdersViewData.inventorySize',
          'OrdersViewData.conditionName',
          'OrdersViewData.consignmentlineitemId_D',
          'OrdersViewData.completedAt.second',
          'OrdersViewData.costperItem',
        ],
        measures: [
          'OrdersViewData.payoutAmount',
          'OrdersViewData.TotalpriceUsd',
          'OrdersViewData.orderQuantity',
          'OrdersViewData.count',
        ],
        timezone: currentTimezone,
        filters: appliedFiltersPayload,
        order: orderDetailsPayload,
      };
};

export const getTotalOrderDetailsById = (orderId: any, consignorId?: any) => {
  const currentTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const appliedFiltersPayload = [
    {
      member: 'OrdersViewData.sellerorderId',
      operator: 'equals',
      values: [`${orderId}`],
    },
  ];
  if (!!consignorId) {
    appliedFiltersPayload.push({
      member: 'OrdersViewData.consigneeId',
      operator: 'equals',
      values: [`${consignorId}`],
    });
  }
  return {
    measures: [
      'OrdersViewData.TotalpriceUsd',
      'OrdersViewData.payoutAmount',
      'OrdersViewData.count',
    ],
    timezone: currentTimezone,
    filters: appliedFiltersPayload,
  };
};

export const getConsignmentQuery = (
  userInput: any,
  userOffset: any,
  selectedSort: any,
  filterInput: any,
  userDetails: any,
  limit = 8
) => {
  const consignmentSortPayload = [];

  switch (selectedSort) {
    case 'qtyLow':
      consignmentSortPayload.push(['ConsignmentData.Quantity', 'asc']);
      break;
    case 'qtyHigh':
      consignmentSortPayload.push(['ConsignmentData.Quantity', 'desc']);
      break;
    case 'dateNew':
      consignmentSortPayload.push(['ConsignmentData.creationTime', 'desc']);
      break;
    case 'dateOld':
      consignmentSortPayload.push(['ConsignmentData.creationTime', 'asc']);
      break;
    case 'consignmentIdAsc':
      consignmentSortPayload.push(['ConsignmentData.consignmentId', 'asc']);
      break;
    case 'consignmentIdDesc':
      consignmentSortPayload.push(['ConsignmentData.consignmentId', 'desc']);
      break;
  }

  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'ConsignmentData.consignmentId_D',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ConsignmentData.consignmentStatus',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ConsignmentData.barcode',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ConsignmentData.userName',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];

  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsignmentData.creationTime',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsignmentData.consignmentStatus',
      operator: 'contains',
      values: filterInput.status,
    });
  }

  return {
    dimensions: [
      'ConsignmentData.consignmentId',
      'ConsignmentData.Quantity',
      'ConsignmentData.creationTime',
      'ConsignmentData.consignmentStatus',
      'ConsignmentData.userName',
    ],
    order: consignmentSortPayload,
    filters: appliedFiltersPayload,
    limit: limit,
    offset: userOffset,
  };
};

export const getPaginationCountForConsignment = (
  userInput: any,
  filterInput: any,
  userDetails: any
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'ConsignmentData.consignmentId_D',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ConsignmentData.consignmentStatus',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ConsignmentData.barcode',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ConsignmentData.userName',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];

  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsignmentData.creationTime',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsignmentData.consignmentStatus',
      operator: 'contains',
      values: filterInput.status,
    });
  }

  return {
    measures: ['ConsignmentData.count'],
    filters: appliedFiltersPayload,
  };
};

export const getShoeSize = () => {
  return {
    dimensions: ['ConsigneeSize.Size', 'ConsigneeSize.menSize'],
    order: [['ConsigneeSize.menSize', 'asc']],
  };
};

export const shoeDetails = (
  consignmentLineItemId: any,
  currentPath: any,
  isShoeCatalog = false,
  isSearchWithBarcode = false
) => {
  const currentTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const appliedFiltersPayload = [];
  if (isSearchWithBarcode) {
    appliedFiltersPayload.push({
      member: 'OrdersShoeDetails.barcode',
      operator: 'equals',
      values: [consignmentLineItemId?.toString()],
    });
  } /* 
  this is commented for future ref.
  else if (
    currentPath === CONSIGNMENT_ADMIN_INNER_PATH.CONSIGNMENTS_SKU_DETAILS_PATH
  ) {
    appliedFiltersPayload.push({
      member: 'OrdersShoeDetails.consignmentID',
      operator: 'equals',
      values: [consignmentLineItemId?.toString()],
    });
  } */ else {
    appliedFiltersPayload.push({
      member: 'OrdersShoeDetails.consignmentlineitemId_D',
      operator: 'equals',
      values: [consignmentLineItemId?.toString()],
    });
  }
  return {
    dimensions: [
      'OrdersShoeDetails.brandName',
      'OrdersShoeDetails.productDescription',
      'OrdersShoeDetails.Name',
      'OrdersShoeDetails.shortDescription',
      'OrdersShoeDetails.style',
      'OrdersShoeDetails.releaseDate',
      'OrdersShoeDetails.colorway',
      'OrdersShoeDetails.eventType',
      'OrdersShoeDetails.eventTime',
      'OrdersShoeDetails.eventTime.second',
      'OrdersShoeDetails.description',
      'OrdersShoeDetails.userName',
      'OrdersShoeDetails.consignmentlineitemId_D',
      'OrdersShoeDetails.saleLocation',
      'OrdersShoeDetails.status',
      'OrdersShoeDetails.createdAt',
      'OrdersShoeDetails.barcode',
      'OrdersShoeDetails.conditionName',
      'OrdersShoeDetails.size',
      'OrdersShoeDetails.retailPrice_D',
      'OrdersShoeDetails.payoutAmount',
      'OrdersShoeDetails.costPerItem',
      'OrdersShoeDetails.Quantity',
    ],
    order: [['OrdersShoeDetails.eventTime', 'desc']],
    filters: appliedFiltersPayload,
    timezone: currentTimezone,
    timeDimensions: [
      {
        dimension: 'OrdersShoeDetails.eventTime',
        granularity: 'second',
      },
    ],
  };
};
export const getConsignmentDetailsById = (
  consignmentId: any,
  userInput: any,
  selectedSort: any,
  filterInput: any,
  userDetails: any,
  offset: any,
  limit: any
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'ConsignmentviewDetails.sku',
          operator: 'equals',
          values: [userInput],
        },
        {
          member: 'ConsignmentviewDetails.status',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
    {
      member: 'ConsignmentviewDetails.consignmentID',
      operator: 'equals',
      values: [consignmentId],
    },
  ];

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsignmentviewDetails.status',
      operator: 'contains',
      values: filterInput.status,
    });
  }

  if (filterInput?.sku?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsignmentviewDetails.sku',
      operator: 'equals',
      values: filterInput.sku,
    });
  }
  if (filterInput?.product?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsignmentviewDetails.itemName',
      operator: 'contains',
      values: filterInput.product,
    });
  }
  const consignmentDetailsPayload = [];

  switch (selectedSort) {
    case 'skuAsc':
      consignmentDetailsPayload.push(['ConsignmentviewDetails.sku', 'asc']);
      break;
    case 'skuDesc':
      consignmentDetailsPayload.push(['ConsignmentviewDetails.sku', 'desc']);
      break;
    case 'qtyLow':
      consignmentDetailsPayload.push([
        'ConsignmentviewDetails.skulevelCount',
        'asc',
      ]);
      break;
    case 'qtyHigh':
      consignmentDetailsPayload.push([
        'ConsignmentviewDetails.skulevelCount',
        'desc',
      ]);
      break;
  }
  return {
    dimensions: [
      'ConsignmentviewDetails.consignmentID',
      'ConsignmentviewDetails.creationTime',
      'ConsignmentviewDetails.consignmentStatus',
      'ConsignmentviewDetails.numberofItems',
      'ConsignmentviewDetails.consignment_value',
      'ConsignmentviewDetails.sku',
      'ConsignmentviewDetails.itemName',
      'ConsignmentviewDetails.skulevelCount',
      'ConsignmentviewDetails.status',
      'ConsignmentviewDetails.consigneeId',
      'ConsignmentviewDetails.userName',
      'ConsignmentviewDetails.emailId',
      'ConsignmentviewDetails.PhoneNumber',
    ],
    order: consignmentDetailsPayload,
    filters: appliedFiltersPayload,
    offset: offset,
    limit: limit,
  };
};

export const getConsignmentDetailsByIdPaginationCount = (
  consignmentId: any,
  userInput: any,
  selectedSort: any,
  filterInput: any,
  userDetails: any
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'ConsignmentviewDetails.sku',
          operator: 'equals',
          values: [userInput],
        },
        {
          member: 'ConsignmentviewDetails.status',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
    {
      member: 'ConsignmentviewDetails.consignmentID',
      operator: 'equals',
      values: [consignmentId],
    },
  ];

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsignmentviewDetails.status',
      operator: 'contains',
      values: filterInput.status,
    });
  }

  if (filterInput?.sku?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsignmentviewDetails.sku',
      operator: 'equals',
      values: filterInput.sku,
    });
  }
  if (filterInput?.product?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsignmentviewDetails.itemName',
      operator: 'contains',
      values: filterInput.product,
    });
  }
  const consignmentDetailsPayload = [];

  switch (selectedSort) {
    case 'skuAsc':
      consignmentDetailsPayload.push(['ConsignmentviewDetails.sku', 'asc']);
      break;
    case 'skuDesc':
      consignmentDetailsPayload.push(['ConsignmentviewDetails.sku', 'desc']);
      break;
    case 'qtyLow':
      consignmentDetailsPayload.push([
        'ConsignmentviewDetails.skulevelCount',
        'asc',
      ]);
      break;
    case 'qtyHigh':
      consignmentDetailsPayload.push([
        'ConsignmentviewDetails.skulevelCount',
        'desc',
      ]);
      break;
  }
  return {
    measures: ['ConsignmentviewDetails.count'],
    order: [['ConsignmentviewDetails.sku', 'asc']],
    filters: appliedFiltersPayload,
  };
};
export const getInvetoryDetailsById = (
  skuId: any,
  searchInput: any,
  selectedSort: any,
  filterInput: any,
  offset?: any,
  limit?: any,
  userId?: any
) => {
  let viewFilterValue: any = [];
  const obj = {
    member: '',
    operator: 'contains',
    values: [],
  };
  if (skuId || skuId === undefined || skuId === '') {
    viewFilterValue.push({
      ...obj,
      member: 'InventorySkuDetails.style',
      values: [skuId],
    });
  }
  if (searchInput) {
    viewFilterValue.push({
      or: [
        {
          member: 'InventorySkuDetails.Size',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'InventorySkuDetails.status',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'InventorySkuDetails.barcode',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'InventorySkuDetails.conditionName',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'InventorySkuDetails.locationName',
          operator: 'contains',
          values: [searchInput],
        },
      ],
    });
  }
  if (filterInput?.status?.length > 0) {
    viewFilterValue.push({
      ...obj,
      member: 'InventorySkuDetails.status',
      operator: 'contains',
      values: filterInput.status,
    });
  }
  if (filterInput?.size?.length > 0) {
    viewFilterValue.push({
      ...obj,
      member: 'InventorySkuDetails.Size',
      operator: 'contains',
      values: filterInput.size,
    });
  }
  if (!!userId) {
    viewFilterValue.push({
      ...obj,
      member: 'InventorySkuDetails.consigneeId',
      operator: 'equals',
      values: [`${userId}`],
    });
  }
  if (
    filterInput?.createdDate?.length > 0 &&
    filterInput?.currentDate?.length > 0
  ) {
    viewFilterValue.push({
      ...obj,
      member: 'InventorySkuDetails.releaseDate',
      operator: 'inDateRange',
      values: [filterInput.createdDate, filterInput.currentDate],
    });
  }
  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    viewFilterValue.push({
      ...obj,
      member: 'InventorySkuDetails.releaseDate',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }

  if (filterInput?.brand?.length > 0) {
    viewFilterValue.push({
      ...obj,
      member: 'InventorySkuDetails.brand',
      operator: 'contains',
      values: filterInput.brand,
    });
  }
  const viewSkuDetailsById = [];
  switch (selectedSort) {
    case 'sizeAsc':
      viewSkuDetailsById.push(['InventorySkuDetails.Size', 'asc']);
      break;
    case 'sizeDesc':
      viewSkuDetailsById.push(['InventorySkuDetails.Size', 'desc']);
      break;
    case 'statusAsc':
      viewSkuDetailsById.push(['InventorySkuDetails.status', 'asc']);
      break;
    case 'statusDesc':
      viewSkuDetailsById.push(['InventorySkuDetails.status', 'desc']);
      break;
    case 'sellingPriceAsc':
      viewSkuDetailsById.push(['InventorySkuDetails.retailPrice_D', 'asc']);
      break;
    case 'sellingPriceDesc':
      viewSkuDetailsById.push(['InventorySkuDetails.retailPrice_D', 'desc']);
      break;
  }
  return {
    dimensions: [
      'InventorySkuDetails.locationId',
      'InventorySkuDetails.itemName',
      'InventorySkuDetails.brand',
      'InventorySkuDetails.style',
      'InventorySkuDetails.colorway',
      'InventorySkuDetails.releaseDate',
      'InventorySkuDetails.Size',
      'InventorySkuDetails.conditionName',
      'InventorySkuDetails.status',
      'InventorySkuDetails.retailPrice_D',
      'InventorySkuDetails.payoutAmount',
      'InventorySkuDetails.consignmentlineitemId_D',
      'InventorySkuDetails.consigneeId',
      'InventorySkuDetails.barcode',
      'InventorySkuDetails.variantCount',
      'InventorySkuDetails.actualReleaseDate',
      'InventorySkuDetails.productId',
      'InventorySkuDetails.costperItem',
      'InventorySkuDetails.locationName',
    ],
    order: viewSkuDetailsById,
    filters: viewFilterValue,
    limit: limit || undefined,
    offset: offset === 0 ? 0 : offset || undefined,
  };
};

export const getSkuDetailsByIdQuery = (
  ConsignmentId: any,
  SkuId: any,
  userInput: any,
  selectedSort: any,
  filterInput: any,
  userDetails: any
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'ConsignmentSkuDetails.size',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ConsignmentSkuDetails.status',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'ConsignmentSkuDetails.Barcode',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
    {
      member: 'ConsignmentSkuDetails.consignmentID',
      operator: 'equals',
      values: [ConsignmentId],
    },

    {
      member: 'ConsignmentSkuDetails.style',
      operator: 'equals',
      values: [SkuId],
    },
  ];

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsignmentSkuDetails.status',
      operator: 'contains',
      values: filterInput.status,
    });
  }

  if (filterInput?.size?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsignmentSkuDetails.size',
      operator: 'contains',
      values: filterInput.size,
    });
  }
  const skuDetailsPayload = [];

  switch (selectedSort) {
    case 'sizeAsc':
      skuDetailsPayload.push(['ConsignmentSkuDetails.size', 'asc']);
      break;
    case 'sizeDesc':
      skuDetailsPayload.push(['ConsignmentSkuDetails.size', 'desc']);
      break;
    case 'sellingPriceAsc':
      skuDetailsPayload.push(['ConsignmentSkuDetails.retailPrice_D', 'asc']);
      break;
    case 'sellingPriceDesc':
      skuDetailsPayload.push(['ConsignmentSkuDetails.retailPrice_D', 'desc']);
      break;
    case 'statusAsc':
      skuDetailsPayload.push(['ConsignmentSkuDetails.status', 'asc']);
      break;
    case 'statusDesc':
      skuDetailsPayload.push(['ConsignmentSkuDetails.status', 'desc']);
      break;
  }
  return {
    dimensions: [
      'ConsignmentSkuDetails.consignmentID',
      'ConsignmentSkuDetails.itemName',
      'ConsignmentSkuDetails.description',
      'ConsignmentSkuDetails.Quantity',
      'ConsignmentSkuDetails.style',
      'ConsignmentSkuDetails.colorway',
      'ConsignmentSkuDetails.sizeType',
      'ConsignmentSkuDetails.size',
      'ConsignmentSkuDetails.conditionName',
      'ConsignmentSkuDetails.releaseDate',
      'ConsignmentSkuDetails.retailPrice_D',
      'ConsignmentSkuDetails.payoutAmount',
      'ConsignmentSkuDetails.status',
      'ConsignmentSkuDetails.Barcode',
      'ConsignmentSkuDetails.consignmentlineitemId_D',
      'ConsignmentSkuDetails.costperItem',
    ],
    order: skuDetailsPayload,
    filters: appliedFiltersPayload,
  };
};
export const getPayoutDetailsForHeader = (userId?: number) => {
  let appliedFiltersPayload: any = [
    {
      member: 'Payout.consigneeid_D',
      operator: 'equals',
      values: [`${userId}`],
    },
  ];
  return {
    dimensions: [
      'Payout.consigneeid_D',
      'Payout.Name',
      'Payout.Commission',
      'Payout.totalPayoutAmount',
      'Payout.totalWithdrawalAmount',
      'Payout.requestAmount',
      'Payout.balanceAmount',
    ],
    filters: appliedFiltersPayload,
  };
};

export const getPayoutDetails = (
  userInput: any,
  selectedSort: string,
  filterInput: any,
  limitForQuery?: number,
  userOffset?: number,
  userId?: number
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'Payout.Commission',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'Payout.Name',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'Payout.consigneeid_D',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];
  if (!!userId) {
    appliedFiltersPayload.push({
      member: 'Payout.consigneeid_D',
      operator: 'equals',
      values: [`${userId}`],
    });
  }
  if (filterInput?.commission?.length > 0) {
    appliedFiltersPayload.push({
      member: 'Payout.Commission',
      operator: 'equals',
      values: filterInput.commission,
    });
  }

  let payoutDetailsSortPayload = [];

  switch (selectedSort) {
    case 'commissionAsc':
      payoutDetailsSortPayload.push(['Payout.Commission', 'asc']);
      break;
    case 'commissionDesc':
      payoutDetailsSortPayload.push(['Payout.Commission', 'desc']);
      break;
    case 'amountLow':
      payoutDetailsSortPayload.push(['Payout.totalPayoutAmount', 'asc']);
      break;
    case 'amountHigh':
      payoutDetailsSortPayload.push(['Payout.totalPayoutAmount', 'desc']);
      break;
    case 'requestAmountLow':
      payoutDetailsSortPayload.push(['Payout.requestAmount', 'asc']);
      break;
    case 'requestAmountHigh':
      payoutDetailsSortPayload.push(['Payout.requestAmount', 'desc']);
      break;
  }

  return {
    dimensions: [
      'Payout.consigneeid_D',
      'Payout.Name',
      'Payout.Commission',
      'Payout.totalPayoutAmount',
      'Payout.totalWithdrawalAmount',
      'Payout.requestAmount',
      'Payout.balanceAmount',
    ],
    filters: appliedFiltersPayload,
    order: payoutDetailsSortPayload,
    limit: limitForQuery || undefined,
    offset: userOffset === 0 ? 0 : userOffset || undefined,
  };
};
export const getPayoutDetailsPagination = (
  userInput: any,
  filterInput: any
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'Payout.Commission',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'Payout.Name',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'Payout.consigneeid_D',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];

  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'Payout.status',
      operator: 'contains',
      values: filterInput.status,
    });
  }

  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    appliedFiltersPayload.push({
      member: 'Payout.dateAdded',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }

  return {
    measures: ['Payout.count'],
    filters: appliedFiltersPayload,
  };
};

export const getShoeImages = (skuId: any) => {
  return {
    dimensions: [
      'ConsignmentShoeDetails.imageUrl',
      'ConsignmentShoeDetails.style',
    ],
    filters: [
      {
        member: 'ConsignmentShoeDetails.style',
        operator: 'contains',
        values: [skuId],
      },
    ],
  };
};

export const getConsignorListPagination = (
  searchInput: any,
  filterData: any,
  selectedSort: any
) => {
  const sortConsignor = [];
  switch (selectedSort) {
    case 'consignorIdAsc':
      sortConsignor.push(['Users.userId_D', 'asc']);
      break;
    case 'consignorIdDesc':
      sortConsignor.push(['Users.userId_D', 'desc']);
      break;
    case 'statusAsc':
      sortConsignor.push(['Users.status', 'asc']);
      break;
    case 'statusDesc':
      sortConsignor.push(['Users.status', 'desc']);
      break;
    case 'commissionAsc':
      sortConsignor.push(['ConsigneeType.name', 'asc']);
      break;
    case 'commissionDesc':
      sortConsignor.push(['ConsigneeType.name', 'desc']);
      break;
    case 'dateAddedAsc':
      sortConsignor.push(['Users.createdAt', 'asc']);
      break;
    case 'dateAddedDesc':
      sortConsignor.push(['Users.createdAt', 'desc']);
      break;
  }
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'Users.userName',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Users.emailId',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Users.PhoneNumber',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'ConsigneeType.name',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Users.userId_D',
          operator: 'contains',
          values: [searchInput],
        },
      ],
    },
    { member: 'Users.isOauth', operator: 'equals', values: ['false'] },
  ];
  if (filterData?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'Users.status',
      operator: 'contains',
      values: filterData.status,
    });
  }
  if (filterData?.commission?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsigneeType.name',
      operator: 'contains',
      values: filterData.commission,
    });
  }

  return {
    measures: ['Users.count'],
    order: sortConsignor,
    filters: appliedFiltersPayload,
  };
};
export const getConsignorList = (
  searchInput: any,
  filterData: any,
  selectedSort: any,
  limitForQuery?: number,
  userOffset?: number
) => {
  const sortConsignor = [];
  switch (selectedSort) {
    case 'consignorIdAsc':
      sortConsignor.push(['Users.userId', 'asc']);
      break;
    case 'consignorIdDesc':
      sortConsignor.push(['Users.userId', 'desc']);
      break;
    case 'statusAsc':
      sortConsignor.push(['Users.status', 'asc']);
      break;
    case 'statusDesc':
      sortConsignor.push(['Users.status', 'desc']);
      break;
    case 'commissionAsc':
      sortConsignor.push(['ConsigneeType.name', 'asc']);
      break;
    case 'commissionDesc':
      sortConsignor.push(['ConsigneeType.name', 'desc']);
      break;
    case 'dateAddedAsc':
      sortConsignor.push(['Users.createdAt', 'asc']);
      break;
    case 'dateAddedDesc':
      sortConsignor.push(['Users.createdAt', 'desc']);
      break;
  }
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'Users.userName',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Users.emailId',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Users.PhoneNumber',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'ConsigneeType.name',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Users.userId_D',
          operator: 'contains',
          values: [searchInput],
        },
      ],
    },
    { member: 'Users.isOauth', operator: 'equals', values: ['false'] },
  ];
  if (filterData?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'Users.status',
      operator: 'contains',
      values: filterData.status,
    });
  }
  if (filterData?.commission?.length > 0) {
    appliedFiltersPayload.push({
      member: 'ConsigneeType.name',
      operator: 'contains',
      values: filterData.commission,
    });
  }
  return {
    dimensions: [
      'Users.userId',
      'Users.emailId',
      'Users.status',
      'Users.createdAt',
      'Users.PhoneNumber',
      'Users.userName',
      'ConsigneeType.name',
    ],
    order: sortConsignor,
    filters: appliedFiltersPayload,
    limit: limitForQuery || undefined,
    offset: userOffset === 0 ? 0 : userOffset || undefined,
  };
};

export const getLocationsListPagination = (
  filterInput: any,
  searchInput: any
) => {
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'Locations.locationID_D',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Locations.name',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Locations.city',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Locations.province',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Locations.locationType',
          operator: 'contains',
          values: [searchInput],
        },
      ],
    },
  ];
  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'Locations.Status',
      operator: 'equals',
      values: filterInput.status,
    });
  }
  if (filterInput?.type?.length > 0) {
    appliedFiltersPayload.push({
      member: 'Locations.locationType',
      operator: 'contains',
      values: filterInput.type,
    });
  }
  return {
    measures: ['Locations.count'],
    filters: appliedFiltersPayload,
  };
};
export const getLocationsList = (
  searchInput: any,
  filterInput: any,
  selectedSort: any,
  limitForQuery?: number,
  userOffset?: number
) => {
  const sortConsignor = [];
  switch (selectedSort) {
    case 'newestLocation':
      sortConsignor.push(['Locations.createdAt', 'desc']);
      break;
    case 'OldestLocation':
      sortConsignor.push(['Locations.createdAt', 'asc']);
      break;
    case 'locationStatusAsc':
      sortConsignor.push(['Locations.Status', 'asc']);
      break;
    case 'locationStatusDesc':
      sortConsignor.push(['Locations.Status', 'desc']);
      break;
    case 'locationStateAsc':
      sortConsignor.push(['Locations.province', 'asc']);
      break;
    case 'locationStateDesc':
      sortConsignor.push(['Locations.province', 'desc']);
      break;
    case 'locationCityAsc':
      sortConsignor.push(['Locations.city', 'asc']);
      break;
    case 'locationCityDesc':
      sortConsignor.push(['Locations.city', 'desc']);
      break;
  }
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'Locations.locationID_D',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Locations.name',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Locations.city',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Locations.province',
          operator: 'contains',
          values: [searchInput],
        },
        {
          member: 'Locations.locationType',
          operator: 'contains',
          values: [searchInput],
        },
      ],
    },
  ];
  if (filterInput?.status?.length > 0) {
    appliedFiltersPayload.push({
      member: 'Locations.Status',
      operator: 'equals',
      values: filterInput.status,
    });
  }

  if (filterInput?.type?.length > 0) {
    appliedFiltersPayload.push({
      member: 'Locations.locationType',
      operator: 'contains',
      values: filterInput.type,
    });
  }
  return {
    dimensions: [
      'Locations.locationID_D',
      'Locations.name',
      'Locations.city',
      'Locations.province',
      'Locations.Status',
      'Locations.locationType',
      'Locations.createdAt',
    ],
    order: sortConsignor,
    filters: appliedFiltersPayload,
    limit: limitForQuery || undefined,
    offset: userOffset === 0 ? 0 : userOffset || undefined,
  };
};
export const getSkuDetailsForPrintLabels = (ConsignmentId: any, SkuId: any) => {
  let appliedFiltersPayload: any = [
    {
      member: 'ConsignmentSkuDetails.consignmentID',
      operator: 'equals',
      values: [ConsignmentId],
    },
    {
      member: 'ConsignmentSkuDetails.style',
      operator: 'contains',
      values: SkuId,
    },
  ];

  return {
    dimensions: [
      'ConsignmentSkuDetails.consignmentID',
      'ConsignmentSkuDetails.itemName',
      'ConsignmentSkuDetails.Quantity',
      'ConsignmentSkuDetails.style',
      'ConsignmentSkuDetails.colorway',
      'ConsignmentSkuDetails.sizeType',
      'ConsignmentSkuDetails.size',
      'ConsignmentSkuDetails.releaseDate',
      'ConsignmentSkuDetails.retailPrice_D',
      'ConsignmentSkuDetails.payoutAmount',
      'ConsignmentSkuDetails.Barcode',
      'ConsignmentSkuDetails.status',
    ],
    filters: ConsignmentId ? appliedFiltersPayload : [],
  };
};

export const getLocationsListForConsignmentReviewPopup = () => {
  return {
    dimensions: ['Locations.locationID_D', 'Locations.name', 'Locations.city'],
    filters: [
      { member: 'Locations.active', operator: 'equals', values: ['true'] },
    ],
  };
};

export const getConsignorProfileData = (consignorId: any) => {
  return {
    dimensions: ['ConsignorProfile.id'],
    measures: [
      'ConsignorProfile.payoutAmount',
      'ConsignorProfile.totalLineItemsPrice',
    ],
    filters: [
      {
        member: 'ConsignorProfile.id',
        operator: 'equals',
        values: [consignorId],
      },
    ],
  };
};
export const getPrintLabelsData = (
  userInput: any,
  selectedSort: any,
  filterInput: any,
  userOffset?: any,
  userLimit?: any,
  selectedConsignor?: any,
  selectedStore?: any,
  startDateRange?: any,
  endDateRange?: any
) => {
  const endDate =
    endDateRange && getFormattedDate(endDateRange, FNS_DATE_FORMAT);
  const startDate =
    startDateRange && getFormattedDate(startDateRange, FNS_DATE_FORMAT);
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'printLabel.Sku',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'printLabel.brand',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'printLabel.itemName',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'printLabel.Barcode',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];
  if (!!selectedStore) {
    appliedFiltersPayload.push({
      member: 'printLabel.Location',
      operator: 'equals',
      values: [selectedStore],
    });
  }

  if (!!selectedConsignor) {
    appliedFiltersPayload.push({
      member: 'printLabel.consigneeId',
      operator: 'equals',
      values: [`${selectedConsignor}`],
    });
  }

  if (startDate?.length > 0 && endDate?.length > 0) {
    appliedFiltersPayload.push({
      member: 'printLabel.createdAt',
      operator: 'inDateRange',
      values: [startDate, endDate],
    });
  }

  if (filterInput?.brand?.length > 0) {
    appliedFiltersPayload.push({
      ...filterObj,
      member: 'printLabel.brand',
      operator: 'contains',
      values: filterInput.brand,
    });
  }
  if (filterInput?.size?.length > 0) {
    appliedFiltersPayload.push({
      ...filterObj,
      member: 'printLabel.Size',
      operator: 'contains',
      values: filterInput?.size,
    });
  }

  appliedFiltersPayload.push({
    ...filterObj,
    member: 'printLabel.status',
    operator: 'contains',
    values: ['Active'],
  });

  const orderPayload = [];

  switch (selectedSort) {
    case 'createAT:ASC':
      orderPayload.push(['printLabel.createdAt', 'asc']);
      break;
    case 'createAT:DSC':
      orderPayload.push(['printLabel.createdAt', 'desc']);
      break;
    case 'retailPriceLow':
      orderPayload.push(['printLabel.retailPrice_D', 'asc']);
      break;
    case 'retailPriceHigh':
      orderPayload.push(['printLabel.retailPrice_D', 'desc']);
      break;
    case 'brandLow':
      orderPayload.push(['printLabel.brand', 'asc']);
      break;
    case 'brandHigh':
      orderPayload.push(['printLabel.brand', 'desc']);
      break;

    case 'skuUp':
      orderPayload.push(['printLabel.Sku', 'asc']);
      break;
    case 'skuDown':
      orderPayload.push(['printLabel.Sku', 'desc']);
      break;

    case 'sizeUp':
      orderPayload.push(['printLabel.Size', 'asc']);
      break;
    case 'sizeDown':
      orderPayload.push(['printLabel.Size', 'desc']);
      break;
    default:
      orderPayload.push(['printLabel.brand', 'desc']);
      break;
  }
  return {
    dimensions: [
      'printLabel.Barcode',
      'printLabel.Sku',
      'printLabel.imageUrl',
      'printLabel.brand',
      'printLabel.itemName',
      'printLabel.createdAt',
      'printLabel.Consignor',
      'printLabel.Size',
      'printLabel.retailPrice_D',
      'printLabel.Location',
      'printLabel.status',
    ],
    filters: appliedFiltersPayload,
    order: orderPayload,
    offset: userOffset === 0 ? 0 : userOffset || undefined,
    limit: userLimit || undefined,
  };
};

export const getPrintLabelsDataPagination = (
  userInput: any,
  selectedSort: any,
  filterInput: any,
  selectedConsignor?: any,
  selectedStore?: any,
  startDateRange?: any,
  endDateRange?: any
) => {
  const endDate =
    endDateRange && getFormattedDate(endDateRange, FNS_DATE_FORMAT);
  const startDate =
    startDateRange && getFormattedDate(startDateRange, FNS_DATE_FORMAT);
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'printLabel.Sku',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'printLabel.brand',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'printLabel.itemName',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'printLabel.Barcode',
          operator: 'contains',
          values: [userInput],
        },
      ],
    },
  ];
  if (!!selectedStore) {
    appliedFiltersPayload.push({
      member: 'printLabel.Location',
      operator: 'equals',
      values: [selectedStore],
    });
  }

  if (!!selectedConsignor) {
    appliedFiltersPayload.push({
      member: 'printLabel.consigneeId',
      operator: 'equals',
      values: [`${selectedConsignor}`],
    });
  }

  if (startDate?.length > 0 && endDate?.length > 0) {
    appliedFiltersPayload.push({
      member: 'printLabel.createdAt',
      operator: 'inDateRange',
      values: [startDate, endDate],
    });
  }

  if (filterInput?.brand?.length > 0) {
    appliedFiltersPayload.push({
      ...filterObj,
      member: 'printLabel.brand',
      operator: 'contains',
      values: filterInput.brand,
    });
  }
  if (filterInput?.size?.length > 0) {
    appliedFiltersPayload.push({
      ...filterObj,
      member: 'printLabel.Size',
      operator: 'contains',
      values: filterInput?.size,
    });
  }

  appliedFiltersPayload.push({
    ...filterObj,
    member: 'printLabel.status',
    operator: 'contains',
    values: ['Active'],
  });

  return {
    measures: ['printLabel.count'],
    filters: appliedFiltersPayload,
  };
};
export const getPaginationCountForPayoutHistory = (
  userDetails: any,
  userInput: any,
  filterInput: any
) => {
  const filterPayload = [];
  const filterObj = {
    member: '',
    operator: '',
    values: [],
  };
  let appliedFiltersPayload: any = [
    {
      or: [
        {
          member: 'PayoutHistory.transferMode',
          operator: 'contains',
          values: [userInput],
        },
        {
          member: 'PayoutHistory.consigneePayoutId',
          operator: 'set',
          values: [userInput],
        },
      ],
    },
    {
      member: 'PayoutHistory.consigneeId',
      operator: 'equals',
      values: [userDetails?.user_id?.toString()],
    },
  ];

  if (filterInput?.startDate?.length > 0 && filterInput?.endDate?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'PayoutHistory.payoutDate',
      operator: 'inDateRange',
      values: [filterInput.startDate, filterInput.endDate],
    });
  }

  if (filterInput?.status?.length > 0) {
    filterPayload.push({
      ...filterObj,
      member: 'PayoutHistory.payoutStatus',
      operator: 'equals',
      values: filterInput.status,
    });
  }

  if (filterPayload.length > 0) {
    appliedFiltersPayload.push({
      and: filterPayload,
    });
  }

  const payloadForFilter = [{ and: appliedFiltersPayload }];
  return {
    measures: ['PayoutHistory.count'],
    filters: payloadForFilter,
  };
};
