import React, { useState, useRef } from 'react';

const StaticText = () => {
  return (
    <div className='yk-instructions'>
      <div>
        <h4>Shipping instructions:</h4>
        <br />
        <p>
          Thank you for choosing Yankeekicks as your sneaker consignment
          partner. To ensure a smooth and efficient process, please follow these
          shipping instructions when sending your sneakers to our warehouse:
        </p>
        <p>
          1.Please package your sneakers securely to avoid any damage during
          transit. We recommend using a sturdy box with bubble wrap or other
          protective materials.
        </p>
        <p>
          2.Print and include a copy of your shipment summary in the package.
          This summary should have your name, email address, and phone number.
        </p>
        <p>
          3.Ship your package to our warehouse at 10376 W SR 84, Unit 7, Davie,
          FL 33324.
        </p>
        <p>
          4.Once you have shipped your sneakers, please input the tracking
          number in the shipment section of our website. This will enable us to
          track the status of your shipment and keep you updated throughout the
          process.
        </p>
        <p>
          5.Once we receive your sneakers, our team will inspect and
          authenticate them before listing them for sale.
        </p>
        <p>
          Thank you for choosing Yankeekicks as your sneaker consignment
          partner. If you have any questions or concerns about the shipping
          process, please do not hesitate to contact us.
        </p>
      </div>
      <div>
        <h4>Drop-Off Instructions: </h4>
        <h6>Miami Store Drop-off Instructions:</h6>
        <p>
          1.Please package your sneakers securely to avoid any damage during
          transit. We recommend using a sturdy box with bubble wrap or other
          protective materials.
        </p>
        <p>
          2.Print the summary page of your shipment agreement, which includes
          your name, email address, phone number, and the details of the
          sneakers you are consigning.
        </p>
        <p>
          3.Bring your package and the summary page to our Miami store located
          at 909 Collins Avenue Miami Beach, FL 33139 during our business hours.
        </p>
        <p>
          4.Our staff will inspect your sneakers, confirm the details on the
          summary page, and provide you with a copy of the receipt for your
          records.
        </p>

        <h6>New York Store Drop-off Instructions:</h6>
        <p>
          1.Please package your sneakers securely to avoid any damage during
          transit. We recommend using a sturdy box with bubble wrap or other
          protective materials.
        </p>
        <p>
          2.Print the summary page of your shipment agreement, which includes
          your name, email address, phone number, and the details of the
          sneakers you are consigning.
        </p>
        <p>
          3.Bring your package and the summary page to our New York store
          located at 666 Broadway, New York, NY 10012 during our business hours.
        </p>
        <p>
          4.Our staff will inspect your sneakers, confirm the details on the
          summary page, and provide you with a copy of the receipt for your
          records.
        </p>

        <p>
          Please note that all packages dropped off at our physical stores must
          include the summary page of your shipment agreement. This ensures that
          we have all the necessary information to properly identify and process
          your shipment.
        </p>
      </div>
    </div>
  );
};

export default StaticText;
