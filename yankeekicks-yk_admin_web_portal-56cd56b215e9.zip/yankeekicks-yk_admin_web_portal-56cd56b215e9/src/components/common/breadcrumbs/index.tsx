import React from 'react';
import BreadcrumbArrow from 'assets/images/breadcrumb-arrow.svg';
import Image from 'next/image';
import { Button } from '@mui/material';
import { useRouter } from 'next/router';

const Breadcrumbs = (props: any) => {
  const { data = {} } = props;
  let router = useRouter();

  return (
    <div className='col-lg-12 col-md-12 col-sm-12'>
      {/* <div>
        <Button
          className='btn filter-btn back-btn'
          onClick={() => router.back()}
        >
          &lt; Back
        </Button>
      </div> */}
      <div className='breadcrumbs-wrapper'>
        <ul className='breadcrumbs-list'>
          <li className='yk-heading yk-title-h19 d-flex'>
            {!!data?.titleImage && (
              <Image
                src={data?.titleImage}
                alt='Consinee Group'
                className='Image-fluid me-2'
              />
            )}
            <a
              role='button'
              className='yk-orders-heading'
              onClick={data?.onClick}
            >
              {data?.title}
            </a>
          </li>
          <li className='yk-sub-heading'>
            {data?.nextSubTitle ? (
              <a
                role='button'
                className='yk-orders-heading'
                onClick={data?.onNextClick}
              >
                {data?.subTitle}
              </a>
            ) : (
              data?.subTitle
            )}
          </li>
          {data?.nextSubTitle && (
            <li className='yk-sub-heading'>{data?.nextSubTitle}</li>
          )}
        </ul>
      </div>
    </div>
  );
};
export default Breadcrumbs;
