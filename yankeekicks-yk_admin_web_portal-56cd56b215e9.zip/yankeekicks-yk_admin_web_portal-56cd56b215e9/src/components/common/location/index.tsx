import React, { useState, useEffect, Fragment } from 'react';
import Image from 'next/image';
import { useSelector, useDispatch } from 'react-redux';
import { styled, alpha } from '@mui/material/styles';
import Menu, { MenuProps } from '@mui/material/Menu';
import { ListItemButton, ListItemIcon, ListItemText } from '@mui/material';
import { actions } from 'store/reducers/shared';
import { STORE_BY_LOCATION_REQUEST } from 'actions/shared';
import { ALL_LOCATIONS } from 'utils/constants';
import { isConsignmentAdmin } from 'utils/util';
import useWindowDimensions from '../mobile-card-dimension';
import closeIcon from 'assets/images/black-close-icon.svg';

const StyledMenu = styled((props: MenuProps) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: 'bottom',
      horizontal: 'right',
    }}
    transformOrigin={{
      vertical: 'top',
      horizontal: 'right',
    }}
    {...props}
  />
))(({ theme }) => ({
  '& .MuiPaper-root': {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 180,
    color:
      theme.palette.mode === 'light'
        ? 'rgb(55, 65, 81)'
        : theme.palette.grey[300],
    boxShadow:
      'rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px',
    '& .MuiMenu-list': {
      padding: '4px 0',
    },
    '& .MuiMenuItem-root': {
      '& .MuiSvgIcon-root': {
        fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      '&:active': {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));

const Locations = ({
  item,
  innerPage = false,
  handleDrawerOpen,
  hideLocationDetails,
}: any) => {
  const selectedName: any = localStorage?.getItem('selectedLocName') || '';
  const LocIds: any = localStorage?.getItem('totalLocationIds') || '';

  const { storeLocations, selected, selectedLocation } = useSelector(
    (state: any) => state.shared
  );
  const dispatch = useDispatch();

  // const [selectedLocation, setSelectedLocation] = useState('');

  const [selectedOption, setSelectedOption] = useState(selectedLocation || '');
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [showLocationSidebar, setShowLocationSidebar] = useState<any>(false);
  const openBtn = Boolean(anchorEl);
  const [open, setOpen] = React.useState(true);
  const { width } = useWindowDimensions();

  useEffect(() => {
    const params = {
      locations: localStorage?.getItem('storeLocation'),
    };
    // dispatch({ type: STORE_LOCATION_REQUEST });
    dispatch({ type: STORE_BY_LOCATION_REQUEST, payload: { params } });
    if (selectedName === ALL_LOCATIONS && selectedLocation === ALL_LOCATIONS) {
      dispatch(actions.setSelectedLocation(ALL_LOCATIONS));
    } else if (selectedName) {
      dispatch(actions.setSelectedLocation(selectedName));
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (width < 500) {
      setOpen(false);
    } else {
      setOpen(true);
    }
  }, [width]);

  useEffect(() => {
    setShowLocationSidebar(false);
    handleClose();
  }, [hideLocationDetails]);

  // useEffect(() => {
  //   setSelectedLocation(selected?.id);
  // }, [selected]);

  useEffect(() => {
    if (selectedName === ALL_LOCATIONS && selectedLocation === ALL_LOCATIONS) {
      localStorage?.setItem('selectedLocIds', LocIds);
      setSelectedOption(ALL_LOCATIONS || '');
    } else {
      setSelectedOption(selectedName || '');
    }
  }, [selected, selectedLocation]);

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    handleDrawerOpen();
    setAnchorEl(event.currentTarget);
    setShowLocationSidebar(true);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const locationHandler = (value: any, isAllLocation: any = false) => {
    let selectedLocations: any = [];
    storeLocations?.map((item: any) => {
      item?.locations?.map((subItem: any) => {
        if (subItem?.id === value) {
          return selectedLocations?.push(subItem);
        }
      });
    });
    let selectedItem: any = [];
    storeLocations?.map((loc: any) => {
      loc?.locations?.map((item: any) => {
        if (item?.id === value) {
          return selectedItem?.push({
            id: loc?.id,
            shopifyApiDomain: loc?.shopifyApiDomain,
            shopifyRestApiDomain: loc?.shopifyRestApiDomain,
            location: loc?.location,
            accessToken: loc?.accessToken,
            locations: selectedLocations,
          });
        }
      });
    });

    if (isAllLocation) {
      // set the value in redux
      const totalLocIds: any = localStorage?.getItem('totalLocationIds') || '';
      dispatch(actions.setSelectedLocation(ALL_LOCATIONS));
      localStorage?.setItem('selectedLocName', ALL_LOCATIONS); // need this local storage because redux get restore when refresh
      localStorage?.setItem('selectedLocIds', totalLocIds); // need this local storage because redux get restore when refresh
    } else {
      // setSelectedLocation(value as string);
      localStorage?.setItem('storeId', selectedItem[0].locations[0]?.storeId);
      localStorage?.setItem(
        'storeLocation',
        selectedItem[0].locations[0]?.name
      );
      localStorage?.setItem(
        'selectedLocName',
        selectedItem[0].locations[0]?.name
      ); // need this local storage because redux get restore when refresh
      localStorage.setItem(
        'storeLocationId',
        selectedItem[0]?.locations[0]?.id
      );
      localStorage?.setItem(
        'selectedLocIds',
        selectedItem[0]?.locations[0]?.id
      ); // need this local storage because redux get restore when refresh
      dispatch(actions.selected(selectedItem[0]));
      dispatch(
        actions.setSelectedLocation(selectedItem[0].locations[0]?.name || '')
      );
    }
    innerPage && handleClose && handleClose();
    setShowLocationSidebar(false);
  };

  const showLocationTitle: any = item?.text
    ? localStorage?.getItem('storeLocation')
    : '';

  return (
    <>
      {innerPage && storeLocations?.length > 0 && (
        <div className='locations-dropdown-wrapper'>
          <ListItemButton
            sx={{
              minHeight: 48,
              justifyContent: open ? 'initial' : 'center',
              px: 2.5,
            }}
            onClick={handleClick}
            className='location-dropdown-btn btn'
            id='demo-customized-button'
            aria-controls={openBtn ? 'demo-customized-menu' : undefined}
            aria-haspopup='true'
            aria-expanded={openBtn ? 'true' : undefined}>
            <ListItemIcon
              sx={{
                minWidth: 0,
                justifyContent: 'center',
              }}
            />
            <ListItemText sx={{ opacity: open ? 1 : 0 }}>
              <span className='location-text-wrapper'>
                <span className='portal-text'>
                  {item?.subText ? 'Location' : ''}
                </span>
                <span className='location-name' title={showLocationTitle}>
                  {/* {item?.text ? localStorage?.getItem('storeLocation') : ''} // old code */}
                  {/* {isConsignmentAdmin()
                    ? item?.text
                      ? selectedName
                      : ''
                    : selectedOption === ALL_LOCATIONS
                    ? ALL_LOCATIONS
                    : selectedName || ''} */}
                  {selectedOption === ALL_LOCATIONS
                    ? ALL_LOCATIONS
                    : selectedName || ''}
                </span>
              </span>
            </ListItemText>
          </ListItemButton>

          {/* <Button
            className='location-dropdown-btn btn'
            id='demo-customized-button'
            aria-controls={openBtn ? 'demo-customized-menu' : undefined}
            aria-haspopup='true'
            aria-expanded={openBtn ? 'true' : undefined}
            variant='contained'
            disableElevation
            onClick={handleClick}
            endIcon={<KeyboardArrowDownIcon />}
          >
            <ListItemIcon
              sx={{
                minWidth: 0,
                justifyContent: 'center',
              }}
            >
              icon
            </ListItemIcon>
            <ListItemText>
              <span className='location-text-wrapper'>
                <span className='portal-text'>
                  {item?.subText ? 'Location' : ''}
                </span>
                <span className='location-name' title={showLocationTitle}>
                  {item?.text ? localStorage?.getItem('storeLocation') : ''}
                </span>
              </span>
              <span className='location-name' title={showLocationTitle}>
                {item?.text ? localStorage?.getItem('storeLocation') : ''}
              </span>
            </span>
          </Button> */}
          {showLocationSidebar && (
            <div className='yk-overlapping-window'>
              <div className='close-btn-wrapper'>
                <button
                  className='btn btn-transparent close-btn'
                  onClick={() => setShowLocationSidebar(false)}>
                  <Image src={closeIcon} alt='' className='img-fluid' />
                </button>
              </div>
              <h4 className='yk-store-select'>Select Store</h4>
              <ul className='yk-location-list YKCH-newLocation'>
                {storeLocations?.length &&
                  storeLocations?.map((location: any, index: any) => {
                    return (
                      <li key={index}>
                        <div className='YKCH-noListingPrint'>
                          {/* {index === 0 && !isConsignmentAdmin() && (
                            <div>
                              <span
                                // className='YKCH-titleLlist'
                                onClick={() => locationHandler('', true)}>
                                All
                              </span>
                            </div>
                          )} */}

                          {/* <span
                            className='YKCH-titleLlist'
                            title={location?.location}>
                            {location?.location}
                          </span> */}
                          {location?.locations?.map(
                            (subLocation: any, sIndex: any) => {
                              return (
                                <Fragment key={`${index}-${sIndex}`}>
                                  {/* {sIndex === 0 && !isConsignmentAdmin() && ( */}
                                  {sIndex === 0 && (
                                    <li
                                      className={
                                        selectedName === ALL_LOCATIONS
                                          ? 'YKCH-titleLlist'
                                          : ''
                                      }
                                      onClick={() => locationHandler('', true)}>
                                      {ALL_LOCATIONS}
                                    </li>
                                  )}
                                  <li
                                    key={`${index}-${sIndex}`}
                                    className={
                                      subLocation?.name === selectedName
                                        ? 'YKCH-titleLlist'
                                        : ''
                                    }
                                    title={subLocation?.name || ''}
                                    onClick={() =>
                                      locationHandler(subLocation?.id)
                                    }>
                                    {subLocation?.name || ''}
                                  </li>
                                </Fragment>
                              );
                            }
                          )}
                        </div>
                      </li>
                    );
                  })}
              </ul>
            </div>
          )}
        </div>
      )}
    </>
  );
};

export default Locations;
