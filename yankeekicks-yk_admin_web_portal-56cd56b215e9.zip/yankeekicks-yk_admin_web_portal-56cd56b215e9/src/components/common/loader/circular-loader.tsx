import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import { Backdrop } from '@mui/material';

const CircleLoader = () => {
  return (
    /*  <Box className='loader-wrapper' sx={{ display: 'flex' }}>
      <CircularProgress />
    </Box> */
    <div className='YKCH-loader'>
      <Backdrop sx={{ color: '#fff', zIndex: 20000 }} open={true}>
        <CircularProgress color='inherit' />
      </Backdrop>
    </div>
  );
};

export default CircleLoader;
