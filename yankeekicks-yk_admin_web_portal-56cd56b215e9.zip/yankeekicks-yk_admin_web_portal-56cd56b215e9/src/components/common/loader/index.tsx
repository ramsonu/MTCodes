const Loader = (isLoading: any) => {
  return <>{isLoading === true && <div className='loader'></div>}</>;
};
export default Loader;
