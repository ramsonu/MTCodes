import { Backdrop, CircularProgress } from '@mui/material';
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
const Loader = (props: any) => {
  const { loading } = useSelector((state: any) => state.loader);

  return (
    <>
      {loading && (
        <div>
          <Backdrop sx={{ color: '#fff', zIndex: 999999 }} open={true}>
            <CircularProgress color='inherit' />
          </Backdrop>
        </div>
      )}
      {props.children}
    </>
  );
};
export default Loader;
