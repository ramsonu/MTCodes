import React from 'react';
import { Snackbar } from '@mui/material';
import MuiAlert, { AlertProps } from '@mui/material/Alert';

const Alert = React.forwardRef<HTMLDivElement, AlertProps>(function Alert(
  props,
  ref
) {
  return <MuiAlert elevation={6} ref={ref} variant='filled' {...props} />;
});

const Notification = (props: any) => {
  const {
    showSuccessPopup,
    handleSnackbarClose,
    severityType,
    message,
    className = '',
    showAlways = false,
  } = props;

  return (
    <>
      <Snackbar
        open={showSuccessPopup}
        {...(!showAlways ? { autoHideDuration: 3000 } : {})}
        onClose={handleSnackbarClose}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        className={`yk-toast-message ${className} ${severityType}`}
      >
        <Alert
          icon={true}
          onClose={handleSnackbarClose}
          severity={severityType}
          sx={{ width: '100%' }}
        >
          {message}
        </Alert>
      </Snackbar>
    </>
  );
};

export default Notification;
