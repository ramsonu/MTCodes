import React, { useState, useEffect } from 'react';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import { SEARCH_AGE } from '../constants';
import Radio from '@mui/material/Radio';
import { useSelector, useDispatch } from 'react-redux';
import { actions } from 'store/reducers/kiosk';

const AgeFilters = (props: any) => {
  const { onChange = () => {}, itemKey } = props;
  const dispatch = useDispatch();
  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const handleAgeFilter = (event: any) => {
    dispatch(
      actions.setFilters({
        filterItem: event.target.value,
        filterType: itemKey,
      })
    );
    onChange(event);
  };
  return (
    <>
      <ul className='sub-filter-list'>
        <RadioGroup
          aria-labelledby='demo-radio-buttons-group-label'
          name='radio-buttons-group'
          className='filter-sidebar-checkbox'
          onChange={handleAgeFilter}
        >
          {SEARCH_AGE?.map((obj: any, index: any) => {
            const { key, value } = obj;
            return (
              <div className='list-wrapper' key={index}>
                <li className='justify-content-between d-flex'>
                  <span>{value}</span>

                  <FormControlLabel
                    checked={filterTypes[itemKey] == key}
                    value={key}
                    control={<Radio />}
                    label=''
                  />
                </li>
              </div>
            );
          })}
        </RadioGroup>
      </ul>
    </>
  );
};

export default AgeFilters;
