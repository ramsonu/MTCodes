import React from 'react';
import { Checkbox } from '@mui/material';

const SKUFilters = (props: any) => {
  const {
    onChange = () => {},
    data = [],
    checkedValue = {},
    itemKey = '',
  } = props;

  return (
    <>
      <ul className='sub-filter-list'>
        {data?.map((sku: any, index: any) => {
          return (
            <div className='list-wrapper' key={index}>
              {itemKey === 'consignorFilter' ? (
                <>
                  <div className='clearfix w-100'>
                    <span className='float-start'>
                      {sku?.['ConsigneeType.name']}
                    </span>
                    <Checkbox
                      className='filter-sidebar-checkbox float-end'
                      checked={checkedValue?.includes(
                        sku?.['ConsigneeType.name']
                      )}
                      name={sku?.['ConsigneeType.name']}
                      onChange={(event: any) => onChange(event)}
                    />
                  </div>
                </>
              ) : (
                <>
                  <div className='clearfix w-100'>
                    <span className='float-start'>
                      {sku?.['ConsignmentviewDetails.sku']}
                    </span>
                    <Checkbox
                      className='filter-sidebar-checkbox float-end'
                      checked={checkedValue?.includes(
                        sku?.['ConsignmentviewDetails.sku']
                      )}
                      name={sku?.['ConsignmentviewDetails.sku']}
                      onChange={(event: any) => onChange(event)}
                    />
                  </div>
                </>
              )}
            </div>
          );
        })}
      </ul>
    </>
  );
};

export default SKUFilters;
