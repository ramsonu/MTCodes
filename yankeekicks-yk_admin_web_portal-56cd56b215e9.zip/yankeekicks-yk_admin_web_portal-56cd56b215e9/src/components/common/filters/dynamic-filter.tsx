import React, { useState, useEffect } from 'react';
import { Checkbox, InputAdornment } from '@mui/material';
import { actions } from 'store/reducers/kiosk';
import { useDispatch } from 'react-redux';
import {
  SEARCH_COLOURS,
  // SEARCH_BY_SIZES,
  SEARCH_BRAND,
  SEARCH_BY_TYPES,
  SEARCH_RELEASE_NO_OF_YEARS,
  TRANSFER_TYPE,
} from './constants';
import searchIcon from 'assets/images/search-icon.png';
import { useSelector } from 'react-redux';
import { getPreviousFullYear } from 'utils/util';
import { TextField } from '@mui/material';
import Image from 'next/image';
import sizeMatrix from 'utils/sizeMatrics.json';

const DynamicFilter = ({ itemKey }: any) => {
  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const [items, setItems] = useState([]);
  const dispatch = useDispatch();
  const filterlabel = { inputProps: { 'aria-label': itemKey } };
  useEffect(() => {
    renderFilters();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const applyFilters = (objectItems: any, val: any) =>
    objectItems.filter((obj: any) =>
      obj.value.toLowerCase().includes(val.toLowerCase())
    );
  const renderFilters = (value: any = '') => {
    let items: any = [];
    switch (itemKey) {
      case 'brand':
        items = value !== '' ? applyFilters(SEARCH_BRAND, value) : SEARCH_BRAND;
        break;
      case 'size':
        items =
          value !== '' ? applyFilters(SEARCH_BY_SIZES, value) : SEARCH_BY_SIZES;
        break;
      case 'color':
        items =
          value !== '' ? applyFilters(SEARCH_COLOURS, value) : SEARCH_COLOURS;
        break;
      case 'date':
        const year = getPreviousFullYear(SEARCH_RELEASE_NO_OF_YEARS);
        items = value !== '' ? applyFilters(year, value) : year;
        break;
      case 'type':
        items =
          value !== '' ? applyFilters(SEARCH_BY_TYPES, value) : SEARCH_BY_TYPES;
        break;
      case 'transferType':
        items =
          value !== '' ? applyFilters(TRANSFER_TYPE, value) : TRANSFER_TYPE;
        break;
      default:
        break;
    }
    setItems(items);
  };

  const setFilters = (filterItem: string, filterType: string) => {
    dispatch(
      actions.setFilters({ filterItem: filterItem, filterType: filterType })
    );
  };

  const onChange = (e: any) => {
    renderFilters(e.target.value);
  };

  let SEARCH_BY_SIZES: any = [];
  sizeMatrix.forEach((type: any, index: number) => {
    SEARCH_BY_SIZES = SEARCH_BY_SIZES.concat(type.sizeList);
  });

  return (
    <div>
      <TextField
        id='outlined-search'
        label=''
        type='search'
        onChange={onChange}
        InputProps={{
          type: 'search',
          placeholder: 'Search',
          startAdornment: (
            <InputAdornment position='start'>
              <Image src={searchIcon} alt='search-icon' />
            </InputAdornment>
          ),
        }}
      />
      <ul className='sub-filter-list'>
        {items?.map((obj: any, index: any) => {
          const { key, value } = obj;
          return (
            <div className='list-wrapper' key={`${itemKey}-${index}`}>
              <li className='YKCH-newListingFlexing'>
                <div>
                  {itemKey === 'color' && (
                    <span
                      className='yk-color-badge'
                      style={{
                        background: `var(--bs-${value})`,
                      }}></span>
                  )}
                  <span>{value}</span>
                </div>
                <div>
                  <Checkbox
                    {...filterlabel}
                    checked={filterTypes[itemKey]?.includes(value)}
                    className='filter-sidebar-checkbox'
                    onClick={() => setFilters(value, itemKey)}
                  />
                </div>
              </li>
            </div>
          );
        })}
      </ul>
    </div>
  );
};

export default DynamicFilter;
