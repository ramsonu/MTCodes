import React, { useState } from 'react';
import { Checkbox } from '@mui/material';
import { CONSIGNMENT_ADMIN_AND_YK_ADMIN_TEXTS } from '../constants';

const PayoutStatusFilters = (props: any) => {
  const { onChange = () => {}, checkedValue = {}, itemKey = '' } = props;
  const {
    CONSIGNOR_FILTER_COMMISSION_TEXT,
    TYPE_FILTER_COMMISSION_TEXT,
    ORDER_TEXT,
    CONSIGNEMNT_TEXT,
    COMMISSION_FILTER_STATUS_TEXT,
    SKU_DETAILS_TEXT,
    CONSIGNMENT_DETAILS_TEXT,
    CONSIGNOR_FILTER_STATUS_TEXT,
    MANAGE_USERS_TEXT,
    TRANSFER_TEXT,
    VIEW_ACCEPT_TRANSFER_TEXT,
  } = CONSIGNMENT_ADMIN_AND_YK_ADMIN_TEXTS;

  const pendingColor = 'pending';

  return (
    <div>
      {itemKey !== CONSIGNOR_FILTER_COMMISSION_TEXT &&
        itemKey !== TYPE_FILTER_COMMISSION_TEXT &&
        itemKey !== 'manageLocationType' &&
        itemKey !== TRANSFER_TEXT &&
        itemKey !== VIEW_ACCEPT_TRANSFER_TEXT &&
        itemKey !== 'manageLocationType' && (
          <div className='list-wrapper'>
            <button className={`btn yk-color-badge ${pendingColor}`}>
              Pending
            </button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Pending}
              name='Pending'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        )}
      {itemKey === ORDER_TEXT && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge paid'>Paid</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Paid}
              name='Paid'
              onChange={(event: any) => onChange(event)}
            />
          </div>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge soldGreen'>Sold</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Sold}
              name='Sold'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}
      {itemKey === 'payout' && (
        <div className='list-wrapper'>
          <button className='btn yk-color-badge paid'>Paid</button>
          <Checkbox
            className='filter-sidebar-checkbox'
            checked={checkedValue?.Paid}
            name='Paid'
            onChange={(event: any) => onChange(event)}
          />
        </div>
      )}
      {(itemKey === CONSIGNEMNT_TEXT ||
        itemKey === CONSIGNMENT_DETAILS_TEXT) && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge green'>Completed</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Completed}
              name='Completed'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}
      {itemKey === 'consignmentDetailsStatus' && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge green'>Completed</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Completed}
              name='Completed'
              onChange={(event: any) => onChange(event)}
            />
          </div>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge red'>Rejected</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Rejected}
              name='Rejected'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}
      {(itemKey === 'consignment' || itemKey === CONSIGNMENT_DETAILS_TEXT) && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge yellow'>Yet To Start</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.['Yet To Start']}
              name='Yet To Start'
              onChange={(event: any) => onChange(event)}
            />
          </div>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge orange'>Shopify Error</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.['Shopify Error']}
              name='Shopify Error'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}
      {itemKey === COMMISSION_FILTER_STATUS_TEXT && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge green'>Approved</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Approved}
              name='Approved'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}
      {itemKey === SKU_DETAILS_TEXT && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge green'>Approved</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Approved}
              name='Approved'
              onChange={(event: any) => onChange(event)}
            />
          </div>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge red'>Rejected</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Rejected}
              name='Rejected'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}
      {itemKey === COMMISSION_FILTER_STATUS_TEXT && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge red'>Rejected</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Reject}
              name='Reject'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}
      {itemKey === CONSIGNOR_FILTER_STATUS_TEXT && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge activeBadge'>Active</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.ACTIVE}
              name='ACTIVE'
              onChange={(event: any) => onChange(event)}
            />
          </div>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge disabled'>Disabled</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.DISABLED}
              name='DISABLED'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}
      {itemKey === MANAGE_USERS_TEXT && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge green'>Active</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Active}
              name='Active'
              onChange={(event: any) => onChange(event)}
            />
          </div>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge red'>Disabled</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Disabled}
              name='Disabled'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}
      {itemKey === CONSIGNOR_FILTER_COMMISSION_TEXT && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge green'>Default</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Default}
              name='Default'
              onChange={(event: any) => onChange(event)}
            />
          </div>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge yellow'>VIP</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.VIP}
              name='VIP'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}
      {itemKey === TYPE_FILTER_COMMISSION_TEXT && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge green'>Special</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Special}
              name='Special'
              onChange={(event: any) => onChange(event)}
            />
          </div>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge yellow'>VIP</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.VIP}
              name='VIP'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}

      {itemKey === 'manageLocationType' && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge green'>Warehouse</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Warehouse}
              name='Warehouse'
              onChange={(event: any) => onChange(event)}
            />
          </div>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge yellow'>Store</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Store}
              name='Store'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}

      {itemKey === 'pushNotifications' && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge green'>Done</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Done}
              name='Done'
              onChange={(event: any) => onChange(event)}
            />
          </div>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge red'>Cancelled</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Cancelled}
              name='Cancelled'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}

      {itemKey === TRANSFER_TEXT && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge green'>Completed</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Complete}
              name='Complete'
              onChange={(event: any) => onChange(event)}
            />
          </div>
          <div className='list-wrapper'>
            <button className={`btn yk-color-badge red ${pendingColor}`}>
              Pending
            </button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Pending}
              name='Pending'
              onChange={(event: any) => onChange(event)}
            />
          </div>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge yellow'>Yet To Start</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.['Yet To Start']}
              name='Yet To Start'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}
      {itemKey === VIEW_ACCEPT_TRANSFER_TEXT && (
        <>
          <div className='list-wrapper'>
            <button className='btn yk-color-badge green'>Approved</button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Approved}
              name='Approved'
              onChange={(event: any) => onChange(event)}
            />
          </div>
          <div className='list-wrapper'>
            <button className={`btn yk-color-badge red ${pendingColor}`}>
              Pending
            </button>
            <Checkbox
              className='filter-sidebar-checkbox'
              checked={checkedValue?.Pending}
              name='Pending'
              onChange={(event: any) => onChange(event)}
            />
          </div>
        </>
      )}
    </div>
  );
};

export default PayoutStatusFilters;
