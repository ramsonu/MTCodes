import React, { useState } from 'react';
import { Box, Checkbox, Typography } from '@mui/material';
import { CONSIGNMENT_ADMIN_AND_YK_ADMIN_TEXTS } from '../constants';
import statusClassList from 'utils/statusTypes';

const statusOptions: any = {
  '': [
    'Active',
    'Disabled',
    'Pending',
    'Pending withdraw',
    'Withdrawn',
    'Approved',
    'Rejected',
    'Sold',
    'Completed',
    'Yet To Start',
    'Shopify Error',
    'Paid',
    'Fees Pending',
    'Withdrawal Rejected',
    'Moved to YK',
  ],
  skuDetails: [
    'Active',
    'Disabled',
    'Pending',
    'Pending withdraw',
    'Withdrawn',
    'Approved',
    'Rejected',
    'Sold',
    'Completed',
    'Yet To Start',
    'Shopify Error',
    'Paid',
    'Fees Pending',
    'Withdrawal Rejected',
    'Moved to YK',
  ],

  inventoryDetails: [
    'Active',
    'Disabled',
    'Pending',
    'Pending withdraw',
    'Withdrawn',
    'Approved',
    'Rejected',
    'Sold',
    'Completed',
    'Yet To Start',
    'Shopify Error',
    'Paid',
    'Fees Pending',
    'Withdrawal Rejected',
    'Moved to YK',
    'Missing',
  ],
  consignorInventoryDetails: [
    'Active',
    'Disabled',
    'Pending',
    'Pending withdraw',
    'Withdrawn',
    'Approved',
    'Rejected',
    'Sold',
    'Completed',
    'Yet To Start',
    'Shopify Error',
    'Paid',
    'Fees Pending',
    'Withdrawal Rejected',
    'Moved to YK',
  ],
  withdrawal: ['Yet To Start', 'Pending', 'Completed'],
  withdrawalDetails: [
    'Pending withdraw',
    'Withdrawn',
    'Fees Pending',
    'Withdrawal Rejected',
    'Active',
    'Pending',
    'Moved to YK',
  ],
};
const StatusFilter = (props: any) => {
  const { itemKey, checkedValue, onStatusChange } = props;
  return (
    <Box>
      <Typography>
        {statusOptions?.[itemKey]?.map((status: string, index: number) => {
          return (
            <div key={`status_${index}`} className='list-wrapper'>
              <button
                className={`btn yk-color-badge ${statusClassList[status]}`}>
                {status}
              </button>
              <Checkbox
                className='filter-sidebar-checkbox'
                checked={checkedValue?.[status]}
                name={status}
                onChange={(event: any) => onStatusChange(event)}
              />
            </div>
          );
        })}
      </Typography>
    </Box>
  );
};
export default StatusFilter;
