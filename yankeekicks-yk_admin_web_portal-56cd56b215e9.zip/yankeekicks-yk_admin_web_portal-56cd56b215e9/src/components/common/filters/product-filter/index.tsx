import React, { useState, useEffect } from 'react';
import DynamicFilter from '../dynamic-filter';
import DateFilters from '../date';
import AgeFilters from '../age';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import Tabs from '@mui/material/Tabs';
import { Typography, Button } from '@mui/material';
import {
  filterByInventory,
  filterByOrder,
  filterByConsignment,
  filterByConsignmentDetails,
  filterBySkuDetails,
  filterByCatalog,
  filterByInventorySkuDetails,
  filterByPreviewBulk,
  filterByPayout,
  CONSIGNMENT_ADMIN_AND_YK_ADMIN_TEXTS,
  filterByConsignor,
  filterByManageCommission,
  filterByOrderDetails,
  filterByManageUsers,
  filterByManageLocations,
  filterByViewCommission,
  filterByPayoutDetails,
  filterByPayoutOrderDetails,
  filterByConsignorInventory,
  filterByConsignorInventorySkuDetails,
  filterByPushNotifications,
  filterByPrintLabels,
  filterByTransfer,
  filterByViewAcceptTransfer,
  filterByInitiateTransfer,
  filtersByDashboard,
  filterByWithdraw,
  filterByWithdrawalDetails,
  filterByPayoutHistory,
  filtersByMissingProducts,
} from '../constants';
import PayoutStatusFilters from '../payout-status';
import SKUFilters from '../sku';
import ProductNameFilters from '../product';
import StatusFilter from './status-filter';

const ProductFilters = (props: any) => {
  const {
    itemKey = '',
    component = '',
    startDate = '',
    endDate = '',
    data = [],
    locationTypeValue = {},
    checkedValue = {},
    checkedSkuValue = {},
    checkedProductValue = {},
    commissionValue = {},
    selectedCommissionNames = {},
    checkedPriceValue = {},
    onDateChange = () => {},
    onAgeChange = () => {},
    onSkuChange = () => {},
    onProductChange = () => {},
    onCommissionNameChange = () => {},
    onPriceChange = () => {},
    onLocationTypeChange = () => {},
    onApplyClick = () => {},
    onPayoutChange = () => {},
    onCommissionChange = () => {},
    onClearFilters = () => {},
    clearDisable = false,
    isApplyButtonDisabled = false,
  } = props;

  const [tabIndex, setTabIndex] = useState(0);
  const [filterBy, setFilterBy] = useState<any>([]);

  const {
    ORDER_TEXT,
    CONSIGNEMNT_TEXT,
    COMMISSION_FILTER_STATUS_TEXT,
    CONSIGNOR_FILTER_STATUS_TEXT,
    CONSIGNOR_FILTER_TEXT,
    MANAGE_COMMISSION_TEXT,
    PAYOUT_DETAILS,
    ORDER_DETAILS_TEXT,
    MANAGE_USERS_TEXT,
    MANAGE_LOCATIONS_TEXT,
    PAYOUT_ORDER_DETAILS_TEXT,
    CONSIGNOR_INVENTORY_TEXT,
    CONSIGNOR_INVENTORY_DETAILS_TEXT,
    PRINT_LABELS,
    INITIATE_TRANSFER_TEXT,
    TRANSFER_TEXT,
    VIEW_ACCEPT_TRANSFER_TEXT,
    DASHBOARD_FILTER_TEXT,
    MISSING_PRODUCTS,
  } = CONSIGNMENT_ADMIN_AND_YK_ADMIN_TEXTS;

  const handleTabChange = (event: any, newTabIndex: any) => {
    setTabIndex(newTabIndex);
  };

  useEffect(() => {
    switch (itemKey) {
      case 'inventory':
        setFilterBy(filterByInventory);
        break;
      case 'catalog':
        setFilterBy(filterByCatalog);
        break;
      case 'orders':
        setFilterBy(filterByOrder);
        break;
      case 'consignment':
        setFilterBy(filterByConsignment);
        break;
      case 'withdrawal':
        setFilterBy(filterByWithdraw);
        break;
      case 'consignmentDetails':
        setFilterBy(filterByConsignmentDetails);
        break;
      case 'skuDetails':
        setFilterBy(filterBySkuDetails);
        break;
      case 'withdrawalDetails':
        setFilterBy(filterByWithdrawalDetails);
        break;
      case 'inventoryDetails':
        setFilterBy(filterByInventorySkuDetails);
        break;
      case 'previewBulk':
        setFilterBy(filterByPreviewBulk);
        break;
      case 'payout':
        setFilterBy(filterByPayout);
        break;
      case 'payoutHistory':
        setFilterBy(filterByPayoutHistory);
        break;
      case CONSIGNOR_FILTER_TEXT:
        setFilterBy(filterByConsignor);
        break;
      case MANAGE_COMMISSION_TEXT:
        setFilterBy(filterByManageCommission);
        break;
      case ORDER_DETAILS_TEXT:
        setFilterBy(filterByOrderDetails);
        break;
      case 'pushNotifications':
        setFilterBy(filterByPushNotifications);
        break;
      case MANAGE_USERS_TEXT:
        setFilterBy(filterByManageUsers);
        break;
      case MANAGE_LOCATIONS_TEXT:
        setFilterBy(filterByManageLocations);
        break;
      case 'viewCommission':
        setFilterBy(filterByViewCommission);
        break;
      case PAYOUT_DETAILS:
        setFilterBy(filterByPayoutDetails);
        break;
      case PAYOUT_ORDER_DETAILS_TEXT:
        setFilterBy(filterByPayoutOrderDetails);
        break;
      case CONSIGNOR_INVENTORY_TEXT:
        setFilterBy(filterByConsignorInventory);
        break;
      case CONSIGNOR_INVENTORY_DETAILS_TEXT:
        setFilterBy(filterByConsignorInventorySkuDetails);
        break;
      case PRINT_LABELS:
        setFilterBy(filterByPrintLabels);
        break;
      case INITIATE_TRANSFER_TEXT:
        setFilterBy(filterByInitiateTransfer);
        break;
      case TRANSFER_TEXT:
        setFilterBy(filterByTransfer);
        break;
      case VIEW_ACCEPT_TRANSFER_TEXT:
        setFilterBy(filterByViewAcceptTransfer);
        break;
      case DASHBOARD_FILTER_TEXT:
        setFilterBy(filtersByDashboard);
        break;
      case MISSING_PRODUCTS:
        setFilterBy(filtersByMissingProducts);
        break;
    }
  });
  return (
    <div className='YKCH-newFilterERA'>
      <div className='filters-outer-wrapper YKCH-trickkyLuck'>
        <div className='products-filter-wrapper'>
          <Box sx={{ display: 'flex' }}>
            <Tabs
              value={tabIndex}
              onChange={handleTabChange}
              orientation='vertical'
              className='text-left'>
              {filterBy?.map((data: any, i: number) => {
                return <Tab key={i} label={data} />;
              })}
            </Tabs>
            <Box className='yk-filter-options'>
              {tabIndex === 3 && itemKey === 'inventoryDetails' && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <DynamicFilter itemKey='size' />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 0 &&
                (itemKey === 'inventory' ||
                  itemKey === CONSIGNOR_INVENTORY_TEXT ||
                  itemKey === PRINT_LABELS) && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <DynamicFilter itemKey={'brand'} />
                      </div>
                    </Typography>
                  </Box>
                )}
              {tabIndex === 0 && itemKey === 'catalog' && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <DynamicFilter itemKey={'brand'} />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 0 && itemKey === CONSIGNEMNT_TEXT && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <PayoutStatusFilters
                        onChange={onPayoutChange}
                        checkedValue={checkedValue}
                        itemKey={itemKey}
                      />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 0 && itemKey === 'withdrawal' && (
                <StatusFilter
                  itemKey={itemKey}
                  checkedValue={checkedValue}
                  onStatusChange={onPayoutChange}
                />
              )}
              {tabIndex === 0 && itemKey === 'withdrawalDetails' && (
                <StatusFilter
                  itemKey={itemKey}
                  checkedValue={checkedValue}
                  onStatusChange={onPayoutChange}
                />
              )}
              {tabIndex === 0 &&
                (itemKey === 'inventoryDetails' ||
                  itemKey === CONSIGNOR_INVENTORY_DETAILS_TEXT) && (
                  <StatusFilter
                    onStatusChange={onPayoutChange}
                    checkedValue={checkedValue}
                    itemKey={itemKey}
                  />
                )}
              {tabIndex === 0 && itemKey === 'orders' && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <PayoutStatusFilters
                        onChange={onPayoutChange}
                        checkedValue={checkedValue}
                        itemKey={itemKey}
                      />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 0 && itemKey === CONSIGNOR_FILTER_TEXT && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <PayoutStatusFilters
                        onChange={onPayoutChange}
                        checkedValue={checkedValue}
                        itemKey={CONSIGNOR_FILTER_STATUS_TEXT}
                      />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 0 && itemKey === 'previewBulk' && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <DynamicFilter itemKey={'brand'} />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 0 && itemKey === MANAGE_COMMISSION_TEXT && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <PayoutStatusFilters
                        itemKey={COMMISSION_FILTER_STATUS_TEXT}
                        onChange={onPayoutChange}
                        checkedValue={checkedValue}
                      />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 0 &&
                itemKey === 'consignmentDetails' &&
                itemKey !== 'skuDetails' &&
                itemKey !== MANAGE_COMMISSION_TEXT && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <PayoutStatusFilters
                          onChange={onPayoutChange}
                          checkedValue={checkedValue}
                          itemKey={itemKey}
                        />
                      </div>
                    </Typography>
                  </Box>
                )}
              {tabIndex === 0 &&
                (itemKey === 'manageUsers' ||
                  itemKey === 'pushNotifications') &&
                component !== 'consignmentDetails' &&
                itemKey !== 'skuDetails' &&
                itemKey !== MANAGE_COMMISSION_TEXT &&
                itemKey !== 'consignmentDetails' && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <PayoutStatusFilters
                          onChange={onPayoutChange}
                          checkedValue={checkedValue}
                          itemKey={itemKey}
                        />
                      </div>
                    </Typography>
                  </Box>
                )}
              {tabIndex === 0 &&
                itemKey !== 'manageUsers' &&
                component === 'consignmentDetails' &&
                itemKey !== 'skuDetails' &&
                itemKey !== MANAGE_COMMISSION_TEXT &&
                itemKey !== 'consignmentDetails' && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <PayoutStatusFilters
                          onChange={onPayoutChange}
                          checkedValue={checkedValue}
                          itemKey={'consignmentDetailsStatus'}
                        />
                      </div>
                    </Typography>
                  </Box>
                )}
              {tabIndex === 0 &&
                itemKey !== 'manageUsers' &&
                itemKey !== 'skuDetails' &&
                itemKey !== MANAGE_COMMISSION_TEXT &&
                itemKey !== 'consignmentDetails' &&
                itemKey === 'manageLocations' && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <PayoutStatusFilters
                          onChange={onPayoutChange}
                          checkedValue={checkedValue}
                          itemKey={'manageUsers'}
                        />
                      </div>
                    </Typography>
                  </Box>
                )}
              {tabIndex === 0 && itemKey === 'payoutHistory' && (
                <Box className='m-0 yk-filter-options-scroll'>
                  <Typography>
                    <DateFilters
                      onChange={onDateChange}
                      startDate={startDate}
                      endDate={endDate}
                    />
                  </Typography>
                </Box>
              )}
              {tabIndex === 0 && itemKey === 'payout' && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <SKUFilters
                        onChange={onSkuChange}
                        data={data}
                        checkedValue={checkedSkuValue}
                        itemKey={CONSIGNOR_FILTER_TEXT}
                      />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 0 && itemKey === 'viewCommission' && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <ProductNameFilters
                        onChange={onCommissionNameChange}
                        data={data}
                        checkedValue={selectedCommissionNames}
                        itemKey={itemKey}
                      />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 0 &&
                itemKey !== 'consignmentDetails' &&
                itemKey === 'skuDetails' &&
                itemKey !== MANAGE_COMMISSION_TEXT && (
                  <StatusFilter
                    onStatusChange={onPayoutChange}
                    checkedValue={checkedValue}
                    itemKey={itemKey}
                  />
                )}
              {tabIndex === 0 &&
                (itemKey === PAYOUT_ORDER_DETAILS_TEXT ||
                  itemKey === ORDER_DETAILS_TEXT) && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <ProductNameFilters
                          itemKey={itemKey}
                          onChange={onCommissionChange}
                          data={data}
                          checkedValue={checkedSkuValue}
                        />
                      </div>
                    </Typography>
                  </Box>
                )}
              {tabIndex === 0 && itemKey === INITIATE_TRANSFER_TEXT && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <DynamicFilter itemKey={'brand'} />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 0 && itemKey === VIEW_ACCEPT_TRANSFER_TEXT && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <DynamicFilter itemKey={'size'} />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 0 && itemKey === TRANSFER_TEXT && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <PayoutStatusFilters
                        onChange={onPayoutChange}
                        checkedValue={checkedValue}
                        itemKey={TRANSFER_TEXT}
                      />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 0 && itemKey === DASHBOARD_FILTER_TEXT && (
                <Box className='m-0'>
                  <Typography>
                    <DateFilters
                      onChange={onDateChange}
                      startDate={startDate}
                      endDate={endDate}
                    />
                  </Typography>
                </Box>
              )}
              {tabIndex === 0 && itemKey === MISSING_PRODUCTS && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <DynamicFilter itemKey={'brand'} />
                    </div>
                  </Typography>
                </Box>
              )}

              {tabIndex === 1 && itemKey === PAYOUT_ORDER_DETAILS_TEXT && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <DynamicFilter itemKey={'brand'} />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 1 && itemKey === ORDER_TEXT && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <ProductNameFilters
                        itemKey={itemKey}
                        onChange={onCommissionChange}
                        data={data}
                        checkedValue={checkedSkuValue}
                      />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 1 &&
                itemKey === 'payout' &&
                itemKey !== MANAGE_LOCATIONS_TEXT && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <PayoutStatusFilters
                          onChange={onPayoutChange}
                          checkedValue={checkedValue}
                          itemKey={itemKey}
                        />
                      </div>
                    </Typography>
                  </Box>
                )}
              {tabIndex === 1 && itemKey === MANAGE_COMMISSION_TEXT && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <ProductNameFilters
                        itemKey={itemKey}
                        onChange={onCommissionChange}
                        data={data}
                        checkedValue={checkedSkuValue}
                      />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 1 && itemKey === 'inventoryDetails' && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <AgeFilters
                        onChange={onAgeChange}
                        itemKey={'inventoryDetailsAge'}
                      />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 1 &&
                itemKey === 'consignmentDetails' &&
                itemKey !== 'skuDetails' &&
                itemKey !== 'payout' &&
                itemKey !== MANAGE_LOCATIONS_TEXT &&
                itemKey !== MANAGE_COMMISSION_TEXT &&
                itemKey !== CONSIGNOR_FILTER_TEXT && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <SKUFilters
                          onChange={onSkuChange}
                          data={data}
                          checkedValue={checkedSkuValue}
                        />
                      </div>
                    </Typography>
                  </Box>
                )}
              {tabIndex === 1 && itemKey === CONSIGNOR_FILTER_TEXT && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <SKUFilters
                        onChange={onSkuChange}
                        data={data}
                        checkedValue={checkedSkuValue}
                        itemKey={CONSIGNOR_FILTER_TEXT}
                      />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 1 &&
                itemKey !== 'consignmentDetails' &&
                itemKey !== 'payout' &&
                itemKey === 'skuDetails' &&
                itemKey !== MANAGE_COMMISSION_TEXT &&
                itemKey !== CONSIGNOR_FILTER_TEXT &&
                itemKey !== MANAGE_LOCATIONS_TEXT && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <DynamicFilter itemKey='size' />
                      </div>
                    </Typography>
                  </Box>
                )}
              {tabIndex === 1 &&
                itemKey !== 'consignmentDetails' &&
                itemKey !== 'payout' &&
                itemKey === 'withdrawalDetails' &&
                itemKey !== MANAGE_COMMISSION_TEXT &&
                itemKey !== CONSIGNOR_FILTER_TEXT &&
                itemKey !== MANAGE_LOCATIONS_TEXT && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <DynamicFilter itemKey='size' />
                      </div>
                    </Typography>
                  </Box>
                )}
              {tabIndex === 1 && itemKey === MANAGE_LOCATIONS_TEXT && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <PayoutStatusFilters
                        onChange={onLocationTypeChange}
                        checkedValue={locationTypeValue}
                        itemKey={'manageLocationType'}
                      />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 1 && itemKey === TRANSFER_TEXT && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <DynamicFilter itemKey='transferType' />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 1 && itemKey === VIEW_ACCEPT_TRANSFER_TEXT && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <PayoutStatusFilters
                        onChange={onPayoutChange}
                        checkedValue={checkedValue}
                        itemKey={VIEW_ACCEPT_TRANSFER_TEXT}
                      />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 1 && itemKey === MISSING_PRODUCTS && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <DynamicFilter itemKey={'size'} />
                    </div>
                  </Typography>
                </Box>
              )}
              {/*  {tabIndex === 2 && itemKey === 'inventoryDetails' && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <DynamicFilter itemKey={'brand'} />
                    </div>
                  </Typography>
                </Box>
              )} */}
              {tabIndex === 2 &&
                itemKey !== 'consignmentDetails' &&
                itemKey !== 'skuDetails' &&
                itemKey !== 'inventoryDetails' &&
                itemKey !== MANAGE_COMMISSION_TEXT &&
                itemKey !== TRANSFER_TEXT && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <AgeFilters
                          onChange={onAgeChange}
                          itemKey={'inventoryAge'}
                        />
                      </div>
                    </Typography>
                  </Box>
                )}
              {tabIndex === 2 &&
                itemKey === 'consignmentDetails' &&
                itemKey !== 'skuDetails' &&
                itemKey !== MANAGE_COMMISSION_TEXT && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <ProductNameFilters
                          onChange={onProductChange}
                          data={data}
                          checkedValue={checkedProductValue}
                        />
                      </div>
                    </Typography>
                  </Box>
                )}
              {tabIndex === 2 && itemKey === TRANSFER_TEXT && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <ProductNameFilters
                        onChange={onProductChange}
                        data={data}
                        checkedValue={checkedProductValue}
                      />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 4 && itemKey !== 'inventoryDetails' && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <DynamicFilter itemKey={'date-range'} />
                    </div>
                  </Typography>
                </Box>
              )}
              {(tabIndex === 1 &&
                itemKey !== 'consignmentDetails' &&
                itemKey !== 'skuDetails' &&
                itemKey === 'previewBulk') ||
                (tabIndex === 1 && itemKey === PRINT_LABELS && (
                  <Box>
                    <Typography>
                      <div className='list-wrapper'>
                        <DynamicFilter itemKey='size' />
                      </div>
                    </Typography>
                  </Box>
                ))}
              {tabIndex === 2 && itemKey === 'inventoryDetails' && (
                <Box>
                  <Typography>
                    <div className='list-wrapper'>
                      <DateFilters
                        onChange={onDateChange}
                        startDate={startDate}
                        endDate={endDate}
                      />
                    </div>
                  </Typography>
                </Box>
              )}
              {tabIndex === 1 &&
                (itemKey == 'inventory' || itemKey == 'consignment') && (
                  <Box className='m-0'>
                    <Typography>
                      <DateFilters
                        onChange={onDateChange}
                        startDate={startDate}
                        endDate={endDate}
                      />
                    </Typography>
                  </Box>
                )}
              {/** the below condition is not good, please update to proper
              condition. */}

              {/* {tabIndex === 1 &&
                itemKey !== CONSIGNMENT_DETAILS_TEXT &&
                itemKey !== SKU_DETAILS_TEXT &&
                itemKey !== CONSIGNOR_FILTER_TEXT &&
                itemKey !== MANAGE_COMMISSION_TEXT &&
                itemKey !== MANAGE_LOCATIONS_TEXT &&
                itemKey !== CONSIGNEMNT_TEXT &&
                itemKey !== 'inventoryDetails' &&
                itemKey !== 'orders' &&
                itemKey !== 'payout' &&
                itemKey !== 'catalog' &&
                itemKey !== PRINT_LABELS &&
                itemKey !== PAYOUT_ORDER_DETAILS_TEXT &&
                itemKey !== 'withdrawal' &&
                itemKey !== 'withdrawalDetails' &&
                itemKey !== TRANSFER_TEXT &&
                itemKey !== VIEW_ACCEPT_TRANSFER_TEXT && (
                  <Box className='m-0'>
                    <Typography>
                      <DateFilters
                        onChange={onDateChange}
                        startDate={startDate}
                        endDate={endDate}
                      />
                    </Typography>
                  </Box>
                )}

              {tabIndex === 1 &&
                itemKey !== 'consignmentDetails' &&
                itemKey !== 'skuDetails' &&
                itemKey !== 'withdrawalDetails' &&
                itemKey !== 'inventoryDetails' &&
                itemKey !== 'previewBulk' &&
                itemKey !== MANAGE_LOCATIONS_TEXT &&
                itemKey !== MANAGE_COMMISSION_TEXT &&
                itemKey !== CONSIGNOR_FILTER_TEXT &&
                itemKey !== 'inventory' &&
                itemKey !== 'payout' &&
                itemKey !== 'orders' &&
                itemKey !== PAYOUT_ORDER_DETAILS_TEXT &&
                itemKey !== PRINT_LABELS &&
                itemKey !== TRANSFER_TEXT &&
                itemKey !== VIEW_ACCEPT_TRANSFER_TEXT && (
                  <Box className='m-0'>
                    <Typography>
                      <DateFilters
                        onChange={onDateChange}
                        startDate={startDate}
                        endDate={endDate}
                      />
                    </Typography>
                  </Box>
                )} */}
              {tabIndex === 0 && itemKey === PAYOUT_DETAILS && (
                <Box className='m-0'>
                  <Typography>
                    <DateFilters
                      onChange={onDateChange}
                      startDate={startDate}
                      endDate={endDate}
                    />
                  </Typography>
                </Box>
              )}
              {tabIndex === 1 && itemKey === 'withdrawal' && (
                <Box className='m-0'>
                  <Typography>
                    <DateFilters
                      onChange={onDateChange}
                      startDate={startDate}
                      endDate={endDate}
                    />
                  </Typography>
                </Box>
              )}
            </Box>
          </Box>

          <div className='search-filter-button-wrapper shoesize-apply-btn size-tab ykch-notransparentBG'>
            <Button
              className='btn-transparent clear-filter-btn yk-badge-h7 text-capitalize'
              onClick={onClearFilters}
              disabled={clearDisable}>
              Clear
            </Button>
            <Button
              variant='contained'
              className='btn yk-btn-primary-sm text-capitalize'
              onClick={onApplyClick}
              disabled={isApplyButtonDisabled}>
              Apply
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductFilters;
