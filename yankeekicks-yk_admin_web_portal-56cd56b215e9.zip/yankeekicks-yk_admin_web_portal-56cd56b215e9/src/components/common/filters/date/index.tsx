import React, { useState } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const DateFilters = (props: any) => {
  const {
    onChange = () => {},
    startDate = '',
    endDate = '',
    inline = 'true',
    customInput = {},
    selectsRange = 'true',
  } = props;

  return (
    <>
      {selectsRange ? (
        <div className='YKEE-datePicker'>
          <DatePicker
            onChange={onChange}
            selectsRange={selectsRange}
            inline={inline}
            showMonthDropdown
            showYearDropdown
            dropdownMode='select'
            startDate={startDate}
            endDate={endDate}
            customInput={customInput}
          />
        </div>
      ) : (
        <div className='YKEE-datePicker'>
          <DatePicker
            onChange={onChange}
            inline={inline}
            showMonthDropdown
            showYearDropdown
            dropdownMode='select'
            selected={startDate}
            customInput={customInput}
            minDate={new Date()}
          />
        </div>
      )}
    </>
  );
};

export default DateFilters;
