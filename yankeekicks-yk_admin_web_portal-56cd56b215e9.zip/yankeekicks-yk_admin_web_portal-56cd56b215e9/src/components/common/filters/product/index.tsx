import React from 'react';
import { Checkbox } from '@mui/material';

const ProductNameFilters = (props: any) => {
  const {
    onChange = () => {},
    data = [],
    checkedValue = [],
    itemKey = '',
  } = props;
  return (
    <>
      <ul className='sub-filter-list '>
        {data?.map((product: any, index: any) => {
          return (
            <div className='list-wrapper' key={index}>
              {(itemKey === 'viewCommission' ||
                itemKey === 'manageCommission') &&
                itemKey !== 'orderDetails' &&
                itemKey !== 'orders' &&
                itemKey !== 'payoutOrderDetails' && (
                  <>
                    <div className='d-flex justify-content-between'>
                      <span>{product?.['ConsigneeType.name']}</span>
                      <Checkbox
                        className='filter-sidebar-checkbox'
                        checked={checkedValue?.includes(
                          product?.['ConsigneeType.name']
                        )}
                        name={product?.['ConsigneeType.name']}
                        onChange={(event: any) => onChange(event)}
                      />
                    </div>
                  </>
                )}
              {itemKey !== 'viewCommission' &&
                itemKey !== 'manageCommission' &&
                itemKey !== 'orderDetails' &&
                itemKey !== 'orders' &&
                itemKey !== 'payoutOrderDetails' && (
                  <>
                    <div className='d-flex justify-content-between'>
                      <span>
                        {product?.['ConsignmentviewDetails.itemName']}
                      </span>
                      <Checkbox
                        className='filter-sidebar-checkbox'
                        checked={checkedValue?.includes(
                          product?.['ConsignmentviewDetails.itemName']
                        )}
                        name={product?.['ConsignmentviewDetails.itemName']}
                        onChange={(event: any) => onChange(event)}
                      />
                    </div>
                  </>
                )}
              {itemKey !== 'viewCommission' &&
                itemKey !== 'manageCommission' &&
                itemKey !== 'orderDetails' &&
                (itemKey === 'payoutOrderDetails' || itemKey === 'orders') && (
                  <>
                    <div className='d-flex justify-content-between'>
                      <span
                        className='filter-nameShorter'
                        title={product?.['Locations.name']}
                      >
                        {product?.['Locations.name']}
                      </span>
                      <Checkbox
                        className='filter-sidebar-checkbox'
                        checked={checkedValue?.includes(
                          product?.['Locations.name']
                        )}
                        name={product?.['Locations.name']}
                        onChange={(event: any) => onChange(event)}
                      />
                    </div>
                  </>
                )}
              {itemKey !== 'viewCommission' &&
                itemKey !== 'manageCommission' &&
                itemKey !== 'orders' &&
                itemKey !== 'payoutOrderDetails' &&
                itemKey === 'orderDetails' && (
                  <>
                    <div className='d-flex justify-content-between'>
                      <span>{product?.['OrdersViewData.userName']}</span>
                      <Checkbox
                        className='filter-sidebar-checkbox'
                        checked={checkedValue?.includes(
                          product?.['OrdersViewData.userName']
                        )}
                        name={product?.['OrdersViewData.userName']}
                        onChange={(event: any) => onChange(event)}
                      />
                    </div>
                  </>
                )}
            </div>
          );
        })}
      </ul>
    </>
  );
};

export default ProductNameFilters;
