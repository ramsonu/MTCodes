export const SEARCH_BY_TYPES = [
  { key: 'Him', value: 'Him' },
  { key: 'Her', value: 'Her' },
  { key: 'Unisex', value: 'Unisex' },
  { key: 'Infant', value: 'Infant' },
  { key: 'Preschool', value: 'Preschool' },
  { key: 'Toddler', value: 'Toddler' },
];
export const SEARCH_BY_COLOURS = [
  { btn1: 'btn1' },
  { btn2: 'btn2' },
  { btn3: 'btn3' },
  { btn4: 'btn4' },
  { btn5: 'btn5' },
  { btn6: 'btn6' },
  { btn7: 'btn7' },
  { btn8: 'btn8' },
  { btn9: 'btn9' },
  { btn10: 'btn10' },
];
export const SEARCH_COLOURS = [
  { key: 'btn1', value: 'white' },
  { key: 'btn2', value: 'blue' },
  { key: 'btn3', value: 'navyblue' },
  { key: 'btn4', value: 'red' },
  { key: 'btn5', value: 'green' },
  { key: 'btn6', value: 'yellow' },
  { key: 'btn7', value: 'gray' },
  { key: 'btn8', value: 'lightyellow' },
  { key: 'btn9', value: 'pink' },
  { key: 'btn10', value: 'brown' },
];

export const SEARCH_BY_SIZES = [
  { key: 1, value: '1' },
  { key: '3.5/5W', value: '3.5/5W' },
  { key: '4/5.5W', value: '4/5.5W' },
  { key: '4.5/6W', value: '4.5/6W' },
  { key: '5/6.5W', value: '5/6.5W' },
  { key: '5.5/7W', value: '5.5/7W' },
  { key: '6/7.5W', value: '6/7.5W' },
  { key: '6.5/8W', value: '6.5/8W' },
  { key: '7/8.5W', value: '7/8.5W' },
  { key: '7.5/9W', value: '7.5/9W' },
  { key: '8/9.5W', value: '8/9.5W' },
  { key: '8.5/10W', value: '8.5/10W' },
  { key: '9/10.5W', value: '9/10.5W' },
  { key: '9.5/11W', value: '9.5/11W' },
  { key: '10/11.5W', value: '10/11.5W' },
  { key: '10.5/12W', value: '10.5/12W' },
  { key: 11, value: '11' },
  { key: 11.5, value: '11.5' },
  { key: 12, value: '12' },
  { key: 12.5, value: '12.5' },
  { key: 13, value: '13' },
  { key: 13.5, value: '13.5' },
  { key: 14, value: '14' },
  { key: 14.5, value: '14.5' },
  { key: 15, value: '15' },
];

export const SEARCH_BRAND = [
  { key: 'nike', value: 'nike' },
  { key: 'jordan', value: 'air jordan' },
  { key: 'adidas', value: 'adidas' },
  { key: 'yeezy', value: 'yeezy' },
  { key: 'supreme', value: 'supreme' },
  { key: 'puma', value: 'puma' },
  { key: 'reebok', value: 'reebok' },
  { key: 'luxury brands', value: 'luxury brands' },
  { key: 'birkenstock', value: 'birkenstock' },
  { key: 'timberland', value: 'timberland' },
  { key: 'crocs', value: 'Crocs' },
  { key: 'UGG', value: 'UGG' },
  { key: 'converse', value: 'converse' },
  { key: 'other Brands', value: 'other brands' },
  { key: 'mew balance', value: 'new balance' },
];

export const SEARCH_AGE = [
  { key: '1week', value: '1 week' },
  { key: '1month', value: '1 month' },
  { key: '3months', value: '3 months' },
  { key: '6months', value: '6 months' },
  { key: '9months', value: '9 months' },
  { key: '1year', value: '1 year' },
];
export const TRANSFER_TYPE = [
  { key: 'incoming', value: 'incoming' },
  { key: 'outgoing', value: 'outgoing' },
];

export const SEARCH_RELEASE_NO_OF_YEARS = 10;

export const filterByInventory = ['Brand', 'Date Range', 'Age'];
export const filterByConsignorInventory = ['Brand'];
export const filterByCatalog = ['Brand', 'Date Range', 'Age'];
export const filterByOrder = ['Status', 'Sale Location'];
export const filterByConsignmentDetails = ['Status', 'SKU', 'Product'];
export const filterBySkuDetails = ['Status', 'Size'];
export const filterByWithdrawalDetails = ['Status', 'Size'];
export const filterByConsignment = ['Status', 'Date Range'];
export const filterByWithdraw = ['Status', 'Date Range'];
export const filterByInventorySkuDetails = [
  'Status',
  'Age',
  //  'Brand',
  'Date Range',
  'Size',
];
export const filterByConsignorInventorySkuDetails = ['Status'];
export const filterByPreviewBulk = ['Brand', 'Size'];
export const filterByPayout = ['Commission'];
export const filterByPayoutHistory = ['Date Range'];
export const filterByConsignor = ['Status', 'Commission'];
export const filterByManageCommission = ['Status', 'Type'];
export const filterByOrderDetails = ['Consignor'];
export const filterByPayoutOrderDetails = ['Sale Location', 'Brand'];
export const filterByPushNotifications = ['Status'];
export const filterByManageUsers = ['Status'];
export const filterByManageLocations = ['Status', 'Type'];
export const filterByViewCommission = ['Name'];
export const filterByPayoutDetails = ['Date Range'];
export const filterByPrintLabels = ['Brand', 'Size'];
export const filterByTransfer = ['Status', 'Type'];
export const filterByViewAcceptTransfer = ['Size', 'Status'];
export const filterByInitiateTransfer = ['Brand'];
export const filtersByDashboard = ['Date Range'];
export const filtersByMissingProducts = ['Brand', 'Size'];

export const CONSIGNMENT_ADMIN_AND_YK_ADMIN_TEXTS = {
  SKU_DETAILS_TEXT: 'skuDetails',
  CONSIGNMENT_DETAILS_TEXT: 'consignmentDetails',
  MANAGE_COMMISSION_TEXT: 'manageCommission',
  CONSIGNOR_FILTER_TEXT: 'consignorFilter',
  CONSIGNOR_FILTER_STATUS_TEXT: 'consignorFilterStatus',
  COMMISSION_FILTER_STATUS_TEXT: 'commissionFilterStatus',
  CONSIGNOR_FILTER_COMMISSION_TEXT: 'consignorFilterCommission',
  TYPE_FILTER_COMMISSION_TEXT: 'typeFilterCommission',
  CONSIGNEMNT_TEXT: 'consignment',
  INVENTORY_TEXT: 'inventory',
  CATALOG_TEXT: 'catalog',
  ORDER_TEXT: 'orders',
  PAYOUT_TEXT: 'payout',
  PAYOUT_DETAILS: 'payoutDetails',
  ORDER_DETAILS_TEXT: 'orderDetails',
  PAYOUT_ORDER_DETAILS_TEXT: 'payoutOrderDetails',
  MANAGE_USERS_TEXT: 'manageUsers',
  MANAGE_LOCATIONS_TEXT: 'manageLocations',
  CONSIGNOR_INVENTORY_TEXT: 'consignorInventory',
  CONSIGNOR_INVENTORY_DETAILS_TEXT: 'consignorInventoryDetails',
  PRINT_LABELS: 'printLabels',
  INITIATE_TRANSFER_TEXT: 'initiateTransfer',
  TRANSFER_TEXT: 'transfer',
  VIEW_ACCEPT_TRANSFER_TEXT: 'viewAcceptTransfer',
  DASHBOARD_FILTER_TEXT: 'dashboardFilters',
  MISSING_PRODUCTS: 'missingProducts',
};
