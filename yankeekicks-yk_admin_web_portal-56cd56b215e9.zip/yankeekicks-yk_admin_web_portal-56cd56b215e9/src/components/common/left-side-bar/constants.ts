import DashboardIcon from 'assets/images/menu-icons/dashboard-default.svg';
import SettingsIcon from 'assets/images/menu-icons/orders-default.svg';
import InventoryD from 'assets/images/menu-icons/inventory-default.svg';
import LocationIcon from 'assets/images/location-icon.svg';
import ConsignorIcon from 'assets/images/consignee/group-consignee.svg';

export const consignmentsMenuItems = [
  // {
  //   notVisible: true, //first item needs to hide
  // },
  {
    text: 'Consignment Admin',
    path: '/consignment-admin/consignors',
    subText: 'Portal',
    isLocation: true,
  },
  {
    text: 'Dashboard',
    path: '/consignment-admin',
    imgIcon: ConsignorIcon,
    className: 'dashboard',
  },
  {
    text: 'Consignors',
    path: '/consignment-admin/consignors',
    imgIcon: ConsignorIcon,
    subPaths: [
      '/consignment-admin/consignors/[consignorId]',
      '/consignment-admin/consignors/[consignorId]/edit',
    ],
    className: 'consignors',
  },
  {
    text: 'Shipments',
    path: '/consignment-admin/shipments',
    imgIcon: InventoryD,
    subPaths: [
      '/consignment-admin/shipments/[consignmentId]',
      '/consignment-admin/shipments/[consignmentId]/[...sku]',
    ],
    className: 'consignments',
  },
  {
    text: 'My inventory',
    path: '/consignment-admin/inventory',
    imgIcon: InventoryD,
    subPaths: [
      '/consignment-admin/inventory/bulkimport',
      '/consignment-admin/inventory/AddShoesCatalog',
      '/consignment-admin/inventory/skudetails',
      '/consignment-admin/inventory/[skuId]',
      '/consignment-admin/inventory/shoe-catalog',
      '/consignment-admin/inventory/add-inventory-response',
      '/consignment-admin/inventory/previewcatalog',
      '/consignment-admin/inventory/print-labels',
      '/consignment-admin/inventory/missing-products'
    ],
    className: 'products',
  },
  {
    text: 'Transfers',
    path: '/consignment-admin/transfers',
    imgIcon: InventoryD,
    subPaths: [
      '/consignment-admin/transfers/initiate-transfer',
      '/consignment-admin/transfers/review-transfer',
      '/consignment-admin/transfers/view-transfer',
      '/consignment-admin/transfers/accept-transfer',
    ],
    className: 'transfers',
  },
  {
    text: 'Orders',
    path: '/consignment-admin/orders',
    imgIcon: InventoryD,
    subPaths: ['/consignment-admin/orders/[orderId]'],
    className: 'orders',
  },
  {
    text: 'Payouts',
    path: '/consignment-admin/payouts',
    imgIcon: InventoryD,
    subPaths: [
      '/consignment-admin/payouts/[consignorId]',
      '/consignment-admin/payouts/[consignorId]/[orderId]',
    ],
    className: 'payouts',
  },
  {
    text: 'Product Withdrawal',
    path: '/consignment-admin/withdraws',
    imgIcon: ConsignorIcon,
    subPaths: ['/consignment-admin/withdraws/[withdrawReqId]'],
    className: 'product-withdrawal',
  },
  {
    text: 'Settings',
    path: '/consignment-admin/settings',
    imgIcon: SettingsIcon,
    className: 'settings',
  },
];

export const YK_ADMIN_MENU_ITEMS = [
  {
    text: 'YK Admin',
    path: '/yk-admin/consignors',
    subText: 'Portal',
    isLocation: true,
  },
  {
    text: 'Dashboard',
    path: '/yk-admin',
    imgIcon: ConsignorIcon,
    className: 'dashboard',
  },
  {
    text: 'Consignors',
    path: '/yk-admin/consignors',
    subPaths: [
      '/yk-admin/consignors/[consignorId]',
      '/yk-admin/consignors/[consignorId]/edit',
    ],
    className: 'consignors',
  },
  {
    text: 'Shipments',
    path: '/yk-admin/shipments',
    subPaths: [
      '/yk-admin/shipments/[consignmentId]',
      '/yk-admin/shipments/[consignmentId]/[...sku]',
    ],
    className: 'consignments',
  },
  {
    text: 'My Inventory',
    path: '/yk-admin/inventory',
    subPaths: [
      '/yk-admin/inventory/bulkimport',
      '/yk-admin/inventory/AddShoesCatalog',
      '/yk-admin/inventory/[skuId]',
      '/yk-admin/inventory/skudetails',
      '/yk-admin/inventory/shoe-catalog',
      '/yk-admin/inventory/add-inventory-response',
      '/yk-admin/inventory/previewcatalog',
      '/yk-admin/inventory/missing-products'
    ],
    className: 'products',
  },
  {
    text: 'Transfers',
    path: '/yk-admin/transfers',
    subPaths: [
      '/yk-admin/transfers/initiate-transfer',
      '/yk-admin/transfers/review-transfer',
      '/yk-admin/transfers/view-transfer',
      '/yk-admin/transfers/accept-transfer',
    ],
    className: 'transfers',
  },
  {
    text: 'Orders',
    path: '/yk-admin/orders',
    subPaths: ['/yk-admin/orders/[orderId]'],
    className: 'orders',
  },
  {
    text: 'Payouts',
    path: '/yk-admin/payouts',
    subPaths: [
      '/yk-admin/payouts/[consignorId]',
      '/yk-admin/payouts/[consignorId]/[orderId]',
    ],
    className: 'payouts',
  },

  {
    text: 'Product Withdrawal',
    path: '/yk-admin/withdraws',
    imgIcon: ConsignorIcon,
    subPaths: ['/yk-admin/withdraws/[withdrawReqId]'],
    className: 'product-withdrawal',
  },

  {
    text: 'Manage User',
    path: '/yk-admin/manage-users',
    subPaths: [
      '/yk-admin/manage-users/add-user',
      '/yk-admin/manage-users/[userId]',
      '/yk-admin/manage-users/[userId]/edit',
    ],
    className: 'manage-user',
  },

  {
    text: 'Manage Location',
    path: '/yk-admin/manage-locations',
    subPaths: [
      '/yk-admin/manage-locations/add-location',
      '/yk-admin/manage-locations/[locationId]',
    ],
    className: 'manage-location',
  },
  {
    text: 'Manage commission',
    path: '/yk-admin/manage-commissions',
    subPaths: [
      '/yk-admin/manage-commissions/add-commission',
      '/yk-admin/manage-commissions/view-commissions',
    ],
    className: 'manage-commission',
  },
  {
    text: 'Settings',
    path: '/yk-admin/settings',
    className: 'settings',
  },
  {
    text: 'Push Notifications',
    path: '/yk-admin/push-notifications',
    subPaths: [
      '/yk-admin/push-notifications/new-notification',
      '/yk-admin/push-notifications/[userId]',
    ],
    className: 'push-notifications',
  },
  {
    text: 'reports',
    path: '/yk-admin/reports',
    className: 'reports',
  },
];

export const YK_NEW_ADMIN_MENU_ITEMS = [];

export const YK_ADMIN_MENU_ITEMS_REQUIRED =
  process.env.NEXT_PUBLIC_ENV === 'uat' ||
  process.env.NEXT_PUBLIC_ENV === 'prod'
    ? YK_ADMIN_MENU_ITEMS
    : [...YK_ADMIN_MENU_ITEMS, ...YK_NEW_ADMIN_MENU_ITEMS];
