import * as React from 'react';
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import bulkIcon from 'assets/images/bulk-icon.svg';
import gridIcon from 'assets/images/grid-icon.svg';
import downIcon from 'assets/images/dropdown-white-arrow-icon.svg';
import Image from 'next/image';
import { useRouter } from 'next/router';
export default function ProductMenu() {
  const router = useRouter();
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);

  const open = Boolean(anchorEl);

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <Button
        id='basic-button'
        aria-controls={open ? 'basic-menu' : undefined}
        aria-haspopup='true'
        aria-expanded={open ? 'true' : undefined}
        onClick={handleClick}
        className='add-product-button'>
        Add Product{' '}
        <Image src={downIcon} alt='table-img' className='img-fluid' />
      </Button>

      <Menu
        id='basic-menu'
        className='product-menu-dropdown-btn-wrapper'
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          'aria-labelledby': 'basic-button',
        }}>
        <MenuItem
          className='add-product-meu-item'
          onClick={() => router?.push('inventory/bulkimport')}>
          Bulk Import{' '}
          <Image src={bulkIcon} alt='table-img' className='img-fluid' />
        </MenuItem>
        <MenuItem
          className='add-product-meu-item'
          onClick={() => router?.push('inventory/AddShoesCatalog')}>
          Browse Catalog{' '}
          <Image src={gridIcon} alt='table-img' className='img-fluid' />
        </MenuItem>
      </Menu>
    </div>
  );
}
