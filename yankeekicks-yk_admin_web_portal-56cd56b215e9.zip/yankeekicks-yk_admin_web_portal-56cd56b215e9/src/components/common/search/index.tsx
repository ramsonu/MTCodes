import React, { useMemo } from 'react';
import debounce from 'lodash.debounce';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import Autocomplete from '@mui/material/Autocomplete';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import searchIcon from 'assets/images/search-icon.png';
import Image from 'next/image';
import InputAdornment from '@mui/material/InputAdornment';
import { SEARCH_WTIH_FILTERS_REQUEST } from 'actions/kiosk';

/**
 * This component is using for search the real time api
 * @returns product with title
 */
const Search = (props: any) => {
  const {
    onSelectHandler = () => {},
    isApiCall = false,
    options = [],
    onChangeHandler = () => {},
    optionType = 'default',
    userInput = '',
    placeholder = '',
    limitForInfiniteScroll = 50,
  } = props;
  const router = useRouter();
  const renderOptions = () => {
    let optionsToShow: any = [];
    switch (optionType) {
      case 'default':
        optionsToShow = options?.map((option: any) => {
          return option?.node?.title;
        });
        break;
      case 'change':
        optionsToShow = options?.map((option: any) => {
          return option['InventoryLineItem.name'];
        });
        break;
      case 'no suggestions':
        optionsToShow = [];
        break;
    }
    return optionsToShow;
  };

  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const dispatch = useDispatch();

  const debounceResult = useMemo(() => {
    return debounce(onChangeHandler, 300);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <Stack spacing={2} sx={{ width: '100%' }}>
      <Autocomplete
        freeSolo
        id='searcth-autocomplete'
        disableClearable
        value={userInput}
        options={renderOptions()}
        onSelect={onSelectHandler}
        //onChange={(event, value) => dispatch(actions.setSearch(value))}
        renderInput={(params) => (
          <TextField
            className='custom-search-field'
            {...params}
            onChange={(event) => debounceResult(event)}
            placeholder={placeholder}
            onKeyDown={(e: any) => {
              if (e.keyCode === 13 && e.target.value && isApiCall) {
                dispatch({
                  type: SEARCH_WTIH_FILTERS_REQUEST,
                  payload: {
                    params: {
                      ...filterTypes,
                      limitForQuery: limitForInfiniteScroll,
                    },
                  },
                });
                router.push('/kiosk/results');
              }
            }}
            InputProps={{
              ...params.InputProps,
              type: 'search',
              startAdornment: (
                <InputAdornment position='start'>
                  <Image src={searchIcon} alt='search-icon' />
                </InputAdornment>
              ),
            }}
          />
        )}
      />
    </Stack>
  );
};

export default Search;
