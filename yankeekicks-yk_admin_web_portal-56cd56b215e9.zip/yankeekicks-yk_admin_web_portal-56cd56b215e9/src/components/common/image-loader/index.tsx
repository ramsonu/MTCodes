import React, { useState, useEffect } from 'react';
import { getImage } from 'services/shoesize';
import cachingImage from './caching-image';

const ImageLoader = ({
  src,
  alt = '',
  fallbackImg = '',
  isCaching = true,
  width = '',
  height = '',
  className = '',
}: any) => {
  const [imageData, setImageData] = useState<any>(null);

  useEffect(() => {
    if (isStockxUrl()) {
      const newSrc = `${src.split('?')[0]}?auto=compress&w=200&q=90&dpr=2`;
      setImageData(newSrc);
    } else if (isHttps()) setImageData(src);
    else if (!!src) loadImage();
  }, [src]); //eslint-disable-line
  const isStockxUrl = () => /^(http|https):\/\/images.stockx.com/i.test(src);
  const isHttps = () => /^(http|https):\/\//i.test(src);
  const loadImage = async () => {
    //caching Image to reduce endpoints calls
    if (isCaching) {
      let img: any = await cachingImage(src);
      if (img?.data) {
        setImageData(img.data);
      } else {
        setImageData(fallbackImg?.src);
      }
    } else {
      try {
        const result: any = await getImage(src);
        if (result?.data?.data) {
          setImageData(result.data.data);
        }
      } catch (e) {
        setImageData(fallbackImg?.src);
      }
    }
  };
  return (
    <img
      src={!!imageData ? imageData : fallbackImg?.src}
      alt={alt}
      className={className}
      width={100}
      height={100}
    />
  );
};
export default ImageLoader;
