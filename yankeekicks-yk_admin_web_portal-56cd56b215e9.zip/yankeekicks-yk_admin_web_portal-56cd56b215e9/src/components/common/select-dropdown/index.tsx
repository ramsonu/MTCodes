import React, { useEffect, useState } from 'react';
import { MenuItem, Select } from '@mui/material';
import { FormControl } from '@mui/material';
import upIcon from 'assets/images/up-arrow-icon.svg';
import downIcon from 'assets/images/down-arrow-icon.svg';
import Image from 'next/image';

const Selectdropdown = (props: any) => {
  const {
    handleChange = {},
    dropdownList = [],
    itemKey = '',
    defaultSelectedValue = '',
    selectType = '',
    selectedValues = '',
  } = props;
  const [sortsValue, setSortsValue] = useState<any>([]);
  return (
    <>
      <div className='sort-product-wrapper mu-sort order-sort-btn YKCH-sort'>
        <FormControl sx={{ m: 1, minWidth: 80 }}>
          <Select
            labelId='demo-simple-select-autowidth-label'
            id='demo-simple-select'
            onChange={(e: any) => handleChange(e)}
            defaultValue={defaultSelectedValue}
            displayEmpty
            title={defaultSelectedValue}>
            {!!selectType && (
              <MenuItem
                value=''
                className='YKCH-dataInfinite yk-disabledSelectOption'>
                {selectType}
              </MenuItem>
            )}
            {dropdownList?.map((data: any, index: any) => {
              return (
                <MenuItem
                  key={data?.id || index}
                  value={data}
                  className='YKCH-dataInfinite'>
                  {data?.name || data}
                </MenuItem>
              );
            })}
          </Select>
        </FormControl>
      </div>
    </>
  );
};

export default Selectdropdown;
