import React from 'react';
import ProductFilters from '../filters/product-filter';
import Sortings from '../sortings';
import Image from 'next/image';
import filterIcon from 'assets/images/filter-icon.png';

const Headers = (props: any) => {
  const {
    sortHandler = () => {},
    handleFilterClick = () => {},
    exportsResultsSet = {},
    showFilters = Boolean,
    onDateChange = () => {},
    selectedStartDate = '',
    selectedEndDate = '',
    onClick = () => {},
    onPayoutChange = () => {},
    checked = {},
    onClearFilters = () => {},
  } = props;
  return (
    <>
      <div className='col-lg-6 col-md-12 col-sm-12'>
        <div className='consignment-btn-wrapper'>
          <Sortings handleChange={sortHandler} />

          <div className='filter-btn-wrapper'>
            <button className='btn filter-btn' onClick={handleFilterClick}>
              <Image
                src={filterIcon}
                alt='filter-btn-icon'
                className='filter-btn-icon img-fluid'
              />
              <span className='filter-btn-text yk-badge-h15'>Filter</span>
              {showFilters && (
                <ProductFilters
                  itemKey='order'
                  onDateChange={onDateChange}
                  startDate={selectedStartDate}
                  endDate={selectedEndDate}
                  onClick={onClick}
                  onPayoutChange={onPayoutChange}
                  checkedValue={checked}
                  onClearFilters={onClearFilters}
                />
              )}
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
export default Headers;
