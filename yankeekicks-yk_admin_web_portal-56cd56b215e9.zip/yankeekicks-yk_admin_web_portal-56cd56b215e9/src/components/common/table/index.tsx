import React, { useState } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/router';
import { format } from 'date-fns';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Checkbox,
  Tooltip,
  ClickAwayListener,
} from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';
import {
  convertPriceToUSFormat,
  copyContentToClipBoard,
  getTrimmedText,
  updatePhoneNumber,
} from 'utils/util';
import { CANNOT_ADD_TO_QUEUE, TRANSFER_NOT_ZERO } from 'utils/constants';
import { SELLING_PRICE_ERROR_MSG } from 'components/consignment-admin/products/constant';
import ImageLoader from '../image-loader';
import NoDataFound from '../no-data-found';
import CopyToClipboardComponent from '../copyToClipboard';
import AddIcon from 'assets/images/grey-add-icon.svg';
import productImg from 'assets/images/big-product-img.svg';
import incomingICO from 'assets/images/incomingico.svg';
import statusClassList from 'utils/statusTypes';
import { Diversity2Sharp, Diversity2TwoTone } from '@mui/icons-material';

const VirtualTable = React.forwardRef(
  (props: any, ref: React.Ref<HTMLDivElement>) => {
    const {
      headers = [],
      rowData = [],
      offSet = 0,
      error,
      loading = false,
      noData = false,
      emptyRow = false,
      searchData = false,
    } = props;
    const router = useRouter();

    if (loading) {
      return (
        <div className='YKCH-loader'>
          <CircularProgress />
        </div>
      );
    }
    if (error) {
      return <div>{error?.message?.toString()}</div>;
    }
    if (rowData?.length === 0 && !loading && !emptyRow) {
      return <NoDataFound searchData={searchData} />;
    }

    const renderValue = (data: any, row: any) => {
      let value = data?.[row?.value];
      if (value) {
        if (row?.methodToApply === 'toFix') {
          value = parseFloat(data[row?.value])?.toFixed(2);
        }
        if (row?.prefix && row?.suffix) {
          value = `${row?.prefix}${convertPriceToUSFormat(
            value,
            false,
            row?.prefix,
            row?.suffix
          )}${row?.suffix}`;
        } else {
          if (row?.prefix) {
            value = `${row?.prefix}${convertPriceToUSFormat(
              value,
              false,
              row?.prefix
            )}`;
          }
          if (row?.suffix) {
            value = `${convertPriceToUSFormat(
              data[row?.value],
              false,
              row?.suffix
            )}${row?.suffix}`;
          }
        }
        return value;
      } else if (!data?.[row?.value] && !!row?.nullValue) {
        return 'N/A';
      } else {
        return row?.defaultValue ? row?.defaultValue : '--';
      }
    };

    const getAge = (releaseDate: any) => {
      const currentDate = new Date();
      const releaseDates = new Date(releaseDate);
      var diff = Math.floor(currentDate.getTime() - releaseDates?.getTime());
      var day = 1000 * 60 * 60 * 24;
      var days = Math.floor(diff / day);
      var months = Math.floor(days / 31);
      var years = Math.floor(months / 12);

      if (days < 31) {
        return days + ' days';
      }
      if (months < 12) {
        return months + ' months';
      }
      if (months > 12) {
        return years + ' years';
      }
      // return days;
    };
    const calCulateTotalPrice = (data: any, payout: any) => {
      const calculatedPay =
        (payout / 100) * parseFloat(data['price'] || data['sellingPrice']) ||
        (payout / 100) * parseInt(data['quantity']);
      const minimum = calculatedPay > 25 ? calculatedPay : 25;
      const payCalculated =
        parseFloat(data['price'] || data['sellingPrice']) - minimum;
      const pay = payCalculated;
      const calculatedTotal: any = pay * parseInt(data['quantity']);
      return convertPriceToUSFormat(
        parseFloat(calculatedTotal)?.toFixed(2),
        false
      );
    };
    const calCulatePayOut = (data: any, payout: any) => {
      if (data.sellingPrice || data.price) {
        const calculatedPay =
          (payout / 100) * parseFloat(data['price'] || data['sellingPrice']) ||
          (payout / 100) * parseInt(data['quantity']);
        const minimum = calculatedPay > 25 ? calculatedPay : 25;
        const payCalculated =
          parseInt(data['price'] || data['sellingPrice']) - minimum;
        const pay = payCalculated;
        calculateTotalPay(data);
        data['payout'] = pay;
        return convertPriceToUSFormat(pay?.toFixed(2), false);
      } else {
        return '0.00';
      }
    };
    const calCulatePayOutBulk = (data: any, payout: any) => {
      if (data.sellingPrice || data.price) {
        const calculatedPay =
          (payout / 100) * parseFloat(data['price'] || data['sellingPrice']) ||
          (payout / 100) * parseInt(data['quantity']);
        const minimum = calculatedPay > 25 ? calculatedPay : 25;
        const payCalculated =
          parseFloat(data['price'] || data['sellingPrice']) - minimum;
        const pay = parseInt(data['quantity']) * payCalculated;
        return convertPriceToUSFormat(pay?.toFixed(2), false);
      } else {
        return '0.00';
      }
    };
    const calculateTotalPay = (data: any) => {
      const calculatedTotal: any =
        parseFloat(data['payout']) * parseInt(data['quantity']);
      data['totalPay'] = isNaN(calculatedTotal) ? 0 : calculatedTotal;
      return convertPriceToUSFormat(calculatedTotal?.toFixed(2));
    };
    const calCulateCost = (data: any, itemCost: any) => {
      if (data.itemCost || data.itemCost) {
        return convertPriceToUSFormat(itemCost?.toFixed(2), false);
      } else {
        return '0.00';
      }
    };
    const calculateTotalCost = (data: any) => {
      const calculatedTotal: any =
        parseFloat(data?.['costPerItem']) * parseInt(data?.['quantity']);
      data['totalCost'] = isNaN(calculatedTotal) ? 0 : calculatedTotal;
      // return calculatedTotal?.toFixed(2);
      return isNaN(calculatedTotal)
        ? convertPriceToUSFormat(0)
        : convertPriceToUSFormat(calculatedTotal?.toFixed(2));
    };

    return (
      <div className='parent-table-wrapper'>
        <div className='table-wrapper YKCH-overloadDataTable' ref={ref}>
          <TableContainer component={Paper}>
            <Table
              aria-label='collapsible table'
              className='yk-inventory-table YKCH-FixedTableData bg-transparent'>
              <TableHead>
                <TableRow className='yk-parent-table-row YKCH-FixedRow'>
                  {headers.map((row: any, index: any) => (
                    <React.Fragment key={index}>
                      {(row?.type === 'checkbox' ||
                        row?.type === 'payoutCheckbox' ||
                        row?.type === 'consignmentReviewCheckbox') &&
                      row?.removeCheckAll != true ? (
                        <TableCell
                          className='yk-table-body-td YKCH-FixedCel'
                          key={index}>
                          <Checkbox
                            className={`filter-sidebar-checkbox ${row['isAllChecked']}`}
                            onChange={(e) => row?.checkAll(e, rowData)}
                            name={row.value}
                            value='checkAll'
                          />

                          {row?.title}
                        </TableCell>
                      ) : (
                        row?.type !== 'hidden' && (
                          <TableCell
                            className={`yk-parent-table-th YKCH-FixedCel ${
                              row?.type === 'button' ? 'hide-on-print' : ''
                            }`}
                            key={index}>
                            {row?.title}
                          </TableCell>
                        )
                      )}
                    </React.Fragment>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {rowData?.length === 0 && emptyRow ? (
                  <TableRow className='yk-body-table-row YKCH-FixedRow'>
                    <TableCell
                      className='yk-table-body-td cursor-data YKCH-FixedCel yk-selectToAddTd'
                      colSpan={headers.length}>
                      <span className='yk-addIcon'>
                        <Image src={AddIcon} alt='' className='img-fluid' />
                      </span>
                      Select size to add
                    </TableCell>
                  </TableRow>
                ) : (
                  rowData?.map((data: any, i: any) => (
                    <TableRow
                      key={`row-${data?.id}-${i}`}
                      data-id={`${data?.id}-${i}`}
                      className={`yk-body-table-row YKCH-FixedRow ${
                        Number(data?.sellingPrice) <= Number(data?.costPerItem)
                          ? 'YKCH-TableInvalid'
                          : ''
                      }`}>
                      {headers.map((row: any, index: any) => (
                        <React.Fragment key={`${index}_${i}`}>
                          {row?.type === 'sno' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              {offSet + i + 1}
                            </TableCell>
                          )}
                          {row?.type === 'payoutCheckbox' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              {((): any => {
                                if (data?.['isChecked']) {
                                  return (
                                    <Checkbox
                                      className='filter-sidebar-checkbox'
                                      onChange={(e) =>
                                        row?.onChange(e, data, rowData)
                                      }
                                      checked={data?.['isChecked']}
                                      value={data?.value}
                                      disabled={data[row?.isDisabled]}
                                    />
                                  );
                                } else {
                                  return <span> </span>;
                                }
                              })()}
                            </TableCell>
                          )}
                          {row?.type === 'checkbox' && (
                            <TableCell
                              className={`yk-table-body-td cursor-data YKCH-FixedCel`}
                              key={`${index}_${i}`}>
                              <Checkbox
                                className={`filter-sidebar-checkbox ${
                                  row?.ref == 'withdrawal'
                                    ? !!data[row?.costPerItem]
                                      ? ''
                                      : 'd-none'
                                    : ''
                                }`}
                                onChange={(e) =>
                                  row?.onChange(e, data, rowData)
                                }
                                checked={data?.['isChecked']}
                                value={data?.value}
                                disabled={data[row?.isDisabled]}
                              />
                            </TableCell>
                          )}
                          {row?.type === 'consignmentReviewCheckbox' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              <Checkbox
                                className='filter-sidebar-checkbox'
                                onChange={(e) =>
                                  row?.onChange(e, data, rowData)
                                }
                                checked={!!data?.['isChecked']}
                                value={data?.value}
                                disabled={data[row?.isDisabled]}
                              />
                            </TableCell>
                          )}
                          {row?.type === 'image' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              {row?.mode === 'static' ? (
                                <Image
                                  src={row?.value}
                                  alt='cart-img'
                                  className='img-fluid YKCH-thumbnail'
                                  onClick={() => row?.onClick(data)}
                                />
                              ) : row?.mode === 'staticData' ? (
                                <Image
                                  src={data[row?.value] || productImg}
                                  alt='cart-img'
                                  className='img-fluid'
                                  width={50}
                                  height={50}
                                />
                              ) : (
                                <ImageLoader
                                  src={data[row?.value]}
                                  fallbackImg={productImg}
                                  alt='cart-img'
                                  className='img-fluid YKCH-thumbnail'
                                  onClick={() => row?.onClick(data.size)}
                                />
                              )}
                            </TableCell>
                          )}
                          {row?.type === 'button' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              {row?.mode === 'two buttons' ? (
                                <>
                                  <a
                                    role='button'
                                    className={`yk-table-link-btn clear-filter-btn ${
                                      row.disabled ? 'disabled' : ''
                                    } hide-on-print me-3`}
                                    onClick={() =>
                                      row?.onClick(data, row?.value)
                                    }>
                                    {row?.value}
                                  </a>
                                  <a
                                    role='button'
                                    className={`yk-table-link-btn clear-filter-btn ${
                                      row.disabled ? 'disabled' : ''
                                    } hide-on-print`}
                                    onClick={() =>
                                      row?.onClick(data, row?.value1)
                                    }>
                                    {row?.value1}
                                  </a>
                                </>
                              ) : (
                                <a
                                  role='button'
                                  className={`yk-table-link-btn clear-filter-btn ${
                                    row.disabled ? 'disabled' : ''
                                  } hide-on-print`}
                                  onClick={() => row?.onClick(data)}>
                                  {row?.value}
                                </a>
                              )}
                            </TableCell>
                          )}
                          {row?.type === 'dynamicActionButton' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              <a
                                role='button'
                                className={`yk-table-link-btn clear-filter-btn ${
                                  row.disabled ? 'disabled' : ''
                                } hide-on-print`}
                                onClick={() => row?.onClick(data)}>
                                {data[row?.value] === 'Pending'
                                  ? row?.from === 'Transfer'
                                    ? 'Accept'
                                    : 'Review'
                                  : 'View'}
                              </a>{' '}
                            </TableCell>
                          )}
                          {row?.type === 'transferDynamicActionButton' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              <a
                                role='button'
                                className={`yk-table-link-btn clear-filter-btn ${
                                  row.disabled ? 'disabled' : ''
                                } hide-on-print`}
                                onClick={() => row?.onClick(data)}>
                                {data['Transfers.fromlocationId'] ===
                                  localStorage?.getItem('storeLocationId') ||
                                data[row?.value] === 'Completed'
                                  ? 'View'
                                  : 'Accept'}
                              </a>
                            </TableCell>
                          )}
                          {row?.type === 'printQRButton' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              <a
                                role='button'
                                className={`yk-table-link-btn clear-filter-btn ${
                                  row.disabled ? 'disabled' : ''
                                } hide-on-print`}
                                onClick={() => row?.onClick(data, false)}>
                                {data[row?.value] === 'Active' &&
                                data[row?.additionalCheck] !== null &&
                                data[row?.locationCheck] !== null
                                  ? 'Print QR code'
                                  : null}
                              </a>{' '}
                            </TableCell>
                          )}
                          {row?.type === 'textbox' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              <div
                                className={
                                  row?.title === 'Selling Price' ||
                                  row?.title === 'Payout/Item' ||
                                  row?.title === 'Cost/item'
                                    ? `YKCH-group input-group input-prepend ${
                                        row.disabled ? 'disabled' : ''
                                      }`
                                    : 'YKCH-group input-group input-prepend'
                                }>
                                <span
                                  className={
                                    row?.title === 'Selling Price' ||
                                    row?.title === 'Payout/Item' ||
                                    row?.title === 'Cost/item'
                                      ? 'YKCH-grouping input-group input-prepend'
                                      : 'YKCH-grouping input-group input-prepend'
                                  }>
                                  {row?.title === 'Selling Price' ||
                                  row?.title === 'Payout/Item' ||
                                  row?.title === 'Cost/item' ? (
                                    <span
                                      className={
                                        row?.title === 'Selling Price' ||
                                        row?.title === 'Payout/Item' ||
                                        row?.title === 'Cost/item'
                                          ? 'input-group-text'
                                          : ''
                                      }>
                                      $
                                    </span>
                                  ) : (
                                    <></>
                                  )}
                                  <input
                                    type='text'
                                    className={` ${
                                      row?.title === 'Selling Price' ||
                                      row?.title === 'Payout/Item' ||
                                      row?.title === 'Cost/item'
                                        ? 'YKCH-fieldGroupp'
                                        : 'yk-QuantityInput'
                                    }`}
                                    value={
                                      row?.isAddModal
                                        ? calCulatePayOut(data, row?.payout)
                                        : data?.[row?.value]
                                    }
                                    disabled={row?.disabled}
                                    maxLength={10}
                                    onChange={(e) => row?.onChange(e, i)}
                                  />
                                </span>
                              </div>
                              {row?.title === 'Selling Price' &&
                                Number(data?.sellingPrice) <=
                                  Number(data?.costPerItem) && (
                                  <span className='invalid-feedback'>
                                    {SELLING_PRICE_ERROR_MSG}
                                  </span>
                                )}
                              {row?.title === 'Transfer Quantity' &&
                                // row?.checkStockAvailability?.includes(
                                //   data?.size
                                // )
                                row?.methodToUseForComparison(
                                  row?.checkStockAvailability,
                                  data,
                                  true
                                ) && (
                                  <span className='invalid-feedback'>
                                    {CANNOT_ADD_TO_QUEUE}
                                  </span>
                                )}
                              {row?.title === 'Transfer Quantity' &&
                                data?.quantityToTransfer === 0 && (
                                  <span className='invalid-feedback'>
                                    {TRANSFER_NOT_ZERO}
                                  </span>
                                )}
                            </TableCell>
                          )}

                          {row?.type === 'select' && (
                            <TableCell className='yk-table-body-td YKCH-FixedCel cursor-data select'>
                              <select
                                className='form-control custom-select select-state-dropdown yk-select-condition input-group'
                                id={row?.title}
                                defaultValue={row?.value}
                                onChange={(e) => row?.onChange(e, i)}>
                                <option value=''>Select {row?.title}</option>
                                {row?.dropdown?.map(
                                  (item: any, index: number) => {
                                    return (
                                      <option
                                        key={`selectIndex_${index}`}
                                        value={item?.value}
                                        data-title={item?.title}>
                                        {item?.title}
                                      </option>
                                    );
                                  }
                                )}
                              </select>
                            </TableCell>
                          )}
                          {row?.type === 'previewTotalCost' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              {calculateTotalCost(data)}
                            </TableCell>
                          )}

                          {row?.type === 'date' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              {!!data[row?.value]
                                ? format(
                                    new Date(data[row?.value]),
                                    row?.format
                                  )
                                : '--'}
                            </TableCell>
                          )}
                          {row?.type === 'statusList' && (
                            <TableCell
                              className={`yk-table-body-td cursor-data YKCH-FixedCel ${row?.className}`}
                              key={`${index}_${i}`}>
                              <button
                                className={`btn btn-status payment-pending yk-color-badge ${
                                  statusClassList[data[row?.value]]
                                }
                                 `}>
                                {data[row?.value]}
                              </button>
                            </TableCell>
                          )}
                          {row?.type === 'status' && (
                            <TableCell
                              className={`yk-table-body-td cursor-data YKCH-FixedCel ${row?.className}`}
                              key={`${index}_${i}`}>
                              <button
                                className={`btn btn-status payment-pending yk-color-badge ${
                                  statusClassList[data[row?.value]]
                                }
                                 `}>
                                {data[row?.value].toString().toLowerCase()}
                              </button>
                              {/* <button
                                className={`btn btn-status payment-pending yk-color-badge ${
                                  row?.className
                                } ${
                                  data[row?.value] === row?.success
                                    ? 'green'
                                    : data[row?.value] === row?.warning
                                    ? 'yellow'
                                    : data[row?.value] === row?.danger &&
                                      !row?.consignment
                                    ? 'red'
                                    : data[row?.value] === row?.danger &&
                                      row?.consignment
                                    ? 'orange'
                                    : data[row?.value] === row?.lowdanger
                                    ? 'lowdanger'
                                    : data[row?.value] === row?.greensuccess
                                    ? 'darkgreen'
                                    : 'orange'
                                }`}>
                                {row?.key === 'commissionStatus'
                                  ? data[row?.value] === true
                                    ? 'Active'
                                    : 'Disabled'
                                  : data[row?.value]}
                              </button> */}
                            </TableCell>
                          )}
                          {row?.type === 'statusOrder' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              <button
                                className={`btn btn-status payment-pending yk-order-color-badge ${
                                  data[row?.value] === row?.success
                                    ? 'green'
                                    : data[row?.value] === row?.warning
                                    ? 'yellow'
                                    : data[row?.value] === row?.danger &&
                                      !row?.consignment
                                    ? 'red'
                                    : data[row?.value] === row?.danger &&
                                      row?.consignment
                                    ? 'orange'
                                    : data[row?.value] === row?.lowdanger
                                    ? 'lowdanger'
                                    : data[row?.value] === row?.greensuccess
                                    ? 'darkgreen'
                                    : 'orange'
                                }`}>
                                {row?.key === 'commissionStatus'
                                  ? data[row?.value] === true
                                    ? 'Active'
                                    : 'Disabled'
                                  : data[row?.value]}
                              </button>
                            </TableCell>
                          )}
                          {row?.type === 'saleLocation' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              <button
                                className={`btn btn-status border-0 payment-pending yk-sale-color ${
                                  data[row?.value] === row?.success
                                    ? 'green'
                                    : data[row?.value] === row?.warning
                                    ? 'yellow'
                                    : data[row?.value] === row?.danger &&
                                      !row?.consignment
                                    ? 'red'
                                    : data[row?.value] === row?.danger &&
                                      row?.consignment
                                    ? 'orange'
                                    : data[row?.value] === row?.lowdanger
                                    ? 'lowdanger'
                                    : data[row?.value] === row?.greensuccess
                                    ? 'darkgreen'
                                    : 'orange'
                                }`}
                                onClick={() => row?.onClick(data)}>
                                {row?.key === 'commissionStatus'
                                  ? data[row?.value] === true
                                    ? 'Active'
                                    : 'Disabled'
                                  : data[row?.value]}
                              </button>
                            </TableCell>
                          )}

                          {row?.type === 'external' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              {row?.prefix ? row?.prefix : ''}
                              {row?.value?.toFixed(2)}
                            </TableCell>
                          )}
                          {row?.type === 'age' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              {data[row?.value]
                                ? getAge(data[row?.value])
                                : '--'}
                            </TableCell>
                          )}
                          {row?.type === 'copyToClipboard' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}
                              id='sku'>
                              {data[row?.value] ? data[row?.value] : '--'}
                              <CopyToClipboardComponent
                                copyText={data[row?.value]}
                              />
                            </TableCell>
                          )}
                          {row?.type === 'userType' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={index}
                              id='sku'>
                              <Image
                                src={incomingICO}
                                alt='copy icon'
                                className='img-fluid cursor YKCH-incoming copyIcon'
                              />

                              {data[row?.value] ? data[row?.value] : '--'}
                            </TableCell>
                          )}
                          {row?.type === 'transferType' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={index}>
                              {data[row?.fromLocation]?.includes(
                                row?.currentLocation
                              ) ? (
                                <>
                                  <Image
                                    className='yk-arrowIcon'
                                    src={row?.outgoingImg}
                                    alt='outgoing-icon'
                                  />
                                  Outgoing
                                </>
                              ) : data[row?.toLocation]?.includes(
                                  row?.currentLocation
                                ) ? (
                                <>
                                  <Image
                                    className='yk-arrowIcon'
                                    src={row?.incomingImg}
                                    alt='incoming-icon'
                                  />
                                  Incoming
                                </>
                              ) : (
                                '--'
                              )}
                            </TableCell>
                          )}
                          {row?.type === 'commission' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              {`${data[row?.value]} (${
                                data[row?.commission]
                              }%)`}
                            </TableCell>
                          )}
                          {row?.type === 'phone' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              {data[row?.value]
                                ? updatePhoneNumber(data[row?.value])
                                : '--'}
                            </TableCell>
                          )}
                          {row?.type === 'previewTotalPrice' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              {calCulateTotalPrice(data, row?.payout)}
                            </TableCell>
                          )}
                          {row?.type === 'previewTotalPay' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              {calculateTotalPay(data)}
                            </TableCell>
                          )}
                          {row?.type === 'previewPayout' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              {calCulatePayOutBulk(data, row?.payout)}
                            </TableCell>
                          )}
                          {row?.type === 'multiValueColumn' && (
                            <TableCell
                              className='yk-table-body-td cursor-data YKCH-FixedCel'
                              key={`${index}_${i}`}>
                              {' '}
                              <div className='YKEE-badgee'>
                                <span
                                  className='YKEE-Texting'
                                  title={data[row?.firstValue] || '--'}>
                                  {row?.firstValue &&
                                    (row?.isFirstValueHasEllipses
                                      ? data[row?.firstValue]?.length >
                                        row?.trimAfter
                                        ? getTrimmedText(
                                            data[row?.firstValue],
                                            row?.trimAfter
                                          )
                                        : data[row?.firstValue]
                                      : data[row?.firstValue])}
                                </span>
                                {Number(data[row?.secondValue]) > 1 && (
                                  <span
                                    className={`${
                                      row?.whichValueIsBadge === 'Second'
                                        ? 'YKEE-badgeKee'
                                        : 'YKEE-Texting'
                                    }`}>
                                    {row?.secondValue &&
                                    row?.whichValueIsBadge === 'Second'
                                      ? `+${Number(data[row?.secondValue]) - 1}`
                                      : data[row?.secondValue]}
                                  </span>
                                )}
                              </div>
                            </TableCell>
                          )}
                          {!row?.type && (
                            <TableCell
                              className={`yk-table-body-td cursor-data YKCH-FixedCel ${
                                row?.className
                              } ${
                                row?.title === 'Barcode'
                                  ? 'text-transform-none'
                                  : ''
                              }`}
                              key={`${index}_${i}`}
                              title={renderValue(data, row)}>
                              {renderValue(data, row)}
                            </TableCell>
                          )}
                        </React.Fragment>
                      ))}
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </div>
        <div className='mobile-table-wrapper card'>
          <div className='products-cards-wrapper'>
            <ul className='cards-list'>
              {rowData?.map((data: any, i: any) => (
                <li key={i}>
                  <div className='products-data-wrapper'>
                    {headers.map((row: any, index: any) => (
                      <React.Fragment key={`${index}_${i}`}>
                        {row?.type === 'sno' && (
                          <div
                            key={`${index}_${i}`}
                            className='descriptions-wrapper'>
                            <p className='description-title'>{row?.title}</p>
                            <p className='description'>{offSet + i + 1}</p>
                          </div>
                        )}
                        {row?.type === 'payoutCheckbox' && (
                          <div
                            className='yk-table-body-td cursor-data YKCH-FixedCel'
                            key={`${index}_${i}`}>
                            {((): any => {
                              if (data?.['isChecked']) {
                                return (
                                  <Checkbox
                                    className='filter-sidebar-checkbox'
                                    onChange={(e) =>
                                      row?.onChange(e, data, rowData)
                                    }
                                    checked={data?.['isChecked']}
                                    value={data?.value}
                                    disabled={data[row?.isDisabled]}
                                  />
                                );
                              } else {
                                return <span> </span>;
                              }
                            })()}
                          </div>
                        )}

                        {row?.type === 'checkbox' && (
                          <div
                            className={`yk-table-body-td cursor-data YKCH-FixedCel `}
                            key={`${index}_${i}`}>
                            <Checkbox
                              className={`filter-sidebar-checkbox ${
                                row?.ref == 'withdrawal'
                                  ? !!data[row?.costPerItem]
                                    ? ''
                                    : 'd-none'
                                  : ''
                              }`}
                              onChange={(e) => row?.onChange(e, data, rowData)}
                              checked={data?.['isChecked']}
                              value={data?.value}
                              disabled={data[row?.isDisabled]}
                            />
                          </div>
                        )}

                        {row?.type === 'consignmentReviewCheckbox' && (
                          <div
                            className='yk-table-body-td cursor-data YKCH-FixedCel'
                            key={`${index}_${i}`}>
                            <Checkbox
                              className='filter-sidebar-checkbox'
                              onChange={(e) => row?.onChange(e, data, rowData)}
                              checked={!!data?.['isChecked']}
                              value={data?.value}
                              disabled={data[row?.isDisabled]}
                            />
                          </div>
                        )}

                        {row?.type === 'image' && (
                          <div
                            key={`${index}_${i}`}
                            className='descriptions-wrapper'>
                            <p className='description-title'>{row?.title}</p>
                            <p className='description'>
                              {row?.mode === 'static' ? (
                                <Image
                                  src={row?.value}
                                  alt='cart-img'
                                  className='img-fluid'
                                  onClick={() => row?.onClick(data)}
                                />
                              ) : row?.mode === 'staticData' ? (
                                <Image
                                  src={data[row?.value] || productImg}
                                  alt='cart-img'
                                  className='img-fluid'
                                  width={50}
                                  height={50}
                                />
                              ) : (
                                <ImageLoader
                                  src={data[row?.value]}
                                  fallbackImg={productImg}
                                  alt='cart-img'
                                  className='img-fluid YKCH-thumbnail'
                                  onClick={() => row?.onClick(data.size)}
                                />
                              )}
                            </p>
                          </div>
                        )}
                        {row?.type === 'button' && (
                          <div
                            key={`${index}_${i}`}
                            className='descriptions-wrapper'>
                            <p className='description-title'>{row?.title}</p>
                            <p className='description'>
                              <a
                                role='button'
                                className='yk-table-link-btn clear-filter-btn hide-on-print'
                                onClick={() => row?.onClick(data)}>
                                {row?.value}
                              </a>
                            </p>
                          </div>
                        )}
                        {row?.type === 'printQRButton' && (
                          <div
                            key={`${index}_${i}`}
                            className='descriptions-wrapper'>
                            <p className='description-title'>{row?.title}</p>
                            <p className='description'>
                              <a
                                role='button'
                                className={`yk-table-link-btn clear-filter-btn ${
                                  row.disabled ? 'disabled' : ''
                                } hide-on-print`}
                                onClick={() => row?.onClick(data, true)}>
                                {data[row?.value] === 'Active' &&
                                data[row?.additionalCheck] !== null &&
                                data[row?.locationCheck] !== null
                                  ? 'Download'
                                  : null}
                              </a>
                            </p>
                          </div>
                        )}
                        {row?.type === 'textbox' && (
                          <div
                            key={`${index}_${i}`}
                            className='descriptions-wrapper yk-mobileDescriptionWrapper'>
                            <p className='description-title'>{row?.title}</p>
                            <div
                              className={
                                row?.title === 'Selling Price' ||
                                row?.title === 'Payout/Item' ||
                                row?.title === 'Cost/item'
                                  ? `description input-group input-prepend yk-disabledInputWrapper ${
                                      row.disabled ? 'disabled' : ''
                                    }`
                                  : 'description input-outer-wrapper yk-inputOuterWrapper'
                              }>
                              <p
                                className={
                                  row?.title === 'Selling Price' ||
                                  row?.title === 'Payout/Item' ||
                                  row?.title === 'Cost/item'
                                    ? 'input-prepend mb-inputGroup mb-0'
                                    : 'mb-0'
                                }>
                                {row?.title === 'Selling Price' ||
                                row?.title === 'Payout/Item' ||
                                row?.title === 'Cost/item' ? (
                                  <span
                                    className={
                                      row?.title === 'Selling Price' ||
                                      row?.title === 'Payout/Item' ||
                                      row?.title === 'Cost/item'
                                        ? 'input-group-text'
                                        : ''
                                    }>
                                    $
                                  </span>
                                ) : (
                                  <></>
                                )}
                                <input
                                  type='text'
                                  value={
                                    row?.isAddModal
                                      ? calCulatePayOut(data, row?.payout)
                                      : data[row?.value]
                                  }
                                  disabled={row?.disabled}
                                  maxLength={10}
                                  onChange={(e) => row?.onChange(e, i)}
                                />
                              </p>
                            </div>
                          </div>
                        )}
                        {row?.type === 'select' && (
                          <TableCell className='yk-table-body-td YKCH-FixedCel cursor-data select'>
                            <select
                              className='form-control custom-select select-state-dropdown yk-select-condition'
                              id={row?.title}
                              defaultValue={row?.value}
                              onChange={(e) => row?.onChange(e, i)}>
                              <option value=''>Select {row?.title}</option>
                              {row?.dropdown?.map(
                                (item: any, index: number) => {
                                  return (
                                    <option
                                      key={`selectIndex_${index}`}
                                      value={item?.value}
                                      data-title={item?.title}>
                                      {item?.title}
                                    </option>
                                  );
                                }
                              )}
                            </select>
                          </TableCell>
                        )}
                        {row?.type === 'date' && (
                          <div
                            key={`${index}_${i}`}
                            className='descriptions-wrapper'>
                            <p className='description-title'>{row?.title}</p>
                            <p className='description'>
                              {!!data[row?.value]
                                ? format(
                                    new Date(data[row?.value]),
                                    row?.format
                                  )
                                : '--'}
                            </p>
                          </div>
                        )}
                        {row?.type === 'status' && (
                          <div
                            key={`${index}_${i}`}
                            className={`descriptions-wrapper ${row?.className}`}>
                            <p
                              className={`description-title ${row?.className}`}>
                              {row?.title}
                            </p>
                            {/* <p
                              className={`description ${row?.className} ${
                                data[row?.value] === row?.success
                                  ? 'green'
                                  : data[row?.value] === row?.warning
                                  ? 'yellow'
                                  : data[row?.value] === row?.danger &&
                                    !row?.consignment
                                  ? 'red'
                                  : data[row?.value] === row?.danger &&
                                    row?.consignment &&
                                    'orange'
                              }`}>
                              {data[row?.value]}
                            </p> */}
                            <p className='description'>
                              <button
                                className={`btn btn-status payment-pending yk-color-badge ${
                                  statusClassList[data[row?.value]]
                                } `}>
                                {data[row?.value]}
                              </button>
                            </p>
                          </div>
                        )}
                        {row?.type === 'statusList' && (
                          <div
                            key={`${index}_${i}`}
                            className='descriptions-wrapper'>
                            <p className='description-title'>{row?.title}</p>
                            <p className='description'>
                              <button
                                className={`btn btn-status payment-pending yk-color-badge ${
                                  statusClassList[data[row?.value]]
                                }

      `}>
                                {data[row?.value]}
                              </button>
                            </p>
                          </div>
                        )}
                        {row?.type === 'external' && (
                          <div
                            key={`${index}_${i}`}
                            className='descriptions-wrapper'>
                            <p className='description-title'>{row?.title}</p>
                            <p className='description'>
                              {row?.prefix ? row?.prefix : ''}
                              {row?.value?.toFixed(2)}
                            </p>
                          </div>
                        )}
                        {row?.type === 'age' && (
                          <div
                            key={`${index}_${i}`}
                            className='descriptions-wrapper'>
                            <p className='description-title'>{row?.title}</p>
                            <p className='description'>
                              {data[row?.value]
                                ? getAge(data[row?.value])
                                : '--'}
                            </p>
                          </div>
                        )}

                        {row?.type === 'copyToClipboard' && (
                          <div
                            className='descriptions-wrapper'
                            key={`${index}_${i}`}
                            id='sku'>
                            <p className='description-title'>{row?.title}</p>
                            <p className='description'>
                              {data[row?.value]}
                              <CopyToClipboardComponent
                                copyText={data[row?.value]}
                              />
                            </p>
                          </div>
                        )}
                        {!row?.type && (
                          <div
                            className='descriptions-wrapper'
                            key={`${index}_${i}`}>
                            <p className='description-title'>{row?.title}</p>
                            <p className='description'>
                              {renderValue(data, row)}
                            </p>
                          </div>
                        )}
                        {row?.type === 'previewTotalPrice' && (
                          <div
                            className='descriptions-wrapper'
                            key={`${index}_${i}`}>
                            <p className='description-title'>{row?.title}</p>
                            <p className='description'>
                              {calCulateTotalPrice(data, row?.payout)}
                            </p>
                          </div>
                        )}
                        {row?.type === 'previewTotalPay' && (
                          <div
                            className='descriptions-wrapper'
                            key={`${index}_${i}`}>
                            <p className='description-title'>{row?.title}</p>
                            <p className='description'>
                              {calculateTotalPay(data)}
                            </p>
                          </div>
                        )}
                        {row?.type === 'previewPayout' && (
                          <div
                            className='descriptions-wrapper'
                            key={`${index}_${i}`}>
                            <p className='description-title'>{row?.title}</p>
                            <p className='description'>
                              {calCulatePayOutBulk(data, row?.payout)}
                            </p>
                          </div>
                        )}
                        {row?.type === 'multiValueColumn' && (
                          <div
                            className='descriptions-wrapper'
                            key={`${index}_${i}`}>
                            <p className='description-title'>{row?.title}</p>
                            <div className='description'>
                              <div className='YKEE-badgee'>
                                <span
                                  className='YKEE-Texting'
                                  title={data[row?.firstValue] || '--'}>
                                  {row?.firstValue &&
                                    (row?.isFirstValueHasEllipses
                                      ? data[row?.firstValue]?.length >
                                        row?.trimAfter
                                        ? getTrimmedText(
                                            data[row?.firstValue],
                                            row?.trimAfter
                                          )
                                        : data[row?.firstValue]
                                      : data[row?.firstValue])}
                                </span>
                                {Number(data[row?.secondValue]) > 1 && (
                                  <span
                                    className={`${
                                      row?.whichValueIsBadge === 'Second'
                                        ? 'YKEE-badgeKee'
                                        : 'YKEE-Texting'
                                    }`}>
                                    {row?.secondValue &&
                                    row?.whichValueIsBadge === 'Second'
                                      ? `+${Number(data[row?.secondValue]) - 1}`
                                      : data[row?.secondValue]}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        )}
                        {row?.type === 'saleLocation' && (
                          <div
                            className='descriptions-wrapper align-items-baseline'
                            key={`${index}_${i}`}>
                            <div className='description-title'>
                              {row?.title}
                            </div>
                            <div className='description pe-0'>
                              <button
                                className={`btn yk-mobileStatusBtn btn-status payment-pending yk-sale-color ${
                                  data[row?.value] === row?.success
                                    ? 'green'
                                    : data[row?.value] === row?.warning
                                    ? 'yellow'
                                    : data[row?.value] === row?.danger &&
                                      !row?.consignment
                                    ? 'red'
                                    : data[row?.value] === row?.danger &&
                                      row?.consignment
                                    ? 'orange'
                                    : data[row?.value] === row?.lowdanger
                                    ? 'lowdanger'
                                    : data[row?.value] === row?.greensuccess
                                    ? 'darkgreen'
                                    : 'orange'
                                }`}
                                onClick={() => row?.onClick(data)}>
                                {row?.key === 'commissionStatus'
                                  ? data[row?.value] === true
                                    ? 'Active'
                                    : 'Disabled'
                                  : data[row?.value]}
                              </button>
                            </div>
                          </div>
                        )}
                      </React.Fragment>
                    ))}
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    );
  }
);
VirtualTable.displayName = 'Print Summary';
export default VirtualTable;
