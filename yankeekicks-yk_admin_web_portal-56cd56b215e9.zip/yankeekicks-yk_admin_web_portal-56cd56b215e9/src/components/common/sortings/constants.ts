export const sortsBy = [
  {
    key: 'amountLow',
    value: 'Amount: Lowest',
    img: 'down',
  },
  {
    key: 'amountHigh',
    value: 'Amount: Highest',
    img: 'up',
  },
  {
    key: 'dateNew',
    value: 'Date: Newest',
    img: 'down',
  },
  {
    key: 'dateOld',
    value: 'Date: Oldest',
    img: 'up',
  },
  {
    key: 'orderAsc',
    value: 'Order ID: Asc',
    img: 'down',
  },
  {
    key: 'orderDesc',
    value: 'Order ID: Desc',
    img: 'up',
  },
];

export const sortsByPayout = [
  {
    key: 'amountLow',
    value: 'Amount: Lowest',
    img: 'down',
  },
  {
    key: 'amountHigh',
    value: 'Amount: Highest',
    img: 'up',
  },
  {
    key: 'dateNew',
    value: 'Date: Newest',
    img: 'down',
  },
  {
    key: 'dateOld',
    value: 'Date: Oldest',
    img: 'up',
  },
  {
    key: 'payoutAsc',
    value: 'Payout ID: Asc',
    img: 'down',
  },
  {
    key: 'payoutDesc',
    value: 'Payout ID: Desc',
    img: 'up',
  },
];
export const sortsByMyInventory = [
  {
    key: 'skuAsc',
    value: 'SKU: Asc',
    img: 'down',
  },
  {
    key: 'skuDesc',
    value: 'SKU: Desc',
    img: 'up',
  },
  {
    key: 'brandAsc',
    value: 'Brand:Asc',
    img: 'down',
  },
  {
    key: 'brandDesc',
    value: 'Brand: Desc',
    img: 'up',
  },
  {
    key: 'qtyLow',
    value: 'Qty: Lowest',
    img: 'down',
  },
  {
    key: 'qtyHigh',
    value: 'Qty: Highest',
    img: 'up',
  },
];

export const sortsByCatalog = [
  {
    key: 'skuAsc',
    value: 'Date: Oldest',
    img: 'down',
  },
  {
    key: 'skuDesc',
    value: 'Date: Newest',
    img: 'up',
  },
  {
    key: 'brandAsc',
    value: 'Brand:Asc',
    img: 'down',
  },
  {
    key: 'brandDesc',
    value: 'Brand: Desc',
    img: 'up',
  },
];

export const sortsByConsignmentDetails = [
  {
    key: 'skuAsc',
    value: 'SKU: Asc',
    img: 'down',
  },
  {
    key: 'skuDesc',
    value: 'SKU: Desc',
    img: 'up',
  },
  {
    key: 'qtyLow',
    value: 'Qty: Lowest',
    img: 'down',
  },
  {
    key: 'qtyHigh',
    value: 'Qty: Highest',
    img: 'up',
  },
];

export const sortsByConsignmentSkuDetails = [
  {
    key: 'sizeAsc',
    value: 'Size: Asc',
    img: 'down',
  },
  {
    key: 'sizeDesc',
    value: 'Size: Desc',
    img: 'up',
  },
  {
    key: 'sellingPriceAsc',
    value: 'Price: Lowest',
    img: 'down',
  },
  {
    key: 'sellingPriceDesc',
    value: 'Price: Highest',
    img: 'up',
  },
  {
    key: 'statusAsc',
    value: 'Status: Asc',
    img: 'down',
  },
  {
    key: 'statusDesc',
    value: 'Status: Desc',
    img: 'up',
  },
];

export const sortsByConsignments = [
  {
    key: 'qtyLow',
    value: 'Qty: Lowest',
    img: 'down',
  },
  {
    key: 'qtyHigh',
    value: 'Qty: Highest',
    img: 'up',
  },
  {
    key: 'dateNew',
    value: 'Date: Newest',
    img: 'down',
  },
  {
    key: 'dateOld',
    value: 'Date: Oldest',
    img: 'up',
  },
  {
    key: 'consignmentIdAsc',
    value: 'Shipment ID: Asc',
    img: 'down',
  },
  {
    key: 'consignmentIdDesc',
    value: 'Shipment ID: Desc',
    img: 'up',
  },
];

export const sortByPreviewBulk = [
  {
    key: 'storeNameAsc',
    value: 'StoreName: Asc',
    img: 'down',
  },
  {
    key: 'storeNameDesc',
    value: 'StoreName: Desc',
    img: 'up',
  },
  {
    key: 'sizeAsc',
    value: 'Size: Asc',
    img: 'down',
  },
  {
    key: 'sizeDesc',
    value: 'Size: Desc',
    img: 'up',
  },
];
export const sortBySalesAssoSearch = [
  {
    key: 'newest',
    value: 'Newest',
    img: 'down',
  },
  {
    key: 'oldest',
    value: 'Oldest',
    img: 'up',
  },
];

export const sortsByConsignors = [
  {
    key: 'consignorIdAsc',
    value: 'Consignor ID',
    img: 'up',
  },
  {
    key: 'consignorIdDesc',
    value: 'Consignor ID',
    img: 'down',
  },
  {
    key: 'statusAsc',
    value: 'Status',
    img: 'up',
  },
  {
    key: 'statusDesc',
    value: 'Status',
    img: 'down',
  },
  {
    key: 'commissionAsc',
    value: 'Commission',
    img: 'up',
  },
  {
    key: 'commissionDesc',
    value: 'Commission',
    img: 'down',
  },
  {
    key: 'dateAddedAsc',
    value: 'Date Added',
    img: 'up',
  },
  {
    key: 'dateAddedDesc',
    value: 'Date Added',
    img: 'down',
  },
];
export const sortsByLocations = [
  {
    key: 'newestLocation',
    value: 'Newest Location Added',
    img: 'up',
  },
  {
    key: 'OldestLocation',
    value: 'Oldest Location Added',
    img: 'down',
  },
  {
    key: 'locationStatusAsc',
    value: 'Status',
    img: 'up',
  },
  {
    key: 'locationStatusDesc',
    value: 'Status',
    img: 'down',
  },
  {
    key: 'locationCityAsc',
    value: 'City',
    img: 'up',
  },
  {
    key: 'locationCityDesc',
    value: 'City',
    img: 'down',
  },
  {
    key: 'locationStateAsc',
    value: 'State',
    img: 'up',
  },
  {
    key: 'locationStateDesc',
    value: 'State',
    img: 'down',
  },
];

export const sortByManageCommission = [
  {
    key: 'commissionNewest',
    value: 'Commission Newest',
    img: 'up',
  },
  {
    key: 'comissionOldest',
    value: 'Comission Oldest',
    img: 'down',
  },
  {
    key: 'commissionAsc',
    value: 'CurrentCommission',
    img: 'up',
  },
  {
    key: 'comissionDesc',
    value: 'CurrentCommission',
    img: 'down',
  },
];

export const sortByPrintLabels = [
  {
    key: 'createAT:ASC',
    value: 'Date Added:ASC',
    img: 'up',
  },
  {
    key: 'createAT:DSC',
    value: 'Date Added:DSC',
    img: 'down',
  },
  {
    key: 'retailPriceLow',
    value: 'RetailPrice:ASC',
    img: 'up',
  },
  {
    key: 'retailPriceHigh',
    value: 'RetailPrice:DSC',
    img: 'down',
  },
  {
    key: 'brandLow',
    value: 'Brand:ASC',
    img: 'up',
  },
  {
    key: 'brandHigh',
    value: 'Brand:DSC',
    img: 'down',
  },
  {
    key: 'skuUp',
    value: 'Sku:ASC',
    img: 'up',
  },
  {
    key: 'skuDown',
    value: 'Sku:DSC',
    img: 'down',
  },
  {
    key: 'sizeUp',
    value: 'Size:ASC',
    img: 'up',
  },
  {
    key: 'sizeDown',
    value: 'Size:DSC',
    img: 'down',
  },
];

export const sortByManageUsers = [
  {
    key: 'usersNewest',
    value: 'Users Newest',
    img: 'up',
  },
  {
    key: 'usersOldest',
    value: 'Users Oldest',
    img: 'down',
  },
  {
    key: 'Emp.ID:Asc',
    value: 'Emp.ID:Asc',
    img: 'up',
  },
  {
    key: 'Emp.ID:Desc',
    value: 'Emp.ID:Desc',
    img: 'down',
  },
  {
    key: 'Name:Asc',
    value: 'Name:Asc',
    img: 'up',
  },
  {
    key: 'Name:Desc',
    value: 'Name:Desc',
    img: 'down',
  },
  {
    key: 'Status:Asc',
    value: 'Status:Asc',
    img: 'up',
  },
  {
    key: 'Status:Desc',
    value: 'Status:Desc',
    img: 'down',
  },
];

export const sortByOrderDetails = [
  {
    key: 'sizeAsc',
    value: 'Size: Asc',
    img: 'down',
  },
  {
    key: 'sizeDesc',
    value: 'Size: Desc',
    img: 'up',
  },
  {
    key: 'sellingPriceLow',
    value: 'Price: Lowest',
    img: 'down',
  },
  {
    key: 'sellingPriceHigh',
    value: 'Price: Highest',
    img: 'up',
  },
  {
    key: 'barcodeAsc',
    value: 'Barcode: Asc',
    img: 'down',
  },
  {
    key: 'barcodeDesc',
    value: 'Barcode: Desc',
    img: 'up',
  },
];

export const sortsByPayoutDetails = [
  {
    key: 'amountLow',
    value: 'Amount: Lowest',
    img: 'down',
  },
  {
    key: 'amountHigh',
    value: 'Amount: Highest',
    img: 'up',
  },
  {
    key: 'commissionAsc',
    value: 'Commission: Asc',
    img: 'down',
  },
  {
    key: 'commissionDesc',
    value: 'Commission: Desc',
    img: 'up',
  },
  {
    key: 'requestAmountLow',
    value: 'RequestAmount: Lowest',
    img: 'down',
  },
  {
    key: 'requestAmountHigh',
    value: 'RequestAmount: Highest',
    img: 'up',
  },
];

export const sortsByViewCommission = [
  {
    key: 'percentageLow',
    value: 'Percentage: Lowest',
    img: 'down',
  },
  {
    key: 'percentageHigh',
    value: 'Percentage: Highest',
    img: 'up',
  },
  {
    key: 'minimumFeeLow',
    value: 'MinimumFee: Lowest',
    img: 'down',
  },
  {
    key: 'minimumFeeHigh',
    value: 'MinimumFee: Highest',
    img: 'up',
  },
  {
    key: 'flatFeeLow',
    value: 'FlatFee: Lowest',
    img: 'down',
  },
  {
    key: 'flatFeeHigh',
    value: 'FlatFee: Highest',
    img: 'up',
  },
];

export const sortByPushNotifications = [
  {
    key: 'notificationNewest',
    value: 'Notification New',
    img: 'up',
  },
  {
    key: 'notificationOldest',
    value: 'Notification Old',
    img: 'down',
  },
  {
    key: 'Type:Asc',
    value: 'Type:Asc',
    img: 'up',
  },
  {
    key: 'Type:Desc',
    value: 'Type:Desc',
    img: 'down',
  },
  {
    key: 'NotificationId:Asc',
    value: 'Id:Asc',
    img: 'up',
  },
  {
    key: 'NotificationId:Desc',
    value: 'Id:Desc',
    img: 'down',
  },
];
export const sortsByViewAcceptTransfer = [
  {
    key: 'skuAsc',
    value: 'SKU: Asc',
    img: 'down',
  },
  {
    key: 'skuDesc',
    value: 'SKU: Desc',
    img: 'up',
  },
  {
    key: 'sellingPriceLow',
    value: 'Price: Lowest',
    img: 'down',
  },
  {
    key: 'sellingPriceHigh',
    value: 'Price: Highest',
    img: 'up',
  },
];

export const sortsByTransfer = [
  {
    key: 'transferIdAsc',
    value: 'TransferID: Asc',
    img: 'down',
  },
  {
    key: 'transferIdDesc',
    value: 'TransferID: Desc',
    img: 'up',
  },
  {
    key: 'toAsc',
    value: 'To: Asc',
    img: 'down',
  },
  {
    key: 'toDesc',
    value: 'To: Desc',
    img: 'up',
  },
  {
    key: 'statusAsc',
    value: 'status: Asc',
    img: 'down',
  },
  {
    key: 'statusDesc',
    value: 'status: Desc',
    img: 'up',
  },
];

export const sortsByInitiateTransfer = [
  {
    key: 'skuAsc',
    value: 'SKU: Asc',
    img: 'down',
  },
  {
    key: 'skuDesc',
    value: 'SKU: Desc',
    img: 'up',
  },
  {
    key: 'brandAsc',
    value: 'Brand:Asc',
    img: 'down',
  },
  {
    key: 'brandDesc',
    value: 'Brand: Desc',
    img: 'up',
  },
  {
    key: 'qtyLow',
    value: 'Qty: Lowest',
    img: 'down',
  },
  {
    key: 'qtyHigh',
    value: 'Qty: Highest',
    img: 'up',
  },
];
export const sortsByWithdraw = [
  {
    key: 'dateNew',
    value: 'Date: New',
    img: 'down',
  },
  {
    key: 'dateOld',
    value: 'Date: Old',
    img: 'up',
  },
  {
    key: 'consigorIdAsc',
    value: 'Consignor: Asc',
    img: 'down',
  },
  {
    key: 'consigorIdDsc',
    value: 'Consignor: Desc',
    img: 'up',
  },
];
export const sortByWithdrawDetails = [
  {
    key: 'sizeAsc',
    value: 'Size: Asc',
    img: 'down',
  },
  {
    key: 'sizeDesc',
    value: 'Size: Dsc',
    img: 'up',
  },
  {
    key: 'priceLow',
    value: 'Price: Low',
    img: 'down',
  },
  {
    key: 'priceHigh',
    value: 'Price: High',
    img: 'up',
  },
  {
    key: 'status: Asc',
    value: 'Status: Asc',
    img: 'down',
  },
  {
    key: 'status: Dsc',
    value: 'Status: Dsc',
    img: 'up',
  },
];

export const sortByMissingProducts = [
  {
    key: 'skuAsc',
    value: 'SKU: Asc',
    img: 'down',
  },
  {
    key: 'skuDesc',
    value: 'SKU: Desc',
    img: 'up',
  },
  {
    key: 'sizeAsc',
    value: 'Size: Asc',
    img: 'down',
  },
  {
    key: 'sizeDesc',
    value: 'Size: Desc',
    img: 'up',
  },
  {
    key: 'dateNew',
    value: 'Date: Newest',
    img: 'down',
  },
  {
    key: 'dateOld',
    value: 'Date: Oldest',
    img: 'up',
  },
];
