import { useRouter } from 'next/router';
import React, { useState } from 'react';
import uploadImg from 'assets/images/image-upload.svg';
import { useDropzone } from 'react-dropzone';
import Image from 'next/image';
export const DragandDrop = (props: any) => {
  const { supporttext = '', setSendFile = () => {}, accept } = props;
  const [files, setFiles] = useState<any>([]);

  const { getRootProps, getInputProps } = useDropzone({
    accept: accept,
    onDrop: (acceptedFiles: any) => {
      setFiles(
        acceptedFiles.map((file: any) =>
          Object.assign(file, {
            preview: URL.createObjectURL(file),
          })
        )
      );
      setSendFile(
        acceptedFiles.map((file: any) =>
          Object.assign(file, {
            preview: URL.createObjectURL(file),
          })
        )
      );
    },
  });

  return (
    <div className='text-center'>
      <div {...getRootProps()}>
        <input {...getInputProps()} />
        <>
          <Image src={uploadImg} alt='' className='img-fluid' />
          <p className='drag-drop-text'>Drag & Drop image/document here</p>
          <p className='drag-drop-text'>OR</p>
          <button type='button' className='btn yk-btn-primary-sm browse-btn'>
            Browse
          </button>
          <p className='Ykee-textFormat'>{supporttext}</p>
        </>
      </div>
    </div>
  );
};
