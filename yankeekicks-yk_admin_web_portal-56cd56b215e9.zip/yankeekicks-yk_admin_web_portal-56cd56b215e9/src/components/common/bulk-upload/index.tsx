import React, { useState, useEffect } from 'react';
import uploadImg from 'assets/images/image-upload.svg';
import { useDropzone } from 'react-dropzone';
import Image from 'next/image';
import Notification from 'components/common/notification';
import { NOTIFICATION_INVALID_FILE } from 'utils/constants';
export const BulkUpload = (props: any) => {
  const [files, setFiles] = useState<any>([]);
  const [isVisibleMessage, setIsVisibleMessage] = useState(false);
  const [notificationMsg, setNotificationMsg] = useState('');
  const { getRootProps, getInputProps } = useDropzone({
    accept: {
      csv: ['.csv'],
      'text/csv': ['.csv'],
    },
    onDrop: (acceptedFiles: any) => {
      if (acceptedFiles?.length > 0) {
        setFiles(
          acceptedFiles.map((file: any) =>
            Object.assign(file, {
              preview: URL.createObjectURL(file),
            })
          )
        );
        props.setSendFile(
          acceptedFiles.map((file: any) =>
            Object.assign(file, {
              preview: URL.createObjectURL(file),
            })
          )
        );
      } else {
        setIsVisibleMessage(true); //when file is empty
        setNotificationMsg(NOTIFICATION_INVALID_FILE);
      }
    },
  });
  useEffect(() => {
    if (props.isFileEmpty) setFiles([]);
  }, [props.isFileEmpty]);

  return (
    <div className='text-center mt-3'>
      <div {...getRootProps()}>
        <input {...getInputProps()} />
        <>
          <Image src={uploadImg} alt='' className='img-fluid' />
          <p className='drag-drop-text mt-3'>
            Drag & Drop to import data from your file
          </p>
          <p className='drag-drop-text font-weight-bold'>OR</p>
          {files.length === 0 && (
            <button type='button' className='btn yk-btn-primary-sm browse-btn'>
              Browse
            </button>
          )}
        </>
      </div>
      {files.length > 0 && (
        <button
          type='button'
          className='btn yk-btn-primary-sm upload-btn'
          onClick={props.upload}
        >
          Upload
        </button>
      )}
      <p className='mt-3'>Support only .CSV formate</p>
      <Notification
        showSuccessPopup={isVisibleMessage}
        handleSnackbarClose={() =>
          setTimeout(() => setIsVisibleMessage(false), 1000)
        }
        severityType={'error'}
        message={notificationMsg}
        className='yk-shoesize-alert-wrapper'
      />
    </div>
  );
};
