import React, { useState } from 'react';
import { Tooltip, ClickAwayListener } from '@mui/material';
import Image from 'next/image';
import copyIcon from 'assets/images/copy.png';
import { copyContentToClipBoard } from 'utils/util';

const CopyToClipboardComponent = (props: any) => {
  const { copyText = '' } = props;
  const [showTooltip, setShowTooltip] = useState(false);

  const handleTooltipOpen = (skuValue: any) => {
    copyContentToClipBoard(skuValue);
    setShowTooltip(true);
    setTimeout(() => {
      setShowTooltip(false);
    }, 1500);
  };

  return (
    <>
      {copyText && (
        <ClickAwayListener onClickAway={() => setShowTooltip(false)}>
          <Tooltip
            PopperProps={{
              disablePortal: true,
            }}
            open={showTooltip}
            disableFocusListener
            disableHoverListener
            disableTouchListener
            title='Copied to clipboard'
            placement='right'
            arrow
          >
            <span className='YKCH-copyClip'>
              <Image
                src={copyIcon}
                alt='copy icon'
                className='img-fluid cursor hide-on-print copyIcon'
                data-toggle='tooltip'
                data-placement='top'
                title='Copy to clipboard'
                onClick={() => handleTooltipOpen(copyText)}
              />
            </span>
          </Tooltip>
        </ClickAwayListener>
      )}
    </>
  );
};
export default CopyToClipboardComponent;
