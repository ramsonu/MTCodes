import React, { useEffect, useState } from 'react';
import { FormControl, Menu, MenuItem, Select } from '@mui/material';
import Image from 'next/image';
import exportIcon from 'assets/images/Export.png';
import dropIcon from 'assets/images/dropdown-white-arrow-icon.svg';
import csvIcon from 'assets/images/csv-file.svg';
import xlsIcon from 'assets/images/xls-file.svg';
import pdfIcon from 'assets/images/pdf-file.svg';
import ExportToExcel from './excel';
import ExportToPDF from './pdf';
import ExportToCSV from './csv';

const ExportFiles = ({
  data,
  fileName,
  queryPayload,
  headers,
  onClickPDFExport = () => {},
  isActive = false,
}: any) => {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [isExportActive, setExportActive] = useState<boolean>(false);
  const open = Boolean(anchorEl);
  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
    if (isActive) onClickPDFExport();
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  useEffect(()=>{
    if(isActive && data && data.length )
    setExportActive(true);
  }, [isActive, data])

  return (
    <>
      <div className='export-btn-color YKCH-exportBTN p-0'>
        <FormControl className='export-selectbox d-flex p-3'>
          <span
            id='basic-button'
            className='d-flex align-items-center yk-export-select-item YKCH-noBG ps-0 pe-0'
            aria-controls={open ? 'basic-menu' : undefined}
            aria-haspopup='true'
            aria-expanded={open ? 'true' : undefined}
            onClick={handleClick}
          >
            <Image
              src={exportIcon}
              alt='filter-btn-icon'
              className='filter-btn-icon img-fluid'
            />
            <span className='YKCH-Snow'> Export </span>
            <Image
              src={dropIcon}
              alt='filter-btn-icon'
              className='dropdown-btn-icon'
            />
          </span>

          <Menu
            id='basic-menu'
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            MenuListProps={{
              'aria-labelledby': 'basic-button',
            }}
          >
            <MenuItem className='export-select-item' value={'asc'} disabled>
              Export
            </MenuItem>
            <MenuItem
              onClick={handleClose}
              className='export-select-item'
              value={'csv'}
              disabled={!isExportActive}
            >
              <ExportToCSV data={data} fileName={fileName} headers={headers}>
                CSV
              </ExportToCSV>
            </MenuItem>
            <MenuItem
              onClick={handleClose}
              className='export-select-item'
              value={'xlsx'}
              disabled={!isExportActive}
            >
              <ExportToExcel
                data={data}
                fileName={fileName}
                headers={headers}
              />
            </MenuItem>
            <MenuItem
              onClick={handleClose}
              className='export-select-item'
              value={'pdf'}
              disabled={!isExportActive}
            >
              <ExportToPDF fileName={fileName} queryPayload={queryPayload} />
            </MenuItem>
          </Menu>
        </FormControl>
      </div>
    </>
  );
};
export default ExportFiles;
