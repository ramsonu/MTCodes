import React from 'react';
import * as FileSaver from 'file-saver';
import XLSX from 'sheetjs-style';
import xlsIcon from 'assets/images/xls-file.svg';
import Image from 'next/image';
import { updatePhoneNumber } from 'utils/util';
import { format } from 'date-fns';
import { FNS_DATE_FORMAT } from 'utils/constants';

const ExportToExcel = ({ data, fileName, headers }: any) => {
  const fileType =
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
  const fileExtension = '.xlsx';

  const d = data.map((item: any, index: any) => {
    const newObj: any = {};
    Object.keys(item).forEach((key) => {
      const value = item[key];
      const newName = headers?.find((p: any) => p?.key === key);
      if (newName?.label) {
        const lab: any = newName?.label;
        if (newName?.type == 'amount') {
          if (!!value) {
            if (!value.toString()?.includes('$'))
              newObj[lab] = '$' + parseFloat(value)?.toFixed(2);
            else newObj[lab] = value;
          } else newObj[lab] = '$0';
        } else if (newName?.type == 'phoneNumber') {
          newObj[lab] = updatePhoneNumber(value);
        } else if (newName?.type == 'date') {
          newObj[lab] = !!value
            ? format(new Date(value), FNS_DATE_FORMAT)
            : '--';
        } else newObj[lab] = value;
      }
    });

    return newObj;
  });
  data = d;
  const exportToExcel = () => {
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = { Sheets: { data: ws }, SheetNames: ['data'] };
    const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const excdata = new Blob([excelBuffer], { type: fileType });
    FileSaver.saveAs(excdata, fileName + fileExtension);
  };

  return (
    <span onClick={exportToExcel} className='w-100 '>
      XLSX{' '}
      <Image src={xlsIcon} alt='table-img' className='img-fluid float-end' />
    </span>
  );
};

export default ExportToExcel;
