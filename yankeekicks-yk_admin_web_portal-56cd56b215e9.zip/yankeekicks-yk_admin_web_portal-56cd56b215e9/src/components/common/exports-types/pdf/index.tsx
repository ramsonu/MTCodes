import { downloadPDF } from 'services/consignment';
import pdfIcon from 'assets/images/pdf-file.svg';
import Image from 'next/image';
const ExportToPDF = ({ fileName, queryPayload }: any) => {
  const onClick = async () => {
    await downloadPDF({ fileName, queryPayload });
  };
  return (
    <span onClick={onClick} className='w-100 '>
      PDF{' '}
      <Image src={pdfIcon} alt='table-img' className='img-fluid float-end' />
    </span>
  );
};

export default ExportToPDF;
