import { CSVLink } from 'react-csv';
import Image from 'next/image';
import csvIcon from 'assets/images/csv-file.svg';
import { updatePhoneNumber } from 'utils/util';
import { format } from 'date-fns';
import { FNS_DATE_FORMAT } from 'utils/constants';
const ExportToCSV = ({ data, fileName, headers }: any) => {
  const AmountType = headers?.filter((item: any) => item?.type == 'amount');
  const orderType = headers?.filter(
    (item: any) => item?.type == 'numberToString'
  );
  const phoneType = headers?.filter((item: any) => item?.type == 'phoneNumber');
  const transferType = headers?.filter(
    (item: any) => item?.type == 'Transfers Request'
  );
  const dateType = headers?.filter((item: any) => item?.type == 'date');

  const updatedData = (data: any) => {
    if (AmountType.length >= 1) {
      data = data?.map((row: any, index: number) => {
        AmountType?.forEach((item: any, index: number) => {
          if (row[item.key]) {
            if (!row[item.key]?.toString()?.includes('$'))
              row[item.key] = '$' + parseFloat(row[item.key])?.toFixed(2);
          }
        });
        return row;
      });
    }
    if (orderType.length >= 1) {
      data = data?.map((row: any, index: number) => {
        orderType?.forEach((item: any, index: number) => {
          if (row[item.key]) {
            if (!row[item.key]?.includes('\t'))
              row[item.key] = row[item.key] + '\t';
          }
        });
        return row;
      });
    }
    if (phoneType.length >= 1) {
      data = data?.map((row: any, index: number) => {
        phoneType?.forEach((item: any, index: number) => {
          if (row[item.key]) {
            if (!row[item.key]?.includes('('))
              row[item.key] = updatePhoneNumber(row[item.key]) + '\t';
          }
        });
        return row;
      });
    }
    if (transferType?.length >= 1) {
      data = data?.map((row: any) => {
        transferType?.forEach((item: any) => {
          if (row[item?.fromLocation] === item?.currentLocation) {
            row[item?.key] = 'Outgoing';
          } else if (row[item?.toLocation] === item?.currentLocation) {
            row[item?.key] = 'Incoming';
          }
        });
        return row;
      });
    }
    if (dateType?.length >= 1) {
      data = data?.map((row: any) => {
        dateType?.forEach((item: any, index: number) => {
          row[item.key] = !!row[item.key]
            ? format(new Date(row[item.key]), FNS_DATE_FORMAT)
            : '--';
        });
        return row;
      });
    }
    return data;
  };

  const csvReport = {
    data: updatedData(data),
    headers: headers,
    filename: `${fileName}.csv`,
  };

  return (
    <CSVLink className='deafultLink w-100' {...csvReport}>
      CSV
      <Image src={csvIcon} alt='table-img' className='img-fluid float-end' />
    </CSVLink>
  );
};
export default ExportToCSV;
