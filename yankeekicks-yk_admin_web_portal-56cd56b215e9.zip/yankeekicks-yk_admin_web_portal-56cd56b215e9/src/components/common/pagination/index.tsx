import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import leftArrow from 'assets/images/left-arrow.svg';
import rightArrow from 'assets/images/right-arrow.svg';

const Pagination = (props: any) => {
  const {
    lengthOfData = 10,
    itemsPerPage = 2,
    currentOffset = 0,
    setOffset = () => {},
    setShouldFetchApi = () => {},
    isLoading = false,
  } = props;
  const [currentIndex, setCurrentIndex] = useState<number>(
    currentOffset / itemsPerPage + 1
  );

  let totalPagesToDisplay = lengthOfData / itemsPerPage;
  totalPagesToDisplay = Math.ceil(totalPagesToDisplay); // pages to display in pagination

  const displayCurrentBlockItems = 3; // it should be odd no. only
  const paginationSplittingString = ' | '; // it should be odd no. only
  const pivotPoint = Math.floor(displayCurrentBlockItems / 2); // Pivot point to show "..."
  const minLength = 5;
  let blockStartIndex =
    currentIndex > pivotPoint ? currentIndex - pivotPoint : 1;

  const pageClickHandler = (value: any) => {
    setCurrentIndex(value);
    const calculateOffset = value * itemsPerPage - itemsPerPage;
    setOffset(calculateOffset);
    setShouldFetchApi(true);
  };

  const prevNextHandler = (flag: String) => {
    if (flag === 'prev') {
      if (currentIndex !== 1) {
        setCurrentIndex(currentIndex - 1);
        setOffset(currentOffset - itemsPerPage);
        setShouldFetchApi(true);
      }
    } else {
      if (currentIndex !== totalPagesToDisplay) {
        setCurrentIndex(currentIndex + 1);
        setOffset(currentOffset + itemsPerPage);
        setShouldFetchApi(true);
      }
    }
  };

  return (
    <>
      {!isLoading && (
        <div className='custom-pagination'>
          <nav aria-label='page-navigation'>
            <ul className='pagination'>
              <li
                className={`page-item prev ${
                  currentIndex === 1 ? 'disabled' : ''
                }`}
              >
                <a
                  className='page-link'
                  tabIndex={-1}
                  onClick={() => prevNextHandler('prev')}
                >
                  <Image
                    src={leftArrow}
                    alt='left-arrow-icon'
                    className='left-arrow-icon img-fluid'
                  />
                  Previous
                </a>
              </li>
              <li
                className={`page-item ${currentIndex === 1 ? 'active' : ''}`}
                onClick={() => pageClickHandler(1)}
              >
                <a className='page-link'>1</a>
              </li>

              {currentIndex > displayCurrentBlockItems && (
                <li>{paginationSplittingString}</li>
              )}

              {[...Array(displayCurrentBlockItems)].map((item, index) => {
                return (
                  blockStartIndex + index < totalPagesToDisplay &&
                  blockStartIndex + index > 1 && (
                    <li
                      className={`page-item ${blockStartIndex + index} ${
                        currentIndex === blockStartIndex + index ? 'active' : ''
                      }`}
                      key={blockStartIndex + index}
                      onClick={() => pageClickHandler(blockStartIndex + index)}
                    >
                      <a className='page-link'>{blockStartIndex + index}</a>
                    </li>
                  )
                );
              })}

              {currentIndex + pivotPoint < totalPagesToDisplay - 1 && (
                <li>{paginationSplittingString}</li>
              )}
              {totalPagesToDisplay > 1 && (
                <li
                  className={`page-item ${
                    currentIndex === totalPagesToDisplay ? 'active' : ''
                  }`}
                  onClick={() => pageClickHandler(totalPagesToDisplay)}
                >
                  <a className='page-link'>{totalPagesToDisplay}</a>
                </li>
              )}

              <li
                className={`page-item next ${
                  currentIndex === totalPagesToDisplay ? 'disabled' : ''
                }`}
                onClick={() => prevNextHandler('next')}
              >
                <a className='page-link'>
                  Next
                  <Image
                    src={rightArrow}
                    alt='right-arrow-icon'
                    className='right-arrow-icon img-fluid'
                  />
                </a>
              </li>
            </ul>
          </nav>
        </div>
      )}
    </>
  );
};

export default Pagination;
