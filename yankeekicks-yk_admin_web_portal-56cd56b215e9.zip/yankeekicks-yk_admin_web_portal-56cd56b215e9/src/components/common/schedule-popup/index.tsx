import React, { useState, useEffect, useMemo } from 'react';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import ModalCloseIcon from 'assets/images/modal-close-icon.svg';
import Typography from '@mui/material/Typography';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import {
  DateValidationError,
  TimeValidationError,
} from '@mui/x-date-pickers/models';
import { getDate } from 'utils/util';
import Image from 'next/image';
import calendarIcon from 'assets/images/calendar-black-icon.svg';
import DateFilters from 'components/common/filters/date';
import { TimeField } from '@mui/x-date-pickers/TimeField';

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  '& .MuiDialogContent-root': {
    padding: theme.spacing(2),
  },
  '& .MuiDialogActions-root': {
    padding: theme.spacing(1),
  },
}));

export interface DialogTitleProps {
  id: string;
  children?: React.ReactNode;
  onClose: () => void;
}

function BootstrapDialogTitle(props: DialogTitleProps) {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {onClose ? (
        <IconButton
          aria-label='close'
          onClick={onClose}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}>
          <button className='btn btn-modal-close' onClick={onClose}>
            <Image src={ModalCloseIcon} className='img-fluid' alt=''></Image>
          </button>
        </IconButton>
      ) : null}
    </DialogTitle>
  );
}

export default function SchedulePopup(props: any) {
  const {
    showPopup,
    handleClose,
    handleDateTime,
    id = 'customized-dialog',
    className = '',
  } = props;
  const [error, setError] = useState<DateValidationError | null>(null);
  const [timeError, setTimeError] = useState<TimeValidationError | null>(null);
  const [time, setTime] = useState<any>();
  const [date, setDate] = useState<any>();
  const today = new Date();

  const [startDate, setSelectedStartDate] = useState<any>('');

  const errorTimeMessage = useMemo(() => {
    switch (timeError) {
      case 'disablePast': {
        return 'Please select future time';
      }

      case 'invalidDate': {
        return 'Enter valid time';
      }

      default: {
        return '';
      }
    }
  }, [timeError]);

  // eslint-disable-next-line react/display-name
  const CustomInput = React.forwardRef(
    ({ value, onClick, onChange }: any, ref: any) => (
      <div className='dateBtn'>
        <label className='input-container' onClick={onClick}>
          <input
            value={value}
            placeholder='Select Date'
            className='section-readonly-input p-0'
            onChange={onChange}
            ref={ref}
          />
          <Image
            src={calendarIcon}
            alt='calendar-icon'
            className='dateBtnIcon img-fluid'
          />
        </label>
      </div>
    )
  );

  const onDateChange = (date: any) => {
    setSelectedStartDate(date);
  };

  return (
    <div>
      <BootstrapDialog
        className={`yk-scheduleNotification ${className}`}
        onClose={handleClose}
        aria-labelledby={id}
        open={showPopup}>
        <BootstrapDialogTitle id={id} onClose={handleClose}>
          Schedule Notification
          <p>Select Date and Time to schedule</p>
        </BootstrapDialogTitle>
        <DialogContent dividers>
          <Typography gutterBottom>Date and Time</Typography>
          <div className='yk-contentDivider'>
            <div className='row g-0'>
              <div className='col-md-6'>
                <h2 className='sectionHeading'>Date</h2>
                <div className='yk-datePicker yk-modalInput YKEE-datePicker'>
                  <DateFilters
                    onChange={onDateChange}
                    startDate={startDate}
                    selectsRange={false}
                    inline={false}
                    customInput={<CustomInput />}
                  />
                </div>
              </div>
              <div className='col-md-6'>
                <h2 className='sectionHeading'>Time</h2>
                <div className='yk-TimePicker yk-modalInput '>
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <TimeField
                      onError={(timeError) => setTimeError(timeError)}
                      onChange={(newValue) => setTime(newValue)}
                      slotProps={{
                        textField: {
                          helperText: errorTimeMessage,
                          placeholder: 'Select Time',
                        },
                      }}
                      ampm={false}
                      disablePast={
                        getDate(startDate) <= getDate(today) ? true : false
                      }
                    />
                  </LocalizationProvider>
                </div>
                <p className='yk-errorMessage'>{errorTimeMessage}</p>
              </div>
            </div>
          </div>
        </DialogContent>
        <DialogActions>
          <div className='yk-modalFooter'>
            <Button className='yk-cancel' onClick={handleClose}>
              Cancel
            </Button>
            <Button
              className='yk-scheduleNotification'
              disabled={errorTimeMessage !== '' || !time || !startDate}
              onClick={() => handleDateTime(startDate, time)}>
              Schedule Notification
            </Button>
          </div>
        </DialogActions>
      </BootstrapDialog>
    </div>
  );
}
