import React from 'react';
import Image from 'next/image';
import noRecordImg from 'assets/images/no-table-record-img.png';
import { NO_RESULT_FOUND } from './constant';
const NoDataFound = React.forwardRef(
  (props: any, ref: React.Ref<HTMLDivElement>) => {
    const { data = {}, searchData } = props;

    return (
      <div className='no-record-found-wrapper text-center' ref={ref}>
        <Image
          src={noRecordImg}
          alt='filter-btn-icon'
          className='no-result-img img-fluid'
        />
        <h4 className='yk-title'>{searchData ? NO_RESULT_FOUND.searchTitle : NO_RESULT_FOUND.title}</h4>
        <p className='yk-subtitle'>{searchData ? NO_RESULT_FOUND.searchMsg : NO_RESULT_FOUND.msg}</p>
      </div>
    );
  }
);
NoDataFound.displayName = 'Print Summary';
export default NoDataFound;
