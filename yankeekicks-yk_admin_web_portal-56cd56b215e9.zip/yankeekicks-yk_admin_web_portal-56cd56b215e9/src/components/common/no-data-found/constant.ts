export const NO_RESULT_FOUND = {
  title: 'No results found',
  msg: `We couldn't find anything for what you are looking.`,
  searchTitle: 'Please search or apply filter to begin',
  searchMsg: 'Please select the options to generate the data',
};
