import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import dummyUserImg from 'assets/images/user.svg';
import notificationBell from 'assets/images/notification-bell.svg';
import notificationDot from 'assets/images/notification-dot.svg';
import mapIcon from 'assets/images/location-icon.svg';
import LogOutIcon from 'assets/images/log-out.svg';
import Button from '@mui/material/Button';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import Grow from '@mui/material/Grow';
import Paper from '@mui/material/Paper';
import Popper from '@mui/material/Popper';
import MenuItem from '@mui/material/MenuItem';
import MenuList from '@mui/material/MenuList';
import Stack from '@mui/material/Stack';
import leftArrowIcon from 'assets/images/back-icon.svg';
import { useRouter } from 'next/router';
import { useDispatch } from 'react-redux';
import { actions as authActions } from 'store/reducers/auth';
import { PublicClientApplication } from '@azure/msal-browser';
import { getBasePath } from 'utils/util';
import FormControl from '@mui/material/FormControl';
import { Select } from '@mui/material';

const TopHeader = () => {
  const [open, setOpen] = React.useState(false);
  const [userName, setUserName] = useState<any>('--');
  const [userRole, setUserRole] = useState<any>('--');
  const anchorRef = React.useRef<HTMLButtonElement>(null);

  const router = useRouter();
  const dispatch = useDispatch();

  const msalConfig: any = localStorage.getItem('msalConfig');

  const msalInstance = !!msalConfig
    ? new PublicClientApplication(msalConfig)
    : false;

  useEffect(() => {
    if (
      localStorage?.getItem('user-name') &&
      localStorage?.getItem('user-role')
    ) {
      let role = localStorage
        ?.getItem('user-role')
        ?.toString()
        ?.toLowerCase()
        ?.replaceAll('_', ' ');
      setUserName(localStorage?.getItem('user-name'));
      setUserRole(role);
    } else {
      setUserName('--');
      setUserRole('--');
    }
  }, []);

  const handleToggle = () => {
    setOpen((prevOpen) => !prevOpen);
  };

  const handleClose = (event: Event | React.SyntheticEvent) => {
    if (
      anchorRef.current &&
      anchorRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }

    setOpen(false);
  };

  const getCachedUser = () => {
    if (msalInstance) {
      const allAccounts = msalInstance.getAllAccounts();

      if (allAccounts.length > 0) {
        return allAccounts[0];
      }

      return null;
    }

    return null;
  };

  const logout = () => {
    dispatch(authActions.clearUserDetails());

    if (msalInstance) {
      const logoutRequest = {
        account: getCachedUser(),
        postLogoutRedirectUri: '/',
      };
      if (
        localStorage?.getItem('redirect')?.toLocaleLowerCase() === 'redirect'
      ) {
        msalInstance.logoutRedirect(logoutRequest).catch((e) => {
          console.error(e);
        });
      } else {
        msalInstance.logoutPopup(logoutRequest).catch((e) => {
          console.error(e);
        });
      }
    }

    localStorage?.clear();
    sessionStorage?.clear();
    router.push('/', undefined, { shallow: true });
  };

  function handleListKeyDown(event: React.KeyboardEvent) {
    if (event.key === 'Tab') {
      event.preventDefault();
      setOpen(false);
    } else if (event.key === 'Escape') {
      setOpen(false);
    }
  }

  // return focus to the button when we transitioned from !open -> open
  const prevOpen = React.useRef(open);
  React.useEffect(() => {
    if (prevOpen.current === true && open === false) {
      anchorRef.current!.focus();
    }

    prevOpen.current = open;
  }, [open]);

  const goBackHandler = () => {
    router.back();
  };

  const isBackButtonVisible = () => {
    if (router.pathname.split('/').length > 3) return true;
    else return false;
  };

  return (
    <div className='container-fluid'>
      <div className='row'>
        <div className='col-lg-12 col-md-12 col-sm-12'>
          <div className='heading-wrapper yk-heading-wrapper'>
            {isBackButtonVisible() && (
              <div
                className='yk-heading-btn-wrapper YKCH-backBTNCOnsignee'
                onClick={goBackHandler}
              >
                <button className='btn btn-transparent'>
                  <Image
                    src={leftArrowIcon}
                    alt='left-arrow-icon'
                    className='Image-fluid YKCH-arrowLeft'
                  />
                  Back
                </button>
              </div>
            )}
            <div className='yk-nav-wrapper'>
              <ul className='nav nav-tabs user-nav'>
                <li className='nav-item '>
                  <div className='d-flex justify-content-end'>
                    <div className='dropdown'>
                      <Stack direction='row' spacing={2}>
                        <Button
                          ref={anchorRef}
                          id='composition-button'
                          aria-controls={open ? 'composition-menu' : undefined}
                          aria-expanded={open ? 'true' : undefined}
                          aria-haspopup='true'
                          onClick={handleToggle}
                          className='btn btn-dropdown user-actions-btn'
                        >
                          <Image
                            src={dummyUserImg}
                            alt='User'
                            className='img-fluid'
                          />
                          <span className='user-details-wrapper'>
                            <span className='user-name'>
                              {localStorage.getItem('user-name') || '--'}
                            </span>

                            <span className='emp-id '>
                              {localStorage
                                .getItem('user-role')
                                ?.replace(/_/g, ' ')
                                ?.toLowerCase() || '--'}
                            </span>
                          </span>
                        </Button>
                        <Popper
                          open={open}
                          anchorEl={anchorRef.current}
                          role={undefined}
                          placement='bottom-start'
                          transition
                          disablePortal
                        >
                          {({ TransitionProps, placement }) => (
                            <Grow
                              {...TransitionProps}
                              style={{
                                transformOrigin:
                                  placement === 'bottom-start'
                                    ? 'left top'
                                    : 'left bottom',
                              }}
                            >
                              <Paper className='top-header-popper'>
                                <ClickAwayListener onClickAway={handleClose}>
                                  <MenuList
                                    autoFocusItem={open}
                                    id='composition-menu'
                                    aria-labelledby='composition-button'
                                    onKeyDown={handleListKeyDown}
                                    className='users-menu-list'
                                  >
                                    <MenuItem
                                      className='users-menu-list-item'
                                      onClick={logout}
                                    >
                                      Logout
                                      <Image
                                        src={LogOutIcon}
                                        alt=''
                                        className='img-fluid'
                                      ></Image>
                                    </MenuItem>
                                  </MenuList>
                                </ClickAwayListener>
                              </Paper>
                            </Grow>
                          )}
                        </Popper>
                      </Stack>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TopHeader;
