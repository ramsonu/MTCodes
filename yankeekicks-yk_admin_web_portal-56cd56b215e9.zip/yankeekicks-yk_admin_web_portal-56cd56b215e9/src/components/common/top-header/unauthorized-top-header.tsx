import React, { useRef, useEffect } from 'react';
import Image from 'next/image';
import dummyUserImg from 'assets/images/user.svg';
import notificationBell from 'assets/images/notification-bell.svg';
import notificationDot from 'assets/images/notification-dot.svg';
import LogOutIcon from 'assets/images/log-out.svg';
import Button from '@mui/material/Button';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import Grow from '@mui/material/Grow';
import Paper from '@mui/material/Paper';
import Popper from '@mui/material/Popper';
import MenuItem from '@mui/material/MenuItem';
import MenuList from '@mui/material/MenuList';
import Stack from '@mui/material/Stack';
import { useRouter } from 'next/router';
import { useDispatch } from 'react-redux';
import { actions as authActions } from 'store/reducers/auth';
import { PublicClientApplication } from '@azure/msal-browser';

const UnAuthorizedTopHeader = () => {
  const [open, setOpen] = React.useState(false);
  const anchorRef = React.useRef<HTMLButtonElement>(null);

  const router = useRouter();
  const dispatch = useDispatch();

  const msalConfig: any = localStorage.getItem('msalConfig');

  const msalInstance = !!msalConfig
    ? new PublicClientApplication(msalConfig)
    : false;

  const handleToggle = () => {
    setOpen((prevOpen) => !prevOpen);
  };

  const handleClose = (event: Event | React.SyntheticEvent) => {
    if (
      anchorRef.current &&
      anchorRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }

    setOpen(false);
  };

  const getCachedUser = () => {
    if (msalInstance) {
      const allAccounts = msalInstance.getAllAccounts();

      if (allAccounts.length > 0) {
        return allAccounts[0];
      }

      return null;
    }

    return null;
  };

  const logout = () => {
    dispatch(authActions.clearUserDetails());

    if (msalInstance) {
      const logoutRequest = {
        account: getCachedUser(),
        postLogoutRedirectUri: '/',
      };
      if (
        localStorage?.getItem('redirect')?.toLocaleLowerCase() === 'redirect'
      ) {
        msalInstance.logoutRedirect(logoutRequest).catch((e) => {
          console.error(e);
        });
      } else {
        msalInstance.logoutPopup(logoutRequest).catch((e) => {
          console.error(e);
        });
      }
    }

    localStorage?.clear();
    sessionStorage?.clear();
    router.push('/', undefined, { shallow: true });
  };

  function handleListKeyDown(event: React.KeyboardEvent) {
    if (event.key === 'Tab') {
      event.preventDefault();
      setOpen(false);
    } else if (event.key === 'Escape') {
      setOpen(false);
    }
  }

  // return focus to the button when we transitioned from !open -> open
  const prevOpen = useRef(open);
  useEffect(() => {
    if (prevOpen.current === true && open === false) {
      anchorRef.current!.focus();
    }

    prevOpen.current = open;
  }, [open]);

  return (
    <div className='container-fluid'>
      <div className='row'>
        <div className='col-lg-12 col-md-12 col-sm-12'>
          <div className='heading-wrapper yk-heading-wrapper'>
            <div className='yk-nav-wrapper'>
              <ul className='nav nav-tabs user-nav'>
                <li className='nav-item notification-li d-none'>
                  <a className='nav-link' aria-current='page' href='#'>
                    <Image
                      src={notificationBell}
                      alt=''
                      className='img-fluid notification-bell'
                    />
                    <Image
                      src={notificationDot}
                      alt=''
                      className='img-fluid notification-dot'
                    />
                  </a>
                </li>
                <li className='nav-item dropdown'>
                  <Stack direction='row' spacing={2}>
                    <Button
                      ref={anchorRef}
                      id='composition-button'
                      aria-controls={open ? 'composition-menu' : undefined}
                      aria-expanded={open ? 'true' : undefined}
                      aria-haspopup='true'
                      onClick={handleToggle}
                      className='btn btn-dropdown user-actions-btn'
                    >
                      <Image
                        src={dummyUserImg}
                        alt='User'
                        className='img-fluid'
                      />
                      <span className='user-details-wrapper'>&nbsp;</span>
                    </Button>
                    <Popper
                      open={open}
                      anchorEl={anchorRef.current}
                      role={undefined}
                      placement='bottom-start'
                      transition
                      disablePortal
                    >
                      {({ TransitionProps, placement }) => (
                        <Grow
                          {...TransitionProps}
                          style={{
                            transformOrigin:
                              placement === 'bottom-start'
                                ? 'left top'
                                : 'left bottom',
                          }}
                        >
                          <Paper className='top-header-popper'>
                            <ClickAwayListener onClickAway={handleClose}>
                              <MenuList
                                autoFocusItem={open}
                                id='composition-menu'
                                aria-labelledby='composition-button'
                                onKeyDown={handleListKeyDown}
                                className='users-menu-list'
                              >
                                <MenuItem
                                  className='users-menu-list-item'
                                  onClick={logout}
                                >
                                  Logout
                                  <Image
                                    src={LogOutIcon}
                                    alt=''
                                    className='img-fluid'
                                  ></Image>
                                </MenuItem>
                              </MenuList>
                            </ClickAwayListener>
                          </Paper>
                        </Grow>
                      )}
                    </Popper>
                  </Stack>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UnAuthorizedTopHeader;
