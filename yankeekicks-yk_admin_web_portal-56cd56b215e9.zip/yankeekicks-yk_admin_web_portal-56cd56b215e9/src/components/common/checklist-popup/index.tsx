import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useTheme } from '@mui/material/styles';
import type { NextPage } from 'next';
import SearchComp from 'components/common/search';
import Modal from '@mui/material/Modal';
import Image from 'next/image';
import arrowToggle from 'assets/images/caretArrow.svg';
import ModalCloseIcon from 'assets/images/modal-close-icon.svg';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Checkbox,
  Typography,
} from '@mui/material';
import ConfirmPopup from 'components/common/confirm-popup';
import {
  CONSIGNMENT_REVIEW_POPUP_CHECKLIST,
  CONSIGNMENT_REVIEW_APPROVE_STATUS,
  NOTIFICATION_SOMETHING_WENT_WRONG,
  CONSIGNMENT_REVIEW_REJECT_STATUS,
} from 'utils/constants';
import { getLocationsListForConsignmentReviewPopup } from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import { useCubeQuery } from '@cubejs-client/react';
import {
  getLocationDetails,
  postConsignmentReview,
} from 'services/consignment';
import { DISABLE_LOADER, ENABLE_LOADER } from 'actions/loader';
import { useDispatch } from 'react-redux';
import { CONFIRM_MESSAGE_CONSIGNEMNT_REVIEW } from 'components/yk-admin/constants';
import { ValidationRequired } from 'utils/validators';

interface Props {
  showModal?: any;
}

const ChecklistPopupModal = (props: any) => {
  const {
    showModal,
    setShowDetailsModal,
    consignmentId,
    consignorName,
    sku,
    handleShowNotification,
    showRejectPopup = false,
    setShowRejectPopup,
  } = props;
  const dispatch = useDispatch();
  const [showCheckListTab, setShowCheckListTab] = useState(true);
  const [locationList, setLocationList] = useState<any>([]);
  const [selectedLocationList, setSelectedLocationList] = useState<any>([]);
  const [checkListCheckedCount, setCheckListCheckedCount] = useState(0);
  const [showApproveConfirmModal, setShowApproveConfirmModal] = useState(false);
  const [rejectMessage, setRejectMessage] = useState('');
  const [enableSelectLocationButton, setEnableSelectLocationButton] =
    useState(false);
  const [enableApproveButton, setEnableApproveButton] = useState(false);
  const [checkAllChecklist, setCheckAllChecklist] = useState(false);
  const [checkListUpdate, setCheckListUpdate] = useState<any>(
    Array(CONSIGNMENT_REVIEW_POPUP_CHECKLIST.length).fill(false)
  );
  const [checkLocationUpdate, setCheckLocationUpdate] = useState<any>([]);
  const [locationPayload, setLocationPayload] = useState<any>([]);

  const checkAllChecked = (event: any) => {
    setCheckListCheckedCount(
      event?.target?.checked ? CONSIGNMENT_REVIEW_POPUP_CHECKLIST.length : 0
    );
    setCheckListUpdate(
      Array(CONSIGNMENT_REVIEW_POPUP_CHECKLIST.length).fill(
        event?.target?.checked
      )
    );
    setCheckAllChecklist(event?.target?.checked);
    setEnableSelectLocationButton(event?.target?.checked);
  };

  const checkListChecked = (event: any) => {
    let tempCheckboxCheckedCount = checkListCheckedCount;
    let tempCheckListUpdate: any = checkListUpdate;
    tempCheckListUpdate[event?.target?.value] = event?.target?.checked;
    if (event?.target?.checked) tempCheckboxCheckedCount += 1;
    else tempCheckboxCheckedCount -= 1;
    setCheckListCheckedCount(tempCheckboxCheckedCount);
    if (tempCheckboxCheckedCount == CONSIGNMENT_REVIEW_POPUP_CHECKLIST.length) {
      setEnableSelectLocationButton(true);
      setCheckAllChecklist(true);
    } else {
      setEnableSelectLocationButton(false);
      setCheckAllChecklist(false);
    }
    setCheckListUpdate(tempCheckListUpdate);
  };
  const handleLoc = (event: any, index: any, storeId: any) => {
    const tempCheckLocationUpdate: any = checkLocationUpdate;
    tempCheckLocationUpdate[index] = {
      locationId: event?.target?.value,
      storeId: storeId,
    };
    setEnableApproveButton(true);
    setCheckLocationUpdate(tempCheckLocationUpdate);
    setLocationPayload(
      checkLocationUpdate.filter((loc: any) => {
        if (loc.locationId != 0 && loc.storeId != 0) return loc;
      })
    );
  };

  const fetchLocationDetails = async () => {
    try {
      let getLocations = await getLocationDetails();
      let locationListArray = Object.values(getLocations?.data);
      setLocationList(Object.values(locationListArray));
      setCheckLocationUpdate(
        Array(locationListArray?.length).fill({ locationId: 0, storeId: 0 })
      );
    } catch (e: any) {
      setLocationList([]);
    }
  };
  useEffect(() => {
    fetchLocationDetails();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (showRejectPopup) handleButtonRejected();
  }, [showRejectPopup]);

  useEffect(() => {
    setShowCheckListTab(true);
    setCheckListCheckedCount(0);
    setCheckListUpdate(
      Array(CONSIGNMENT_REVIEW_POPUP_CHECKLIST.length).fill(false)
    );
    setEnableSelectLocationButton(false);
    setEnableApproveButton(false);
    setCheckLocationUpdate(Array(checkLocationUpdate.length).fill(0));
    setCheckAllChecklist(false);
  }, [showModal]);

  const handleConsignmentApproved = async () => {
    const status = CONSIGNMENT_REVIEW_APPROVE_STATUS;
    try {
      dispatch({ type: ENABLE_LOADER });
      let handleAction = await postConsignmentReview(
        Number(consignmentId),
        locationPayload,
        CONSIGNMENT_REVIEW_APPROVE_STATUS,
        consignorName,
        sku
      );
      if (handleAction.status == 200) {
        dispatch({ type: DISABLE_LOADER });
        handleShowNotification(status);
        setShowDetailsModal(false);
        setShowApproveConfirmModal(false);
      } else {
        handleShowNotification(
          status,
          handleAction?.data?.message || NOTIFICATION_SOMETHING_WENT_WRONG
        );
        setShowDetailsModal(false);
        setShowApproveConfirmModal(false);
        dispatch({ type: DISABLE_LOADER });
      }
    } catch (e: any) {
      console.log('catch error', e);
      handleShowNotification(
        status,
        e?.response?.data?.message || NOTIFICATION_SOMETHING_WENT_WRONG
      );
      setShowDetailsModal(false);
      setShowApproveConfirmModal(false);
      dispatch({ type: DISABLE_LOADER });
    }
  };
  const handleConsignmentRejected = async () => {
    const status = CONSIGNMENT_REVIEW_REJECT_STATUS;
    try {
      dispatch({ type: ENABLE_LOADER });
      let handleAction = await postConsignmentReview(
        Number(consignmentId),
        selectedLocationList.map((loc: any) => {
          return Number(loc?.['Locations.locationID_D']);
        }),
        CONSIGNMENT_REVIEW_REJECT_STATUS,
        consignorName,
        sku,
        rejectMessage
      );
      if (handleAction.status == 200) {
        dispatch({ type: DISABLE_LOADER });
        handleShowNotification(status);
        setShowDetailsModal(false);
        setShowRejectPopup(false);
      } else {
        dispatch({ type: DISABLE_LOADER });
        handleShowNotification(status, handleAction?.data?.message);
        setShowDetailsModal(false);
        setShowApproveConfirmModal(false);
      }
    } catch (e: any) {
      dispatch({ type: DISABLE_LOADER });
      console.log('catch error', e);
      handleShowNotification(
        status,
        e?.response?.data?.message || NOTIFICATION_SOMETHING_WENT_WRONG
      );
      setShowDetailsModal(false);
      setShowApproveConfirmModal(false);
    }
  };
  const handleButtonRejected = () => {
    setShowDetailsModal(false);
    setShowRejectPopup(true);
  };
  const handelButtonApproved = () => {
    setShowDetailsModal(false);
    setShowApproveConfirmModal(true);
  };

  return (
    <div className='modal-wrapper'>
      <Modal
        open={showModal}
        onClose={() => setShowDetailsModal(false)}
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'
        className='yk-product-details-modal'>
        <div className='modal-outer-wrapper modal-checklist-container'>
          <div className='modal-inner-wrapper container'>
            <div className='modal-heading-wrapper'>
              <div className='heading-wrapper yk-list-wrap'>
                <div className='align-items-center'>
                  {/* <h3 className='heading d-inline-block mb-0'>Checklist</h3> */}
                  <h2 className='yk-checklist-title'>
                    {showCheckListTab ? `Checklist` : `Locations`}
                  </h2>
                  <p className='yk-checklist-tag'>
                    Please check the list below to confirm approval
                  </p>
                </div>
                <button
                  className='btn btn-modal-close'
                  onClick={() => setShowDetailsModal(false)}>
                  <Image
                    src={ModalCloseIcon}
                    className='img-fluid'
                    alt=''></Image>
                </button>
              </div>

              <div className='modal-body-wrapper row'>
                <div className='product-description-wrapper'>
                  <div className='row m-auto'>
                    <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                      {showCheckListTab && (
                        <div className={`yk-checklist-container-wrap`}>
                          {
                            <div className='yk-checklist-wrap' key={`checkAll`}>
                              <label htmlFor={`selectAllCheckList`}>
                                <Checkbox
                                  onChange={(e) => checkAllChecked(e)}
                                  className='filter-sidebar-checkbox'
                                  value={'checkall'}
                                  id='selectAllCheckList'
                                  checked={checkAllChecklist}
                                />
                                {'Select All'}
                              </label>
                            </div>
                          }
                          {CONSIGNMENT_REVIEW_POPUP_CHECKLIST.map(
                            (checklistItem: string, index: number) => {
                              return (
                                <div
                                  className='yk-checklist-wrap'
                                  key={`checkList_${index}`}>
                                  <label htmlFor={`checkListCheckbox_${index}`}>
                                    <Checkbox
                                      onChange={(e) => checkListChecked(e)}
                                      className='filter-sidebar-checkbox'
                                      value={index}
                                      checked={checkListUpdate[index]}
                                      id={`checkListCheckbox_${index}`}
                                    />
                                    {checklistItem}
                                  </label>
                                </div>
                              );
                            }
                          )}
                        </div>
                      )}
                      {!showCheckListTab && (
                        <div
                          className={`yk-checklist-container-wrap locationAccordion`}>
                          {locationList &&
                            locationList.map((location: any, index: number) => {
                              return (
                                <Accordion
                                  defaultExpanded={false}
                                  className={`accordion`}
                                  key={`accordion_${index}`}>
                                  <AccordionSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls='panel1a-content'
                                    id='panel1a-header'>
                                    <Typography>
                                      {location?.location}
                                    </Typography>
                                  </AccordionSummary>
                                  <AccordionDetails>
                                    <div className='c-accordion-info in'>
                                      <Typography>
                                        <div
                                          className='yk-checklist-wrap'
                                          key={`checkListLoc_1`}>
                                          {location?.locations?.length &&
                                            location?.locations.map(
                                              (
                                                store: any,
                                                storeindex: number
                                              ) => {
                                                return (
                                                  <div
                                                    className={`store-button-div`}
                                                    key={`store_${index}_${storeindex}`}>
                                                    <input
                                                      type='radio'
                                                      value={store?.id}
                                                      className='form-check-input'
                                                      id={`store_${index}_${storeindex}`}
                                                      name={`store_${index}`}
                                                      onChange={(e) =>
                                                        handleLoc(
                                                          e,
                                                          index,
                                                          store?.storeId
                                                        )
                                                      }
                                                      data-locationid={
                                                        location?.id
                                                      }
                                                      checked={
                                                        store?.id ==
                                                        checkLocationUpdate[
                                                          index
                                                        ].locationId
                                                      }
                                                    />
                                                    <label
                                                      htmlFor={`store_${index}_${storeindex}`}
                                                      className=''>
                                                      {store?.name}
                                                    </label>
                                                  </div>
                                                );
                                              }
                                            )}
                                        </div>
                                      </Typography>
                                    </div>
                                  </AccordionDetails>
                                </Accordion>
                              );
                            })}
                        </div>
                      )}

                      <div className='yk-checklist-buttons'>
                        <div>
                          <a
                            onClick={(e) => setShowCheckListTab(true)}
                            className={`yk-table-link-btn red ${
                              showCheckListTab ? 'd-none' : ''
                            }`}
                            type='button'>
                            Back
                          </a>
                          <button
                            type='button'
                            className='btn yk-checklist-reject'
                            onClick={handleButtonRejected}>
                            Reject
                          </button>
                        </div>
                        {showCheckListTab && (
                          <button
                            type='button'
                            className='btn yk-checklist-approve'
                            disabled={!enableSelectLocationButton}
                            onClick={(e) => setShowCheckListTab(false)}>
                            Select Location
                          </button>
                        )}
                        {!showCheckListTab && (
                          <button
                            type='button'
                            className='btn yk-checklist-approve'
                            disabled={!enableApproveButton}
                            onClick={(e) => handelButtonApproved()}>
                            Approve
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Modal>

      <ConfirmPopup
        showPopup={showApproveConfirmModal}
        handleClose={(e: any) => setShowApproveConfirmModal(false)}
        title='Approve Shipment'
        message={CONFIRM_MESSAGE_CONSIGNEMNT_REVIEW}
        handleSave={handleConsignmentApproved}
      />
      <ConfirmPopup
        showPopup={showRejectPopup}
        handleClose={(e: any) => setShowRejectPopup(false)}
        title='Reject'
        backButton='Back'
        // handleBack={(e: any)=>setShowCheckListTab(true)}
        message={
          <div>
            <p>Please enter the reason for rejection</p>
            <h6>Reason</h6>
            <input
              className='form-control'
              onChange={(e: any) => setRejectMessage(e?.target?.value)}
            />
          </div>
        }
        handleSave={handleConsignmentRejected}
      />
    </div>
  );
};

export default ChecklistPopupModal;
