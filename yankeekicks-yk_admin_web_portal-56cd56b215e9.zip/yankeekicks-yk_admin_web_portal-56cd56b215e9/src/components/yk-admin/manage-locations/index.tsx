import React, { useState, useMemo, useEffect } from 'react';
import type { NextPage } from 'next';
import Image from 'next/image';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import SearchComp from 'components/common/search';
import Sortings from 'components/common/sortings';
import ProductFilters from 'components/common/filters/product-filter';
import VirtualTable from 'components/common/table';
import filterIcon from 'assets/images/filter-icon.png';
import { useCubeQuery } from '@cubejs-client/react';
import { useRouter } from 'next/router';
import {
  getLocationsList,
  getLocationsListPagination,
} from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import Pagination from 'components/common/pagination';
import ExportsTypes from 'components/common/exports-types';
import { getBasePath } from 'utils/util';

const ManageLocations: NextPage = () => {
  const [userInput, setUserInput] = useState('');
  const [selectedSort, setSelectedSort] = useState('newestLocation');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedPayoutStatus, setSelectedPayoutStatus] = useState<any>([]);
  const [checked, setChecked] = useState({
    Pending: false,
    Active: false,
    Disabled: false,
  });
  const [locationTypeChecked, setLocationTypeChecked] = useState({
    Warehouse: false,
    Store: false,
  });
  const [selectedLocationType, setSelectedLocationType] = useState<any>([]);
  const [filterInput, setFilterInput] = useState<any>({});
  const [clearDisable, setClearDisable] = useState(true);
  const [locationList, setLocationList] = useState([]);
  const [searchOffset, setSearchOffset] = useState<any>(0);
  const [countForPagination, setCountForPagination] = useState(0);
  const [searchInput, setSearchInput] = useState('');
  const [isPDFExport, setIsPDFExport] = useState(true);
  const router = useRouter();
  const pageLimit = 10;

  const queryPayload = {
    userInput,
    selectedSort,
    filterInput,
  };

  const consignmentQuery: any = getLocationsList(
    searchInput,
    filterInput,
    selectedSort,
    pageLimit,
    searchOffset
  );
  const paginationCountForConsignment: any = getLocationsListPagination(
    filterInput,
    searchInput
  );

  const exportsLocationsQuery: any = getLocationsList(
    searchInput,
    filterInput,
    selectedSort
  );

  const {
    resultSet: consignorListResultSet,
    isLoading: consignmentIsLoading,
    error: consignmentError,
  }: any = useCubeQuery(consignmentQuery);

  const { resultSet: pageCountResultSet }: any = useCubeQuery(
    paginationCountForConsignment
  );

  const { resultSet: exportsResultsSet }: any = useCubeQuery(
    exportsLocationsQuery,
    { skip: isPDFExport }
  );
  useEffect(() => {
    const data = consignorListResultSet?.loadResponses[0]?.data;
    if (data) {
      setLocationList(data);
    } else {
      setLocationList([]);
    }
    if (pageCountResultSet) {
      let countData =
        +pageCountResultSet?.loadResponses[0]?.data[0]?.['Locations.count'] ||
        0;
      setCountForPagination(countData);
    }
  }, [consignorListResultSet, pageCountResultSet]);

  const onClickPDFExport = () => {
    setIsPDFExport(false);
    setTimeout(() => {
      setIsPDFExport(true);
    }, 100);
  };

  const userInputChangeHandler = (event: any) => {
    setSearchInput(event.target.value);
    setSearchOffset(0);
  };

  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
  };

  const viewButtonHandler = (data: any) => {
    router.push(
      `${getBasePath(`manage-locations/${data?.['Locations.locationID_D']}`)}`
    );
  };

  const onStatusChange = (event: any) => {
    setChecked({ ...checked, [event?.target?.name]: event?.target?.checked });
    var updatedList = [...selectedPayoutStatus];
    if (event.target.checked) {
      updatedList = [...selectedPayoutStatus, event.target.name];
    } else {
      updatedList.splice(selectedPayoutStatus.indexOf(event.target.name), 1);
    }
    setSelectedPayoutStatus(updatedList);
    if (updatedList.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  };

  const onLocationTypeChange = (event: any) => {
    setLocationTypeChecked({
      ...locationTypeChecked,
      [event?.target?.name]: event?.target?.checked,
    });
    var updatedList = [...selectedLocationType];
    if (event.target.checked) {
      updatedList = [...selectedLocationType, event.target.name];
    } else {
      updatedList.splice(selectedLocationType.indexOf(event.target.name), 1);
    }
    setSelectedLocationType(updatedList);
    if (updatedList.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  };

  const onApplyClick = () => {
    const filterPayload = {
      status: selectedPayoutStatus,
      type: selectedLocationType,
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setShowFilters(false);
  };
  const onClearFilters = () => {
    setSelectedPayoutStatus([]);
    setChecked({ Pending: false, Active: false, Disabled: false });
    setLocationTypeChecked({
      Warehouse: false,
      Store: false,
    });
    setFilterInput({});
    setShowFilters(false);
    setClearDisable(true);
  };

  const columns = useMemo(
    () => [
      {
        title: 'Location ID',
        value: 'Locations.locationID_D',
      },
      {
        title: 'Name',
        value: 'Locations.name',
      },
      {
        title: 'City',
        value: 'Locations.city',
      },
      {
        title: 'State',
        value: 'Locations.province',
      },
      {
        title: 'Type',
        value: 'Locations.locationType',
      },
      {
        title: 'Status',
        type: 'status',
        value: 'Locations.Status',
        success: 'Active',
        danger: 'Disabled',
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          viewButtonHandler(data);
        },
        value: 'View',
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );
  const exportHeaders = [
    { label: 'Location ID', key: 'Locations.locationID_D' },
    { label: 'Name', key: 'Locations.name' },
    { label: 'City', key: 'Locations.city' },
    { label: 'State', key: 'Locations.province' },
    { label: 'Type', key: 'Locations.locationType' },
    { label: 'Status', key: 'Locations.Status' },
  ];

  return (
    <div className='app-wrapper w-100 orders-page-wrapper yk-admin-manage-locations-page-wrapper'>
      <div className='manage-user-page-inner-wrapper'>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-lg-12 col-md-12 col-sm-12'>
              <div className='heading-wrapper orders-heading-wrapper'>
                <div className='col-lg-6 col-md-12 col-sm-12'>
                  <h2 className='heading'>Locations</h2>
                </div>
                <div className='col-lg-6 col-md-12 col-sm-12'>
                  <div className='consignment-btn-wrapper export-location-btn-wrapper'>
                    <div className='sort-product-wrapper black-export-btn'>
                      <ExportsTypes
                        data={
                          (exportsResultsSet?.loadResponses &&
                            exportsResultsSet?.loadResponses[0]?.data) ||
                          []
                        }
                        fileName='locations'
                        headers={exportHeaders}
                        queryPayload={queryPayload}
                        onClickPDFExport={onClickPDFExport}
                        isActive={locationList && locationList?.length > 0}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className='search-btn-wrapper'>
              <div className='row'>
                <div className='col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKCH-searchingData'>
                    <SearchComp
                      onChangeHandler={userInputChangeHandler}
                      userInput={userInput}
                      optionType='no suggestions'
                      placeholder='Search'
                    />
                  </div>
                </div>
                <div className='col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 YKEE-columns'>
                  <div className='consignment-btn-wrapper'>
                    <Sortings
                      itemKey='locationSort'
                      handleChange={sortHandler}
                      defaultSelectedValue={selectedSort}
                    />

                    <div className='filter-btn-wrapper'>
                      <ClickAwayListener
                        onClickAway={() => {
                          setShowFilters(false);
                        }}
                      >
                        <div>
                          <button
                            className='btn filter-btn'
                            onClick={() => setShowFilters(!showFilters)}
                          >
                            <Image
                              src={filterIcon}
                              alt='filter-btn-icon'
                              className='filter-btn-icon img-fluid'
                            />
                            <span className='filter-btn-text yk-badge-h15'>
                              Filter
                            </span>
                          </button>

                          {showFilters && (
                            <ProductFilters
                              itemKey='manageLocations'
                              onApplyClick={onApplyClick}
                              onPayoutChange={onStatusChange}
                              checkedValue={checked}
                              onClearFilters={onClearFilters}
                              clearDisable={clearDisable}
                              locationTypeValue={locationTypeChecked}
                              onLocationTypeChange={onLocationTypeChange}
                            />
                          )}
                        </div>
                      </ClickAwayListener>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <VirtualTable
            loading={consignmentIsLoading}
            error={consignmentError}
            headers={columns}
            rowData={locationList}
          />
          {countForPagination > 0 && (
            <div className='center-pagination'>
              <Pagination
                lengthOfData={countForPagination}
                itemsPerPage={pageLimit}
                currentOffset={searchOffset}
                setOffset={setSearchOffset}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
export default ManageLocations;
