import React, { useState, useEffect } from 'react';
import locationManagement from 'assets/images/consignee/location-Management.svg';
import Breadcrumbs from 'components/common/breadcrumbs';
import { getBasePath } from 'utils/util';
import { useRouter } from 'next/router';
import { useForm } from 'react-hook-form';
import {
  getLocationDetailsRequest,
  postAddLocationRequest,
} from 'services/consignor';
import ConfirmPopup from 'components/common/confirm-popup';
import Notification from 'components/common/notification';
import stateCitiesData from 'utils/states-cities.json';
import {
  NEW_COMMISSION_CONFIRM_MESSAGE,
  NEW_COMMISSION_SUCCESS,
  UPDATE_LOCATION_CONFIRM_MESSAGE,
} from '../constants';
import {
  ValidationFullName,
  ValidationMaxLength14,
  ValidationMaxLength250,
  ValidationMaxLength5,
  ValidationMinLength14,
  ValidationMinLength5,
  ValidationMinLength6,
  ValidationOnlyNumbers,
  ValidationOnlyPhoneNumber,
  ValidationRequired,
} from 'utils/validators';
import { updatePhoneNumber } from 'utils/util';
import { US_COUNTRY_INDEX, LOCATIONS_TYPE_LIST } from 'utils/constants';

import { format } from 'date-fns';

interface regForm {
  type: string;
  name: string;
  city: string;
  address: string;
  state: string;
  zipCode: string;
  contactNumber: string;
  locationDetails: any;
  isEditFlag: any;
  isDisabled: any;
  setIsDisabled: any;
}
const AddLocation = (props: any) => {
  let router = useRouter();
  let { locationId } = router.query;
  const { locationDetails, isEditFlag, isDisabled, setIsDisabled } = props;
  let [stateList, setSateList] = useState<any>(
    stateCitiesData[US_COUNTRY_INDEX].states
  );
  const [cityList, setCityList] = useState<any>([]);
  const [isDisable, setIsDisable] = useState<any>(false); // form can able to edit
  let [userRegError, setUserRegError] = useState<string>('');
  const {
    handleSubmit,
    watch,
    setValue,
    register,
    formState: { errors },
  } = useForm<regForm>();
  const [userData, setUserData] = useState({
    type: '',
    name: '',
    city: '',
    address: '',
    state: '',
    zipCode: '',
    contactNumber: '',
  });
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);
  const [showWarningPopup, setShowWarningPopup] = useState(false);
  const [warningMessage, setWarningMessage] = useState('');

  useEffect(() => {
    loadLocationData();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!!isDisabled) {
      setIsDisable(true);
    } else {
      setIsDisable(false);
    }
  });

  const loadLocationData = async () => {
    const getCommissionTypes = await getLocationDetailsRequest(locationId);
    const result: any = getCommissionTypes?.data;
    setValue('type', getCommissionTypes?.data?.locationType);
    setValue('name', getCommissionTypes?.data?.name);
    setValue('city', getCommissionTypes?.data?.city);
    setValue('address', getCommissionTypes?.data?.address1);
    setValue('state', getCommissionTypes?.data?.province);
    setValue('zipCode', getCommissionTypes?.data?.zip);
    setValue('contactNumber', getCommissionTypes?.data?.phone);
    setCityDropdownListFromState(getCommissionTypes?.data?.province);
    setUserData({
      type: getCommissionTypes?.data?.locationType,
      name: getCommissionTypes?.data?.name,
      city: getCommissionTypes?.data?.city,
      address: getCommissionTypes?.data?.address1,
      state: getCommissionTypes?.data?.province,
      zipCode: getCommissionTypes?.data?.zip,
      contactNumber: getCommissionTypes?.data?.phone,
    });
  };

  const handleChange = (e: any) => {
    setUserRegError('');
    if (e.target.name == 'contactNumber') {
      setUserData({
        ...userData,
        [e.target.name]: updatePhoneNumber(e.target.value),
      });
    } else setUserData({ ...userData, [e.target.name]: e.target.value });
  };

  const setCityDropdownListFromState = (state: string) => {
    const tempCityList = stateList.filter((stateRow: any) => {
      return stateRow.name == state;
    });
    setCityList(tempCityList[0]?.cities);
  };

  const handleStateChange = (e: any, selectedState?: any) => {
    let selectedIndex = e.target.options.selectedIndex;
    if (selectedIndex > 0) {
      setCityList(stateList[selectedIndex - 1].cities);
    } else setCityList([]);
  };
  const headers = {
    title: 'Location Management',
    titleImage: locationManagement,
    subTitle: 'Add Location',
    onClick: () => {
      router?.push(`${getBasePath('manage-locations')}`);
    },
  };
  const onSubmit = () => {
    setShowConfirmModal(true);
  };

  const onConfirmClick = async () => {
    let payload = {
      address1: userData?.address,
      address2: locationDetails ? locationDetails?.address2 : '',
      adminGraphqlApiId: locationDetails
        ? locationDetails?.adminGraphqlApiId
        : '',
      city: userData?.city,
      country: locationDetails ? locationDetails?.country : '',
      countryCode: locationDetails ? locationDetails?.countryCode : '',
      createdBy: 0,
      id: locationDetails ? locationDetails?.id : 0,
      localizedCountryName: locationDetails
        ? locationDetails?.localizedCountryName
        : '',
      localizedProvinceName: locationDetails
        ? locationDetails?.localizedProvinceName
        : '',
      locationType: userData?.type,
      name: userData?.name,
      phone: userData?.contactNumber,
      province: userData?.state,
      provinceCode: locationDetails ? locationDetails?.provinceCode : '',
      storeId: locationDetails
        ? locationDetails?.storeId
        : localStorage.getItem('storeId'),
      state: userData?.state,
      updatedBy: 0,
      zip: userData?.zipCode,
    };
    let result: any = [];
    try {
      result = await postAddLocationRequest(locationDetails?.id, payload);

      if (result?.status === 201 || result?.status === 200) {
        setShowConfirmModal(false);
        setShowSuccessPopup(true);
        setTimeout(() => {
          router?.push(`${getBasePath('manage-locations')}`);
        }, 1500);
      } else {
        setShowWarningPopup(true);
        setWarningMessage(
          result?.response?.data?.message || result?.response?.data?.error
        );
        setShowConfirmModal(false);
      }
    } catch {
      setShowWarningPopup(true);
      setWarningMessage(
        result?.response?.data?.message || result?.response?.data?.error
      );
      setShowConfirmModal(false);
    }
  };

  const handleClose = () => {
    setShowConfirmModal(false);
  };

  const handleSnackbarClose = () => {
    setShowSuccessPopup(false);
    setShowWarningPopup(false);
  };

  const onCancelClick = () => {
    router?.push(`${getBasePath('manage-locations')}`);
  };

  const message = (
    <h3 className='notification-heading'>
      {isEditFlag ? UPDATE_LOCATION_CONFIRM_MESSAGE : NEW_COMMISSION_SUCCESS}
    </h3>
  );

  const warningMessages = (
    <h3 className='notification-heading'>{warningMessage}</h3>
  );

  return (
    <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
      {!isEditFlag && (
        <>
          {/* breadCrumb */}
          <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex'>
            <Breadcrumbs data={headers} />
          </div>

          <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
            <h2 className='YKEE-headlines'>Add Location</h2>
            <p className='YKEE-overviews'>
              Please fill the details below to add new location
            </p>
          </div>
        </>
      )}
      {/* card sections */}
      <form onSubmit={handleSubmit(onSubmit)} className='row'>
        <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 YKEE-columns'>
          <div className='card YKEE-cardCover'>
            <div className='YKEE-coverArea YKEE-topAreas'>
              <div className='row'>
                {' '}
                <div className='YKEE-headerStrip'>
                  <h4 className='YKEE-personalInfo'>Location</h4>{' '}
                </div>
                <div className='col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>Type</label>
                    <div className='YKEE-arrowDownns '>
                      <select
                        className='form-control YKEE-field'
                        {...register('type', {
                          ...ValidationRequired,
                          onChange: (e) => handleChange(e),
                        })}
                        disabled={isDisable}
                      >
                        <option value=''>Select Location Type</option>
                        {LOCATIONS_TYPE_LIST.map(
                          (type: string, index: number) => (
                            <>
                              <option key={index} value={type}>
                                {type}
                              </option>
                            </>
                          )
                        )}
                      </select>
                    </div>
                    {errors.type && (
                      <div className='invalid-feedback'>
                        {errors.type.message}
                      </div>
                    )}
                  </div>
                </div>
                <div className='col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>Name</label>
                    <input
                      type='text'
                      placeholder='Enter Location Name'
                      className='form-control YKEE-field'
                      {...register('name', {
                        ...ValidationFullName,
                        onChange: (e) => handleChange(e),
                      })}
                      disabled={isDisable}
                    />
                    {errors.name && (
                      <div className='invalid-feedback'>
                        {errors.name.message}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className='YKEE-coverArea YKEE-topAreas'>
              <div className='row'>
                {' '}
                <div className='YKEE-headerStrip'>
                  <h4 className='YKEE-personalInfo'>Communication</h4>{' '}
                </div>
                <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>
                      Location Contact Number
                    </label>
                    <input
                      type='text'
                      placeholder='Enter Contact Number'
                      className='form-control YKEE-field'
                      id='contact-number'
                      {...register('contactNumber', {
                        ...ValidationRequired,
                        ...ValidationMaxLength14,
                        ...ValidationMinLength14,
                        ...ValidationOnlyPhoneNumber,
                        onChange: (e) => handleChange(e),
                      })}
                      disabled={isDisable}
                      value={userData.contactNumber}
                    />
                    {errors.contactNumber && (
                      <div className='invalid-feedback'>
                        {errors.contactNumber.message}
                      </div>
                    )}
                  </div>
                </div>
                <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>Street Address</label>
                    <input
                      type='text'
                      placeholder='Enter Street Address'
                      className='form-control YKEE-field'
                      {...register('address', {
                        ...ValidationRequired,
                        ...ValidationMinLength6,
                        ...ValidationMaxLength250,
                        onChange: (e) => handleChange(e),
                      })}
                      disabled={isDisable}
                    />
                    {errors.address && (
                      <div className='invalid-feedback'>
                        {errors.address.message}
                      </div>
                    )}
                  </div>
                </div>
                <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>State</label>
                    <div className='YKEE-arrowDownns '>
                      <select
                        className='form-control YKEE-field'
                        id='State'
                        {...register('state', {
                          ...ValidationRequired,
                          onChange: (e) => {
                            handleChange(e);
                            handleStateChange(e);
                          },
                        })}
                        disabled={isDisable}
                      >
                        <option value=''>Select State</option>
                        {stateList?.map((item: any, index: number) => {
                          return (
                            <option key={index} value={item.name}>
                              {item.name}
                            </option>
                          );
                        })}
                      </select>
                    </div>
                    {errors.state && (
                      <div className='invalid-feedback'>
                        {errors.state.message}
                      </div>
                    )}
                  </div>
                </div>
                <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>City</label>
                    <div className='YKEE-arrowDownns '>
                      <select
                        className='form-control YKEE-field'
                        {...register('city', {
                          ...ValidationRequired,
                          onChange: (e) => handleChange(e),
                        })}
                        disabled={isDisable}
                      >
                        <option>Select City</option>
                        {cityList?.map((item: any, index: number) => {
                          return (
                            <option key={index} value={item.name}>
                              {item.name}
                            </option>
                          );
                        })}
                      </select>
                    </div>
                    {errors.city && (
                      <div className='invalid-feedback'>
                        {errors.city.message}
                      </div>
                    )}
                  </div>
                </div>
                <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 YKEE-columns mb-5'>
                  <div className='YKEE-formArea YKEE-eYEMark'>
                    <label className='YKEE-lable'>Zip/Postal Code</label>
                    <input
                      type='text'
                      placeholder='Enter Zip/Postal Code'
                      className='form-control YKEE-field'
                      id='zip-code'
                      {...register('zipCode', {
                        ...ValidationRequired,
                        ...ValidationMaxLength5,
                        ...ValidationMinLength5,
                        ...ValidationOnlyNumbers,
                        onChange: (e) => handleChange(e),
                      })}
                      disabled={isDisable}
                    />
                    {errors.zipCode && (
                      <div className='invalid-feedback'>
                        {errors.zipCode.message}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
          <div className='YKEE-submitDicard'>
            <div className='YKEE-twoBTNS'>
              {/* <button
                className={`btn YKEE-noOverlay`}
                type='button'
                onClick={onCancelClick}
              >
                Back
              </button> */}
            </div>
          </div>
        </div>
      </form>
      {
        <ConfirmPopup
          showPopup={showConfirmModal}
          handleClose={handleClose}
          title={isEditFlag ? 'Edit Location' : 'Add New Location'}
          message={
            isEditFlag
              ? UPDATE_LOCATION_CONFIRM_MESSAGE
              : NEW_COMMISSION_CONFIRM_MESSAGE
          }
          handleSave={onConfirmClick}
        />
      }
      <Notification
        showSuccessPopup={showSuccessPopup}
        handleSnackbarClose={handleSnackbarClose}
        severityType='success'
        message={message}
        className='yk-shoesize-alert-wrapper'
      />
      <Notification
        showSuccessPopup={showWarningPopup}
        handleSnackbarClose={handleSnackbarClose}
        severityType='warning'
        message={warningMessages}
        className='yk-shoesize-alert-wrapper'
      />
    </div>
  );
};
export default AddLocation;
