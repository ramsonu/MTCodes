import { useRouter } from 'next/router';
import React, { useEffect, useState } from 'react';
import Breadcrumbs from 'components/common/breadcrumbs';
import { convertPriceToUSFormat, getBasePath } from 'utils/util';
import AddLocation from './add-location';
import { getLocationDetailsRequest } from 'services/consignor';
import { getViewLocations } from 'middleware/cubejs-wrapper/yk-super-admin-cubejs-query';
import { useCubeQuery } from '@cubejs-client/react';
import locationManagement from 'assets/images/consignee/location-Management.svg';

const ViewLocation = () => {
  const [locationDetails, setLocationDetails] = useState<any>([]);
  const [isEdit, setIsEdit] = useState(true);
  const [isDisabled, setIsDisabled] = useState<any>(true);
  const [viewLocationDetails, setViewLocationDetails] = useState<any>([]);
  let router = useRouter();
  let { locationId } = router.query;

  const viewLocationsQuery: any = getViewLocations(locationId);

  const {
    resultSet: locationListResultSet,
    isLoading: locationIsLoading,
    error: locationError,
  }: any = useCubeQuery(viewLocationsQuery);

  useEffect(() => {
    (async () => {
      const getCommissionTypes = await getLocationDetailsRequest(locationId);
      const result: any = getCommissionTypes?.data;
      setLocationDetails(result);
    })();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const data = locationListResultSet?.loadResponses[0]?.data;
    if (data) {
      setViewLocationDetails(data);
    } else {
      setViewLocationDetails([]);
    }
  }, [locationListResultSet]);

  const headers = {
    title: 'Location Management',
    titleImage: locationManagement,
    subTitle: locationId,
    onClick: () => {
      router?.push(`${getBasePath('manage-locations')}`);
    },
  };

  return (
    <div className='row m-auto YKEE-additional'>
      {/* breadCrumb */}
      <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
        <Breadcrumbs data={headers} />
      </div>

      <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
        <h2 className='YKEE-headlines'>{`(${locationDetails?.name || ''})${
          locationId || ''
        }`}</h2>
        <p className='YKEE-overviews'>Location Details</p>
      </div>

      <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 YKEE-columns YKEE-dropDetails'>
        <div className='YKEE-DetailsWrapArea'>
          <h2 className='YKEE-headlines YKEE-DetailsList'>Details</h2>
        </div>
        <div className='card YKEE-cardCover YKEE-spacerInBetween h-auto'>
          <div className='YKEE-coverArea'>
            <div className='row'>
              <div className='col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 YKEE-columns YKEE-rightLines'>
                <p className='YKEE-titleProperty'>Status</p>
                <h4 className='YKEE-value YKEE-greenActive'>
                  {viewLocationDetails?.[0]?.['ViewLocation.Status']
                    ? viewLocationDetails?.[0]?.['ViewLocation.Status']
                    : '--'}
                </h4>
              </div>
              <div className='col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 YKEE-columns YKEE-rightLines'>
                <p className='YKEE-titleProperty'>Number of Employees</p>
                <h4 className='YKEE-value'>
                  {' '}
                  {viewLocationDetails?.[0]?.['ViewLocation.userCount']
                    ? viewLocationDetails?.[0]?.['ViewLocation.userCount']
                    : 0}
                </h4>
              </div>
              <div className='col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 YKEE-columns'>
                <p className='YKEE-titleProperty'>Inventory Value</p>
                <h4 className='YKEE-value'>
                  {viewLocationDetails?.[0]?.['ViewLocation.inventoryValue']
                    ? convertPriceToUSFormat(
                        parseFloat(
                          viewLocationDetails?.[0]?.[
                            'ViewLocation.inventoryValue'
                          ]
                        )?.toFixed(2)
                      )
                    : 0}
                </h4>
              </div>
            </div>
          </div>
        </div>
      </div>

      <AddLocation
        locationDetails={locationDetails}
        isEditFlag={isEdit}
        isDisabled={isDisabled}></AddLocation>
    </div>
  );
};
export default ViewLocation;
