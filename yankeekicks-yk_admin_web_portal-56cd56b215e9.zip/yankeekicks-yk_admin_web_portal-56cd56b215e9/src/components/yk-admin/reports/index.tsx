import React, { useState } from 'react';
import { REPORTS } from './constants';
import { MenuItem, Select, FormControl } from '@mui/material';

const ReportsComp = () => {
  const [report, setReport] = useState<any>(REPORTS[0]);
  const handleChange = (e: any) => {
    const item = REPORTS.find((re: any) => re.value === e.target.value);
    setReport(item);
  };
  return (
    <div className='app-wrapper w-100 orders-page-wrapper yk-admin-manage-user-page-wrapper'>
      <div className='manage-user-page-inner-wrapper yk-reports-page-inner-wrapper'>
        <div className='container-fluid'>
          <div className='reportsHeadingWrapper'>
            <div className='orders-heading-wrapper'>
              <h2 className='heading'>Reports</h2>
              <p className='sub-haeding mb-0'>
                Please download report to open. Report will be downloaded with
                the applied filters.
              </p>
            </div>

            <div className='sort-product-wrapper mu-sort order-sort-btn YKCH-sort yk-reportTypeBtn'>
              <FormControl sx={{ m: 1, minWidth: 80 }}>
                <Select
                  className=''
                  id='report'
                  defaultValue={report.value}
                  onChange={handleChange}>
                  {REPORTS.map((item, index) => {
                    return (
                      <MenuItem
                        className='YKCH-dataInfinite'
                        key={index}
                        value={item.value}>
                        {item.name}
                      </MenuItem>
                    );
                  })}
                </Select>
              </FormControl>
            </div>
          </div>

          <div className='row'>
            <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
              <div className='reportsWrapper'>
                <iframe
                  title={report.title}
                  src={`${report.value}`}
                  frameBorder='0'
                  allowFullScreen={true}
                  className='ykch-BIpower'
                  style={{ background: '#f5f5f5' }}></iframe>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReportsComp;
