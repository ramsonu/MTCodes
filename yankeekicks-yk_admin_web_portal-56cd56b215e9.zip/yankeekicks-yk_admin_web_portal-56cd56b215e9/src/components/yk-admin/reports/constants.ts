import {
  PBI_REPORTS_INVENTORY_URL,
  PBI_REPORTS_SALES_URL,
  PBI_REPORTS_TOP_URL,
  PBI_REPORTS_USER_URL,
} from 'services/apiUrl';

export const REPORTS = [
  {
    name: 'Sales',
    value: PBI_REPORTS_SALES_URL,
    title: 'Sales Reports',
  },
  {
    name: 'Inventory',
    value: PBI_REPORTS_INVENTORY_URL,
    title: 'Inventory Reports',
  },
  {
    name: 'Top Reports',
    value: PBI_REPORTS_TOP_URL,
    title: 'Top reports',
  },
  {
    name: 'User reports',
    value: PBI_REPORTS_USER_URL,
    title: 'User reports',
  },
];
