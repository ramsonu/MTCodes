import React, { useState, useMemo, useEffect } from 'react';
import type { NextPage } from 'next';
import Image from 'next/image';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import SearchComp from 'components/common/search';
import Sortings from 'components/common/sortings';
import ProductFilters from 'components/common/filters/product-filter';
import VirtualTable from 'components/common/table';
import filterIcon from 'assets/images/filter-icon.png';
import { useCubeQuery } from '@cubejs-client/react';
import {
  getCommissionNames,
  getManageCommissionQuery,
  getPaginationCountForManageCommission,
} from 'middleware/cubejs-wrapper/yk-super-admin-cubejs-query';
import Pagination from 'components/common/pagination';
import ChangeRequestModal from './change-request-modal';
import { useRouter } from 'next/router';
import { YK_ADMIN_INNER_PATH } from '../constants';

const ManageCommissions: NextPage = () => {
  const [userInput, setUserInput] = useState('');
  const [commissionOffset, setCommissionOffset] = useState(0);
  const [selectedSort, setSelectedSort] = useState('commissionNewest');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState<any>([]);
  const [checked, setChecked] = useState({
    Approved: false,
    Pending: false,
    Reject: false,
  });
  const [selectedCommisonType, setSelectedCommisonType] = useState<any>([]);
  const [selectedType, setSelectedType] = useState<any>([]);
  const [typeFilter, setTypeFilter] = useState({
    Special: false,
    Vip: false,
  });
  const [clearDisable, setClearDisable] = useState(true);
  const [manageCommissionData, setManageCommissionData] = useState([]);
  const [filterInput, setFilterInput] = useState<any>({});
  const [countForPagination, setCountForPagination] = useState(0);
  const [viewChangeRequestModal, setViewChangeRequestModal] = useState(false);
  const [requestData, setRequestData] = useState([]);
  const [commissionNamesList, setCommissionNamesList] = useState([]);
  const [reloadData, setReloadData] = React.useState<any>(false);
  const router = useRouter();
  const { VIEWCOMMISSIONS_PATH } = YK_ADMIN_INNER_PATH;

  const commissionDetailsByIdQuery: any = getCommissionNames();

  const { resultSet: commissionDetailsResultSet }: any = useCubeQuery(
    commissionDetailsByIdQuery
  );

  const manageCommissionQuery: any = getManageCommissionQuery(
    userInput,
    selectedSort,
    filterInput,
    commissionOffset
  );

  const {
    resultSet: manageCommissionResultSet,
    isLoading: manageCommissionIsLoading,
    error: manageCommissionError,
  }: any = useCubeQuery(manageCommissionQuery, { subscribe: reloadData });

  const paginationCountForManageCommission: any =
    getPaginationCountForManageCommission(userInput, selectedSort, filterInput);

  const { resultSet: pageCountResultSet }: any = useCubeQuery(
    paginationCountForManageCommission
  );

  useEffect(() => {
    const data = commissionDetailsResultSet?.loadResponses[0]?.data;
    if (data) {
      setCommissionNamesList(data);
    } else {
      setCommissionNamesList([]);
    }
  }, [commissionDetailsResultSet]);

  useEffect(() => {
    const data = manageCommissionResultSet?.loadResponses[0]?.data;
    if (data) {
      setManageCommissionData(data);
    } else {
      setManageCommissionData([]);
    }
    if (pageCountResultSet) {
      let countData =
        +pageCountResultSet?.loadResponses[0]?.data[0]?.[
          'Managecomission.count'
        ] || 0;
      setCountForPagination(countData);
    }
  }, [manageCommissionResultSet, pageCountResultSet]);

  const onStatusChange = (event: any) => {
    setChecked({ ...checked, [event?.target?.name]: event?.target?.checked });
    let updatedList = [...selectedStatus];
    if (event.target.checked) {
      updatedList = [...selectedStatus, event.target.name];
    } else {
      updatedList.splice(selectedStatus.indexOf(event.target.name), 1);
    }
    setSelectedStatus(updatedList);
    if (updatedList.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  };

  const onCommissionChange = (event: any) => {
    if (selectedCommisonType.includes(event?.target?.name)) {
      let tempOption = [];
      tempOption = selectedCommisonType.filter(
        (data: any) => data !== event?.target?.name
      );
      setSelectedCommisonType(tempOption);
      if (tempOption.length === 0) {
        setClearDisable(true);
      }
    } else {
      setSelectedCommisonType([...selectedCommisonType, event?.target?.name]);
      setClearDisable(false);
    }
  };

  const onTypeChange = (event: any) => {
    setTypeFilter({
      ...typeFilter,
      [event?.target?.name]: event?.target?.checked,
    });
    let updatedList = [...selectedType];
    if (event.target.checked) {
      updatedList = [...selectedType, event.target.name];
    } else {
      updatedList.splice(selectedType.indexOf(event.target.name), 1);
    }
    setSelectedType(updatedList);
    if (updatedList.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  };

  const onApplyFilters = () => {
    const filterPayload: any = {
      status: selectedStatus,
      type: selectedCommisonType,
    };
    setFilterInput(filterPayload);
    setShowFilters(false);
  };

  const onClearFilters = () => {
    setSelectedStatus([]);
    setChecked({ Approved: false, Pending: false, Reject: false });
    setFilterInput([]);
    setSelectedCommisonType([]);
    setShowFilters(false);
    setClearDisable(true);
  };

  const userInputChangeHandler = (event: any) => {
    setUserInput(event.target.value);
    setCommissionOffset(0);
  };

  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
  };

  const viewButtonHandler = (data: any) => {
    setViewChangeRequestModal(true);
    setRequestData(data);
  };
  const viewCommissions = () => {
    router?.push(
      {
        pathname: VIEWCOMMISSIONS_PATH,
        query: {
          data: manageCommissionData,
        },
      },
      VIEWCOMMISSIONS_PATH
    );
  };
  const handleModalClose = (isRefresh: boolean = false) => {
    setReloadData(isRefresh);
    setViewChangeRequestModal(false);
    setTimeout(() => {
      setReloadData(false);
    }, 500);
  };
  const columns = useMemo(
    () => [
      {
        title: 'Consignor ID',
        value: 'Managecomission.consigneeD',
      },
      {
        title: 'Name',
        value: 'Managecomission.userName',
      },
      {
        title: 'Type',
        value: 'Managecomission.comissionType',
      },
      {
        title: 'Current Commission',
        value: 'Managecomission.currentCommission',
        suffix: '%',
      },
      {
        title: 'New Commission',
        value: 'Managecomission.newComissionName',
        type: 'commission',
        commission: 'Managecomission.newCommission',
      },
      {
        title: 'Status',
        type: 'status',
        value: 'Managecomission.Status',
        success: 'Approved',
        pending: 'Pending',
        danger: 'Reject',
      },
      {
        title: 'Actions',
        type: 'dynamicActionButton',
        onClick: (data: any) => {
          viewButtonHandler(data);
        },
        value: 'Managecomission.Status',
      },
    ],
    []
  );

  return (
    <>
      <div className='app-wrapper w-100 orders-page-wrapper yk-admin-manage-commission-page-wrapper'>
        <div className='manage-user-page-inner-wrapper'>
          <div className='container-fluid'>
            <div className='row'>
              <div className='col-lg-12 col-md-12 col-sm-12'>
                <div className='heading-wrapper orders-heading-wrapper'>
                  <h2 className='heading'>Manage Commission</h2>
                  <div className='add-user-btn-wrapper'>
                    <button
                      className='btn yk-btn-primary-sm'
                      onClick={viewCommissions}
                    >
                      View Commissions
                    </button>
                  </div>
                </div>
              </div>
              <div className='search-btn-wrapper'>
                <div className='row'>
                  <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12'>
                    <div className='search-bar-wrapper yk-search-bar table-filter-search'>
                      <SearchComp
                        onChangeHandler={userInputChangeHandler}
                        userInput={userInput}
                        optionType='no suggestions'
                        placeholder='Search'
                      />
                    </div>
                  </div>
                  <div className='col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12'>
                    <div className='consignment-btn-wrapper p-0 YKCH-topSSpacSS YKCH-filterArenas'>
                      <Sortings
                        itemKey='manageCommission'
                        handleChange={sortHandler}
                        defaultSelectedValue={selectedSort}
                      />

                      <div className='filter-btn-wrapper'>
                        <ClickAwayListener
                          onClickAway={() => {
                            setShowFilters(false);
                          }}
                        >
                          <div>
                            <button
                              className='btn filter-btn'
                              onClick={() => setShowFilters(!showFilters)}
                            >
                              <Image
                                src={filterIcon}
                                alt='filter-btn-icon'
                                className='filter-btn-icon img-fluid'
                              />
                              <span className='filter-btn-text yk-badge-h15'>
                                Filter
                              </span>
                            </button>

                            {showFilters && (
                              <ProductFilters
                                itemKey='manageCommission'
                                data={commissionNamesList}
                                clearDisable={clearDisable}
                                onApplyClick={onApplyFilters}
                                checkedValue={checked}
                                checkedSkuValue={selectedCommisonType}
                                onClearFilters={onClearFilters}
                                onPayoutChange={onStatusChange}
                                onCommissionChange={onCommissionChange}
                                onTypeChange={onTypeChange}
                                typeValue={typeFilter}
                              />
                            )}
                          </div>
                        </ClickAwayListener>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <VirtualTable
              loading={manageCommissionIsLoading}
              error={manageCommissionError}
              headers={columns}
              rowData={manageCommissionData}
            />
          </div>
          {countForPagination > 0 && (
            <div className='center-pagination'>
              <Pagination
                lengthOfData={countForPagination}
                itemsPerPage={10}
                currentOffset={commissionOffset}
                setOffset={setCommissionOffset}
              />
            </div>
          )}
        </div>
      </div>
      <ChangeRequestModal
        viewChangeRequestModal={viewChangeRequestModal}
        setViewChangeRequestModal={setViewChangeRequestModal}
        handleModalClose={handleModalClose}
        requestData={requestData}
      />
    </>
  );
};
export default ManageCommissions;
