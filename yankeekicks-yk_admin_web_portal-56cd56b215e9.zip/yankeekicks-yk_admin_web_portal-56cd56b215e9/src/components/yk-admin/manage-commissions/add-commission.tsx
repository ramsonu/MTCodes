import React, { useEffect, useState } from 'react';
import type, { NextPage } from 'next';
import Modal from '@mui/material/Modal';
import { addNewCommissionRequest } from 'services/consignor';
import ConfirmPopup from 'components/common/confirm-popup';
import Notification from 'components/common/notification';
import {
  EDIT_COMMISSION_CONFIRM_MESSAGE,
  NEW_COMMISSION_CONFIRM_MESSAGE,
  NEW_COMMISSION_SUCCESS,
  UPDATE_COMMISSION_SUCCESS,
} from '../constants';
import { useForm } from 'react-hook-form';
import {
  ValidationCommissionName,
  ValidationMaxLength30,
  ValidationMaxLength5,
  ValidationMaxLength6,
  ValidationOnlyNumbers,
  ValidationOnlyUptoTwoDecimals,
  ValidationRequired,
} from 'utils/validators';

interface Props {
  showAddCommissionModal?: any;
  setShowAddCommissionModal?: any;
  editCommissionData?: any;
  isEdit?: any;
  handleModalClose?: any;
}
interface addCommissionForm {
  name: string;
  profitRatio: string;
  minimumFee: string;
  flatFee: string;
}
const AddCommissionModal: NextPage<Props> = ({
  showAddCommissionModal,
  setShowAddCommissionModal,
  editCommissionData,
  isEdit,
  handleModalClose,
}) => {
  const initialState = {
    name: '',
    profitRatio: '',
    minimumFee: '',
    flatFee: '',
    id: '',
  };
  const [addCommissionPayload, setAddCommissionPayload] =
    useState(initialState);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);
  const [showWarningPopup, setShowWarningPopup] = useState(false);
  const [warningMessage, setWarningMessage] = useState('');
  const {
    handleSubmit,
    watch,
    setValue,
    register,
    formState: { errors },
  } = useForm<addCommissionForm>();

  useEffect(() => {
    commissionInit();
  }, [editCommissionData]);

  const commissionInit = () => {
    setValue('name', editCommissionData['ConsigneeType.name']);
    setValue('profitRatio', editCommissionData['ConsigneeType.profitRatio']);
    setValue('minimumFee', editCommissionData['ConsigneeType.minimumFee']);
    setValue('flatFee', editCommissionData['ConsigneeType.flatFee']);
    setAddCommissionPayload({
      name: editCommissionData['ConsigneeType.name'] || '',
      profitRatio: editCommissionData['ConsigneeType.profitRatio'] || '',
      minimumFee: editCommissionData['ConsigneeType.minimumFee'] || '',
      flatFee: editCommissionData['ConsigneeType.flatFee'] || '',
      id: editCommissionData['ConsigneeType.consigneeTypeId_D'] || '',
    });
  };

  const onChangeHandler = (e: any) => {
    setAddCommissionPayload({
      ...addCommissionPayload,
      [e.target.name]: e.target.value,
    });
  };

  const onSubmit = () => {
    setShowConfirmModal(true);
    setShowAddCommissionModal(false);
  };
  const handleClose = () => {
    setShowConfirmModal(false);
  };

  const handleSnackbarClose = () => {
    setShowSuccessPopup(false);
    setShowWarningPopup(false);
  };

  const onConfirmClick = async () => {
    const userId = JSON.parse(localStorage.getItem('userId') || '');
    let payload = {
      commissionName: addCommissionPayload?.name,
      consigneeTypeId:  isEdit ? addCommissionPayload?.id : 0,
      createdBy: userId,
      flatFee: addCommissionPayload?.flatFee,
      minimumFee: addCommissionPayload?.minimumFee,
      profitRatio: addCommissionPayload?.profitRatio,
      updatedBy: userId,
    };
    let result: any = [];
    try {
      result = await addNewCommissionRequest(
        isEdit ? addCommissionPayload?.id : null,
        payload
      );

      if (result?.status === 201 || result?.status === 200) {
        setShowConfirmModal(false);
        setShowSuccessPopup(true);
        setAddCommissionPayload({
          name: '',
          profitRatio: '',
          minimumFee: '',
          flatFee: '',
          id: '',
        });
        handleModalClose(true);
      } else {
        setShowWarningPopup(true);
        setWarningMessage(
          result?.response?.data?.message || result?.response?.data?.error
        );
        setShowConfirmModal(false);
        handleModalClose();
      }
    } catch (e: any) {
      console.log('e', e);
      setShowWarningPopup(true);
      setWarningMessage(e?.response?.data?.message);
      setShowConfirmModal(false);
      handleModalClose();
    }
  };

  const message = (
    <h3 className='notification-heading'>
      {isEdit ? UPDATE_COMMISSION_SUCCESS : NEW_COMMISSION_SUCCESS}
    </h3>
  );

  const warningMessages = (
    <h3 className='notification-heading'>{warningMessage}</h3>
  );

  return (
    <>
      <div className='app-wrapper w-100 landing-page-wrapper'>
        <Modal
          open={showAddCommissionModal}
          onClose={handleModalClose}
          className='yk-change-commission-modal-wrapper'
          aria-labelledby='modal-modal-title'
          aria-describedby='modal-modal-description'
        >
          <div className='app-wrapper change-commission-modal-wrapper'>
            <div className='yk-modal-body'>
              <div className='modal-heading-wrapper'>
                <h3 className='modal-title yk-badge-h11'>{`${
                  isEdit ? 'Edit Commission' : 'Add New Commission'
                }`}</h3>
                <p className='modal-sub-title'>
                  Please fill the details below to add new commission
                </p>
              </div>
              <form onSubmit={handleSubmit(onSubmit)} className='row'>
                <div className='row'>
                  <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                    <div className='yk-form-field'>
                      <label className='col-form-label form-field-title'>
                        Commission Name
                      </label>
                      <input
                        type='text'
                        className='form-control yk-form-field-input'
                        id='name'
                        placeholder='Enter Commission Name'
                        {...register('name', {
                          ...ValidationRequired,
                          ...ValidationMaxLength30,
                          ...ValidationCommissionName,
                          onChange: (e) => onChangeHandler(e),
                        })}
                      />
                      {errors.name && (
                        <div className='invalid-feedback'>
                          {errors.name.message}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className='col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12'>
                    <div className='yk-form-field '>
                      <label className='col-form-label form-field-title'>
                        Percentage
                      </label>
                      <input
                        type='text'
                        className='form-control yk-form-field-input'
                        placeholder='Percentage'
                        {...register('profitRatio', {
                          ...ValidationRequired,
                          ...ValidationOnlyUptoTwoDecimals,
                          ...ValidationMaxLength6,
                          onChange: (e) => onChangeHandler(e),
                        })}
                      />
                      {errors.profitRatio && (
                        <div className='invalid-feedback'>
                          {errors.profitRatio.message}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className='col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12'>
                    <div className='yk-form-field '>
                      <label className='col-form-label form-field-title'>
                        Minimum Fee
                      </label>
                      <input
                        type='text'
                        className='form-control yk-form-field-input'
                        id='minimum-fee'
                        placeholder='Enter Minimum Fee'
                        {...register('minimumFee', {
                          ...ValidationMaxLength5,
                          ...ValidationOnlyNumbers,
                          onChange: (e) => onChangeHandler(e),
                        })}
                        disabled={!addCommissionPayload?.flatFee ? false : true}
                      />
                      {errors.minimumFee && (
                        <div className='invalid-feedback'>
                          {errors.minimumFee.message}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className='col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12'>
                    <div className='yk-form-field mb-5'>
                      <label className='col-form-label form-field-title'>
                        Flat Fee
                      </label>
                      <input
                        type='text'
                        className='form-control yk-form-field-input'
                        id='flat-fee'
                        placeholder='Enter Flat Fee'
                        {...register('flatFee', {
                          ...ValidationMaxLength5,
                          ...ValidationOnlyNumbers,
                          onChange: (e) => onChangeHandler(e),
                        })}
                        disabled={
                          !addCommissionPayload?.minimumFee ? false : true
                        }
                      />
                      {errors.flatFee && (
                        <div className='invalid-feedback'>
                          {errors.flatFee.message}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                  <div className='YKEE-submitDicard'>
                    <div className='class="YKEE-twoBTNS d-flex justify-content-between'>
                      <button
                        type='button'
                        className='btn modal-btn-cancel YKEE-noOverlay'
                        data-bs-dismiss='modal'
                        onClick={() => setShowAddCommissionModal(false)}
                      >
                        Cancel
                      </button>

                      <button
                        type='submit'
                        className='btn modal-btn-submit YKEE-Default w-auto'
                      >
                        {`${isEdit ? 'Update Commission' : 'Add Commission'}`}
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </Modal>
        {
          <ConfirmPopup
            showPopup={showConfirmModal}
            handleClose={handleClose}
            title={isEdit ? 'Update Existing Commission' : 'Add New Commission'}
            message={
              isEdit
                ? EDIT_COMMISSION_CONFIRM_MESSAGE
                : NEW_COMMISSION_CONFIRM_MESSAGE
            }
            handleSave={onConfirmClick}
          />
        }
        <Notification
          showSuccessPopup={showSuccessPopup}
          handleSnackbarClose={handleSnackbarClose}
          severityType='success'
          message={message}
          className='yk-shoesize-alert-wrapper'
        />
        <Notification
          showSuccessPopup={showWarningPopup}
          handleSnackbarClose={handleSnackbarClose}
          severityType='warning'
          message={warningMessages}
          className='yk-shoesize-alert-wrapper'
        />
      </div>
    </>
  );
};
export default AddCommissionModal;
