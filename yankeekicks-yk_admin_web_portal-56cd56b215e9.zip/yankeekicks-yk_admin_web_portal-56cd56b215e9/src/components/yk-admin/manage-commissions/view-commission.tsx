import React, { useEffect, useState, useMemo } from 'react';
import type { NextPage } from 'next';
import { useRouter } from 'next/router';
import Breadcrumbs from 'components/common/breadcrumbs';
import Image from 'next/image';
import SearchComp from 'components/common/search';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import filterIcon from 'assets/images/filter-icon.png';
import { useCubeQuery } from '@cubejs-client/react';
import { getPaginationViewCommissions, getViewCommissions } from 'middleware/cubejs-wrapper/yk-super-admin-cubejs-query';
import VirtualTable from 'components/common/table';
import Sortings from 'components/common/sortings';
import ProductFilters from 'components/common/filters/product-filter';
import AddCommissionModal from './add-commission';
import { getBasePath } from 'utils/util';
import locationManagement from 'assets/images/consignee/location-Management.svg';
import Pagination from 'components/common/pagination';

const ViewCommission: NextPage = () => {
  const [isEdit, setIsEdit] = useState<any>(false);
  const router = useRouter();
  const [commissionsData, setCommissionsData] = useState<any>([]);
  const [commissionsOffset, setCommissionsOffset] = useState(0);
  const [userInput, setUserInput] = useState<any>('');
  const [selectedSort, setSelectedSort] = useState('percentageLow');
  const [showFilters, setShowFilters] = useState(false);
  const [filterInput, setFilterInput] = useState<any>({});
  const [showAddCommissionModal, setShowAddCommissionModal] =
    useState<any>(false);
  const [editCommissionData, setEditCommissionData] = useState<any>([]);
  const [selectedCommissionNames, setSelectedCommissionNames] = useState<any>(
    []
  );
  const [reloadData, setReloadData] = React.useState<any>(false);
  const [clearDisable, setClearDisable] = useState(true);
  const [countForPagination, setCountForPagination] = useState(0);
  const [searchOffset, setSearchOffset] = useState<any>(0);
  const limitForQuery = 10;
  const itemsPerPage = 10;

  const columns = useMemo(
    () => [
      {
        title: 'Name',
        value: 'ConsigneeType.name',
      },
      {
        title: 'Percentage',
        value: 'ConsigneeType.profitRatio',
        suffix: '%',
        nullValue: true,
      },
      {
        title: 'Minimum Fee',
        value: 'ConsigneeType.minimumFee',
        prefix: '$',
        methodToApply: 'toFix',
        nullValue: true,
      },
      {
        title: 'Flat Fee',
        value: 'ConsigneeType.flatFee',
        prefix: '$',
        methodToApply: 'toFix',
        nullValue: true,
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          viewButtonHandler(data);
        },
        value: 'Edit',
      },
    ],
    []
  );

  const viewButtonHandler = (data: any) => {
    setShowAddCommissionModal(true);
    setEditCommissionData(data);
    setIsEdit(true);
  };

  const commissionDetailsByIdQuery: any = getViewCommissions(
    userInput,
    filterInput,
    selectedSort,
    commissionsOffset,
    limitForQuery
  );

  const {
    resultSet: commissionDetailsResultSet,
    isLoading: commissionDetailsIsLoading,
    error: commissionDetailsError,
  }: any = useCubeQuery(commissionDetailsByIdQuery, { subscribe: reloadData });


  const paginationViewCommissions: any =
  getPaginationViewCommissions(
    userInput,
    filterInput,
    selectedSort,
  );
const {
  resultSet: paginationViewCommissionsQueryResultSet,
  isLoading: paginationViewCommissionsQueryIsLoading,
  error: paginationViewCommissionsQueryError,
}: any = useCubeQuery(paginationViewCommissions);

  useEffect(() => {
    const data = commissionDetailsResultSet?.loadResponses[0]?.data;
    if (data) {
      setCommissionsData(data);
    } else {
      setCommissionsData([]);
    }

    const paginationCountdata =
    paginationViewCommissionsQueryResultSet?.loadResponses[0]?.data[0]?.['ConsigneeType.count'];
  if (paginationCountdata) {
    let countData = +paginationCountdata || 0;
    setCountForPagination(countData);
  } else {
    setCountForPagination(0);
  }

  }, [commissionDetailsResultSet, paginationViewCommissionsQueryResultSet]);

  const headers = {
    title: 'Manage Commission',
    titleImage: locationManagement,
    subTitle: 'View Commissions',
    onClick: () => {
      router?.push(`${getBasePath('manage-commissions')}`);
    },
  };

  const onChangeHandler = (event: any) => {
    setUserInput(event.target.value);
    setCommissionsOffset(0);
  };

  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
  };

  const AddCommission = () => {
    setEditCommissionData([]);
    setShowAddCommissionModal(true);
    setIsEdit(false);
  };

  const onCommissionNameChange = (event: any) => {
    if (selectedCommissionNames.includes(event?.target?.name)) {
      let tempOption = [];
      tempOption = selectedCommissionNames.filter(
        (data: any) => data !== event?.target?.name
      );
      setSelectedCommissionNames(tempOption);
      if (tempOption.length > 0) {
        setClearDisable(false);
      }
    } else {
      setSelectedCommissionNames([
        ...selectedCommissionNames,
        event?.target?.name,
      ]);
      setClearDisable(false);
    }
  };
  const onApplyFilters = () => {
    const filterPayload = {
      name: selectedCommissionNames,
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setShowFilters(false);
    setCommissionsOffset(0);
  };
  const onClearFilters = () => {
    setShowFilters(false);
    setSelectedCommissionNames([]);
    setFilterInput({});
    setClearDisable(true);
  };

  const handleModalClose = (isRefresh: boolean = false) => {
    setReloadData(isRefresh);
    setShowAddCommissionModal(false);
    setTimeout(() => {
      setReloadData(false);
    }, 500);
  };

  return (
    <>
      <div className='row m-auto YKEE-additional'>
        <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
          <div className='YKEE-breadCrumb d-flex justify-content-between'>
            <Breadcrumbs data={headers} />
          </div>
        </div>
        <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
          <div className='row'>
            <div className='col-md-10'>
              <h2 className='YKEE-headlines'>Commissions</h2>
              <p className='YKEE-overviews'>Existing commission details</p>
            </div>
            <div className='col-md-2 clearfix'>
              <div className='YKEE-submitDicard m-0 float-md-end'>
                <div className='YKEE-twoBTNS'>
                  <button className='YKEE-Default' onClick={AddCommission}>
                    Add Commission
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* card sections */}

        <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 YKEE-columns'>
          <div className='card YKEE-cardCover'>
            <div className='YKEE-coverArea'>
              <div className='row'>
                <div className='YKEE-headerStrip pb-3'>
                  <h4 className='YKEE-personalInfo'>All Commissions</h4>
                </div>
                <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 YKEE-columns YKEE-noTableBG'>
                  <div className='search-btn-wrapper pb-2'>
                    <div className='row'>
                      <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 YKEE-columns'>
                        <div className='YKCH-searchingData'>
                          <SearchComp
                            optionType='change'
                            placeholder='Search'
                            onChangeHandler={onChangeHandler}
                          />
                        </div>
                      </div>
                      <div className='col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12 YKEE-columns'>
                        <div className='consignment-btn-wrapper'>
                          <div className='filter-btn-wrapper'>
                            <ClickAwayListener
                              onClickAway={() => {
                                setShowFilters(false);
                              }}
                            >
                              <div>
                                <button
                                  className='btn filter-btn '
                                  onClick={() => setShowFilters(!showFilters)}
                                >
                                  <Image
                                    src={filterIcon}
                                    alt='filter-btn-icon'
                                    className='filter-btn-icon img-fluid'
                                  />
                                  <span className='filter-btn-text yk-badge-h15'>
                                    Filter
                                  </span>
                                </button>
                                {showFilters && (
                                  <ProductFilters
                                    itemKey='viewCommission'
                                    data={commissionsData}
                                    onCommissionNameChange={
                                      onCommissionNameChange
                                    }
                                    selectedCommissionNames={
                                      selectedCommissionNames
                                    }
                                    onApplyClick={onApplyFilters}
                                    onClearFilters={onClearFilters}
                                    clearDisable={clearDisable}
                                  />
                                )}
                              </div>
                            </ClickAwayListener>
                          </div>
                          <Sortings
                            itemKey='viewCommission'
                            handleChange={sortHandler}
                            defaultSelectedValue={selectedSort}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <VirtualTable
                    loading={commissionDetailsIsLoading}
                    error={commissionDetailsError}
                    headers={columns}
                    rowData={commissionsData}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        {
          <AddCommissionModal
            showAddCommissionModal={showAddCommissionModal}
            setShowAddCommissionModal={setShowAddCommissionModal}
            handleModalClose={handleModalClose}
            editCommissionData={editCommissionData}
            isEdit={isEdit}
          />
        }
          {countForPagination > 0 && (
          <div className='center-pagination'>
            <Pagination
              lengthOfData={countForPagination}
              itemsPerPage={itemsPerPage}
              currentOffset={commissionsOffset}
              setOffset={setCommissionsOffset}
            />
          </div>
        )}
      </div>
    </>
  );
};
export default ViewCommission;
