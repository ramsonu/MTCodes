import React, { useState } from 'react';
import type, { NextPage } from 'next';
import Image from 'next/image';
import Modal from '@mui/material/Modal';
import {
  putCommissionChangeRequest,
  updateConsignmentPayout,
} from 'services/consignor';
import arrowIcon from 'assets/images/menu-icons/green-right-arrow.svg';
import ConfirmPopup from 'components/common/confirm-popup';
import Notification from 'components/common/notification';
import {
  CHANGE_COMMISSION_SUCCESS,
  CONFIRM_MESSAGE_COMMISSION_CHANGE,
} from '../constants';

interface Props {
  viewChangeRequestModal?: any;
  setViewChangeRequestModal?: any;
  requestData?: any;
  handleModalClose?: any;
}

const ChangeRequestModal: NextPage<Props> = ({
  viewChangeRequestModal,
  setViewChangeRequestModal,
  requestData,
  handleModalClose,
}) => {
  const [showInput, setShowInput] = useState(false);
  const [rejectComment, setRejectComment] = useState('');
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);
  const [showWarningPopup, setShowWarningPopup] = useState(false);
  const [warningMessage, setWarningMessage] = useState('');

  const onButtonClick = async (type: any) => {
    let payload = {};
    if (type === 'reject') {
      setShowInput(true);
      if (rejectComment !== '') {
        payload = {
          comment: rejectComment,
          commissionId: requestData['Managecomission.id'],
          isApproved: false,
        };
        await putCommissionChangeRequest(payload).then((response) => {
          if (response?.status === 201 || response?.status === 200) {
            setShowSuccessPopup(true);
            handleModalClose(true);
          } else {
            setShowWarningPopup(true);
            setWarningMessage(response?.data?.message || response?.data?.error);
            handleModalClose();
          }
        });
      }
    } else {
      setShowConfirmModal(true);
      setViewChangeRequestModal(false);
    }
  };
  const handleClose = () => {
    setShowConfirmModal(false);
  };
  const handleSave = async () => {
    const payload = {
      comment: rejectComment,
      commissionId: requestData['Managecomission.id'],
      isApproved: true,
    };
    let result: any = [];
    try {
      result = await putCommissionChangeRequest(payload);
      if (result?.status === 201 || result?.status === 200) {
        const payout: any = await updateConsignmentPayout({
          consigneeId: requestData['Managecomission.consigneeD'],
          newCommission: {
            profitRatio: requestData['Managecomission.newCommission'],
          },
        });
        if (result?.status === 201 || result?.status === 200) {
          setShowConfirmModal(false);
          setShowSuccessPopup(true);
          handleModalClose(true);
        } else {
          setShowWarningPopup(true);
          setWarningMessage(
            result?.response?.data?.message || result?.response?.data?.error
          );
          setShowConfirmModal(false);
          handleModalClose();
        }
      } else {
        setShowWarningPopup(true);
        setWarningMessage(
          result?.response?.data?.message || result?.response?.data?.error
        );
        setShowConfirmModal(false);
      }
    } catch (e: any) {
      console.log('e', e);
      setShowWarningPopup(true);
      setWarningMessage(
        result?.response?.data?.message || result?.response?.data?.error
      );
      setShowConfirmModal(false);
      handleModalClose();
    }
  };

  const handleSnackbarClose = () => {
    setShowSuccessPopup(false);
    setShowWarningPopup(false);
  };

  const message = (
    <h3 className='notification-heading'>{CHANGE_COMMISSION_SUCCESS}</h3>
  );

  const warningMessages = (
    <h3 className='notification-heading'>{warningMessage}</h3>
  );
  return (
    <>
      <div className='app-wrapper'>
        <Modal
          open={viewChangeRequestModal}
          onClose={handleModalClose}
          className='yk-change-request-modal-wrapper'
          aria-labelledby='modal-modal-title'
          aria-describedby='modal-modal-description'
        >
          <div className='app-wrapper change-request-modal-wrapper'>
            <div className='yk-modal-body'>
              <div className='modal-heading-wrapper'>
                <h3 className='modal-title yk-badge-h11'>Change Request</h3>
                <p className='modal-sub-title yk-badge-h16'>
                  Details of change request
                </p>
              </div>
              <div className='yk-form-field'>
                <div className='row'>
                  <div className='col-lg-6 col-md-6'>
                    <div className='form-field-title yk-badge-h14'>
                      Requested By
                    </div>
                  </div>
                  <div className='col-lg-6 col-md-6'>
                    <div className='form-field-input'>
                      {requestData['Managecomission.requestedByName']
                        ? requestData['Managecomission.requestedByName']
                        : '--'}
                      <div className='field-value yk-badge-h8'>
                        {requestData['Managecomission.userId']
                          ? requestData['Managecomission.userId']
                          : '--'}
                        <span className='dot'></span>
                        <span className='name-value yk-badge-h8'>
                          {requestData['Managecomission.reqUserEmail']
                            ? requestData['Managecomission.reqUserEmail']
                            : '--'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='yk-form-field'>
                <div className='row'>
                  <div className='col-lg-6 col-md-6'>
                    <div className='form-field-title yk-badge-h14'>
                      Consignor
                    </div>
                  </div>
                  <div className='col-lg-6 col-md-6'>
                    <div className='form-field-input'>
                      {requestData['Managecomission.userName']
                        ? requestData['Managecomission.userName']
                        : '--'}
                      <div className='field-value yk-badge-h8'>
                        {requestData['Managecomission.UserEmail']
                          ? requestData['Managecomission.UserEmail']
                          : '--'}
                        <span className='dot'></span>
                        <span className='name-value yk-badge-h8'>
                          {requestData['Managecomission.phoneNumber']
                            ? `+${requestData['Managecomission.phoneNumber']}`
                            : '--'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='yk-form-field'>
                <div className='row'>
                  <div className='col-lg-6 col-md-6'>
                    <div className='form-field-title yk-badge-h14'>
                      Commission
                    </div>
                  </div>

                  <div className='col-lg-6 col-md-6'>
                    <div className='yk-form-field yk-commission-field'>
                      <div className='field-value yk-badge-h8'>
                        Current Commision
                        <div className='form-field-input'>
                          {`${requestData['Managecomission.currentCommission']}%`}
                        </div>
                      </div>
                      <div className='arrow-img-wrapper'>
                        <Image
                          src={arrowIcon}
                          alt='arrow-icon'
                          className='img-fluid'
                        />
                      </div>
                      <div className='field-value yk-badge-h8'>
                        New Commision
                        <div className='form-field-input'>{`${requestData['Managecomission.newCommission']}%`}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {requestData['Managecomission.Status'] === 'Pending' && (
                <>
                  {showInput && (
                    <div className='yk-form-field'>
                      <label className='reject-title yk-badge-h16'>
                        Reject reason
                      </label>
                      <textarea
                        className='form-control yk-form-field-input'
                        id='recipient-name'
                        placeholder='Type here..'
                        onChange={(e: any) => setRejectComment(e.target.value)}
                        required
                      />
                    </div>
                  )}
                  <div className='yk-modal-btn-wrapper'>
                    {showInput === false ? (
                      <button
                        type='button'
                        className='btn modal-btn-reject'
                        data-bs-dismiss='modal'
                        onClick={() => onButtonClick('reject')}
                      >
                        Reject
                      </button>
                    ) : (
                      <button
                        type='button'
                        className='btn modal-btn-cancel'
                        data-bs-dismiss='modal'
                        onClick={() => setShowInput(false)}
                      >
                        Cancel
                      </button>
                    )}
                    {showInput === false ? (
                      <button
                        type='button'
                        className='btn modal-btn-submit'
                        onClick={() => onButtonClick('approve')}
                      >
                        Approve
                      </button>
                    ) : (
                      <button
                        type='button'
                        className='btn modal-btn-submit'
                        onClick={() => onButtonClick('reject')}
                        disabled={rejectComment !== '' ? false : true}
                      >
                        Reject
                      </button>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
        </Modal>
        {
          <ConfirmPopup
            showPopup={showConfirmModal}
            handleClose={handleClose}
            title={'Change Consignor Commission'}
            message={CONFIRM_MESSAGE_COMMISSION_CHANGE}
            handleSave={handleSave}
          />
        }
        <Notification
          showSuccessPopup={showSuccessPopup}
          handleSnackbarClose={handleSnackbarClose}
          severityType='success'
          message={message}
          className='yk-shoesize-alert-wrapper'
        />
        <Notification
          showSuccessPopup={showWarningPopup}
          handleSnackbarClose={handleSnackbarClose}
          severityType='warning'
          message={warningMessages}
          className='yk-shoesize-alert-wrapper'
        />
      </div>
    </>
  );
};
export default ChangeRequestModal;
