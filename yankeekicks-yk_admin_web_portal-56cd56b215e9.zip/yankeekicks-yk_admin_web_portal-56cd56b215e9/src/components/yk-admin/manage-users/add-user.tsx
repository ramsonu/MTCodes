import { useRouter } from 'next/router';
import React, { useEffect, useState } from 'react';
import Breadcrumbs from 'components/common/breadcrumbs';
import { getBasePath } from 'utils/util';
import { useForm } from 'react-hook-form';
import {
  getConsignorDetails,
  getUserRoles,
  putAddUserRequest,
  updateConsignorStatus,
} from 'services/consignor';
import ConfirmPopup from 'components/common/confirm-popup';
import Notification from 'components/common/notification';
import {
  CONFIRM_MESSAGE_ACTIVE_USER,
  CONFIRM_MESSAGE_DISABLE_USER,
  NEW_ADDUSER_CONFIRM_MESSAGE,
  NEW_ADDUSER_SUCCESS,
  UPDATE_USER_CONFIRM_MESSAGE,
} from '../constants';
import { useCubeQuery } from '@cubejs-client/react';
import { getLocationsListForConsignmentReviewPopup } from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import { USER_UPDATE_SUCCESS } from 'utils/constants';
import { DISABLE_LOADER, ENABLE_LOADER } from 'actions/loader';
import { useDispatch } from 'react-redux';
import ManageUserIcon from 'assets/images/menu-icons/manage-user-default.svg';
import { ValidationEmail, ValidationRequired } from 'utils/validators';

interface initialStateInterface {
  email: string;
  roles: string;
  locations: string;
}
const AddUser = () => {
  const initialState: initialStateInterface = {
    email: '',
    roles: '',
    locations: '',
  };
  let router = useRouter();
  const dispatch = useDispatch();
  const { userId } = router.query;
  const isUSerEditFlag = !!userId;
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showDisableConfirmModal, setShowDisableConfirmModal] = useState(false);
  const [locations, setLocations] = useState<any>([]);
  const [userRoles, setUserRoles] = useState<any>([]);
  const [userData, setUserData] = useState<any>([]);
  const [selectedLocations, setSelectedLocations] = useState<any>([]);
  const [selectedRoles, setSelectedRoles] = useState<any>([]);
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [notificationMessage, setNotificationMessage] = useState<string>('');
  const [severityType, setSeverityType] = useState<string>('');
  const [addUserData, setAddUserData] = useState<any>(initialState);
  const [disableButton, setDisableButton] = useState(false);
  const [locationErrorMsg, setLocationErrorMsg] = useState('');
  const USER_DETAILS_SUCCESS = userId
    ? 'User details updated successfully'
    : 'User created successfully';
  const {
    handleSubmit,
    watch,
    setValue,
    register,
    formState: { errors },
  } = useForm<initialStateInterface>();

  const consigneeRole = 'CONSIGNEE_SELLER';

  const getLocationsListQuery: any =
    getLocationsListForConsignmentReviewPopup();
  const {
    resultSet: locationList,
    isLoading: getLocationsListIsLoading,
    error: getLocationsListError,
  }: any = useCubeQuery(getLocationsListQuery);

  useEffect(() => {
    loadUserDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const loadUserDetails = async () => {
    let tempUserRoles = await getUserRoles();
    setUserRoles(tempUserRoles?.data);
    if (!!userId) {
      let getConsignorsData = await getConsignorDetails(userId);
      setUserData(getConsignorsData?.data);
      const role: any = getConsignorsData?.data?.roles?.[0].role;
      setAddUserData({
        email: getConsignorsData?.data?.email,
        roles: [role],
      });

      const tempLocations: any = [];
      getConsignorsData?.data?.roles.forEach((role: any) => {
        setSelectedRoles([role?.roleType]);
        setSelectedLocations([
          ...selectedLocations,
          { name: role.location, id: role.locationId },
        ]);
        tempLocations.push(role.location);
      });
      setLocations(tempLocations);
      setValue('email', getConsignorsData?.data?.email);
      setValue('roles', getConsignorsData?.data?.roles);
      setValue('locations', getConsignorsData?.data?.location);
    }
  };

  const headers = {
    title: 'User Management',
    titleImage: ManageUserIcon,
    subTitle: isUSerEditFlag ? 'User Details' : 'Add User',
    onClick: () => {
      router?.push(`${getBasePath('manage-users')}`);
    },
  };

  const handleOnChange = (e: any) => {
    if (e.target.name === 'locations') {
      if (locations.indexOf(e.target.value) < 0) {
        const dataset = e.target.options[e.target.selectedIndex].dataset;
        setSelectedLocations([{ name: e.target.value, id: dataset.locid }]);
        setLocations([e.target.value]);
      }
    } else setAddUserData({ ...addUserData, [e.target.name]: e.target.value });
    setDisableButton(true);
  };
  const handleRole = (e: any) => {
    setSelectedRoles([{ id: e.target.dataset.roleid, role: e.target.value }]);
    setAddUserData({ ...addUserData, roles: e.target.value });
    setDisableButton(true);
  };

  const onRemoveLocation = (index: any) => {
    if (locations?.length > 1) {
      setLocations(
        locations.filter((location: any, ind: any) => ind !== index)
      );
    } else setLocations([]);
  };

  const onSubmit = () => {
    setLocationErrorMsg('');
    if (selectedLocations.length > 0) setShowConfirmModal(true);
    else {
      setLocationErrorMsg('Please fill this field');
    }
  };
  const onConfirmClick = async () => {
    dispatch({ type: ENABLE_LOADER });
    let payload = {
      email: addUserData?.email,
      // id: !!userId ? userId : 0,
      locations: selectedLocations,
      roles: selectedRoles,
    };
    let result: any = [];
    try {
      result = await putAddUserRequest(payload);

      if (result?.status === 201 || result?.status === 200) {
        dispatch({ type: DISABLE_LOADER });
        setIsVisibleMessage(true);
        setSeverityType('success');
        setNotificationMessage(result?.data?.message || USER_DETAILS_SUCCESS);
        setShowConfirmModal(false);
        setTimeout(() => {
          router.push(`${getBasePath('manage-users')}`);
        }, 1500);
      } else {
        dispatch({ type: DISABLE_LOADER });
        setIsVisibleMessage(true);
        setSeverityType('warning');
        setNotificationMessage(
          result?.response?.data?.message || result?.response?.data?.error
        );

        setShowConfirmModal(false);
      }
    } catch (e: any) {
      dispatch({ type: DISABLE_LOADER });
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setNotificationMessage(
        e?.response?.data?.message || e?.response?.data?.error
      );
      setShowConfirmModal(false);
    }
  };

  const handleClose = () => {
    setShowConfirmModal(false);
  };

  const handleSnackbarClose = () => {
    setIsVisibleMessage(false);
  };

  const onCancelClick = () => {
    if (isUSerEditFlag) router.push(`${getBasePath(`manage-users/${userId}`)}`);
    else router?.push(`${getBasePath('manage-users')}`);
  };

  const enableDisableUser = async () => {
    try {
      dispatch({ type: ENABLE_LOADER });
      let handleCongnorAction = await updateConsignorStatus(userData);
      if (handleCongnorAction.status == 200) {
        setIsVisibleMessage(true);
        setSeverityType('success');
        setNotificationMessage(USER_UPDATE_SUCCESS);
        setTimeout(() => {
          router.push(`${getBasePath('manage-users')}`);
        }, 2000);
      } else {
        dispatch({ type: DISABLE_LOADER });
        setIsVisibleMessage(true);
        setSeverityType('warning');
        setNotificationMessage(handleCongnorAction?.data?.message);
      }
    } catch (e: any) {
      dispatch({ type: DISABLE_LOADER });
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setNotificationMessage(e?.response?.data?.message);
    }
  };

  return (
    <div className='row YKEE-additional'>
      {/* breadCrumb */}
      <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
        <Breadcrumbs data={headers} />
      </div>

      <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
        <div className='d-flex justify-content-between'>
          <h2 className='YKEE-headlines pb-2'>
            {isUSerEditFlag ? 'Edit User' : 'Add User'}{' '}
          </h2>
          <button
            onClick={(e) => setShowDisableConfirmModal(true)}
            type='button'
            className='btn ykch-disableButton'
          >
            {userData?.active ? 'Disable User' : 'Activate User'}
          </button>
        </div>
        {isUSerEditFlag && (
          <div className='right-tool-info'>
            <ConfirmPopup
              showPopup={showDisableConfirmModal}
              handleClose={(e: any) => setShowDisableConfirmModal(false)}
              title={userData?.active ? 'Disable User' : 'Activate User'}
              message={
                userData?.active
                  ? CONFIRM_MESSAGE_DISABLE_USER
                  : CONFIRM_MESSAGE_ACTIVE_USER
              }
              handleSave={enableDisableUser}
            />
          </div>
        )}
      </div>

      {/* card sections */}
      <form
        onSubmit={handleSubmit(onSubmit)}
        className='row add-user-form m-auto p-0'
      >
        <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 YKEE-columns'>
          <div className='card YKEE-cardCover pt-2'>
            <div className='YKEE-coverArea'>
              <div className='row'>
                <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea pb-4'>
                    <label className='YKEE-lable'>Employee Email</label>
                    <input
                      type='text'
                      placeholder='Enter Employee Email'
                      className='form-control YKEE-field'
                      {...register('email', {
                        ...ValidationEmail,
                      })}
                      onChange={handleOnChange}
                      value={addUserData?.email}
                    />
                    {errors.email && (
                      <div className='invalid-feedback'>
                        {errors.email.message}
                      </div>
                    )}
                  </div>
                </div>{' '}
                <div className='YKEE-headerStrip'>
                  <h4 className='YKEE-personalInfo'>Roles</h4>
                </div>
                <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 YKEE-columns clearfix'>
                  <div className='row radio-button-list'>
                    {Object?.values(userRoles)?.map(
                      (role: any, index: number) => {
                        return (
                          role.role != consigneeRole && (
                            <div
                              key={index}
                              className='col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12 mb-3'
                            >
                              <label htmlFor={role.role} key={role.role}>
                                <input
                                  {...register('roles', {
                                    ...ValidationRequired,
                                    onChange: (e) => handleRole(e),
                                  })}
                                  type='checkbox'
                                  value={role.role}
                                  className='form-check-input'
                                  id={role.role}
                                  data-roleId={role.id}
                                  checked={role.role == selectedRoles[0]?.role}
                                />
                                {role.role.replace('_', ' ')}
                              </label>
                            </div>
                          )
                        );
                      }
                    )}
                  </div>
                </div>
                {errors?.roles && (
                  <div className='invalid-feedback'>
                    <p>{errors?.roles?.message}</p>
                  </div>
                )}
              </div>
            </div>

            <div className='YKEE-coverArea YKEE-topAreas'>
              <div className='row'>
                {' '}
                <div className='YKEE-headerStrip'>
                  <h4 className='YKEE-personalInfo'>Location</h4>
                </div>
                <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <div className=''>
                      <select
                        className='form-select YKEE-field YKEE-arrowDownns'
                        value={locations}
                        {...register('locations')}
                        onChange={handleOnChange}
                      >
                        <option>Select Location</option>
                        {locationList?.loadResponses[0]?.data?.map(
                          (loc: any, index: number) => (
                            <option
                              key={index}
                              value={loc?.['Locations.name']}
                              data-locId={loc?.['Locations.locationID_D']}
                              selected={locations.includes(
                                loc?.['Locations.name']
                              )}
                            >
                              {loc?.['Locations.name']}
                            </option>
                          )
                        )}
                      </select>
                    </div>
                    {locationErrorMsg && (
                      <div className='invalid-feedback'>
                        <p>{locationErrorMsg}</p>
                      </div>
                    )}
                  </div>
                </div>
                <div className='col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-category d-flex'>
                    {locations?.map((location: any, index: number) => {
                      return (
                        <span className='YKEE-Name' key={index}>
                          {location}
                          <button
                            type='button'
                            className='btn-close YKEE-close'
                            onClick={() => onRemoveLocation(index)}
                          ></button>
                        </span>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
            <div className='YKEE-submitDicard'>
              <div className='YKEE-twoBTNS'>
                <button
                  className={`btn YKEE-noOverlay`}
                  type='button'
                  onClick={onCancelClick}
                >
                  Cancel
                </button>

                <button
                  className={`btn YKEE-Default ${
                    !disableButton ? 'disabled' : ''
                  }`}
                >
                  {isUSerEditFlag ? 'Update' : 'Add User'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </form>
      {
        <ConfirmPopup
          showPopup={showConfirmModal}
          handleClose={handleClose}
          title={isUSerEditFlag ? 'Update User Details' : 'Add User'}
          message={
            isUSerEditFlag
              ? UPDATE_USER_CONFIRM_MESSAGE
              : NEW_ADDUSER_CONFIRM_MESSAGE
          }
          handleSave={onConfirmClick}
        />
      }

      <Notification
        showSuccessPopup={isVisibleMessage}
        handleSnackbarClose={handleSnackbarClose}
        severityType={severityType}
        message={notificationMessage}
        className='yk-shoesize-alert-wrapper YKCH-TostifyMsg'
      />
    </div>
  );
};
export default AddUser;
