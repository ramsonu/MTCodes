import React, { useState, useMemo, useEffect } from 'react';
import type { NextPage } from 'next';
import Image from 'next/image';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import SearchComp from 'components/common/search';
import Sortings from 'components/common/sortings';
import ProductFilters from 'components/common/filters/product-filter';
import VirtualTable from 'components/common/table';
import filterIcon from 'assets/images/filter-icon.png';
import {
  getUserList,
  getUserListPagination,
} from 'middleware/cubejs-wrapper/yk-super-admin-cubejs-query';
import { useCubeQuery } from '@cubejs-client/react';
import Pagination from 'components/common/pagination';
import { useRouter } from 'next/router';
import { YK_ADMIN_INNER_PATH } from '../constants';
import ExportsTypes from 'components/common/exports-types';
import { getBasePath } from 'utils/util';

const ManageUsers: NextPage = () => {
  const [userInput, setUserInput] = useState('');
  const [searchOffset, setSearchOffset] = useState(0);
  const [selectedSort, setSelectedSort] = useState('usersNewest');
  const [showFilters, setShowFilters] = useState(false);
  const [checked, setChecked] = useState({
    Pending: false,
    Active: false,
    Disabled: false,
  });
  const [clearDisable, setClearDisable] = useState(true);
  const [usersList, setUsersList] = useState([]);
  const [countForPagination, setCountForPagination] = useState(0);
  const [selectedPayoutStatus, setSelectedPayoutStatus] = useState<any>([]);
  const [filterInput, setFilterInput] = useState<any>({});
  const [isPDFExport, setIsPDFExport] = useState(true);
  const pageLimit = 10;
  const router = useRouter();

  const { ADD_USER } = YK_ADMIN_INNER_PATH;
  const queryPayload = {
    userInput,
    selectedSort,
    filterInput,
  };
  const consignmentQuery: any = getUserList(
    filterInput,
    userInput,
    selectedSort,
    pageLimit,
    searchOffset
  );
  const paginationCountForConsignment: any = getUserListPagination(
    filterInput,
    selectedSort,
    userInput
  );

  const exportsUserListQuery: any = getUserList(
    filterInput,
    userInput,
    selectedSort
  );

  const {
    resultSet: consignorListResultSet,
    isLoading: consignmentIsLoading,
    error: consignmentError,
  }: any = useCubeQuery(consignmentQuery);
  const { resultSet: pageCountResultSet }: any = useCubeQuery(
    paginationCountForConsignment
  );
  const { resultSet: exportsResultsSet }: any = useCubeQuery(
    exportsUserListQuery,
    { skip: isPDFExport }
  );

  useEffect(() => {
    const data = consignorListResultSet?.loadResponses[0]?.data;
    if (data) {
      setUsersList(data);
    } else {
      setUsersList([]);
    }
    if (pageCountResultSet) {
      let countData =
        +pageCountResultSet?.loadResponses[0]?.data[0]?.['Manageuser.count'] ||
        0;
      setCountForPagination(countData);
    }
  }, [consignorListResultSet, pageCountResultSet]);

  const onClickPDFExport = () => {
    setIsPDFExport(false);
    setTimeout(() => {
      setIsPDFExport(true);
    }, 100);
  };

  const userInputChangeHandler = (event: any) => {
    setUserInput(event.target.value);
    setSearchOffset(0);
  };

  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
  };

  const addUser = () => {
    router?.push(
      {
        pathname: ADD_USER,
      },
      ADD_USER
    );
  };
  const onStatusChange = (event: any) => {
    setChecked({ ...checked, [event?.target?.name]: event?.target?.checked });
    var updatedList = [...selectedPayoutStatus];
    if (event.target.checked) {
      updatedList = [...selectedPayoutStatus, event.target.name];
    } else {
      updatedList.splice(selectedPayoutStatus.indexOf(event.target.name), 1);
    }
    setSelectedPayoutStatus(updatedList);
    if (updatedList.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  };

  const onApplyClick = () => {
    const filterPayload = {
      status: selectedPayoutStatus,
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setShowFilters(false);
  };
  const onClearFilters = () => {
    setSelectedPayoutStatus([]);
    setChecked({ Pending: false, Active: false, Disabled: false });
    setFilterInput({});
    setShowFilters(false);
    setClearDisable(true);
  };

  const columns = useMemo(
    () => [
      {
        title: '#',
        value: 'Manageuser.employeeId',
        type: 'sno',
      },
      {
        title: 'Employee ID',
        value: 'Manageuser.employeeId',
      },
      {
        title: 'Role',
        value: 'Manageuser.role',
      },
      {
        title: 'Name',
        value: 'Manageuser.userName',
      },
      {
        title: 'Location',
        value: 'Manageuser.location',
      },
      {
        title: 'Status',
        type: 'status',
        value: 'Manageuser.status',
        success: 'ACTIVE',
        pending: 'PENDING',
        danger: 'DISABLED',
      },
      {
        title: 'Actions',
        type: 'button',
        value: 'View',
        onClick: (data: any) => {
          router.push(getBasePath(`manage-users/${data['Manageuser.userId']}`));
        },
      },
    ],
    []
  );

  const exportHeaders = [
    { label: 'Employee ID', key: 'Manageuser.employeeId' },
    { label: 'Role', key: 'Manageuser.role' },
    { label: 'Name', key: 'Manageuser.userName' },
    { label: 'Location', key: 'Manageuser.location' },
    { label: 'Status', key: 'Manageuser.status' },
  ];

  return (
    <div className='app-wrapper w-100 orders-page-wrapper yk-admin-manage-user-page-wrapper'>
      <div className='manage-user-page-inner-wrapper'>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-lg-12 col-md-12 col-sm-12'>
              <div className='heading-wrapper orders-heading-wrapper'>
                <h2 className='heading'>
                  Manage User
                  <span className='count-badge'>{countForPagination}</span>
                </h2>
                <div className='add-user-btn-wrapper'>
                  <button
                    className='add-user-btn muyk-btn-primary-sm'
                    onClick={addUser}
                  >
                    Add User
                  </button>
                </div>
              </div>
            </div>
            <div className='search-btn-wrapper'>
              <div className='row'>
                <div className='col-xl-6 col-lg-4 col-md-12 col-sm-12 col-12'>
                  <div className='search-bar-wrapper yk-search-bar table-filter-search'>
                    <SearchComp
                      onChangeHandler={userInputChangeHandler}
                      userInput={userInput}
                      optionType='no suggestions'
                      placeholder='Search'
                    />
                  </div>
                </div>
                <div className='col-xl-6 col-lg-8 col-md-12 col-sm-12 col-12'>
                  <div className='YKCH-topSSpacSS d-sm-block d-lg-block'>
                    <div className='consignment-btn-wrapper YKCH-noFllexy'>
                      <div className='sort-product-wrapper export-btn me-3'>
                        <ExportsTypes
                          data={
                            (exportsResultsSet?.loadResponses &&
                              exportsResultsSet?.loadResponses[0]?.data) ||
                            []
                          }
                          fileName='users'
                          headers={exportHeaders}
                          queryPayload={queryPayload}
                          onClickPDFExport={onClickPDFExport}
                          isActive={usersList && usersList?.length > 0}
                        />
                      </div>

                      <Sortings
                        itemKey='userSort'
                        handleChange={sortHandler}
                        defaultSelectedValue={selectedSort}
                      />

                      <div className='filter-btn-wrapper'>
                        <ClickAwayListener
                          onClickAway={() => {
                            setShowFilters(false);
                          }}
                        >
                          <div>
                            <button
                              className='btn filter-btn'
                              onClick={() => setShowFilters(!showFilters)}
                            >
                              <Image
                                src={filterIcon}
                                alt='filter-btn-icon'
                                className='filter-btn-icon img-fluid'
                              />
                              <span className='filter-btn-text yk-badge-h15'>
                                Filter
                              </span>
                            </button>

                            {showFilters && (
                              <ProductFilters
                                itemKey='manageUsers'
                                onApplyClick={onApplyClick}
                                onPayoutChange={onStatusChange}
                                checkedValue={checked}
                                onClearFilters={onClearFilters}
                                clearDisable={clearDisable}
                              />
                            )}
                          </div>
                        </ClickAwayListener>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <VirtualTable
            loading={consignmentIsLoading}
            error={consignmentError}
            headers={columns}
            rowData={usersList}
            offSet={searchOffset}
          />
          {countForPagination > 0 && (
            <div className='center-pagination'>
              <Pagination
                lengthOfData={countForPagination}
                itemsPerPage={pageLimit}
                currentOffset={searchOffset}
                setOffset={setSearchOffset}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
export default ManageUsers;
