import React, { useEffect, useState } from 'react';
import type { NextPage } from 'next';
import Image from 'next/image';
import router from 'next/router';
import { Button, Checkbox, Menu, MenuItem } from '@mui/material';
import bannerImg from 'assets/images/request-details-banner.png';
import ManageUserIcon from 'assets/images/menu-icons/manage-user-default.svg';
import { getBasePath } from 'utils/util';
import Notification from 'components/common/notification';
import { getConsignorDetails, updateConsignorStatus } from 'services/consignor';
import DotsThreeVertical from 'assets/images/DotsThreeVertical.svg';
import ConfirmPopup from 'components/common/confirm-popup';
import {
  CONFIRM_MESSAGE_ACTIVE_USER,
  CONFIRM_MESSAGE_DISABLE_USER,
  SUCCESS_MESSAGE_ACTIVE_USER,
  SUCCESS_MESSAGE_DISABLE_USER,
} from '../constants';
import { DISABLE_LOADER, ENABLE_LOADER } from 'actions/loader';
import { useDispatch } from 'react-redux';
import Breadcrumbs from 'components/common/breadcrumbs';
import dummyUserImg from 'assets/images/user.svg';

interface regForm {
  stateId: string;
  passport: string;
  profilePicture: string;
}
const ViewUser: NextPage = () => {
  const dispatch = useDispatch();
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [notificationMessage, setNotificationMessage] = useState<string>('');
  const [severityType, setSeverityType] = useState<string>('');
  const { userId } = router.query;
  const [userData, setUserData] = useState<any>([]);
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [showConfirmModal, setShowConfirmModal] = useState<any>(false);
  const open = Boolean(anchorEl);

  useEffect(() => {
    loadUserDetails();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const loadUserDetails = async () => {
    let getConsignorsData = await getConsignorDetails(userId);
    setUserData(getConsignorsData.data);
  };

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleEdit = () => {
    router.push(`${userId}/edit`);
  };
  const enableDisableUser = async () => {
    try {
      dispatch({ type: ENABLE_LOADER });
      let handleCongnorAction = await updateConsignorStatus(userData);
      if (handleCongnorAction.status == 200) {
        dispatch({ type: DISABLE_LOADER });
        setIsVisibleMessage(true);
        setSeverityType('success');
        setNotificationMessage(
          userData?.active
            ? SUCCESS_MESSAGE_DISABLE_USER
            : SUCCESS_MESSAGE_ACTIVE_USER
        );
        setTimeout(() => {
          router.push(`${getBasePath('manage-users')}`);
        }, 2000);
      } else {
        dispatch({ type: DISABLE_LOADER });
        setIsVisibleMessage(true);
        setSeverityType('warning');
        setNotificationMessage(handleCongnorAction?.data?.message);
      }
    } catch (e: any) {
      dispatch({ type: DISABLE_LOADER });
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setNotificationMessage(e?.response?.data?.message);
    }
  };

  const headers = {
    title: 'Manage User',
    titleImage: ManageUserIcon,
    subTitle: 'User Details',
    onClick: () => {
      router?.push(`${getBasePath('manage-users')}`);
    },
  };
  return (
    <>
      <div className='row m-auto'>
        <Breadcrumbs data={headers} />
      </div>
      <div className='app-wrapper w-100 settings-page-wrapper profile-details-page-wrapper'>
        <div className='page-inner-wrapper'>
          <div className='container-fluid'>
            <div className='user-area-wrapper'>
              <div className='request-details-banner-wrapper setting-details-banner'>
                <div className='yk-request-banner-wrapper'>
                  <Image
                    src={bannerImg}
                    alt=''
                    className='w-100 yk-request-banner img-fluid'
                  />
                </div>
                <div className='profile-info-details'>
                  <div className='row g-0'>
                    <div className='YKCH-newSettingERA d-flex justify-content-start align-items-center'>
                      <div className='user-img-wrapper'>
                        <Image
                          src={dummyUserImg}
                          alt=''
                          className='yk-user-img img-fluid'
                        />
                      </div>
                      <div className='profile-heading-wrapper ykch-leftAlignings'>
                        <h3 className='profile-name'>{userData?.fullName}</h3>
                        <p className='profile-request-text'>
                          {userData?.email} .{userData?.phoneNumber}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className='user-area-inner-wrapper ykch-SettingSpaceEnd'>
                <div className='yk-profile-form'>
                  <div className='d-flex justify-content-between'>
                    <div className='ykch-profileTileHeader'>
                      <span className='ykch-mainTiles'>
                        Employee ID :{' '}
                        <span className='yckh-valueTitle'>
                          #{userData?.employeeId}
                        </span>
                      </span>
                    </div>
                    <div className='YKCH-activeBTTN YKCH-activeOutliness d-flex justify-content-end align-items-center'>
                      <button
                        className={`btn btn-status payment-pending yk-color-badge ${
                          userData?.active ? 'green' : 'red'
                        } yk-greenBTNT`}>
                        {userData?.active ? 'ACTIVE' : 'INACTIVE'}
                      </button>

                      <Button
                        id='basic-button'
                        aria-controls={open ? 'basic-menu' : undefined}
                        aria-haspopup='true'
                        aria-expanded={open ? 'true' : undefined}
                        onClick={handleClick}>
                        <Image
                          src={DotsThreeVertical}
                          alt=''
                          title=''
                          className='mt-1'
                        />
                      </Button>
                      <Menu
                        id='basic-menu'
                        anchorEl={anchorEl}
                        open={open}
                        onClose={handleClose}
                        MenuListProps={{
                          'aria-labelledby': 'basic-button',
                        }}>
                        <MenuItem onClick={() => handleEdit()}>Edit</MenuItem>
                        <MenuItem
                          className={`${
                            userData?.active
                              ? 'text-danger'
                              : 'activeUserDropdown'
                          }`}
                          onClick={() => setShowConfirmModal(true)}>
                          {userData?.active ? ' Disable ' : ' Activate '}
                          User
                        </MenuItem>
                      </Menu>
                    </div>
                  </div>
                  <div className='form-wrapper ykch-formGroupWraper'>
                    <div className='row'>
                      <h3 className='yk-para-p5'>Roles</h3>
                      <div className='col-lg-4'>
                        <h3 className='yk-para-p6'>
                          <Checkbox
                            className='filter-sidebar-checkbox'
                            checked={true}
                            name='consignerRequestEmailFlag'
                          />
                          {userData?.roles?.[0].role}
                        </h3>
                      </div>
                    </div>
                    <h3 className='yk-para-p5'>Locations</h3>
                    <div className='row'>
                      {userData?.roles &&
                        userData?.roles.map((role: any, index: number) => (
                          <div className='col-lg-4' key={index}>
                            <h3 className='yk-para-p6'>
                              <Checkbox
                                className='filter-sidebar-checkbox'
                                checked={true}
                                name='consignerRequestEmailFlag'
                              />
                              {role.location}
                            </h3>
                          </div>
                        ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <ConfirmPopup
        showPopup={showConfirmModal}
        handleClose={(e: any) => setShowConfirmModal(false)}
        title={userData?.active ? 'Disable User' : 'Activate User'}
        message={
          userData?.active
            ? CONFIRM_MESSAGE_DISABLE_USER
            : CONFIRM_MESSAGE_ACTIVE_USER
        }
        handleSave={enableDisableUser}
      />

      <Notification
        showSuccessPopup={isVisibleMessage}
        handleSnackbarClose={() => setIsVisibleMessage(false)}
        severityType={severityType}
        message={notificationMessage}
        className='yk-shoesize-alert-wrapper'
      />
    </>
  );
};
export default ViewUser;
