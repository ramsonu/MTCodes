export const CHANGE_COMMISSION_SUCCESS = 'Commission Changed Successfully';
export const YK_ADMIN_INNER_PATH = {
  YK_ADMIN_PATH: '/yk-admin',
  VIEWCOMMISSIONS_PATH: '/yk-admin/manage-commissions/view-commission',
  ADD_USER: '/yk-admin/manage-users/add-user',
  NEW_NOTIFICATION: '/yk-admin/push-notifications/new-notification',
  ADD_LOCATION_PATH: '/yk-admin/manage-locations/add-location',
};
export const NEW_COMMISSION_SUCCESS = 'New Commission Added Successfully';
export const UPDATE_COMMISSION_SUCCESS = 'Commission Updated Successfully';
export const NEW_COMMISSION_CONFIRM_MESSAGE =
  'New commission will be added, and ready to use immediately.';
export const EDIT_COMMISSION_CONFIRM_MESSAGE =
  'Commission will be changed, and applied immediately.';

export const NEW_LOCATION_SUCCESS = 'New Location Added Successfully';
export const NEW_LOCATION_CONFIRM_MESSAGE =
  'New location will be added, and available to use immediately.';
export const NOTIFICATION_SENT_SUCCESS =
  'Notifications will be sent to all active push notification subscribers.';
export const NOTIFICATION_CONFIRM_CANCEL =
  'Scheduled push notification will be cancelled. Are you sure?';
export const NEW_ADDUSER_SUCCESS = 'User details updated successfully';
export const NEW_ADDUSER_CONFIRM_MESSAGE =
  'Are you sure you want add this user?';
export const UPDATE_USER_CONFIRM_MESSAGE =
  'Are you sure you want update the user details?';

export const UPDATE_LOCATION_SUCCESS = 'Location Updated Successfully';
export const UPDATE_LOCATION_CONFIRM_MESSAGE =
  'New details will be updated, and applied immediately.';

export const CONFIRM_MESSAGE_DISABLE_CONSIGNOR =
  'Consignor will be deactivated along with their inventory. Are you sure want to disable consignor?';
export const CONFIRM_MESSAGE_ACTIVE_CONSIGNOR =
  ' Are you sure want to Activate consignor?';
export const CONFIRM_MESSAGE_DISABLE_USER =
  'User will no longer be able to login to the portal. Are you sure you want to disable user?';
export const CONFIRM_MESSAGE_ACTIVE_USER =
  'Are you sure want to Activate user?';
export const CONFIRM_MESSAGE_CONSIGNEMNT_REVIEW =
  'Shipment will be approved, and confirmation email will be sent to the consignor. Are you sure you want to approve shipment?';
export const CONFIRM_MESSAGE_COMMISSION_CHANGE =
  'New commission will be changed, and applied immediately.';
export const CONFIRM_MESSAGE_PAYOUT =
  'Payout will be confirmed, and confirmation email will be sent to the consignors. Are you sure want to complete payout?';
export const COMPLETE_PAYMENT_SUCCESS = 'Payment completed successfully!';
export const COMPLETE_PAYMENT_FAIL = 'Payment not completed successfully!';
export const SUCCESS_MESSAGE_DISABLE_USER = 'User disabled';
export const SUCCESS_MESSAGE_ACTIVE_USER = 'User activated';
export const COMPLETE_PRINT_LABEL_SUCCESS = 'Labels Downloaded successfully!';
export const COMPLETE_PRINT_LABEL_FAIL = 'Labels not Downloaded successfully!';
export const COMPLETE_INITIATE_TRANSFER_SUCCESS =
  'Transfer initiated successfully!';
export const REJECT_TRANSFER_MSG = 'Transfer Rejected successfully!';
export const ACCEPT_TRANSFER_MSG = 'Transfer Accepted successfully!';
export const TRANSFER_APPROVE_REJECT_STATUS = {
  APPROVED: 'Approved',
  REJECTED: 'Rejected',
};

export const MISSING_PRODUCT_SUCCESS = 'Missing Product Cleared';
export const SOMETHING_WENT_WRONG = 'Something went wrong';
