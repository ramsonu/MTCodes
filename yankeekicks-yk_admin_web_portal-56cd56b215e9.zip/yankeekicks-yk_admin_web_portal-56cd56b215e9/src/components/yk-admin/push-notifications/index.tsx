import React, { useState, useMemo, useEffect } from 'react';
import type { NextPage } from 'next';
import Image from 'next/image';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import SearchComp from 'components/common/search';
import Sortings from 'components/common/sortings';
import ProductFilters from 'components/common/filters/product-filter';
import VirtualTable from 'components/common/table';
import filterIcon from 'assets/images/filter-icon.png';
import {
  getPushNotificationsList,
  getPushNotificationPagination,
} from 'middleware/cubejs-wrapper/yk-super-admin-cubejs-query';
import { useCubeQuery } from '@cubejs-client/react';
import Pagination from 'components/common/pagination';
import { useRouter } from 'next/router';
import { YK_ADMIN_INNER_PATH } from '../constants';
import ExportsTypes from 'components/common/exports-types';
import { getBasePath } from 'utils/util';
import {
  getActivesubscribers,
  getPushNotificationsRequestById,
} from 'services/notifications';

const PushNotifications: NextPage = () => {
  const [userInput, setUserInput] = useState('');
  const [searchOffset, setSearchOffset] = useState(0);
  const [selectedSort, setSelectedSort] = useState('notificationNewest');
  const [showFilters, setShowFilters] = useState(false);
  const [checked, setChecked] = useState({
    Pending: false,
    Done: false,
    Cancelled: false,
  });
  const [activeUsers, setUsers] = useState(0);
  const [clearDisable, setClearDisable] = useState(true);
  const [notificationList, setNotificationList] = useState([]);
  const [countForPagination, setCountForPagination] = useState(0);
  const [selectedPayoutStatus, setSelectedPayoutStatus] = useState<any>([]);
  const [filterInput, setFilterInput] = useState<any>({});
  const [isPDFExport, setIsPDFExport] = useState(true);
  const pageLimit = 10;
  const router = useRouter();

  const getActiveUsers = async () => {
    const getActiveSubscribers = await getActivesubscribers();
    const result: any = getActiveSubscribers?.data?.count;
    setUsers(result);
  };

  const { NEW_NOTIFICATION } = YK_ADMIN_INNER_PATH;
  const queryPayload = {
    userInput,
    selectedSort,
    filterInput,
  };
  const pushNotificationQuery: any = getPushNotificationsList(
    filterInput,
    userInput,
    selectedSort,
    pageLimit,
    searchOffset
  );
  const paginationCountForConsignment: any = getPushNotificationPagination(
    filterInput,
    selectedSort,
    userInput
  );

  const exportsUserListQuery: any = getPushNotificationsList(
    filterInput,
    userInput,
    selectedSort
  );

  const {
    resultSet: notificationListResultSet,
    isLoading: notificationIsLoading,
    error: consignmentError,
  }: any = useCubeQuery(pushNotificationQuery);
  const { resultSet: pageCountResultSet }: any = useCubeQuery(
    paginationCountForConsignment
  );
  const { resultSet: exportsResultsSet }: any = useCubeQuery(
    exportsUserListQuery,
    { skip: isPDFExport }
  );

  useEffect(() => {
    getActiveUsers();
  }, []);

  useEffect(() => {
    const data = notificationListResultSet?.loadResponses[0]?.data;
    if (data) {
      setNotificationList(data);
    } else {
      setNotificationList([]);
    }
    if (pageCountResultSet) {
      let countData =
        +pageCountResultSet?.loadResponses[0]?.data[0]?.[
          'pushNotification.count'
        ] || 0;
      setCountForPagination(countData);
    }
  }, [notificationListResultSet, pageCountResultSet]);

  const userInputChangeHandler = (event: any) => {
    setUserInput(event.target.value);
    setSearchOffset(0);
  };

  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
  };

  const addUser = () => {
    router?.push(
      {
        pathname: NEW_NOTIFICATION,
      },
      NEW_NOTIFICATION
    );
  };
  const onStatusChange = (event: any) => {
    setChecked({ ...checked, [event?.target?.name]: event?.target?.checked });
    var updatedList = [...selectedPayoutStatus];
    if (event.target.checked) {
      updatedList = [...selectedPayoutStatus, event.target.name];
    } else {
      updatedList.splice(selectedPayoutStatus.indexOf(event.target.name), 1);
    }
    setSelectedPayoutStatus(updatedList);
    if (updatedList.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  };

  const onApplyClick = () => {
    const filterPayload = {
      status: selectedPayoutStatus,
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setShowFilters(false);
  };
  const onClearFilters = () => {
    setSelectedPayoutStatus([]);
    setChecked({ Pending: false, Done: false, Cancelled: false });
    setFilterInput({});
    setShowFilters(false);
    setClearDisable(true);
  };

  const columns = useMemo(
    () => [
      {
        title: 'Notification ID',
        value: 'pushNotification.notificationId',
      },
      {
        title: 'Type',
        value: 'pushNotification.notificationType',
      },
      {
        title: 'Status',
        type: 'status',
        value: 'pushNotification.notificationStatus',
        success: 'done',
        pending: 'pending',
        danger: 'cancelled',
        className: 'text-capitalize',
      },
      {
        title: 'Actions',
        type: 'button',
        value: 'View',
        onClick: (data: any) => {
          router.push(
            getBasePath(`push-notifications/${data['pushNotification.id']}`)
          );
        },
      },
    ],
    []
  );

  return (
    <div className='app-wrapper w-100 yk-push-notifications-page-wrapper'>
      <div className='push-notifications-page-inner-wrapper'>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-lg-12 col-md-12 col-sm-12'>
              <div className='heading-wrapper'>
                <h2 className='heading'>Push Notifications</h2>
                <h2 className='yk-activeSubscriber'>
                  {activeUsers && `${activeUsers} Active Subscribers`}
                </h2>
              </div>
              <h5 className='sub-heading'>
                Schedule or Send push notifications to mobile subscribers
              </h5>
            </div>
            <div className='search-btn-wrapper'>
              <div className='row'>
                <div className='col-xl-6 col-lg-4 col-md-12 col-sm-12 col-12'>
                  <div className='search-bar-wrapper yk-search-bar table-filter-search'>
                    <SearchComp
                      onChangeHandler={userInputChangeHandler}
                      userInput={userInput}
                      optionType='no suggestions'
                      placeholder='Search'
                    />
                  </div>
                </div>
                <div className='col-xl-6 col-lg-8 col-md-12 col-sm-12 col-12'>
                  <div className='YKCH-topSSpacSS d-sm-block d-lg-block'>
                    <div className='consignment-btn-wrapper YKCH-noFllexy'>
                      <div className='filter-btn-wrapper'>
                        <ClickAwayListener
                          onClickAway={() => {
                            setShowFilters(false);
                          }}>
                          <div>
                            <button
                              className='btn filter-btn'
                              onClick={() => setShowFilters(!showFilters)}>
                              <Image
                                src={filterIcon}
                                alt='filter-btn-icon'
                                className='filter-btn-icon img-fluid'
                              />
                              <span className='filter-btn-text yk-badge-h15'>
                                Filter
                              </span>
                            </button>

                            {showFilters && (
                              <ProductFilters
                                itemKey='pushNotifications'
                                onApplyClick={onApplyClick}
                                onPayoutChange={onStatusChange}
                                checkedValue={checked}
                                onClearFilters={onClearFilters}
                                clearDisable={clearDisable}
                              />
                            )}
                          </div>
                        </ClickAwayListener>
                      </div>

                      <Sortings
                        itemKey='notificationSort'
                        handleChange={sortHandler}
                        defaultSelectedValue={selectedSort}
                      />

                      <button
                        className='yk-newNotificationsBtn'
                        onClick={addUser}>
                        New Notification
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <VirtualTable
            loading={notificationIsLoading}
            error={consignmentError}
            headers={columns}
            rowData={notificationList}
            offSet={searchOffset}
          />
          {countForPagination > 0 && (
            <div className='center-pagination'>
              <Pagination
                lengthOfData={countForPagination}
                itemsPerPage={pageLimit}
                currentOffset={searchOffset}
                setOffset={setSearchOffset}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
export default PushNotifications;
