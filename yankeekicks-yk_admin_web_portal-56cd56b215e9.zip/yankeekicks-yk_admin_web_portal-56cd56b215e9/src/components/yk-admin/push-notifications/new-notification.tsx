import { useRouter } from 'next/router';
import React, { useEffect, useState } from 'react';
import Breadcrumbs from 'components/common/breadcrumbs';
import {
  getBasePath,
  get24HoursTime,
  getDate,
  getMyEmail,
  getUTCtoLocaleDate,
  convertLocalTimeToUTCTime,
} from 'utils/util';
import { useForm } from 'react-hook-form';
import ConfirmPopup from 'components/common/confirm-popup';
import Notification from 'components/common/notification';
import {
  NOTIFICATION_CONFIRM_CANCEL,
  NOTIFICATION_SENT_SUCCESS,
} from '../constants';
import { DISABLE_LOADER, ENABLE_LOADER } from 'actions/loader';
import { useDispatch } from 'react-redux';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';

import {
  ValidationMaxLength5,
  ValidationRequired,
  getDay,
} from 'utils/validators';
import SchedulePopup from 'components/common/schedule-popup';
import Image from 'next/image';
import mobileImage from 'assets/images/iPhone-bg-img.svg';
import notificationLogo from 'assets/images/notification-logo.svg';
import { format } from 'date-fns';
import {
  FNS_DATE_NOTIFICATIONS_FORMAT,
  FNS_TIME_NOTIFICATIONS_FORMAT,
  KPI_DATE_FORMAT,
  NOTIFICATION_TIME_FORMAT,
  NOTIFICATION_UPDATE_SUCCESS,
  NOTIFICATION_SCHEDULE_SUCCESS,
  NOTIFICATION_CANCEL_SUCCESS,
} from 'utils/constants';
import {
  addPushNotifications,
  cancelPushNotifications,
  getPushNotificationsRequestById,
} from 'services/notifications';

interface initialStateInterface {
  heading: string;
  message: string;
}
const NewNotification = () => {
  const initialState: initialStateInterface = {
    heading: '',
    message: '',
  };
  let router = useRouter();
  const dispatch = useDispatch();
  const { notificationId } = router.query;
  const isViewEditFlag = !!notificationId;
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showCancelConfirmModal, setShowCancelConfirmModal] = useState(false);
  const [showDisableConfirmModal, setShowDisableConfirmModal] = useState(false);
  const [showDisableScheduleModal, setShowDisableScheduleModal] =
    useState(false);
  const [viewData, setViewData] = useState<any>([]);
  const [count, setCount] = useState<any>(0);
  const [messageCount, setMessageCount] = useState<any>(0);
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [showMessage, setshowMessage] = useState<boolean>(false);
  const [showHeading, setshowHeading] = useState<boolean>(false);
  const [notificationMessage, setNotificationMessage] = useState<string>('');
  const [severityType, setSeverityType] = useState<string>('');
  const [notificationData, setNotificationData] = useState<any>({});
  const [date, setDate] = useState<string>('');
  const [time, setTime] = useState<string>('');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [scheduleTime, setScheduleTime] = useState<any>();
  const [heading, setheading] = useState<string>('');
  const [message, setMessage] = useState<string>('');
  const [actualDate, setActualDate] = useState<any>(new Date());
  const {
    handleSubmit,
    watch,
    setValue,
    register,
    formState: { errors },
  } = useForm<initialStateInterface>();

  const loadLocationData = async () => {
    const getNotificationDetails = await getPushNotificationsRequestById(
      notificationId
    );
    const result: any = getNotificationDetails?.data[0];
    setNotificationData(result);
    const dateDisplayed = result?.scheduleTimeStamp
      ? result?.scheduleTimeStamp
      : result?.createdTimeStamp;
    const currentTime = new Date();
    const localDate = getUTCtoLocaleDate(dateDisplayed);
    setScheduleTime(getUTCtoLocaleDate(dateDisplayed));
    //setCurrentTime(currentTime);
    setDate(getDate(localDate));
    setTime(format(localDate, FNS_TIME_NOTIFICATIONS_FORMAT));
    setheading(result?.title);
    setMessage(result?.body);
    setActualDate(localDate);
  };
  useEffect(() => {
    if (isViewEditFlag) loadLocationData();
  }, [notificationId]);

  useEffect(() => {
    if (!isViewEditFlag && !showDisableScheduleModal) {
      let timer = setInterval(() => setActualDate(new Date()), 1000);
      return function cleanup() {
        clearInterval(timer);
      };
    }
  });

  const headers = {
    title: 'Push Notifications',
    subTitle: isViewEditFlag ? 'View Notification' : 'New Notification',
    onClick: () => {
      router?.push(`${getBasePath('push-notifications')}`);
    },
  };

  const handleSnackbarClose = () => {
    setIsVisibleMessage(false);
  };

  const handleDateTime = (date: any, time: any) => {
    const utcDateTime = convertLocalTimeToUTCTime(date, time);
    sendNotification(utcDateTime);
  };

  const sendNotification = async (buttonType: any) => {
    setShowDisableConfirmModal(false);

    const apiSendNotificationParams = {
      body: viewData.message,
      initiatedBy: getMyEmail(),
      initiatedTo: null,
      notificationTypeId: 1,
      scheduleActiveFlag: buttonType === 'send' ? false : true,
      title: viewData.heading,
      topic: '/topics/buyer',
    };
    const apiScheduleNotificationParams = {
      ...apiSendNotificationParams,
      scheduleTimeStamp: buttonType,
    };
    const paramsData =
      buttonType === 'send'
        ? apiSendNotificationParams
        : apiScheduleNotificationParams;

    try {
      dispatch({ type: ENABLE_LOADER });
      let handlePushNotification = await addPushNotifications(paramsData);
      if (handlePushNotification.status == 200) {
        dispatch({ type: DISABLE_LOADER });
        setIsVisibleMessage(true);
        setSeverityType('success');
        setNotificationMessage(
          buttonType === 'send'
            ? NOTIFICATION_UPDATE_SUCCESS
            : NOTIFICATION_SCHEDULE_SUCCESS
        );
        setTimeout(() => {
          router.push(`${getBasePath('push-notifications')}`);
        }, 2000);
      } else {
        dispatch({ type: DISABLE_LOADER });
        setIsVisibleMessage(true);
        setSeverityType('warning');
        setNotificationMessage(handlePushNotification?.data?.message);
      }
    } catch (e: any) {
      dispatch({ type: DISABLE_LOADER });
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setNotificationMessage(e?.response?.data?.message);
    }
  };

  const handleOnChange = (e: any) => {
    if (e.target.name === 'heading') {
      setCount(e.target.value.length);
      setViewData({ ...viewData, heading: e.target.value });
      setDate(e.target.value);
    } else {
      setViewData({ ...viewData, message: e.target.value });
      setMessageCount(e.target.value.length);
      setTime(e.target.value);
    }
  };

  const onSubmit = () => {
    setShowConfirmModal(true);
  };

  const handleSendNow = () => {
    setShowDisableConfirmModal(true);
  };
  const handleCancelNow = () => {
    setShowCancelConfirmModal(true);
  };
  const calcelNotification = async () => {
    setShowCancelConfirmModal(false);
    try {
      dispatch({ type: ENABLE_LOADER });
      let handlePushNotification = await cancelPushNotifications(
        notificationId
      );
      if (handlePushNotification.status == 200) {
        dispatch({ type: DISABLE_LOADER });
        setIsVisibleMessage(true);
        setSeverityType('success');
        setNotificationMessage(NOTIFICATION_CANCEL_SUCCESS);
        setTimeout(() => {
          router.push(`${getBasePath('push-notifications')}`);
        }, 1000);
      } else {
        dispatch({ type: DISABLE_LOADER });
        setIsVisibleMessage(true);
        setSeverityType('warning');
        setNotificationMessage(handlePushNotification?.data?.message);
      }
    } catch (e: any) {
      dispatch({ type: DISABLE_LOADER });
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setNotificationMessage(e?.response?.data?.message);
    }
  };

  return (
    <div className='yk-push-notifications-page-wrapper'>
      <div className='yk-notifications-page-inner-wrapper'>
        <div className='row YKEE-additional'>
          {/* breadCrumb */}
          <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
            <Breadcrumbs data={headers} />
          </div>
          <form
            onSubmit={handleSubmit(onSubmit)}
            className='row add-user-form m-auto p-0'>
            <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
              <div className='yk-notifications-heading-wrapper'>
                <h2 className='YKEE-headlines'>
                  {isViewEditFlag ? 'View Notification' : 'New Notification'}{' '}
                </h2>
                {!isViewEditFlag ? (
                  <div className='btn-wrapper'>
                    <button
                      onClick={(e) => {
                        handleSendNow();
                      }}
                      type='submit'
                      className='btn yk-sendNowBtn'
                      disabled={!viewData?.heading || !viewData?.message}>
                      Send Now
                    </button>
                    <button
                      className='yk-newNotificationsBtn yk-scheduleBtn'
                      onClick={(e) => setShowDisableScheduleModal(true)}
                      disabled={!viewData?.heading || !viewData?.message}>
                      Schedule Notification
                    </button>
                  </div>
                ) : (
                  <div className='btn-wrapper'>
                    <button
                      onClick={(e) => {
                        handleCancelNow();
                      }}
                      type='button'
                      className='btn  yk-cancelNowBtn'
                      disabled={
                        !(
                          notificationData?.scheduleActiveFlag &&
                          scheduleTime > currentTime
                        )
                      }>
                      Cancel Notification
                    </button>
                  </div>
                )}
              </div>
              {!isViewEditFlag && (
                <div className='right-tool-info'>
                  <ConfirmPopup
                    showPopup={showDisableConfirmModal}
                    handleClose={(e: any) => setShowDisableConfirmModal(false)}
                    title={'Send Notification now?'}
                    message={NOTIFICATION_SENT_SUCCESS}
                    handleSave={() => sendNotification('send')}
                    className='yk-sendNowNotificationModal'
                  />
                </div>
              )}
              {!isViewEditFlag && (
                <div className='right-tool-info'>
                  <SchedulePopup
                    showPopup={showDisableScheduleModal}
                    handleClose={(e: any) => setShowDisableScheduleModal(false)}
                    handleDateTime={(date: any, time: any) =>
                      handleDateTime(date, time)
                    }
                  />
                </div>
              )}
              <div className='right-tool-info'>
                <ConfirmPopup
                  showPopup={showCancelConfirmModal}
                  handleClose={(e: any) => setShowCancelConfirmModal(false)}
                  title={'Cancel Push Notification'}
                  message={NOTIFICATION_CONFIRM_CANCEL}
                  handleSave={() => calcelNotification()}
                  className='yk-sendNowNotificationModal'
                />
              </div>
            </div>

            {/* card sections */}
            <section className='yk-push-notifications-section'>
              <div className='row'>
                <div className='col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12'>
                  <section className='yk-section-cards yk-push-notificationsWrapper'>
                    <h2 className='yk-section-heading'>Type of Push</h2>
                    <FormControl className='yk-radioBtnWrapper'>
                      <RadioGroup
                        aria-labelledby='demo-radio-buttons-group-label'
                        defaultValue='female'
                        name='radio-buttons-group'>
                        <FormControlLabel
                          value='female'
                          control={
                            <Radio
                              sx={{
                                color: '#CBCACE',
                                '&.Mui-checked': {
                                  color: '#C92626',
                                },
                              }}
                            />
                          }
                          label='Text Only'
                        />
                      </RadioGroup>
                    </FormControl>
                    {isViewEditFlag && (
                      <h2 className='yk-section-heading date-time-heading ps-0'>
                        Sent Date and Time
                      </h2>
                    )}
                    <div className='yk-notifications-form-wrapper'>
                      <div className='row'>
                        {isViewEditFlag && (
                          <>
                            {' '}
                            <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 YKEE-columns'>
                              <div className='yk-form-field'>
                                <label className='yk-form-label '>Date</label>
                                <input
                                  type='text'
                                  placeholder='dd/mm/yyyy'
                                  className='form-control YKEE-field'
                                  disabled
                                  value={date}
                                />
                              </div>
                            </div>
                            <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 YKEE-columns'>
                              <div className='yk-form-field'>
                                <label className='yk-form-label'>Time</label>
                                <input
                                  type='text'
                                  placeholder='Enter Time'
                                  className='form-control YKEE-field'
                                  disabled
                                  value={time}
                                />
                              </div>
                            </div>{' '}
                          </>
                        )}
                        <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 YKEE-columns'>
                          <div className='yk-form-field'>
                            <label className='yk-form-label'>Heading</label>
                            <div className='input-group'>
                              <input
                                type='text'
                                className='form-control yk-form-field-input'
                                placeholder='Enter heading here'
                                minLength={0}
                                maxLength={40}
                                {...register('heading', {
                                  ...ValidationRequired,
                                  ...ValidationMaxLength5,
                                })}
                                onChange={handleOnChange}
                                defaultValue={heading}
                                onBlur={() => setshowHeading(true)}
                                onFocus={() => setshowHeading(false)}
                                disabled={isViewEditFlag}
                                required
                                aria-describedby='basic-addon2'
                              />
                              {!isViewEditFlag && (
                                <span
                                  className='input-group-text'
                                  id='basic-addon2'>
                                  {count}/40
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 YKEE-columns'>
                          <div className='yk-form-field'>
                            <label className='yk-form-label'>Message</label>

                            <div className='input-group yk-msg-input-group'>
                              <textarea
                                rows={5}
                                className='form-control yk-form-field-input yk-msgInput'
                                placeholder='Type message here'
                                minLength={0}
                                maxLength={178}
                                {...register('message', {
                                  ...ValidationRequired,
                                })}
                                onChange={handleOnChange}
                                defaultValue={message}
                                onBlur={() => setshowMessage(true)}
                                onFocus={() => setshowMessage(false)}
                                required
                                disabled={isViewEditFlag}
                                aria-label="Recipient's username"
                                aria-describedby='basic-addon2'
                              />
                              {!isViewEditFlag && (
                                <span
                                  className='input-group-text'
                                  id='basic-addon2'>
                                  {messageCount}/178
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                </div>
                <div className='col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12'>
                  <section className='yk-section-cards yk-notification-previewWrapper'>
                    <div className='yk-section-heading'>Preview</div>
                    <div className='yk-preview-section-wrapper'>
                      <div className='yk-iphoneImgWrapper'>
                        <Image
                          src={mobileImage}
                          alt=''
                          className='image-fluid'
                        />
                        <div className='yk-dateTimeWrapper'>
                          <h2 className='yk-dateField'>
                            {getDay()},{' '}
                            {format(actualDate, FNS_DATE_NOTIFICATIONS_FORMAT)}
                          </h2>
                          <h2 className='yk-timeField'>
                            {format(actualDate, FNS_TIME_NOTIFICATIONS_FORMAT)}
                          </h2>
                        </div>
                        <div className='yk-notificationWrapper'>
                          <div className='yk-notificationCard'>
                            <Image
                              src={notificationLogo}
                              alt=''
                              className='yk-notification-img image-fluid'
                            />
                            <div className='yk-card-body'>
                              <div className='card-heading-wrapper'>
                                <h5 className='card-heading'>
                                  {heading ||
                                    (showHeading && viewData?.heading)}
                                </h5>
                                <h5 className='yk-time'>
                                  {format(actualDate, NOTIFICATION_TIME_FORMAT)}
                                </h5>
                              </div>
                              <p className='card-message'>
                                {message || (showMessage && viewData?.message)}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                </div>
              </div>
            </section>
          </form>
          <Notification
            showSuccessPopup={isVisibleMessage}
            handleSnackbarClose={handleSnackbarClose}
            severityType={severityType}
            message={notificationMessage}
            className='yk-shoesize-alert-wrapper YKCH-TostifyMsg'
          />
        </div>
      </div>
    </div>
  );
};
export default NewNotification;
