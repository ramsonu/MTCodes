import React, { useState } from 'react';
import type { NextPage } from 'next';
import Image from 'next/image';
import ykLogo from 'assets/images/yankeekicks-black-logo.png';
import warehouseIcon from 'assets/images/warehouse-icon.png';
import sideNavBlackIcon from 'assets/images/sidenav-black-icon.png';
import SideNavRedIcon from 'assets/images/sidenav-red-icon.png';
import notificationIcon from 'assets/images/notification-bell.svg';
import notificationDotIcon from 'assets/images/notification-dot.svg';
import userIcon from 'assets/images/user.png';
import pendingIcon from 'assets/images/pending.png';
import checkedOutIcon from 'assets/images/checked-out.png';
import checkedInIcon from 'assets/images/checked-in.png';
import soldOutIcon from 'assets/images/sold-out.png';
import searchIcon from 'assets/images/search.png';
import qrScan from 'assets/images/qr-scan-icon.svg';
import addIcon from 'assets/images/add-icon.png';
import closeIcon from 'assets/images/close-icon.png';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import thumbnailIcon1 from 'assets/images/thumbnail/thumbnail-1.png';
import thumbnailIcon2 from 'assets/images/thumbnail/thumbnail-2.png';
import thumbnailIcon3 from 'assets/images/thumbnail/thumbnail-3.png';

const Dashboard: NextPage = () => {
  const [value, setValue] = React.useState('1');

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };
  return (
    <>
      <div className='app-wrapper sales-associate-dashboard-wrapper'>
        <div className='page-inner-wrapper'>
          <div className='left-menu-wrapper'>
            <div className='d-flex flex-column flex-shrink-0 p-3 bg-light'>
              <a
                href='#'
                className='d-flex logo-icon align-items-center mb-3 mb-md-0 me-md-auto  text-decoration-none'
              >
                <span className=''>
                  <Image
                    src={ykLogo}
                    alt='yk-logo'
                    className='Image-fluid brand-logo'
                  />
                </span>
              </a>
              <hr />
              <ul className='nav main-nav nav-pills flex-column mb-auto'>
                <li className='nav-item dropdown'>
                  <a
                    className='nav-link dropdown-toggle'
                    data-bs-toggle='dropdown'
                    aria-expanded='false'
                  >
                    <Image
                      src={warehouseIcon}
                      alt='warehouse-icon'
                      className='Image-fluid'
                    />
                    <p>
                      <span className='portal'>Portal</span>
                      <br />
                      <span className='Warehouse'>Warehouse</span>
                    </p>
                  </a>
                  <ul className='dropdown-menu'>
                    <li className='dropdown-item'>
                      <a
                        href='#'
                        className=' d-inline-flex text-decoration-none rounded'
                      >
                        Home
                      </a>
                    </li>
                    <li className='dropdown-item'>
                      <a
                        href='#'
                        className=' d-inline-flex text-decoration-none rounded'
                      >
                        Weekly
                      </a>
                    </li>
                    <li className='dropdown-item'>
                      <a
                        href='#'
                        className=' d-inline-flex text-decoration-none rounded'
                      >
                        Monthly
                      </a>
                    </li>
                    <li className='dropdown-item'>
                      <a
                        href='#'
                        className=' d-inline-flex text-decoration-none rounded'
                      >
                        Annually
                      </a>
                    </li>
                  </ul>
                </li>
                <li className='nav-item'>
                  <a
                    href="{{ url('/') }}"
                    className='nav-link active'
                    aria-current='page'
                  >
                    <Image
                      src={sideNavBlackIcon}
                      alt='side-nav-black-icon'
                      className='Image-fluid black-icon'
                    />
                    <Image
                      src={SideNavRedIcon}
                      alt='side-nav-red-icon'
                      className='Image-fluid red-icon'
                    />
                    Home
                  </a>
                </li>
                <li className='nav-item'>
                  <a
                    href="{{ url('/logout') }}"
                    className='nav-link'
                    aria-current='page'
                  >
                    <Image
                      src={sideNavBlackIcon}
                      alt='side-nav-black-icon'
                      className='Image-fluid black-icon'
                    />
                    <Image
                      src={SideNavRedIcon}
                      alt='side-nav-red-icon'
                      className='Image-fluid red-icon'
                    />
                    Logout
                  </a>
                </li>
                <li className='nav-item'>
                  <a href="{{ route('login') }}" className='nav-link '>
                    <Image
                      src={sideNavBlackIcon}
                      alt='side-nav-black-icon'
                      className='Image-fluid black-icon'
                    />
                    <Image
                      src={SideNavRedIcon}
                      alt='side-nav-red-icon'
                      className='Image-fluid red-icon'
                    />
                    Log In
                  </a>
                </li>
                <li className='nav-item'>
                  <a href="{{ route('register') }}" className='nav-link '>
                    <Image
                      src={sideNavBlackIcon}
                      alt='side-nav-black-icon'
                      className='Image-fluid black-icon'
                    />
                    <Image
                      src={SideNavRedIcon}
                      alt='side-nav-red-icon'
                      className='Image-fluid red-icon'
                    />
                    Register
                  </a>
                </li>

                <li className='nav-item'>
                  <a href='#' className='nav-link '>
                    <Image
                      src={sideNavBlackIcon}
                      alt='side-nav-black-icon'
                      className='Image-fluid black-icon'
                    />
                    <Image
                      src={SideNavRedIcon}
                      alt='side-nav-red-icon'
                      className='Image-fluid red-icon'
                    />
                    Dashboard
                  </a>
                </li>
                <li className='nav-item'>
                  <a href='#' className='nav-link '>
                    <Image
                      src={sideNavBlackIcon}
                      alt='side-nav-black-icon'
                      className='Image-fluid black-icon'
                    />
                    <Image
                      src={SideNavRedIcon}
                      alt='side-nav-red-icon'
                      className='Image-fluid red-icon'
                    />
                    Item label
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className='page-user-area-wrapper'>
            <div className='user-actions-wrapper'>
              <ul className='nav nav-tabs user-nav'>
                <li className='nav-item'>
                  <a className='nav-link' aria-current='page' href='#'>
                    <Image
                      src={notificationIcon}
                      alt='notification-icon'
                      className='Image-fluid'
                    />
                    <Image
                      src={notificationDotIcon}
                      alt='notification-dot-icon'
                      className='Image-fluid'
                    />
                  </a>
                </li>
                <li className='nav-item dropdown'>
                  <a
                    className='nav-link dropdown-toggle'
                    data-bs-toggle='dropdown'
                    href='#'
                    role='button'
                    aria-expanded='false'
                  >
                    <Image
                      src={userIcon}
                      alt='user-icon'
                      className='Image-fluid'
                    />
                    <span>
                      <span className='user-name'>Jackob Deo</span>
                      <span className='emp-id'>Emp. ID:2152</span>
                    </span>
                  </a>
                  <ul className='dropdown-menu'>
                    <li>
                      <a className='dropdown-item' href='#'>
                        Action
                      </a>
                    </li>
                    <li>
                      <a className='dropdown-item' href='#'>
                        Another action
                      </a>
                    </li>
                    <li>
                      <a className='dropdown-item' href='#'>
                        Something else here
                      </a>
                    </li>
                    <li>
                      <hr className='dropdown-divider' />
                    </li>
                    <li>
                      <a className='dropdown-item' href='#'>
                        Separated link
                      </a>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
            <div className='user-area-wrapper'>
              <div className='user-area-inner-wrapper'>
                <div className='container'>
                  <div className='row'>
                    <div className='col-lg-8'>
                      <div className='status-wrapper'>
                        <div className='row'>
                          <div className='col-sm-12 col-md-3 col-lg-3'>
                            <div className='card status-card pending'>
                              <div className='card-body'>
                                <div className='card-heading-wrapper'>
                                  <h5 className='card-title'>10</h5>
                                  <div className='icon-wrapper'>
                                    <Image
                                      src={pendingIcon}
                                      alt=''
                                      className='img-fluid'
                                    />
                                  </div>
                                </div>
                                <p className='card-text'>Pending</p>
                              </div>
                            </div>
                          </div>
                          <div className='col-sm-12 col-md-3 col-lg-3'>
                            <div className='card status-card pending'>
                              <div className='card-body'>
                                <div className='card-heading-wrapper'>
                                  <h5 className='card-title'>10</h5>
                                  <div className='icon-wrapper'>
                                    <Image
                                      src={checkedOutIcon}
                                      alt=''
                                      className='img-fluid'
                                    />
                                  </div>
                                </div>
                                <p className='card-text'>Checked Out</p>
                              </div>
                            </div>
                          </div>
                          <div className='col-sm-12 col-md-3 col-lg-3'>
                            <div className='card status-card checked-in'>
                              <div className='card-body'>
                                <div className='card-heading-wrapper'>
                                  <h5 className='card-title'>10</h5>
                                  <div className='icon-wrapper'>
                                    <Image
                                      src={checkedInIcon}
                                      alt=''
                                      className='img-fluid'
                                    />
                                  </div>
                                </div>
                                <p className='card-text'>Checked In</p>
                              </div>
                            </div>
                          </div>
                          <div className='col-sm-12 col-md-3 col-lg-3'>
                            <div className='card status-card sold-out'>
                              <div className='card-body'>
                                <div className='card-heading-wrapper'>
                                  <h5 className='card-title'>10</h5>
                                  <div className='icon-wrapper'>
                                    <Image
                                      src={soldOutIcon}
                                      alt=''
                                      className='img-fluid'
                                    />
                                  </div>
                                </div>
                                <p className='card-text'>Sold</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className='searchbar-wrapper'>
                        <form className=''>
                          <div className='searchbar-inner-wrapper'>
                            <div className='input-wrapper'>
                              <label
                                htmlFor='staticsearch2'
                                className='visually-hidden'
                              >
                                search
                              </label>
                              <div className='input-group'>
                                <span className='input-group-text'>
                                  <Image
                                    src={searchIcon}
                                    alt='serach-icon'
                                    className='Image-fluid'
                                  />
                                </span>
                                <input
                                  type='text'
                                  className='form-control'
                                  id='staticsearch2'
                                  placeholder='Search for brand, color etc.'
                                />
                              </div>
                            </div>
                            <div className=''>
                              <button type='submit' className='btn btn-scan'>
                                <Image
                                  src={qrScan}
                                  alt='qr-scan-icon'
                                  className='Image-fluid'
                                />
                                &nbsp;scan QR
                              </button>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                    <div className='col-lg-4'>
                      <div className='status-tabs-wrapper'>
                        <Box sx={{ width: '100%', typography: 'body1' }}>
                          <TabContext value={value}>
                            <Box
                              sx={{ borderBottom: 1, borderColor: 'divider' }}
                            >
                              <TabList
                                onChange={handleChange}
                                aria-label='lab API tabs example'
                              >
                                <Tab label='Request' value='1' />
                                <Tab label='Pending' value='2' />
                                <Tab label='Checked-Out' value='3' />
                              </TabList>
                            </Box>
                            <TabPanel value='1'>
                              <div className='tab-content-inner-wrapper'>
                                <div className='add-shoes-wrapper'>
                                  <div className='empty-list'>
                                    <Image
                                      src={addIcon}
                                      alt=''
                                      className='img-fluid'
                                    />
                                    <p>Add shoes to request from warehouse</p>
                                  </div>
                                </div>
                                <div className='button-action-wrapper'>
                                  <button className='btn btn-place-request'>
                                    place request
                                  </button>
                                </div>
                              </div>
                            </TabPanel>
                            <TabPanel value='2'>
                              <div className='tab-content-inner-wrapper'>
                                <div className='add-shoes-wrapper pending-tab-wrapper'>
                                  <ul className='pending-list list-all'>
                                    <li>
                                      <div className='img-thumbnail-icon'>
                                        <Image
                                          src={thumbnailIcon1}
                                          alt=''
                                          className='img-fluid'
                                        />
                                      </div>
                                      <div className='product-details'>
                                        <p className='product-name'>
                                          Air Jordan 1 Retro
                                        </p>
                                        <p className='price'>
                                          <span>&#36;419.00</span>{' '}
                                          <span>9.5/11w</span>{' '}
                                        </p>
                                      </div>
                                      <div className='close-btn-wrapper'>
                                        <button className='btn prod-close'>
                                          <Image
                                            src={closeIcon}
                                            alt=''
                                            className='img-fluid'
                                          />
                                        </button>
                                      </div>
                                    </li>
                                    <li>
                                      <div className='img-thumbnail-icon'>
                                        <Image
                                          src={thumbnailIcon2}
                                          alt=''
                                          className='img-fluid'
                                        />
                                      </div>
                                      <div className='product-details'>
                                        <p className='product-name'>
                                          Nike Air Presto
                                        </p>
                                        <p className='price'>
                                          <span>&#36;325.00</span>{' '}
                                          <span>0.5/2w</span>{' '}
                                        </p>
                                      </div>
                                      <div className='close-btn-wrapper'>
                                        <button className='btn prod-close'>
                                          <Image
                                            src={closeIcon}
                                            alt=''
                                            className='img-fluid'
                                          />
                                        </button>
                                      </div>
                                    </li>
                                    <li>
                                      <div className='img-thumbnail-icon'>
                                        <Image
                                          src={thumbnailIcon3}
                                          alt=''
                                          className='img-fluid'
                                        />
                                      </div>
                                      <div className='product-details'>
                                        <p className='product-name'>
                                          Addidas Yeezy...
                                        </p>
                                        <p className='price'>
                                          <span>&#36;325.00</span>{' '}
                                          <span>0.5/2w</span>{' '}
                                        </p>
                                      </div>
                                      <div className='close-btn-wrapper'>
                                        <button className='btn prod-close'>
                                          <Image
                                            src={closeIcon}
                                            alt=''
                                            className='img-fluid'
                                          />
                                        </button>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                                <div className='button-action-wrapper'>
                                  <button className='btn btn-place-request'>
                                    place request
                                  </button>
                                </div>
                              </div>
                            </TabPanel>
                            <TabPanel value='3'>
                              <div className='tab-content-inner-wrapper'>
                                <div className='add-shoes-wrapper'></div>
                                <div className='button-action-wrapper'>
                                  <button className='btn btn-place-request'>
                                    place request
                                  </button>
                                </div>
                              </div>
                            </TabPanel>
                          </TabContext>
                        </Box>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Dashboard;
