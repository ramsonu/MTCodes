import IdleTimerContainer from 'components/common/idle-timer';
import LeftSideBar from 'components/common/left-side-bar';
import TopHeader from 'components/common/top-header';
import React from 'react';
import { useSelector } from 'react-redux';
const LayoutPage = ({ children }: any) => {
  return (
    <div className='page-layout-wrapper'>
      <div className='page-layout-inner-wrapper'>
        <div className='left-side-nav-wrapper YKCH-leftSIdebarMenu'>
          {/* LEFT SIDE NAV */}
          <LeftSideBar></LeftSideBar>
        </div>
        <div className='layout-user-area-wrapper'>
          {/* INCLUDE HEADER */}
          <TopHeader></TopHeader>
          {/* MAIN AREA - USER AREA */}
          <IdleTimerContainer>{children}</IdleTimerContainer>
        </div>
      </div>
    </div>
  );
};

export default LayoutPage;
