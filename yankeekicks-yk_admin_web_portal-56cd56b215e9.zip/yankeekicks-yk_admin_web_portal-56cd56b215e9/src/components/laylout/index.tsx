import React, { Component, useEffect, useState } from 'react';
import { useRouter } from 'next/router';
//import CommonLayout from './common';
import { useSelector, useDispatch } from 'react-redux';
import { actions } from 'store/reducers/auth';
// import IdleTimerContainer from 'components/common/idle-timer';
import { NO_HEADER_ROUTES, USER_ROLES } from 'utils/constants';
import dynamic from 'next/dynamic';
//import { Login } from 'components/common/user';

import { useIsAuthenticated } from '@azure/msal-react';
import { doRequest } from 'utils/request';
import { USER_DETAILS, USER_VALIDATION } from 'services/apiUrl';
import jwt_decode from 'jwt-decode';
import {
  checkPermission,
  checkPermissionForLayout,
  displayNoResultsFound,
  displayUnauthorized,
  navigateTo,
} from 'utils/util';
import CircleLoader from 'components/common/loader/circular-loader';
import TopHeader from 'components/common/top-header';
import LayoutPage from 'components/laylout/common';
import { validateUser } from 'services/auth';
import UnAuthorizedTopHeader from 'components/common/top-header/unauthorized-top-header';

const Layout = ({ children }: any) => {
  const router = useRouter();
  const dispatch = useDispatch();
  const { user, status: loginStatus } = useSelector((state: any) => state.auth);
  const { token } = useSelector((state: any) => state.auth);

  const [isTokenAvailable, setIsTokenAvailable] = useState(loginStatus);
  const [isAccessTokenInvalid, setIsAccessTokenInvalid] = useState(false);

  const isAuthenticated = useIsAuthenticated();
  const curretUrl = router.pathname.replace(/\//, '');
  const noHeaderFlag = NO_HEADER_ROUTES.includes(curretUrl);

  useEffect(() => {
    const userRole: any = localStorage.getItem('user-role');
    if (router.pathname === '/' && userRole) {
      const pathName = navigateTo(userRole);
      const roles = [USER_ROLES?.CONSIGNMENT_ADMIN, USER_ROLES?.YK_ADMIN];
      if (pathName) {
        if (pathName === '/' && !roles?.includes(userRole)) {
          router.push(
            { pathname: '/unauthorized', query: { section: 'section' } },
            undefined,
            { shallow: true }
          );
        } else {
          router.push(pathName, undefined, { shallow: true });
        }
      }
    }
  }, [router.pathname, isTokenAvailable]);

  useEffect(() => {
    if (!localStorage.getItem('jwt-token')) {
      fetchToken();
    } else {
      setIsTokenAvailable(true);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const fetchToken = async () => {
    if (isAuthenticated || localStorage.getItem('access-token')) {
      try {
        const { response, userInfoResponse } = await validateUser();
        if (response) {
          setIsTokenAvailable(true);
          // Check user has permission for current path
          const currentPathPermission = checkPermissionForLayout(
            router.pathname
          );
          if (!currentPathPermission) {
            // Navigate user to respective portal
            const pathName = navigateTo(userInfoResponse?.data[0]?.role);
            router.push(pathName);
          }
          dispatch(actions.setUserDetails(response.data.token));
        }
      } catch (error: any) {
        // console.log('validaton error');
        // router.push('/unauthorized');
        console.log(error);
        if (
          error?.response?.status === 401 ||
          error?.response?.status === 403
        ) {
          setIsAccessTokenInvalid(true);
        } else {
          setIsAccessTokenInvalid(false);
        }
        setIsTokenAvailable(false);
      }
    }
  };

  const checkPathnames =
    router.pathname?.includes('/consignment-admin') ||
    router.pathname?.includes('/yk-admin') ||
    router.pathname === '/unauthorized';

  const renderApplication = (
    <div className='layout'>
      {(() => {
        return <LayoutPage>{children}</LayoutPage>;
      })()}
    </div>
  );

  const displayLoader = (
    <div className='circular-loader-wrapper'>
      <CircleLoader />
    </div>
  );

  const displayUnauthorizedPage = (
    <>
      <UnAuthorizedTopHeader />
      {displayUnauthorized()}
    </>
  );

  const displayNoResultsFoundPage = (
    <>
      <TopHeader></TopHeader>
      {displayNoResultsFound()}
    </>
  );

  const handleUnauthorizedPage = () => {
    // setTimeout(() => {
    //   LogoutUser();
    //   router.push('/', undefined, { shallow: true });
    // }, 4000);
    return displayUnauthorizedPage;
  };

  return (
    <>
      {(() => {
        if (isTokenAvailable && localStorage.getItem('jwt-token')) {
          // if current user roles has access for portal then move further
          if (
            checkPermission('CONSIGNMENT_ADMIN_PORTAL') ||
            checkPermission('YK_ADMIN_PORTAL')
          ) {
            if (checkPermissionForLayout(router.pathname)) {
              return renderApplication;
            } else if (router.pathname === '/') {
              return displayLoader; // no permission yet, instead of showing no results found, display loader
            } else if (checkPathnames) {
              return displayUnauthorizedPage; // no permission and accessing valid pages
            } else {
              return displayNoResultsFoundPage; // no permission and accessing invalid pages
            }
          } else {
            return displayUnauthorizedPage; // current user role don't have the access
          }
        } else {
          if (isAccessTokenInvalid) {
            return handleUnauthorizedPage(); // when oauth gives error
          }
        }
      })()}
    </>
  );
};

export default Layout;
