import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import { format } from 'date-fns';
import Modal from '@mui/material/Modal';
import { Button, Box } from '@mui/material';
import MobileStepper from '@mui/material/MobileStepper';
import KeyboardArrowLeft from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRight from '@mui/icons-material/KeyboardArrowRight';
import { useTheme } from '@mui/material/styles';
import {
  DAYS_LIMIT_FOR_MOVE_TO_YK_INV,
  FNS_DATE_FORMAT,
  FNS_TIME_FORMAT,
  TIME_TO_DAYS_CONVERSION,
} from 'utils/constants';
import VirtualTable from 'components/common/table';
import {
  getBrandNameFromSku,
  postUpdateRetailPrice,
} from 'services/consignment';
import { shoeDetails } from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import Notification from 'components/common/notification';
import ImageLoader from 'components/common/image-loader';
import { PREFIX, SHOE_JOURNEY_TYPES } from '../constants';
import { convertPriceToUSFormat } from 'utils/util';
import CopyToClipboardComponent from 'components/common/copyToClipboard';
import NoDataFound from 'components/common/no-data-found';
import CircleLoader from 'components/common/loader/circular-loader';
import StatusIcon from 'assets/images/status-icon.svg';
import ModalCloseIcon from 'assets/images/modal-close-icon.svg';
import productImg from 'assets/images/big-product-img.svg';
import CalendarIcon from 'assets/images/calendar-icon.svg';
import TimeIcon from 'assets/images/time-icon.svg';
import PriceIcon from 'assets/images/price-icon.svg';
import LocationIcon from 'assets/images/modal-location-icon.svg';
import invoiceIcon from 'assets/images/invoice-icon.svg';
import paymentReceivedIcon from 'assets/images/payment-received-icon.svg';
import barcodeGenIcon from 'assets/images/reverse-icon.svg';
import missingIcon from 'assets/images/menu-icons/missing-icon.svg';
import clearedIcon from 'assets/images/menu-icons/cleared-icon.svg';
import statusClassList from 'utils/statusTypes';

const OrderDetailsModal = (props: any) => {
  const {
    showModal,
    handleClose,
    orderDetails,
    modalData,
    skuId,
    lineItemId,
    profitRatio,
    isShoeCatalog = false,
    modalUsedFor = '',
    isSearchWithBarcode = false,
    handleMoveToYKInv = false,
    handleMarkPaid = false,
    modalClassName = '',
  } = props;

  const theme = useTheme();
  const router = useRouter();
  const { pathname } = router;
  const currentPath = pathname;

  const [tableData, setTableData] = useState<any>([]);
  const [activeLineItemId, setActiveLineItemId] = useState<any>(lineItemId);
  const [searchWithBarcode, setSearchWithBarcode] =
    useState<any>(isSearchWithBarcode);
  const [activeStep, setActiveStep] = useState(0);
  const [otherBarCode, setOtherBarCode] = useState<any>();
  const [enableMoveToYKInv, setEnableMoveToYKInv] = useState<boolean>(false);
  const [actionToggler, setActionToggler] = useState(true);
  const [shoeDetailsData, setShoeDetailsData] = useState<any>([]);
  const [skuDetailsImages, setSkuDetailsImages] = useState<any>([]);
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [severityType, setSeverityType] = useState<string>('');
  const [msg, setMsg] = useState<string>('');
  const [fetchOrderDetails, setFetchOrderDetails] = useState<boolean>(false);
  const [isUpdateActive, setIsUpdateActive] = useState(true);
  const userId = localStorage.getItem('userId');
  const maxSteps = skuDetailsImages?.length;

  const status = shoeDetailsData[0]?.['OrdersShoeDetails.status'];

  const shoeDetailsQuery: any = shoeDetails(
    activeLineItemId,
    currentPath,
    isShoeCatalog,
    searchWithBarcode
  );
  const otherShoeDetailsQuery: any = shoeDetails(
    otherBarCode,
    currentPath,
    false,
    true
  );

  const {
    resultSet: otherShoeDetailsResultSet,
    isLoading: otherShoeDetailsIsLoading,
    error: otherShoeDetailsError,
  }: any = useCubeQuery(otherShoeDetailsQuery, { skip: !otherBarCode });

  const {
    resultSet: shoeDetailsResultSet,
    isLoading: shoeDetailsIsLoading,
    error: shoeDetailsError,
  }: any = useCubeQuery(shoeDetailsQuery, { skip: !fetchOrderDetails });

  useEffect(() => {
    if (activeLineItemId) {
      setFetchOrderDetails(true);
    } else {
      setFetchOrderDetails(false);
    }
  }, [activeLineItemId]);

  useEffect(() => {
    let data = shoeDetailsResultSet?.loadResponses[0]?.data;
    if (data) {
      const ykInvStatus = data.findIndex(
        (event: any) =>
          event?.['OrdersShoeDetails.eventType'] ==
          SHOE_JOURNEY_TYPES.ADDED_TO_YK_INV
      );
      const updatedData = ykInvStatus >= 0 ? data.splice(ykInvStatus, 1) : [];
      setShoeDetailsData([...data, ...updatedData]);
      setTableData([
        {
          ...data[0],
          sellingPrice:
            data[0]?.['OrdersShoeDetails.retailPrice_D']?.toFixed(2),
          costPerItem:
            modalUsedFor === 'withDrawal'
              ? parseFloat(
                  data[0]?.['OrdersShoeDetails.payoutAmount']
                )?.toFixed(2)
              : parseFloat(data[0]?.['OrdersShoeDetails.costPerItem'])?.toFixed(
                  2
                ),
        },
      ]);
      setFetchOrderDetails(false);
    } else {
      setShoeDetailsData([]);
    }
  }, [shoeDetailsResultSet]);

  useEffect(() => {
    const data = otherShoeDetailsResultSet?.loadResponses[0]?.data;
    if (!!data) setShoeDetailsData([...shoeDetailsData, ...data]);
  }, [otherShoeDetailsResultSet]);

  useEffect(() => {
    const getImages = async () => {
      const param = { id: skuId };
      try {
        await getBrandNameFromSku(param).then((response: any) => {
          const imageUrls = response?.data[0]?.catalogueImageList;
          setSkuDetailsImages(imageUrls);
        });
      } catch (e: any) {
        console.log(e);
      }
    };

    if (skuId && fetchOrderDetails) {
      getImages();
    }
  }, [skuId, fetchOrderDetails]);

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const viewButtonHandler = (data: any) => {
    const cActionToggler = actionToggler;
    setActionToggler(!actionToggler);
    if (cActionToggler === false) {
      if (
        parseFloat(tableData[0]?.costPerItem) <
        parseFloat(tableData[0]?.sellingPrice)
      ) {
        updateRetailPrice(
          parseFloat(tableData[0].sellingPrice),
          parseFloat(tableData[0].costPerItem)
        );
      } else {
        setSeverityType('error');
        setMsg('Selling price should be greater than the cost per item');
        setIsVisibleMessage(true);
      }
    }
  };

  const handleonChange = (data: any, type: string, i: any) => {
    const sellingPriceRegex = /^[0-9-.]*$/;
    const value = data?.target?.value;
    if (value.match(sellingPriceRegex)) {
      setTableData([
        {
          ...tableData[i],
          ...{ [type]: data?.target?.value },
        },
      ]);
      setIsUpdateActive(true);
    }
  };

  const updateRetailPrice = async (price: any, cost: any) => {
    const param = {
      createdBy: userId,
      id: shoeDetailsData[0]?.['OrdersShoeDetails.consignmentlineitemId_D'],
      retailPrice: +price,
      cost: +cost,
      updatedBy: userId,
      userId: userId,
    };
    try {
      await postUpdateRetailPrice(param);
      setSeverityType('success');
      setMsg('Price Updated');
      setIsVisibleMessage(true);
      setTimeout(() => {
        handleClose(true);
      }, 500);
    } catch (e: any) {
      setSeverityType('error');
      setMsg(e?.response?.data?.message || 'Something went wrong');
      setIsVisibleMessage(true);

      setTimeout(() => {
        handleClose(false);
      }, 500);
      console.log(e);
    }
  };

  const handleSnackbarClose = () => {
    setIsVisibleMessage(false);
  };

  const withdrawalInventoryColumns = [
    {
      title: 'Size',
      value: 'OrdersShoeDetails.size',
    },
    {
      title: 'Condition',
      value: 'OrdersShoeDetails.conditionName',
    },
    {
      title: 'Quantity',
      value: 'OrdersShoeDetails.Quantity',
      type: 'textbox',
      disabled: true,
    },
    {
      title: 'Cost/item',
      type: 'textbox',
      disabled: false,
      //isAddCostModal: true,
      value: 'costPerItem',
      onChange: (data: any, i: any) => {
        handleonChange(data, 'costPerItem', i);
      },
    },
    {
      title: 'Selling Price',
      type: 'textbox',
      value: 'sellingPrice',
      onChange: (data: any, i: any) => {
        handleonChange(data, 'sellingPrice', i);
      },
    },

    {
      title: 'Actions',
      type: 'button',
      onClick: (data: any) => {
        setEnableMoveToYKInv(false);
      },
      value: 'Cancel',
    },
  ];

  const columns = [
    {
      title: 'Size',
      value: 'OrdersShoeDetails.size',
    },
    {
      title: 'Condition',
      value: 'OrdersShoeDetails.conditionName',
    },
    {
      title: 'Quantity',
      value: 'OrdersShoeDetails.Quantity',
      type: 'textbox',
      disabled: true,
    },
    {
      title: 'Cost/item',
      type: 'textbox',
      //isAddCostModal: true,
      value: 'costPerItem',
      disabled: actionToggler,
      onChange: (data: any, i: any) => {
        handleonChange(data, 'costPerItem', i);
      },
    },
    {
      title: 'Selling Price',
      type: 'textbox',
      value: 'sellingPrice',
      disabled: actionToggler,
      onChange: (data: any, i: any) => {
        handleonChange(data, 'sellingPrice', i);
      },
    },

    {
      title: 'Actions',
      type: 'button',
      visibility:
        shoeDetailsData[0]?.['OrdersShoeDetails.status'] === 'Pending' ||
        shoeDetailsData[0]?.['OrdersShoeDetails.status'] === 'Active'
          ? ''
          : 'd-none',

      onClick: (data: any) => {
        viewButtonHandler(data);
      },
      value: actionToggler === true ? 'Edit' : 'Update',
    },
  ];

  const colorCode =
    status === 'Pending'
      ? 'red'
      : status === 'Sold'
      ? 'darkgreen'
      : status === 'Active'
      ? 'green'
      : status === 'Withdrawn'
      ? 'yellow'
      : 'green';

  const appendShoeJourney = (barcode: any) => {
    if (shoeDetailsData[0]?.['OrdersShoeDetails.barcode'] != barcode)
      setOtherBarCode(barcode);
  };

  const switchShoeJourney = (barcode: any) => {
    if (shoeDetailsData[0]?.['OrdersShoeDetails.barcode'] != barcode) {
      setActiveLineItemId(barcode);
      setSearchWithBarcode(true);
    }
  };
  return (
    <div className={`modal-wrapper`}>
      <Modal
        open={showModal}
        onClose={() => handleClose(false)}
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'
        className={`yk-product-details-modal yk-transfer-details-modal ${
          modalUsedFor === 'Transfer' ? 'yk-transferShoeDetailsModal' : ''
        }
        ${modalUsedFor === 'withDrawal' ? 'yk-withdrawShoeDetailsModal' : ''}
        ${modalClassName}
        `}>
        <div
          className={`yk-shoe-details-wrapper modal-outer-wrapper YKCH-autoHeight  ${
            isShoeCatalog ? 'minHeightAuto' : ''
          }`}>
          {shoeDetailsError ? (
            <p>Something went wrong!</p>
          ) : (
            <div className='modal-inner-wrapper container-fluid'>
              <div className='modal-heading-wrapper'>
                <div className='heading-wrapper'>
                  <div className='dFlexCenter'>
                    <h3 className='heading d-inline-block mb-0'>
                      Shoe details{' '}
                    </h3>
                    <span
                      className={`yk-color-badge ${
                        statusClassList[
                          shoeDetailsData[0]?.['OrdersShoeDetails.status']
                        ]
                      } ms-2`}>
                      {shoeDetailsData[0]?.['OrdersShoeDetails.status']
                        ? shoeDetailsData[0]?.['OrdersShoeDetails.status']
                        : '--'}
                    </span>
                  </div>
                  <button
                    className='btn btn-modal-close'
                    onClick={() => handleClose(false)}>
                    <Image
                      src={ModalCloseIcon}
                      className='img-fluid'
                      alt=''></Image>
                  </button>
                </div>
              </div>
              <div className='modal-body-wrapper row'>
                <div className='product-description-wrapper'>
                  <div className='row'>
                    <div className='col-lg-3'>
                      <Box
                        sx={{ maxWidth: 135, flexGrow: 1 }}
                        className='mx-auto position-relative'>
                        <ImageLoader
                          src={skuDetailsImages?.[activeStep]}
                          fallbackImg={productImg}
                          alt='cart-img'
                          className='img-fluid d-block m-auto img-product-logo'
                        />
                        <MobileStepper
                          steps={maxSteps}
                          position='static'
                          activeStep={activeStep}
                          nextButton={
                            <Button
                              className='next-button'
                              size='small'
                              onClick={handleNext}
                              disabled={activeStep === maxSteps - 1}>
                              {theme.direction === 'rtl' ? (
                                <KeyboardArrowLeft />
                              ) : (
                                <KeyboardArrowRight />
                              )}
                            </Button>
                          }
                          backButton={
                            <Button
                              className='back-button'
                              size='small'
                              onClick={handleBack}
                              disabled={activeStep === 0}>
                              {theme.direction === 'rtl' ? (
                                <KeyboardArrowRight />
                              ) : (
                                <KeyboardArrowLeft />
                              )}
                            </Button>
                          }
                        />
                      </Box>
                    </div>
                    <div className='col-lg-9'>
                      <p className='mb-0 yk-brandName'>
                        {shoeDetailsData[0]?.['OrdersShoeDetails.brandName'] ||
                          '--'}
                      </p>
                      <h3 className='heading'>
                        {shoeDetailsData[0]?.['OrdersShoeDetails.Name']
                          ? `${shoeDetailsData[0]?.['OrdersShoeDetails.Name']} ${shoeDetailsData[0]?.['OrdersShoeDetails.productDescription']}`
                          : '--'}
                      </h3>
                      <div className='row mt-3'>
                        <div className='col-lg-6 col-md-6 col-sm-12 col-12 YKCH-newDetails'>
                          <p className='sku-details yk-myouwnData yk-badge-h16 yk-modal-row-spacing'>
                            <span className='yk-order-details fw-bold'>
                              SKU :&nbsp;
                            </span>
                            <span className='sku-number' id='sku'>
                              <span className='YKCH-nowData yk-fieldValueColor'>
                                {shoeDetailsData[0]?.[
                                  'OrdersShoeDetails.style'
                                ] || '--'}
                              </span>
                            </span>
                            <CopyToClipboardComponent
                              copyText={
                                shoeDetailsData[0]?.['OrdersShoeDetails.style']
                              }
                            />
                          </p>
                        </div>
                        <div className='col-lg-6 col-md-6 col-sm-12 col-12'>
                          <div className='yk-productFieldWrapper yk-modal-row-spacing'>
                            <span className='fw-bold yk-modalFieldTitle'>
                              Barcode :&nbsp;
                            </span>
                            <span className='yk-order-title-size yk-fieldValueColor yk-modalFieldTitle'>
                              {shoeDetailsData[0]?.[
                                'OrdersShoeDetails.barcode'
                              ] ? (
                                <>
                                  {
                                    shoeDetailsData[0]?.[
                                      'OrdersShoeDetails.barcode'
                                    ]
                                  }
                                  <CopyToClipboardComponent
                                    copyText={
                                      shoeDetailsData[0]?.[
                                        'OrdersShoeDetails.barcode'
                                      ]
                                    }
                                  />
                                </>
                              ) : (
                                '--'
                              )}
                            </span>
                          </div>
                        </div>
                        <div className='col-lg-6 col-md-6 col-sm-12 col-12'>
                          <div className='yk-productFieldWrapper yk-modal-row-spacing'>
                            <span className='fw-bold yk-modalFieldTitle'>
                              Release Date :&nbsp;
                            </span>
                            <span className='yk-fieldValueColor yk-modalFieldTitle'>
                              {shoeDetailsData[0]?.[
                                'OrdersShoeDetails.releaseDate'
                              ]
                                ? format(
                                    new Date(
                                      shoeDetailsData[0]?.[
                                        'OrdersShoeDetails.releaseDate'
                                      ]
                                    ),
                                    FNS_DATE_FORMAT
                                  )
                                : '--'}
                            </span>
                          </div>
                        </div>
                        <div className='col-lg-6 col-md-6 col-sm-12 col-12'>
                          <div className='yk-productFieldWrapper yk-modal-row-spacing'>
                            <span className='fw-bold yk-modalFieldTitle'>
                              Added Date :&nbsp;
                            </span>
                            <span className='yk-fieldValueColor yk-modalFieldTitle'>
                              {shoeDetailsData[0]?.[
                                'OrdersShoeDetails.createdAt'
                              ]
                                ? format(
                                    new Date(
                                      shoeDetailsData[0]?.[
                                        'OrdersShoeDetails.createdAt'
                                      ]
                                    ),
                                    FNS_DATE_FORMAT
                                  )
                                : '--'}
                            </span>
                          </div>
                        </div>
                        <div className='col-lg-6 col-md-6 col-sm-12 col-12'>
                          <div className='yk-colorwayTitle yk-productFieldWrapper yk-modal-row-spacing'>
                            <span className='fw-bold yk-modalFieldTitle'>
                              Condition :&nbsp;
                            </span>
                            <span className='yk-order-title-size yk-fieldValueColor yk-modalFieldTitle'>
                              {shoeDetailsData[0]?.[
                                'OrdersShoeDetails.conditionName'
                              ] ? (
                                <>
                                  {
                                    shoeDetailsData[0]?.[
                                      'OrdersShoeDetails.conditionName'
                                    ]
                                  }
                                </>
                              ) : (
                                '--'
                              )}
                            </span>
                          </div>
                        </div>

                        <div className='col-lg-6 col-md-6 col-sm-12 col-12'>
                          <div className='d-flex yk-colorwayTitle yk-modal-row-spacing'>
                            <div className='fw-bold yk-modalFieldTitle'>
                              Colorway :&nbsp;
                            </div>
                            <div
                              className='yk-modalInput yk-fieldValueColor yk-modalFieldTitle'
                              title={
                                shoeDetailsData[0]?.[
                                  'OrdersShoeDetails.colorway'
                                ] || '--'
                              }>
                              {shoeDetailsData[0]?.[
                                'OrdersShoeDetails.colorway'
                              ] || '--'}
                            </div>
                          </div>
                        </div>
                        {orderDetails !== 'shoeDetails' &&
                          orderDetails !== 'withdrawalDetails' &&
                          shoeDetailsData[0]?.['OrdersShoeDetails.status'] ===
                            'Sold' && (
                            <div className='col-lg-6 '>
                              <div className='d-flex yk-colorwayTitle '>
                                <div className='fw-bold yk-modalFieldTitle'>
                                  Sale Location : &nbsp;
                                </div>
                                <div
                                  className='yk-modalInput yk-modalLocationInput yk-modalFieldTitle yk-fieldValueColor'
                                  title={
                                    shoeDetailsData[0]?.[
                                      'OrdersShoeDetails.saleLocation'
                                    ]
                                      ? shoeDetailsData[0]?.[
                                          'OrdersShoeDetails.saleLocation'
                                        ]
                                      : '--'
                                  }>
                                  {shoeDetailsData[0]?.[
                                    'OrdersShoeDetails.saleLocation'
                                  ]
                                    ? shoeDetailsData[0]?.[
                                        'OrdersShoeDetails.saleLocation'
                                      ]
                                    : '--'}
                                </div>
                              </div>
                            </div>
                          )}
                      </div>
                    </div>
                    {orderDetails !== 'shoeDetails' &&
                      orderDetails !== 'orderDetails' &&
                      orderDetails !== 'withdrawalDetails' &&
                      !!shoeDetailsData[0]?.[
                        'OrdersShoeDetails.costPerItem'
                      ] && (
                        <div className='col-12'>
                          <div className='yk-sizeTableWrapper'>
                            {shoeDetailsData[0]?.[
                              'OrdersShoeDetails.status'
                            ] === 'Pending' ||
                              (shoeDetailsData[0]?.[
                                'OrdersShoeDetails.status'
                              ] === 'Active' && (
                                <VirtualTable
                                  headers={columns}
                                  rowData={tableData}
                                />
                              ))}
                          </div>
                        </div>
                      )}
                    {orderDetails == 'withdrawalDetails' &&
                      enableMoveToYKInv == true && (
                        <div className='col-12'>
                          <div className='yk-sizeTableWrapper'>
                            <VirtualTable
                              headers={withdrawalInventoryColumns}
                              rowData={tableData}
                            />
                          </div>
                        </div>
                      )}
                  </div>
                </div>
                <div
                  className={`shoe-journy-wrapper ${
                    isShoeCatalog ? 'd-none' : ''
                  }`}>
                  <div className='heading-wrapper'>
                    <h3 className='heading'>Shoe journey</h3>
                  </div>
                  <div className='shoe-journy-inner-wrapper'>
                    {(!!shoeDetailsIsLoading ||
                      !!otherShoeDetailsIsLoading) && <CircleLoader />}
                    {!shoeDetailsIsLoading && shoeDetailsData?.length === 0 && (
                      <NoDataFound />
                    )}

                    {shoeDetailsData?.map((item: any, index: any) => {
                      const eventType = item?.['OrdersShoeDetails.eventType'];
                      const isTransfer =
                        eventType === SHOE_JOURNEY_TYPES?.TRANSFER_REJECTED ||
                        eventType === SHOE_JOURNEY_TYPES?.TRANSFER_ACCEPTED
                          ? true
                          : false;
                      const isProductMissing =
                        eventType === SHOE_JOURNEY_TYPES?.PRODUCT_MISSING;
                      const isProductCleared =
                        eventType === SHOE_JOURNEY_TYPES?.PRODUCT_CLEARED;
                      const price =
                        item?.['OrdersShoeDetails.description']?.split('/');
                      const toPrice = price?.[0];
                      const fromPrice = price?.[1];
                      const toCpi = price?.[2];
                      const fromCpi = price?.[3];
                      const steperCircle =
                        index === 0
                          ? `journey-step journey-step-1`
                          : `journey-step journey-step-2`;
                      const shoeStatusMessageClass =
                        eventType === SHOE_JOURNEY_TYPES.SHOPIFY_ERROR
                          ? 'btn btn-price red'
                          : 'btn btn-price green';
                      const shoesStatusMessage =
                        eventType === SHOE_JOURNEY_TYPES.SHOPIFY_ERROR
                          ? 'Shopify Error'
                          : eventType === SHOE_JOURNEY_TYPES.REJECTED
                          ? 'Rejected'
                          : item?.['OrdersShoeDetails.eventType'];
                      const imageToUse: any = isTransfer
                        ? LocationIcon
                        : isProductMissing
                        ? missingIcon
                        : isProductCleared
                        ? clearedIcon
                        : PriceIcon;
                      const status1 =
                        item?.['OrdersShoeDetails.description']?.split('/')[0];
                      const status2 =
                        item?.['OrdersShoeDetails.description']?.split(
                          '/'
                        )?.[1];

                      return (
                        <>
                          {eventType && (
                            <div key={index} className={steperCircle}>
                              <div className='journey-inner-wrapper'>
                                <h6 className='journey-title'>
                                  {item?.['OrdersShoeDetails.userName'] || '--'}{' '}
                                  changed
                                  <span className='date'>
                                    <Image
                                      src={CalendarIcon}
                                      className='img-fluid'
                                      alt=''></Image>
                                    {item?.[
                                      'OrdersShoeDetails.eventTime.second'
                                    ]
                                      ? format(
                                          new Date(
                                            item?.[
                                              'OrdersShoeDetails.eventTime.second'
                                            ]
                                          ),
                                          FNS_DATE_FORMAT
                                        )
                                      : '--'}
                                  </span>
                                  <span className='time'>
                                    <Image
                                      src={TimeIcon}
                                      className='img-fluid'
                                      alt=''></Image>

                                    {item?.[
                                      'OrdersShoeDetails.eventTime.second'
                                    ]
                                      ? format(
                                          new Date(
                                            item?.[
                                              'OrdersShoeDetails.eventTime.second'
                                            ]
                                          ),
                                          FNS_TIME_FORMAT
                                        )
                                      : '--'}
                                  </span>
                                </h6>

                                {eventType ===
                                  SHOE_JOURNEY_TYPES.ADDED_TO_YK_INV && (
                                  <div className='details-row ms-0 d-flex yk-addToYkInventoryWrapper'>
                                    <Image
                                      src={barcodeGenIcon}
                                      className='img-fluid'
                                      alt='reverse-img'
                                    />

                                    <span className='dFlexCenter green-label'>
                                      Added to YK Inventory
                                    </span>

                                    <span className='dFlexCenter invoice-number-text'>
                                      Old Barcode: &nbsp;&nbsp;
                                      <a
                                        title={
                                          'Click here to load shoe journey.'
                                        }
                                        className='yk-redLink'
                                        onClick={(e) =>
                                          appendShoeJourney(
                                            item?.[
                                              'OrdersShoeDetails.description'
                                            ]
                                          )
                                        }
                                        type='button'>
                                        {
                                          item?.[
                                            'OrdersShoeDetails.description'
                                          ]
                                        }
                                      </a>
                                    </span>
                                  </div>
                                )}

                                {eventType ===
                                  SHOE_JOURNEY_TYPES.MOVED_TO_YK_INV && (
                                  <div className='details-row ms-0 d-flex yk-addToYkInventoryWrapper'>
                                    <Image
                                      src={barcodeGenIcon}
                                      className='img-fluid'
                                      alt='reverse-img'
                                    />

                                    <span className='dFlexCenter green-label'>
                                      Barcode Generated
                                    </span>
                                    <span className='dFlexCenter invoice-number-text'>
                                      New Barcode:&nbsp;&nbsp;
                                      <a
                                        className='yk-redLink'
                                        title={'Click here to switch.'}
                                        onClick={(e) =>
                                          switchShoeJourney(
                                            item?.[
                                              'OrdersShoeDetails.description'
                                            ]
                                          )
                                        }
                                        type='button'>
                                        {
                                          item?.[
                                            'OrdersShoeDetails.description'
                                          ]
                                        }
                                      </a>
                                    </span>
                                  </div>
                                )}

                                {(eventType ===
                                  SHOE_JOURNEY_TYPES.INVENTORY_ADDITION ||
                                  eventType ===
                                    SHOE_JOURNEY_TYPES.PRODUCT_SOLD ||
                                  eventType === SHOE_JOURNEY_TYPES.APPROVED ||
                                  eventType ===
                                    SHOE_JOURNEY_TYPES.PAYOUT_AMOUNT_UPDATED ||
                                  eventType === SHOE_JOURNEY_TYPES.REJECTED ||
                                  isTransfer ||
                                  eventType ===
                                    SHOE_JOURNEY_TYPES.SHOPIFY_ERROR) &&
                                  !(isProductMissing || isProductCleared) && (
                                    <div className='details-row d-flex ms-0'>
                                      <Image
                                        src={StatusIcon}
                                        className='img-fluid'
                                        alt=''></Image>
                                      <button className='btn btn-status'>
                                        status
                                      </button>
                                      <button
                                        className={shoeStatusMessageClass}>
                                        {shoesStatusMessage || '--'}
                                      </button>
                                    </div>
                                  )}
                                {(eventType ===
                                  SHOE_JOURNEY_TYPES.SELLER_PRICE_CHANGE ||
                                  eventType ===
                                    SHOE_JOURNEY_TYPES.ORDER_PLACED ||
                                  eventType ===
                                    SHOE_JOURNEY_TYPES.PAYOUT_PAID ||
                                  isTransfer ||
                                  isProductMissing ||
                                  isProductCleared) && (
                                  <>
                                    <div className='details-row ms-0'>
                                      <Image
                                        src={imageToUse}
                                        className='img-fluid'
                                        alt=''></Image>
                                      <button className='btn btn-status'>
                                        {isTransfer
                                          ? 'location'
                                          : isProductMissing
                                          ? 'missing'
                                          : isProductCleared
                                          ? 'cleared'
                                          : 'price'}
                                      </button>
                                      <span className='text'>from</span>
                                      <button
                                        className={`btn btn-price ${
                                          isProductMissing ? 'green' : 'red'
                                        }`}>
                                        {isTransfer
                                          ? fromPrice
                                          : isProductMissing
                                          ? 'Active'
                                          : isProductCleared
                                          ? 'Missing'
                                          : convertPriceToUSFormat(fromPrice)}
                                      </button>
                                      <span className='text'>to</span>
                                      <button
                                        className={`btn btn-price ${
                                          isProductMissing ? 'red' : 'green'
                                        }`}>
                                        {isTransfer
                                          ? toPrice
                                          : isProductMissing
                                          ? 'Missing'
                                          : isProductCleared
                                          ? 'Active'
                                          : convertPriceToUSFormat(toPrice) ||
                                            '--'}
                                      </button>
                                    </div>
                                    {!!fromCpi &&
                                      !!toCpi &&
                                      !(
                                        isProductMissing || isProductCleared
                                      ) && (
                                        <div className='details-row ms-0'>
                                          <Image
                                            src={imageToUse}
                                            className='img-fluid'
                                            alt=''></Image>
                                          <button className='btn btn-status'>
                                            Cost/Item
                                          </button>
                                          <span className='text'>from</span>
                                          <button className='btn btn-price red'>
                                            {convertPriceToUSFormat(fromCpi) ||
                                              '--'}
                                          </button>
                                          <span className='text'>to</span>
                                          <button className='btn btn-price green'>
                                            {convertPriceToUSFormat(toCpi) ||
                                              '--'}
                                          </button>
                                        </div>
                                      )}
                                  </>
                                )}

                                {eventType ===
                                  SHOE_JOURNEY_TYPES.WITHDRAW_CHANGE && (
                                  <div className='details-row ms-0 dFlexCenter'>
                                    <Image
                                      src={StatusIcon}
                                      className='img-fluid'
                                      alt=''></Image>
                                    <button className='btn btn-status'>
                                      status
                                    </button>{' '}
                                    <span className='span-text'>from</span>
                                    <button
                                      className={`btn btn-price ${statusClassList[status1]}`}>
                                      {status1}
                                    </button>
                                    <span className='span-text'>to</span>
                                    <button
                                      className={`btn btn-price ${statusClassList[status2]}`}>
                                      {status2}
                                    </button>
                                  </div>
                                )}
                                {eventType ===
                                  SHOE_JOURNEY_TYPES.WITHDRAWN_INVOICE_GENERATED && (
                                  <div className='details-row ms-0 d-flex'>
                                    <Image
                                      src={invoiceIcon}
                                      className='img-fluid'
                                      alt='invoice-img'
                                    />

                                    <span className='dFlexCenter warning-label'>
                                      Invoice Generated
                                    </span>

                                    <span className='dFlexCenter invoice-number-text'>
                                      Invoice No &nbsp;:&nbsp;
                                      {status1}
                                      {status2
                                        ? ` / Draft Order :${status2}`
                                        : ''}
                                    </span>
                                  </div>
                                )}

                                {eventType ===
                                  SHOE_JOURNEY_TYPES.WITHDRAWN_PAYMENT_RECEIVED && (
                                  <div className='details-row d-flex ms-0'>
                                    <Image
                                      src={paymentReceivedIcon}
                                      className='img-fluid'
                                      alt='image'
                                    />
                                    <div className='dFlexCenter paymentReceivedInfoWrapper'>
                                      <span className='paymentReceivedInfo'>
                                        <span className='green-label mb-0'>
                                          Payment received&nbsp;
                                        </span>

                                        <span className='invoice-number-text yk-paymentInvoiceText mb-0'>
                                          for Invoice No.
                                        </span>
                                      </span>

                                      <span className=' invoice-number-text'>
                                        &nbsp;
                                        {status1}
                                        {status2
                                          ? ` / Draft Order :${status2}`
                                          : ''}
                                      </span>
                                    </div>
                                  </div>
                                )}
                                {/* Kept Commented code for future use */}
                                {/* Added Missing Pair Shoe Details modal changes */}
                                {/* <div className='details-row ms-0 dFlexCenter'>
                                  <Image
                                    src={clearedIcon}
                                    className='img-fluid'
                                    alt=''></Image>
                                  <button className='btn btn-status'>
                                    Cleared
                                  </button>
                                  <span className='span-text'>from</span>
                                  <button
                                    className={`btn btn-price activeBadge ${statusClassList[status1]}`}>
                                    Missing
                                  </button>
                                  <span className='span-text'>to</span>
                                  <button
                                    className={`btn btn-price pending ${statusClassList[status2]}`}>
                                    Active
                                  </button>
                                </div>
                                <div className='details-row ms-0 dFlexCenter'>
                                  <Image
                                    src={missingIcon}
                                    className='img-fluid'
                                    alt=''></Image>
                                  <button className='btn btn-status'>
                                    Missing
                                  </button>
                                  <span className='span-text'>from</span>
                                  <button
                                    className={`btn btn-price activeBadge ${statusClassList[status1]}`}>
                                    Active
                                  </button>
                                  <span className='span-text'>to</span>
                                  <button
                                    className={`btn btn-price pending ${statusClassList[status2]}`}>
                                    Missing
                                  </button>
                                </div> */}
                              </div>
                            </div>
                          )}
                        </>
                      );
                    })}
                  </div>
                </div>
              </div>
              {shoeDetailsData[0]?.['OrdersShoeDetails.status'] ==
                'Fees Pending' &&
                modalUsedFor === 'withDrawal' && (
                  <div className={`modal-action-wrapper`}>
                    {enableMoveToYKInv == true && (
                      <>
                        <div>
                          <button
                            type='button'
                            className='btn yk-blackBtn confirm_Move_YkInv'
                            onClick={() => setEnableMoveToYKInv(false)}>
                            Cancel
                          </button>
                        </div>
                        <div>
                          <button
                            type='button'
                            className='btn modal-btn-submit yk-redBtn confirm_Move_YkInv'
                            onClick={() => handleMoveToYKInv(true, tableData)}>
                            Move To YK Inventory
                          </button>
                        </div>
                      </>
                    )}
                    {enableMoveToYKInv == false && (
                      <>
                        <div className=''>
                          {(new Date().getTime() -
                            new Date(
                              shoeDetailsData?.[0]?.[
                                'OrdersShoeDetails.eventTime.second'
                              ]
                            ).getTime()) /
                            TIME_TO_DAYS_CONVERSION >
                            DAYS_LIMIT_FOR_MOVE_TO_YK_INV && (
                            <button
                              type='button'
                              className='btn yk-blackBtn'
                              data-bs-dismiss='modal'
                              onClick={() => setEnableMoveToYKInv(true)}>
                              Move To YK Inventory
                            </button>
                          )}
                        </div>
                        <div>
                          <button
                            type='button'
                            className='btn modal-btn-submit yk-redBtn'
                            onClick={() => handleMarkPaid(true)}>
                            Mark As Paid
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                )}
            </div>
          )}
        </div>
      </Modal>

      <Notification
        showSuccessPopup={isVisibleMessage}
        handleSnackbarClose={handleSnackbarClose}
        severityType={severityType}
        message={msg}
        className='yk-shoesize-alert-wrapper'
      />
    </div>
  );
};

export default OrderDetailsModal;
