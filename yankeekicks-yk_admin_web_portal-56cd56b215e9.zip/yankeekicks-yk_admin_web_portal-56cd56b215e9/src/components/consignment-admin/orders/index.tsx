import React, { useState, useEffect, useMemo } from 'react';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import Image from 'next/image';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import Pagination from 'components/common/pagination';
import SearchComp from 'components/common/search';
import {
  getLocationsListForConsignmentReviewPopup,
  getWeeklyOrders,
  getWeeklyOrdersTotalCount,
} from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import {
  FNS_DATE_FORMAT,
  NOTIFICATION_SOMETHING_WENT_WRONG,
} from 'utils/constants';
import { ValidationOnlyAlphaNumbers } from 'utils/validators';
import { ORDERS_LABEL } from '../constants';
import ExportsTypes from 'components/common/exports-types';
import Sortings from 'components/common/sortings';
import VirtualTable from 'components/common/table';
import ProductFilters from 'components/common/filters/product-filter';
import { Button } from '@mui/material';
import ConfirmPopup from 'components/common/confirm-popup';
import { COMPLETE_PAYMENT_SUCCESS } from 'components/yk-admin/constants';
import Notification from 'components/common/notification';
import { DISABLE_LOADER, ENABLE_LOADER } from 'actions/loader';
import { useDispatch } from 'react-redux';
import { postCompletePayout } from 'services/payouts';
import { getBasePath } from 'utils/util';
import PayoutDetailsHeader from '../payouts/payout-header';
import Breadcrumbs from 'components/common/breadcrumbs';
import filterIcon from 'assets/images/filter-icon.png';

const Orders = (props: any) => {
  const { showConsginorOrders = false } = props;
  const router = useRouter();
  const dispatch = useDispatch();
  const consignorId: any = showConsginorOrders
    ? router.query.consignorId
    : null;
  const [userInput, setUserInput] = useState('');
  const [weeklyOrders, setWeeklyOrders] = useState([]);
  const [countForPagination, setCountForPagination] = useState(0);
  const [ordersOffset, setOrdersOffset] = useState(0);
  const [selectedSort, setSelectedSort] = useState('orderDesc');
  const [showFilters, setShowFilters] = useState(false);
  const [showError, setShowError] = useState<any>('');
  const [selectedPayoutStatus, setSelectedPayoutStatus] = useState<any>([]);
  const [checked, setChecked] = useState({
    Pending: false,
    Paid: false,
    Sold: false,
  });
  const [filterInput, setFilterInput] = useState<any>({});
  const [clearDisable, setClearDisable] = useState(true);
  const [selectedCommisonType, setSelectedCommisonType] = useState<any>([]);
  const [isPDFExport, setIsPDFExport] = useState(true);
  const [showDetailsModal, setShowDetailsModal] = useState<any>(false);
  const [isVisibleMessage, setIsVisibleMessage] = useState<any>(false);
  const [severityType, setSeverityType] = useState<any>('');
  const [notificationMessage, setNotificationMessage] = useState<any>('');
  const [tansactionId, setTansactionId] = useState<any>('');
  const [completePaymentData, setCompletePaymentData] = useState<any>([]);
  const [withdrawalCurrentAmount, setWithdrawalCurrentAmount] =
    useState<any>(0);

  const { pathname } = router;
  const currentPath = pathname;
  const pageName = showConsginorOrders ? 'Payout Details' : ORDERS_LABEL;
  // removed pagination for payout orders
  const limitForQuery = showConsginorOrders ? 1000 : 10;
  const queryPayload = {
    userInput,
    selectedSort,
    currentPath,
    filterInput,
  };
  const getLocationsListQuery: any =
    getLocationsListForConsignmentReviewPopup();
  const {
    resultSet: locationList,
    isLoading: getLocationsListIsLoading,
    error: getLocationsListError,
  }: any = useCubeQuery(getLocationsListQuery);
  const ordersQuery: any = getWeeklyOrders(
    userInput,
    selectedSort,
    currentPath,
    filterInput,
    ordersOffset,
    limitForQuery,
    consignorId
  );
  const paginationCountQuery: any = getWeeklyOrdersTotalCount(
    userInput,
    currentPath,
    filterInput,
    consignorId
  );
  const exportsOrdersQuery: any = getWeeklyOrders(
    userInput,
    selectedSort,
    currentPath,
    filterInput,
    null,
    0,
    consignorId
  );

  const {
    resultSet: ordersResultsSet,
    isLoading: ordersIsLoading,
    error: ordersError,
  }: any = useCubeQuery(ordersQuery);
  const {
    resultSet: ordersCountResultSet,
    isLoading: ordersCountIsLoading,
    error: ordersCountError,
  }: any = useCubeQuery(paginationCountQuery);

  const { resultSet: exportsResultsSet }: any = useCubeQuery(
    exportsOrdersQuery,
    { skip: isPDFExport }
  );
  useEffect(() => {
    const data = ordersResultsSet?.loadResponses[0]?.data;
    if (data) {
      const checkBoxAdded = addCheckPropertyToData(data);
      setWeeklyOrders(checkBoxAdded);
      setCompletePaymentData(
        checkBoxAdded
          .filter((row: any) => row.isChecked === true)
          .map((row: any) => Number(row?.['WeeklyOrderData.orderId']))
      );
    } else {
      setWeeklyOrders([]);
    }
  }, [ordersResultsSet]);

  useEffect(() => {
    let countData =
      +ordersCountResultSet?.loadResponses[0]?.data[0]?.[
        'WeeklyOrderData.count'
      ] || 0;
    setCountForPagination(countData);
  }, [ordersCountResultSet]);

  const addCheckPropertyToData = (tempData: any) => {
    return tempData.map((lineItem: any) => {
      return {
        ...lineItem,
        isChecked:
          lineItem['WeeklyOrderData.processed'] === true ? true : false, // keep the logic for checking elements
        checkboxDisabled: true,
      };
    });
  };

  const onClickPDFExport = () => {
    setIsPDFExport(false);
    setTimeout(() => {
      setIsPDFExport(true);
    }, 100);
  };
  const userInputChangeHandler = (event: any) => {
    setUserInput(event.target.value);
    setOrdersOffset(0);
  };

  const columns = useMemo(
    () => [
      {
        title: 'Order Number',
        value: 'WeeklyOrderData.orderId',
      },
      {
        title: 'Order Id',
        value: 'WeeklyOrderData.sellerorderId',
      },
      {
        title: 'Payout Amount',
        value: 'WeeklyOrderData.weeklyOrderData',
        prefix: '$',
        methodToApply: 'toFix',
        defaultValue: '$0.00',
      },
      {
        title: 'Order Amount',
        value: 'WeeklyOrderData.totalSellingPrice',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Sale Location',
        value: 'WeeklyOrderData.saleLocation',
        type: 'saleLocation',
        success: 'Online',
        danger: 'Store',
      },
      {
        title: 'Quantity',
        value: 'WeeklyOrderData.quantitySum',
      },
      {
        title: 'Date',
        type: 'date',
        format: FNS_DATE_FORMAT,
        value: 'WeeklyOrderData.completedAt',
      },
      {
        title: 'Status',
        type: 'statusList',
        value: 'WeeklyOrderData.adminPayoutStatus',
        success: 'Paid',
        danger: 'Pending',
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          router.push(
            getBasePath(
              `orders/${data?.['WeeklyOrderData.sellerorderId'].replace(
                '#',
                ''
              )}`
            )
          );
        },
        value: 'View',
      },
    ],
    []
  );

  const columnsForPayout = useMemo(
    () => [
      {
        type: 'payoutCheckbox',
        title: '',
        checked: 'isChecked',
        value: 'WeeklyOrderData.orderId',
        isDisabled: 'checkboxDisabled',
        removeCheckAll: true,
      },
      {
        title: 'Order Id',
        value: 'WeeklyOrderData.orderId',
      },
      {
        title: 'Payout Amount',
        value: 'WeeklyOrderData.weeklyOrderData',
        prefix: '$',
        methodToApply: 'toFix',
        defaultValue: '$0.00',
      },
      {
        title: 'Order Amount',
        value: 'WeeklyOrderData.totalSellingPrice',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Sale Location',
        value: 'WeeklyOrderData.saleLocation',
        type: 'saleLocation',
        success: 'Online',
        danger: 'Store',
      },
      {
        title: 'Quantity',
        value: 'WeeklyOrderData.quantitySum',
      },
      {
        title: 'Date',
        type: 'date',
        format: FNS_DATE_FORMAT,
        value: 'WeeklyOrderData.completedAt',
      },
      {
        title: 'Status',
        type: 'statusList',
        value: 'WeeklyOrderData.payoutStatus',
        success: 'Paid',
        danger: 'Pending',
        greensuccess: 'Sold',
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          router.push(
            getBasePath(
              `payouts/${consignorId}/${data?.[
                'WeeklyOrderData.sellerorderId'
              ].replace('#', '')}`
            )
          );
        },
        value: 'View',
      },
    ],
    []
  );

  const exportHeaders = [
    {
      label: 'Order Number',
      key: 'WeeklyOrderData.orderId',
      type: 'numberToString',
    },
    {
      label: 'Order Id',
      key: 'WeeklyOrderData.sellerorderId',
      type: 'numberToString',
    },
    {
      label: 'Payout Amount',
      key: 'WeeklyOrderData.weeklyOrderData',
      type: 'amount',
    },
    {
      label: 'Order Amount',
      key: 'WeeklyOrderData.totalSellingPrice',
      type: 'amount',
    },
    { label: 'Item Qty', key: 'WeeklyOrderData.quantitySum' },
    { label: 'Sale Location', key: 'WeeklyOrderData.saleLocation' },
    { label: 'Payout Status', key: 'WeeklyOrderData.adminPayoutStatus' },
  ];

  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
  };

  const onCommissionChange = (event: any) => {
    if (selectedCommisonType.includes(event?.target?.name)) {
      let tempOption = [];
      tempOption = selectedCommisonType.filter(
        (data: any) => data !== event?.target?.name
      );
      setSelectedCommisonType(tempOption);
      if (tempOption.length === 0) {
        setClearDisable(true);
      }
    } else {
      setSelectedCommisonType([...selectedCommisonType, event?.target?.name]);
      setClearDisable(false);
    }
  };
  const onPayoutChange = (event: any) => {
    setChecked({ ...checked, [event?.target?.name]: event?.target?.checked });
    var updatedList = [...selectedPayoutStatus];
    if (event.target.checked) {
      updatedList = [...selectedPayoutStatus, event.target.name];
    } else {
      updatedList.splice(selectedPayoutStatus.indexOf(event.target.name), 1);
    }
    setSelectedPayoutStatus(updatedList);
    if (updatedList.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  };
  const onApplyClick = () => {
    const filterPayload = {
      saleLocation: selectedCommisonType,
      status: selectedPayoutStatus,
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setShowFilters(false);
    setOrdersOffset(0);
  };

  const onHandleMessage = (e: any) => {
    const alphaValid = ValidationOnlyAlphaNumbers?.pattern?.value;
    if (e.match(alphaValid) || e === '') {
      setTansactionId(e);
      setShowError('');
    } else setShowError(ValidationOnlyAlphaNumbers?.pattern?.message);
  };

  const onClearFilters = () => {
    setSelectedPayoutStatus([]);
    setChecked({ Pending: false, Paid: false, Sold: false });
    setFilterInput({});
    setShowFilters(false);
    setOrdersOffset(0);
    setClearDisable(true);
  };

  const handleCompletePayout = async () => {
    try {
      dispatch({ type: ENABLE_LOADER });
      const payload = {
        consignorId: consignorId,
        orders: completePaymentData,
        totalPayoutAmt: withdrawalCurrentAmount,
        transactionId: tansactionId,
      };
      let handleAction = await postCompletePayout(payload);
      dispatch({ type: DISABLE_LOADER });
      setIsVisibleMessage(true);
      setSeverityType('success');
      setNotificationMessage(COMPLETE_PAYMENT_SUCCESS);
      setShowDetailsModal(false);
      setTimeout(() => {
        router.push(getBasePath('payouts'));
      }, 1500);
    } catch (e: any) {
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setNotificationMessage(
        e?.response?.data?.message || NOTIFICATION_SOMETHING_WENT_WRONG
      );
      setShowDetailsModal(false);
      console.log('catch error', e);
      dispatch({ type: DISABLE_LOADER });
    }
  };
  const breadCrumbHeaders = {
    title: 'Payouts',
    titleImage: '',
    subTitle: 'Payout Details',

    onClick: () => {
      router?.push(`${getBasePath('payouts')}`);
    },
  };

  return (
    <div className='app-wrapper w-100 orders-page-wrapper'>
      <div className='orders-page-inner-wrapper'>
        <div className='container-fluid'>
          <div className='row'>
            {!!showConsginorOrders && <Breadcrumbs data={breadCrumbHeaders} />}
            <div className='col-lg-12 col-md-12 col-sm-12'>
              <div className='heading-wrapper orders-heading-wrapper'>
                <h2 className='heading'>
                  {pageName}
                  <span className='count-badge'>{countForPagination}</span>
                </h2>
                <div className='d-flex justify-content-between'>
                  {!!showConsginorOrders && (
                    <>
                      <Button
                        className='MuiButtonBase-root float-right complete-payout-btn YKEE-confirm'
                        onClick={() => setShowDetailsModal(true)}
                        disabled={withdrawalCurrentAmount <= 0}>
                        Complete Payout
                      </Button>
                      <Button
                        className='btn-transparent history-btn yk-title-h19'
                        onClick={() =>
                          router.push(
                            getBasePath(`payouts/${consignorId}/history`)
                          )
                        }>
                        Payout History
                      </Button>
                    </>
                  )}
                  {!showConsginorOrders && (
                    <div className='sort-product-wrapper orders-export-btn export-btn text-end'>
                      <ExportsTypes
                        data={
                          (exportsResultsSet?.loadResponses &&
                            exportsResultsSet?.loadResponses[0]?.data) ||
                          []
                        }
                        fileName='orders'
                        headers={exportHeaders}
                        queryPayload={queryPayload}
                        onClickPDFExport={onClickPDFExport}
                        isActive={weeklyOrders && weeklyOrders?.length > 0}
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
            {!!showConsginorOrders && (
              <PayoutDetailsHeader
                setWithdrawalAmount={setWithdrawalCurrentAmount}
              />
            )}
            <div className='search-btn-wrapper'>
              <div className='row'>
                <div className='col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12'>
                  <div className='YKCH-searchingData'>
                    <SearchComp
                      onChangeHandler={userInputChangeHandler}
                      userInput={userInput}
                      optionType='no suggestions'
                      placeholder='Search'
                    />
                  </div>
                </div>
                <div className='col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12'>
                  <div className='consignment-btn-wrapper'>
                    <div className='filter-btn-wrapper YKCH-filterWrapperr d-flex'>
                      <div className='consignment-btn-wrapper me-3'>
                        <Sortings
                          handleChange={sortHandler}
                          defaultSelectedValue={selectedSort}
                        />
                      </div>
                      <ClickAwayListener
                        onClickAway={() => {
                          setShowFilters(false);
                        }}>
                        <div className='YKCH-filterBTNWrapp'>
                          <button
                            className='btn filter-btn'
                            onClick={() => setShowFilters(!showFilters)}>
                            <Image
                              src={filterIcon}
                              alt='filter-btn-icon'
                              className='filter-btn-icon img-fluid'
                            />
                            <span className='filter-btn-text yk-badge-h15'>
                              Filter
                            </span>
                          </button>

                          {showFilters && (
                            <ProductFilters
                              itemKey='orders'
                              data={locationList?.loadResponses[0]?.data}
                              onCommissionChange={onCommissionChange}
                              checkedSkuValue={selectedCommisonType}
                              onApplyClick={onApplyClick}
                              onPayoutChange={onPayoutChange}
                              checkedValue={checked}
                              onClearFilters={onClearFilters}
                              clearDisable={clearDisable}
                            />
                          )}
                        </div>
                      </ClickAwayListener>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <VirtualTable
            loading={ordersIsLoading}
            error={ordersError}
            headers={showConsginorOrders ? columnsForPayout : columns}
            rowData={weeklyOrders}
          />
        </div>

        {countForPagination > 0 && (
          <div className='center-pagination'>
            <Pagination
              lengthOfData={countForPagination}
              itemsPerPage={limitForQuery}
              currentOffset={ordersOffset}
              setOffset={setOrdersOffset}
              isLoading={ordersIsLoading}
            />
          </div>
        )}

        <ConfirmPopup
          showPopup={showDetailsModal}
          handleClose={(e: any) => {
            setShowDetailsModal(false);
            setShowError('');
          }}
          title='Complete Payment'
          message={
            <div>
              <p>Please enter the #Transaction for Reference</p>
              <input
                className='form-control'
                onChange={(e: any) => onHandleMessage(e?.target?.value)}
                maxLength={20}
              />
              <p style={{ color: 'red' }}>{showError}</p>
            </div>
          }
          handleSave={handleCompletePayout}
          handleSaveDisabled={!tansactionId || showError !== ''}
        />

        <Notification
          showSuccessPopup={isVisibleMessage}
          handleSnackbarClose={() => setIsVisibleMessage(false)}
          severityType={severityType}
          message={notificationMessage}
          className='yk-shoesize-alert-wrapper'
        />
      </div>
    </div>
  );
};
export default Orders;
