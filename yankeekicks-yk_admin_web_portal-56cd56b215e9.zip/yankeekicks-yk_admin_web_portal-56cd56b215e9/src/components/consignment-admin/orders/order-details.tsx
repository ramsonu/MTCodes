import React, { useEffect, useState, useMemo } from 'react';
import { useRouter } from 'next/router';
import Breadcrumbs from 'components/common/breadcrumbs';
import Image from 'next/image';
import {
  getLocationsListForConsignmentReviewPopup,
  getOrderDetailsById,
  getTotalOrderDetailsById,
} from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import { useCubeQuery } from '@cubejs-client/react';
import VirtualTable from 'components/common/table';
import OrderDetailsModal from './order-details-modal';
import Sortings from 'components/common/sortings';
import SearchComp from 'components/common/search';
import { ClickAwayListener } from '@mui/material';
import ProductFilters from 'components/common/filters/product-filter';
import filterIcon from 'assets/images/filter-icon.png';
import { CONSIGNMENT_ADMIN_INNER_PATH } from '../constants';
import { convertPriceToUSFormat, getBasePath } from 'utils/util';
import { useSelector, useDispatch } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import ordersIcon from 'assets/images/menu-icons/orders-default.svg';
import OrderDetailsHeader from './order-details-header';

const style = {
  position: 'absolute' as 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '1px solid rgba(0,0,0, .7)',
  boxShadow: 24,
  p: 4,
};

const OrderDetails = (props: any) => {
  const dispatch = useDispatch();
  const router = useRouter();
  const { pathname } = router;
  const { orderId, payoutDate, consignorId }: any = router.query;
  const { showConsginorOrders = false } = props;
  const [orderDetailsData, setOrderDetailsData] = useState<any>([]);
  const [showDetailsModal, setShowDetailsModal] = useState<any>(false);
  const [skuId, setSkuId] = useState('');
  const [lineItemId, setLineItemId] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedSort, setSelectedSort] = useState('sizeAsc');
  const [filterInput, setFilterInput] = useState<any>({});
  const [clearDisable, setClearDisable] = useState(true);
  const [userInput, setUserInput] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<any>([]);
  const [checked, setChecked] = useState({ Pending: false, Paid: false });
  const [selectedCommisonType, setSelectedCommisonType] = useState<any>([]);
  const { filterTypes } = useSelector((state: any) => state.kiosk);

  let isPayoutModuleFlag = !!payoutDate && !!consignorId ? true : false;

  const getLocationsListQuery: any =
    getLocationsListForConsignmentReviewPopup();
  const {
    resultSet: locationList,
    isLoading: getLocationsListIsLoading,
    error: getLocationsListError,
  }: any = useCubeQuery(getLocationsListQuery);

  const orderDetailsByIdQuery: any = getOrderDetailsById(
    orderId,
    filterInput,
    selectedSort,
    userInput,
    payoutDate,
    consignorId
  );

  const totalOrderDetailsByIdQuery: any = getTotalOrderDetailsById(
    orderId,
    consignorId
  );

  const {
    resultSet: orderDetailsResultSet,
    isLoading: orderDetailsIsLoading,
    error: orderDetailsError,
  }: any = useCubeQuery(orderDetailsByIdQuery);

  const { resultSet: totalOrderDetailsResultSet }: any = useCubeQuery(
    totalOrderDetailsByIdQuery
  );

  useEffect(() => {
    const data = orderDetailsResultSet?.loadResponses[0]?.data;
    if (data) {
      setOrderDetailsData(data);
    } else {
      setOrderDetailsData([]);
    }
  }, [orderDetailsResultSet]);

  const headers = !showConsginorOrders
    ? {
        title: 'Orders',
        titleImage: ordersIcon,
        subTitle: orderId,
        onClick: () => {
          router?.push(`${getBasePath('orders')}`);
        },
      }
    : {
        title: 'Payouts',
        subTitle: consignorId,
        nextSubTitle: orderId,
        onClick: () => {
          router?.push(`${getBasePath('payouts')}`);
        },
        onNextClick: () => {
          router.push(`${getBasePath(`payouts/${consignorId}`)}`);
        },
      };

  const viewButtonHandler = (data: any) => {
    setSkuId(data['OrdersViewData.sku']);
    setLineItemId(data['OrdersViewData.consignmentlineitemId_D']);
    setShowDetailsModal(true);
  };

  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
  };

  const onChangeHandler = (event: any) => {
    setUserInput(event.target.value);
  };

  const onStatusChange = (event: any) => {
    setChecked({ ...checked, [event?.target?.name]: event?.target?.checked });
    var updatedList = [...selectedStatus];
    if (event.target.checked) {
      updatedList = [...selectedStatus, event.target.name];
    } else {
      updatedList.splice(selectedStatus.indexOf(event.target.name), 1);
    }
    setSelectedStatus(updatedList);
    if (updatedList?.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  };

  const onCommissionChange = (event: any) => {
    if (selectedCommisonType.includes(event?.target?.name)) {
      let tempOption = [];
      tempOption = selectedCommisonType.filter(
        (data: any) => data !== event?.target?.name
      );
      setSelectedCommisonType(tempOption);
      if (tempOption.length === 0) {
        setClearDisable(true);
      }
    } else {
      setSelectedCommisonType([...selectedCommisonType, event?.target?.name]);
      setClearDisable(false);
    }
  };

  const onApplyFilters = () => {
    let filterPayload = {};
    if (!isPayoutModuleFlag) {
      filterPayload = {
        consignor: selectedCommisonType,
      };
    } else {
      filterPayload = {
        saleLocation: selectedCommisonType,
        brand: filterTypes?.brand,
      };
    }
    if (filterTypes?.brand?.length > 0 || selectedCommisonType?.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
    setFilterInput(filterPayload);
    setUserInput('');
    setShowFilters(false);
  };
  const onClearFilters = () => {
    setShowFilters(false);
    setFilterInput({});
    setClearDisable(true);
    setSelectedCommisonType([]);
    dispatch(actions.clearAllFilters({}));
  };
  const payoutColumns = useMemo(
    () => [
      {
        title: 'SKU',
        value: 'OrdersViewData.sku',
      },
      {
        title: 'Barcode',
        value: 'OrdersViewData.Barcode',
      },
      {
        title: 'Image',
        type: 'image',
        value: 'OrdersViewData.imageUrl',
      },
      {
        title: 'Brand',
        value: 'OrdersViewData.brandName',
      },
      {
        title: 'Product Name',
        value: 'OrdersViewData.Name',
      },
      {
        title: 'Size',
        value: 'OrdersViewData.inventorySize',
      },
      {
        title: 'Condition',
        value: 'OrdersViewData.conditionName',
      },
      {
        title: 'Price',
        value: 'OrdersViewData.TotalpriceUsd',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Consignor',
        value: 'OrdersViewData.userName',
      },
      {
        title: 'Sale Location',
        value: 'OrdersViewData.LocationName',
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          viewButtonHandler(data);
        },
        value: 'View',
      },
    ],
    []
  );
  const columns = useMemo(
    () => [
      {
        title: 'Barcode',
        type: 'copyToClipboard',
        value: 'OrdersViewData.Barcode',
      },
      {
        title: 'Size',
        value: 'OrdersViewData.inventorySize',
      },
      {
        title: 'Condition',
        value: 'OrdersViewData.conditionName',
      },
      {
        title: 'Consignor',
        value: 'OrdersViewData.userName',
      },
      {
        title: 'Selling Price',
        value: 'OrdersViewData.TotalpriceUsd',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Payout',
        value: 'OrdersViewData.payoutAmount',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Cost/Item',
        value: 'OrdersViewData.costperItem',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Transaction Id',
        value: 'OrdersViewData.transactiontraceId',
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          viewButtonHandler(data);
        },
        value: 'View',
      },
    ],
    []
  );

  return (
    <div className='app-wrapper w-100 landing-page-wrapper'>
      <div className='orders-page-wrapper'>
        <div className='orders-page-inner-wrapper'>
          <div className='container-fluid'>
            <div className='row'>
              <Breadcrumbs data={headers} />
              <div className='col-lg-12 col-md-12 col-sm-12 consignmentDetailsHeader'>
                <div className='heading-wrapper orders-heading-wrapper'>
                  <h2 className='heading'>
                    {!isPayoutModuleFlag
                      ? orderId
                      : `(${
                          orderDetailsData?.[0]?.['OrdersViewData.userName']
                            ? orderDetailsData?.[0]?.['OrdersViewData.userName']
                            : '--'
                        }) ${consignorId}`}
                  </h2>
                </div>
                <h5 className='sub-haeding'>Order details</h5>
              </div>
            </div>
            <OrderDetailsHeader />
            <div className='row'>
              <div className='col-lg-12 col-md-12 col-sm-12'>
                <div className='ConsignmentsWrap'>
                  <div className='yk-sku-titles YKCH-detailTitle'>
                    <h2 className='yk-prod-main-titles mt-1 mb-3 YK-LKEEEE'>
                      {!isPayoutModuleFlag ? 'Items' : 'Orders'}
                    </h2>
                  </div>
                  <div className='search-btn-wrapper'>
                    <div className='row'>
                      <div className='col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12'>
                        <div className='YKCH-searchingData'>
                          <SearchComp
                            optionType='change'
                            placeholder='Search'
                            onChangeHandler={onChangeHandler}
                          />
                        </div>
                      </div>
                      <div className='col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12'>
                        <div className='consignment-btn-wrapper'>
                          <Sortings
                            itemKey='orderDetails'
                            handleChange={sortHandler}
                            defaultSelectedValue={selectedSort}
                          />
                          <div className='filter-btn-wrapper YKCH-filterWrapperr'>
                            <ClickAwayListener
                              onClickAway={() => {
                                setShowFilters(false);
                              }}>
                              <div className='YKCH-filterBTNWrapp'>
                                <button
                                  className='btn filter-btn'
                                  onClick={() => setShowFilters(!showFilters)}>
                                  <Image
                                    src={filterIcon}
                                    alt='filter-btn-icon'
                                    className='filter-btn-icon img-fluid'
                                  />
                                  <span className='filter-btn-text yk-badge-h15'>
                                    Filter
                                  </span>
                                </button>
                                {showFilters && (
                                  <ProductFilters
                                    itemKey={
                                      isPayoutModuleFlag
                                        ? 'payoutOrderDetails'
                                        : 'orderDetails'
                                    }
                                    data={
                                      isPayoutModuleFlag
                                        ? locationList?.loadResponses[0]?.data
                                        : orderDetailsData
                                    }
                                    onCommissionChange={onCommissionChange}
                                    checkedSkuValue={selectedCommisonType}
                                    onPayoutChange={onStatusChange}
                                    checkedValue={checked}
                                    onApplyClick={onApplyFilters}
                                    onClearFilters={onClearFilters}
                                    clearDisable={clearDisable}
                                  />
                                )}
                              </div>
                            </ClickAwayListener>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <VirtualTable
                    loading={orderDetailsIsLoading}
                    error={orderDetailsError}
                    headers={isPayoutModuleFlag ? payoutColumns : columns}
                    rowData={orderDetailsData}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {showDetailsModal && (
        <OrderDetailsModal
          showModal={showDetailsModal}
          handleClose={setShowDetailsModal}
          orderDetails='orderDetails'
          skuId={skuId}
          lineItemId={lineItemId}
        />
      )}
    </div>
  );
};
export default OrderDetails;
