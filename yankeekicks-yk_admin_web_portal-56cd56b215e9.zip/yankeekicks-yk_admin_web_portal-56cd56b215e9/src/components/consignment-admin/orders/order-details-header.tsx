import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import { getOrderDetailsHeader } from 'middleware/cubejs-wrapper/cubejs-page-header-query';
import { convertPriceToUSFormat } from 'utils/util';

const OrderDetailsHeader = () => {
  const [shouldFetchDataOfRequestId, setShouldFetchTransfersHeaderData] =
    useState<boolean>(false);
  const router = useRouter();
  let { orderId } = router.query;
  const query: any = getOrderDetailsHeader(orderId);
  const [orderDetailsData, setOrderDetailsData] = useState<any>([]);
  const { resultSet: resultSet }: any = useCubeQuery(query, {
    skip: shouldFetchDataOfRequestId,
  });

  useEffect(() => {
    setOrderDetailsData(resultSet?.loadResponses[0]?.data);
  }, [resultSet]);
  useEffect(() => {
    if (!!router.query.withdrawReqId) {
      setShouldFetchTransfersHeaderData(true);
    } else {
      setShouldFetchTransfersHeaderData(false);
    }
  }, [router?.query]);
  return (
    <div className='ConsignmentsWrap mb-4 d-flex justify-content-between order-details-card-mobile'>
      <div className='row'>
        <div className='col-lg-12 col-md-12 col-sm-12'>
          <div className='heading-wrapper orders-heading-wrapper '>
            <h2 className='yk-badge-h5 heading'>Details</h2>
          </div>
        </div>
      </div>
      <div className='row yk-con-detail-wrap YKCH-noShadeShadow'>
        <div className='col yk-con-lable-wrap'>
          <div className='yk-con-detail-lable'>Sale Location</div>
          <div className='yk-con-detail-status text-success'>
            {' '}
            {orderDetailsData?.[0]?.['OrdersViewData.LocationName']
              ? orderDetailsData?.[0]?.['OrdersViewData.LocationName']
              : '--'}
          </div>
        </div>
        <div className='col yk-con-lable-wrap'>
          <div className='yk-con-detail-lable'>Number of Items</div>
          <div className='yk-con-detail-status'>
            {parseInt(orderDetailsData?.[0]?.['OrdersViewData.count'])
              ? parseInt(orderDetailsData?.[0]?.['OrdersViewData.count'])
              : '--'}
          </div>
        </div>
        <div className='col yk-con-lable-wrap'>
          <div className='yk-con-detail-lable'>Order Amount</div>
          <div className='yk-con-detail-status'>
            {orderDetailsData?.[0]?.['OrdersViewData.TotalpriceUsd']
              ? convertPriceToUSFormat(
                  parseFloat(
                    orderDetailsData?.[0]?.['OrdersViewData.TotalpriceUsd']
                  )?.toFixed(2)
                )
              : '$0.00'}
          </div>
        </div>
        <div className='col yk-con-lable-wrap'>
          <div className='yk-con-detail-lable'>Payout Amount</div>
          <div className='yk-con-detail-status'>
            {orderDetailsData?.[0]?.['OrdersViewData.payoutAmount']
              ? convertPriceToUSFormat(
                  parseFloat(
                    orderDetailsData?.[0]?.['OrdersViewData.payoutAmount']
                  )?.toFixed(2)
                )
              : '$0.00'}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderDetailsHeader;
