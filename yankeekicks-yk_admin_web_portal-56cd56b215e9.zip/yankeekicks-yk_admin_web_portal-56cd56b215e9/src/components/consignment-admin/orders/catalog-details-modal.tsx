import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import Modal from '@mui/material/Modal';
import { Button, Box } from '@mui/material';
import MobileStepper from '@mui/material/MobileStepper';
import KeyboardArrowLeft from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRight from '@mui/icons-material/KeyboardArrowRight';
import { useTheme } from '@mui/material/styles';
import ModalCloseIcon from 'assets/images/modal-close-icon.svg';
import CalendarIcon from 'assets/images/calendar-icon.svg';
import TimeIcon from 'assets/images/time-icon.svg';
import PriceIcon from 'assets/images/price-icon.svg';
import { format } from 'date-fns';
import { FNS_DATE_FORMAT, FNS_TIME_FORMAT } from 'utils/constants';
import VirtualTable from 'components/common/table';
import {
  getBrandNameFromSku,
  postUpdateRetailPrice,
} from 'services/consignment';
import type { NextPage } from 'next';
import { useCubeQuery } from '@cubejs-client/react';
import { shoeDetails } from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import Notification from 'components/common/notification';
import { useRouter } from 'next/router';
import productImg from 'assets/images/big-product-img.svg';
import ImageLoader from 'components/common/image-loader';
import StatusIcon from 'assets/images/status-icon.svg';
import { PREFIX, SHOE_JOURNEY_TYPES } from '../constants';
import CopyToClipboardComponent from 'components/common/copyToClipboard';
import NoDataFound from 'components/common/no-data-found';
import CircleLoader from 'components/common/loader/circular-loader';

interface Props {
  modalData?: Array<any>;
  showModal?: boolean;
  handleClose?: Function;
  skuId?: any;
  lineItemId?: any;
  orderDetails?: string;
  quantity?: any;
  profitRatio?: any;
  isShoeCatalog?: boolean;
  isConsignorFlag?: boolean;
  productInfo?: any;
  showBrand?: boolean;
}

const CatalogDetailsModal = (props: any) => {
  const {
    showModal,
    handleClose,
    orderDetails,
    modalData,
    quantity,
    skuId,
    lineItemId,
    profitRatio,
    isShoeCatalog = false,
    isConsignorFlag = false,
    showBrand = true,
    productInfo = {},
    catalogTableName = 'Catalogue',
  } = props;
  const [tableData, setTableData] = useState([modalData]);
  const [activeStep, setActiveStep] = useState(0);
  const [actionToggler, setActionToggler] = useState(true);
  const [shoeDetailsData, setShoeDetailsData] = useState<any>([]);
  const [skuDetailsImages, setSkuDetailsImages] = useState<any>([]);
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [severityType, setSeverityType] = useState<string>('');
  const [msg, setMsg] = useState<string>('');
  const [sellingPrice, setSellingPrice] = useState(
    modalData?.['InventorySkuDetails.retailPrice_D']
  );
  const router = useRouter();
  const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
  const calculate = (profitRatio / 100) * sellingPrice;
  const minimum = calculate > 25 ? calculate : 25;
  const payCalculated = sellingPrice - minimum;
  const maxSteps = skuDetailsImages?.length;
  const theme = useTheme();
  const [payoutPerItem, setPayoutPerItem] = useState(payCalculated);
  const [totalPrice, setTotalPrice] = useState(
    tableData?.length * payCalculated
  );
  const { pathname } = router;
  const currentPath = pathname;

  useEffect(() => {
    const getImages = async () => {
      const param = { id: skuId };
      try {
        await getBrandNameFromSku(param).then((response: any) => {
          const imageUrls = response?.data[0]?.catalogueImageList;
          setSkuDetailsImages(imageUrls);
        });
      } catch (e: any) {
        console.log(e);
      }
    };
    getImages();
  }, [skuId]);

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleonChange = (data: any, i: any) => {
    const sellingPriceRegex = /^[0-9-.]*$/;
    const typing = data?.currentTarget?.value;
    if (typing.match(sellingPriceRegex)) {
      setSellingPrice(data?.currentTarget?.value);
      const calculate = (profitRatio / 100) * data?.currentTarget?.value;
      const minimum = calculate > 25 ? calculate : 25;
      const payCalculated = data?.currentTarget?.value
        ? data?.currentTarget?.value - minimum
        : 0;
      const qty = +tableData[0]['InventorySkuDetails.variantCount'];
      const total = qty * payCalculated;
      setTotalPrice(total);
      if (!data?.currentTarget?.value) {
        setPayoutPerItem(0);
      }
      setPayoutPerItem(payCalculated);
    }
  };

  const updateRetailPrice = async (price: any) => {
    const param = {
      createdBy: userDetails?.user_id,
      id: lineItemId,
      retailPrice: +price,
      updatedBy: userDetails?.user_id,
      userId: userDetails?.user_id,
    };
    try {
      await postUpdateRetailPrice(param);
      setSeverityType('success');
      setMsg('Price Updated');
      setIsVisibleMessage(true);
      handleClose(true);
    } catch (e: any) {
      setSeverityType('error');
      setMsg('Something went wrong');
      setIsVisibleMessage(true);
      handleClose();
      console.log(e);
    }
  };
  return (
    <div className={`modal-wrapper`}>
      <Modal
        open={showModal}
        onClose={handleClose}
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'
        className='yk-product-details-modal'>
        <div
          className={`yk-shoe-details-wrapper modal-outer-wrapper YKCH-autoHeight  ${
            isShoeCatalog ? 'minHeightAuto' : ''
          }`}>
          <div className='modal-inner-wrapper container'>
            <div className='modal-heading-wrapper'>
              <div className='heading-wrapper'>
                <div className='d-flex align-items-center'>
                  <h3 className='heading d-inline-block mb-0'>Shoe details</h3>
                </div>
                <button
                  className='btn btn-modal-close'
                  onClick={() => handleClose(false)}>
                  <Image
                    src={ModalCloseIcon}
                    className='img-fluid'
                    alt=''></Image>
                </button>
              </div>
            </div>
            <div className='modal-body-wrapper row'>
              <div className='product-description-wrapper'>
                <div className='row'>
                  <div className='col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12'>
                    <Box
                      sx={{ maxWidth: 135, flexGrow: 1 }}
                      className='mx-auto position-relative'>
                      <ImageLoader
                        src={skuDetailsImages?.[activeStep]}
                        fallbackImg={productImg}
                        alt='cart-img'
                        className='img-fluid d-block m-auto img-product-logo'
                      />
                      <MobileStepper
                        steps={maxSteps}
                        position='static'
                        activeStep={activeStep}
                        nextButton={
                          <Button
                            className='next-button'
                            size='small'
                            onClick={handleNext}
                            disabled={activeStep === maxSteps - 1}>
                            {theme.direction === 'rtl' ? (
                              <KeyboardArrowLeft />
                            ) : (
                              <KeyboardArrowRight />
                            )}
                          </Button>
                        }
                        backButton={
                          <Button
                            className='back-button'
                            size='small'
                            onClick={handleBack}
                            disabled={activeStep === 0}>
                            {theme.direction === 'rtl' ? (
                              <KeyboardArrowRight />
                            ) : (
                              <KeyboardArrowLeft />
                            )}
                          </Button>
                        }
                      />
                    </Box>
                  </div>
                  <div className='col-xl-9 col-lg-9 col-md-9 col-sm-12 col-12'>
                    {showBrand == true && (
                      <p className='mb-0'>
                        {productInfo[`${catalogTableName}.brand`] || '--'}
                      </p>
                    )}
                    <h3 className='heading'>
                      {/*   {productInfo[`${catalogTableName}.brand`]} &nbsp; */}
                      {productInfo[`${catalogTableName}.itemName`]}
                    </h3>
                    <div className='row mt-3'>
                      <div className='col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12 YKCH-newDetails'>
                        <p className='sku-details yk-myouwnData mb-2 yk-badge-h16'>
                          <span className='yk-order-details fw-bold'>
                            SKU :&nbsp;
                          </span>
                          <span className='sku-number' id='sku'>
                            <span className='YKCH-nowData yk-fieldValueColor'>
                              {productInfo[`${catalogTableName}.style`] || '--'}
                            </span>
                          </span>
                          <CopyToClipboardComponent
                            copyText={productInfo[`${catalogTableName}.style`]}
                          />
                        </p>
                      </div>
                      <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12'>
                        <span className='fw-bold yk-modalFieldTitle yk-badge-h16'>
                          Release Date :&nbsp;
                        </span>
                        <span className='yk-badge-h16 yk-fieldValueColor'>
                          {productInfo[`${catalogTableName}.releaseDate`]
                            ? format(
                                new Date(
                                  productInfo[`${catalogTableName}.releaseDate`]
                                ),
                                FNS_DATE_FORMAT
                              )
                            : '--'}
                        </span>
                      </div>

                      <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                        <div className='d-flex align-items-center mt-2 yk-colorwayTitle'>
                          <div className='fw-bold yk-modalFieldTitle yk-badge-h16'>
                            Colorway :&nbsp;
                          </div>
                          <div
                            className='yk-modalInput yk-badge-h16 yk-fieldValueColor'
                            title={
                              productInfo[`${catalogTableName}.colorway`] ||
                              '--'
                            }>
                            {productInfo[`${catalogTableName}.colorway`] ||
                              '--'}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default CatalogDetailsModal;
