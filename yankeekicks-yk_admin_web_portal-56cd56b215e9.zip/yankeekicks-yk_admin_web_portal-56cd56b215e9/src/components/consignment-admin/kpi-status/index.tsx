import React, { useState, useEffect } from 'react';
import Loader from 'components/common/loader';
import Image from 'next/image';
import { getConsignmentKPIQuery } from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import { STATUS_TYPE } from '../constants';
import ActiveImg from 'assets/images/active-kpi.svg';
import SoldImg from 'assets/images/sold-kpi.svg';
import PayoutImg from 'assets/images/payout-kpi.svg';
import { useCubeQuery } from '@cubejs-client/react';
import { format } from 'date-fns';
import { FNS_DATE_FORMAT } from 'utils/constants';
import { convertPriceToUSFormat, getDifferenceDate, getMyId } from 'utils/util';
const KpiStatus = (props: any) => {
  const [consignmentKPIData, setConsignmentKPIData] = useState<any>([]);
  const oneMonthPrev = getDifferenceDate(new Date(), 30);
  const oneMonthPrevFormated = format(oneMonthPrev, FNS_DATE_FORMAT);
  const todaysDate = format(new Date(), FNS_DATE_FORMAT);

  const consignmentKPIQuery: any = getConsignmentKPIQuery(
    oneMonthPrevFormated,
    todaysDate,
    getMyId
  );

  const {
    resultSet: consignmentKPIResultSet,
    isLoading: isConsignmentKPILoading,
  }: any = useCubeQuery(consignmentKPIQuery);

  useEffect(() => {
    setConsignmentKPIData(consignmentKPIResultSet?.loadResponses[0]?.data);
  }, [consignmentKPIResultSet]);

  const renderKpi = (
    isLaodingData: any,
    imagePath: any,
    statusType: string,
    data: any
  ) => {
    return (
      <>
        <div className='col-sm-12 col-md-6 col-lg-4'>
          <div className='card status-card'>
            <div className='card-body'>
              <div className='card-heading-wrapper'>
                <Loader isLoading={isLaodingData}></Loader>

                <div className='icon-wrapper'>
                  <Image src={imagePath} alt='' className='img-fluid' />
                  <p className='card-text'>{statusType}</p>
                </div>
                <h5 className='card-title'>{data}</h5>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  };
  return (
    <div className='status-wrapper kpi-wrapper'>
      <div className='row'>
        {renderKpi(
          isConsignmentKPILoading,
          SoldImg,
          STATUS_TYPE?.SOLD,
          consignmentKPIData?.length &&
            consignmentKPIData[0] &&
            consignmentKPIData[0]['ConsignmentLineItem.sellCount'] !== null
            ? consignmentKPIData[0]['ConsignmentLineItem.sellCount']
            : 0
        )}
        {renderKpi(
          isConsignmentKPILoading,
          ActiveImg,
          STATUS_TYPE?.ACTIVE,
          consignmentKPIData?.length &&
            consignmentKPIData[0] &&
            consignmentKPIData[0]['ConsignmentLineItem.ActiveCount'] !== null
            ? consignmentKPIData[0]['ConsignmentLineItem.ActiveCount']
            : 0
        )}
        {renderKpi(
          isConsignmentKPILoading,
          PayoutImg,
          STATUS_TYPE?.PAYOUTS,
          consignmentKPIData?.length &&
            consignmentKPIData[0] &&
            consignmentKPIData[0]['ConsignmentLineItem.retailPrice'] !== null
            ? convertPriceToUSFormat(
                parseFloat(
                  consignmentKPIData[0]['ConsignmentLineItem.retailPrice']
                ).toFixed(2)
              )
            : `$0.00`
        )}
      </div>
    </div>
  );
};

export default KpiStatus;
