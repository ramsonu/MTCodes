export const STATUS_TYPE: any = {
  SOLD: 'Sold',
  ACTIVE: 'Active',
  PAYOUTS: 'Payouts',
};

export const CONSIGNMENT_ADMIN_INNER_PATH = {
  CONSIGNMENT_PATH: '/consignment-admin/shipments',
  CONSIGNMENT_ADMIN_PATH: '/consignment-admin',
  ORDERS_PATH: '/consignment-admin/orders',
  ORDER_DETAILS_PATH: '/consignment-admin/orders/order-details',
  PAYOUT_HISTORY_PATH: '/consignment-admin/orders/payout-history',
  CONSIGNMENTS_PATH: '/consignment-admin/shipments',
  CONSIGNMENTS_DETAILS_PATH: '/consignment-admin/shipments/consignment-details',
  CONSIGNMENTS_SKU_DETAILS_PATH: '/consignment-admin/shipments/sku-details',
};

export const MY_INVENTORY_INNER_PATH = {
  MY_INVENTORY_PATH: '/consignment-admin/products',
};
export const WEEKLY_ORDERS_LABEL = 'Weekly Orders';
export const ORDERS_LABEL = 'Orders';
export const PREFIX = '$';

export const CHANGE_COMMISSION_REQUEST = 'Change Commission requested';
export const SORTINGS_KEYS: any = {
  ORDERS: {
    amountLow: {
      ORDER_BY_TYPE: 'totalpriceUsd',
      ORDER_BY: 'asc',
    },
    amountHigh: {
      ORDER_BY_TYPE: 'totalpriceUsd',
      ORDER_BY: 'desc',
    },
    dateNew: {
      ORDER_BY_TYPE: 'completedAt',
      ORDER_BY: 'desc',
    },
    dateOld: {
      ORDER_BY_TYPE: 'completedAt',
      ORDER_BY: 'asc',
    },
    orderAsc: {
      ORDER_BY_TYPE: 'completedAt',
      ORDER_BY: 'asc',
    },
    orderDesc: {
      ORDER_BY_TYPE: 'completedAt',
      ORDER_BY: 'desc',
    },
  },
  INVENTORY: {
    skuAsc: {
      ORDER_BY_TYPE: 'sku',
      ORDER_BY: 'asc',
    },
    skuDesc: {
      ORDER_BY_TYPE: 'sku',
      ORDER_BY: 'desc',
    },
    brandAsc: {
      ORDER_BY_TYPE: 'brand',
      ORDER_BY: 'asc',
    },
    brandDesc: {
      ORDER_BY_TYPE: 'brand',
      ORDER_BY: 'dec',
    },
    qtyLow: {
      ORDER_BY_TYPE: 'skuCount',
      ORDER_BY: 'asc',
    },
    qtyHigh: {
      ORDER_BY_TYPE: 'skuCount',
      ORDER_BY: 'desc',
    },
  },
  PAYOUTS: {
    amountLow: {
      ORDER_BY_TYPE: 'totalPayoutAmount',
      ORDER_BY: 'asc',
    },
    amountHigh: {
      ORDER_BY_TYPE: 'totalPayoutAmount',
      ORDER_BY: 'desc',
    },
    commissionAsc: {
      ORDER_BY_TYPE: 'Commission',
      ORDER_BY: 'asc',
    },
    commissionDesc: {
      ORDER_BY_TYPE: 'Commission',
      ORDER_BY: 'desc',
    },
    requestAmountLow: {
      ORDER_BY_TYPE: 'requestAmount',
      ORDER_BY: 'asc',
    },
    requestAmountHigh: {
      ORDER_BY_TYPE: 'requestAmount',
      ORDER_BY: 'desc',
    },
  },
  CONSIGNORS: {
    consignorIdAsc: {
      ORDER_BY_TYPE: 'userId_D',
      ORDER_BY: 'asc',
    },
    consignorIdDesc: {
      ORDER_BY_TYPE: 'userId_D',
      ORDER_BY: 'desc',
    },
    statusAsc: {
      ORDER_BY_TYPE: 'status',
      ORDER_BY: 'asc',
    },
    statusDesc: {
      ORDER_BY_TYPE: 'status',
      ORDER_BY: 'desc',
    },
    commissionAsc: {
      ORDER_BY_TYPE: 'name',
      ORDER_BY: 'asc',
    },
    commissionDesc: {
      ORDER_BY_TYPE: 'name',
      ORDER_BY: 'desc',
    },
    dateAddedAsc: {
      ORDER_BY_TYPE: 'createdAt',
      ORDER_BY: 'asc',
    },
    dateAddedDesc: {
      ORDER_BY_TYPE: 'createdAt',
      ORDER_BY: 'desc',
    },
  },
  USERS: {
    'Emp.ID:Asc': {
      ORDER_BY_TYPE: 'employeeId',
      ORDER_BY: 'asc',
    },
    'Emp.ID:Desc': {
      ORDER_BY_TYPE: 'employeeId',
      ORDER_BY: 'desc',
    },
    'Name:Asc': {
      ORDER_BY_TYPE: 'userName',
      ORDER_BY: 'asc',
    },
    'Name:Desc': {
      ORDER_BY_TYPE: 'userName',
      ORDER_BY: 'desc',
    },
    'Status:Asc': {
      ORDER_BY_TYPE: 'status',
      ORDER_BY: 'asc',
    },
    'Status:Desc': {
      ORDER_BY_TYPE: 'status',
      ORDER_BY: 'desc',
    },
  },
  LOCATIONS: {
    locationStatusAsc: {
      ORDER_BY_TYPE: 'active',
      ORDER_BY: 'asc',
    },
    locationStatusDesc: {
      ORDER_BY_TYPE: 'active',
      ORDER_BY: 'desc',
    },
    locationStateAsc: {
      ORDER_BY_TYPE: 'province',
      ORDER_BY: 'asc',
    },
    locationStateDesc: {
      ORDER_BY_TYPE: 'province',
      ORDER_BY: 'desc',
    },
    locationCityDesc: {
      ORDER_BY_TYPE: 'city',
      ORDER_BY: 'desc',
    },
  },
  TRANSFERS: {
    transferIdAsc: {
      ORDER_BY_TYPE: 'transferId',
      ORDER_BY: 'asc',
    },
    transferIdDesc: {
      ORDER_BY_TYPE: 'transferId',
      ORDER_BY: 'desc',
    },
    toAsc: {
      ORDER_BY_TYPE: 'from',
      ORDER_BY: 'asc',
    },
    toDesc: {
      ORDER_BY_TYPE: 'from',
      ORDER_BY: 'desc',
    },
    statusAsc: {
      ORDER_BY_TYPE: 'status',
      ORDER_BY: 'asc',
    },
    statusDesc: {
      ORDER_BY_TYPE: 'status',
      ORDER_BY: 'desc',
    },
  },
};
export const SHOE_JOURNEY_TYPES = {
  INVENTORY_ADDITION: 'Inventory Addition',
  SELLER_PRICE_CHANGE: 'Seller Price Change',
  ORDER_PLACED: 'Order Placed',
  PAYOUT_PAID: 'Payout Paid',
  PAYOUT_AMOUNT_UPDATED: 'Payout Amount Updated',
  PRODUCT_SOLD: 'Order Create',
  REJECTED: 'Consignment item Rejected',
  APPROVED: 'Consignment item Approved',
  SHOPIFY_ERROR: 'Consignment item Shopify Error',
  TRANSFER_ACCEPTED: 'Transfer Approved',
  TRANSFER_REJECTED: 'Transfer Rejected',
  WITHDRAW_CHANGE: 'Withdrawn Change',
  WITHDRAWN_INVOICE_GENERATED: 'Withdrawn Invoice Generated',
  WITHDRAWN_PAYMENT_RECEIVED: 'Withdrawn Payment Received',
  MOVED_TO_YK_INV: 'Moved to YK Inventory',
  ADDED_TO_YK_INV: 'Added to YK Inventory',
  PRODUCT_MISSING: 'Inventory item Missing',
  PRODUCT_CLEARED: 'Inventory item Found',
};

export const ACCEPT_REJECT_MODAL = {
  ACCEPT_TITLE: 'Accept All Shoes',
  ACCEPT_MSG: 'All shoes will be accepted. Are you sure you want to continue?',
  REJECT_TITLE: 'Reject Shoes',
  REJECT_MSG:
    ' Selected Shoes will be rejected. Are you sure you want to continue?',
};
