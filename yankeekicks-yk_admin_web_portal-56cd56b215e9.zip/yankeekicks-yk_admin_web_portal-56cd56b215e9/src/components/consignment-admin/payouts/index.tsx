import React, { useEffect, useState, useMemo } from 'react';
import type { NextPage } from 'next';
import { useRouter } from 'next/router';
import Image from 'next/image';
import filterIcon from 'assets/images/filter-icon.png';
import {
  getPayoutDetails,
  getPayoutDetailsPagination,
} from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import { useCubeQuery } from '@cubejs-client/react';
import VirtualTable from 'components/common/table';
import SearchComp from 'components/common/search';
import ExportsTypes from 'components/common/exports-types';
import Sortings from 'components/common/sortings';
import { ClickAwayListener } from '@mui/material';
import ProductFilters from 'components/common/filters/product-filter';
import { getBasePath } from 'utils/util';
import Pagination from 'components/common/pagination';
import { postPayoutShedular } from 'services/payouts';
import { getCommissionNames } from 'middleware/cubejs-wrapper/yk-super-admin-cubejs-query';
const style = {
  position: 'absolute' as 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '1px solid rgba(0,0,0, .7)',
  boxShadow: 24,
  p: 4,
};

const PayoutDetails: NextPage = () => {
  const router = useRouter();
  const limit = 10;
  const [payoutDetailsData, setPayoutDetailsData] = useState<any>([]);
  const [userInput, setUserInput] = useState('');
  const [selectedSort, setSelectedSort] = useState('requestAmountHigh');
  const [showFilters, setShowFilters] = useState(false);
  const [filterInput, setFilterInput] = useState<any>({});
  const [clearDisable, setClearDisable] = useState(true);
  const [offset, setOffset] = useState(0);
  const [paginationCount, setPaginationCount] = useState(0);
  const [selectedCommisonType, setSelectedCommisonType] = useState<any>([]);
  const [isPDFExport, setIsPDFExport] = useState(true);
  const [commissionNamesList, setCommissionNamesList] = useState([]);

  const commissionDetailsByIdQuery: any = getCommissionNames();

  const { resultSet: commissionDetailsResultSet }: any = useCubeQuery(
    commissionDetailsByIdQuery
  );
  const payoutDetailsByIdQuery: any = getPayoutDetails(
    userInput,
    selectedSort,
    filterInput,
    limit,
    offset
  );
  const exportsPayoutsQuery: any = getPayoutDetails(
    userInput,
    selectedSort,
    filterInput,
    0
  );
  const { resultSet: exportsResultsSet }: any = useCubeQuery(
    exportsPayoutsQuery,
    { skip: isPDFExport }
  );
  const queryPayload = {
    userInput,
    selectedSort,
    filterInput,
  };
  const {
    resultSet: payoutDetailsResultSet,
    isLoading: payoutIsLoading,
    error: payoutError,
  }: any = useCubeQuery(payoutDetailsByIdQuery);

  const payoutDetailsPagination: any = getPayoutDetailsPagination(
    userInput,
    filterInput
  );

  const {
    resultSet: payoutDetailsPaginationResultSet,
    isLoading: payoutIsPaginationLoading,
    error: payoutPaginationError,
  }: any = useCubeQuery(payoutDetailsPagination);

  useEffect(() => {
    const data = payoutDetailsResultSet?.loadResponses[0]?.data;
    if (payoutDetailsPaginationResultSet) {
      const paginationCountData =
        +payoutDetailsPaginationResultSet?.loadResponses[0]?.data[0]?.[
          'Payout.count'
        ] || 0;
      setPaginationCount(paginationCountData);
    }
    if (data) {
      setPayoutDetailsData(data);
    } else {
      setPayoutDetailsData([]);
    }
  }, [payoutDetailsResultSet, payoutDetailsPaginationResultSet]);

  useEffect(() => {
    postPayoutShedular();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const data = commissionDetailsResultSet?.loadResponses[0]?.data;
    if (data) {
      setCommissionNamesList(data);
    } else {
      setCommissionNamesList([]);
    }
  }, [commissionDetailsResultSet]);

  const onClickPDFExport = () => {
    setIsPDFExport(false);
    setTimeout(() => {
      setIsPDFExport(true);
    }, 100);
  };
  const viewButtonHandler = (data: any) => {
    router?.push(getBasePath(`payouts/${data?.['Payout.consigneeid_D']}`));
  };
  const onChangeHandler = (event: any) => {
    setUserInput(event.target.value);
    setOffset(0);
  };

  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
  };
  const onCommissionChange = (event: any) => {
    if (selectedCommisonType.includes(event?.target?.name)) {
      let tempOption = [];
      tempOption = selectedCommisonType.filter(
        (data: any) => data !== event?.target?.name
      );
      setSelectedCommisonType(tempOption);
      if (tempOption.length === 0) {
        setClearDisable(true);
      }
    } else {
      setSelectedCommisonType([...selectedCommisonType, event?.target?.name]);
      setClearDisable(false);
    }
  };

  const onApplyClick = () => {
    const filterPayload = {
      commission: selectedCommisonType,
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setShowFilters(false);
  };

  const onClearFilters = () => {
    setFilterInput({});
    setShowFilters(false);
    setClearDisable(true);
  };

  const columns = useMemo(
    () => [
      {
        title: 'Consignor ID',
        value: 'Payout.consigneeid_D',
      },
      {
        title: 'Name',
        value: 'Payout.Name',
      },
      {
        title: 'Commission',
        value: 'Payout.Commission',
      },
      {
        title: 'Total Payout Amount',
        value: 'Payout.totalPayoutAmount',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Total Paid Amount',
        value: 'Payout.totalWithdrawalAmount',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Current Balance',
        value: 'Payout.balanceAmount',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Requested Amount',
        value: 'Payout.requestAmount',
        prefix: '$',
        methodToApply: 'toFix',
      },

      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          viewButtonHandler(data);
        },
        value: 'View',
      },
    ],
    []
  );
  const exportHeaders = [
    { label: 'Consignor ID', key: 'Payout.consigneeid_D' },
    { label: 'Name', key: 'Payout.Name' },
    { label: 'Commission', key: 'Payout.Commission' },
    {
      label: 'Total Payout Amount',
      key: 'Payout.totalPayoutAmount',
      type: 'amount',
    },
    {
      label: 'Total Paid Amount',
      key: 'Payout.totalWithdrawalAmount',
      type: 'amount',
    },
    { label: 'Current Balance', key: 'Payout.balanceAmount', type: 'amount' },
    { label: 'Requested Amount', key: 'Payout.requestAmount', type: 'amount' },
  ];
  return (
    <>
      <div className='app-wrapper w-100 consignment-consignments-details-page-wrapper'>
        <div className='orders-page-inner-wrapper'>
          <div className='container-fluid'>
            <div className='row'>
              <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 consignmentDetailsHeader'>
                <div className='heading-wrapper orders-heading-wrapper d-flex justify-content-between'>
                  <h2 className='heading'>
                    Payouts{' '}
                    <span className='count-badge d-none'>
                      {paginationCount}
                    </span>
                  </h2>
                  <div className='sort-product-wrapper orders-export-btn export-btn text-end me-0 bg-transparent p-0'>
                    <ExportsTypes
                      data={
                        (exportsResultsSet?.loadResponses &&
                          exportsResultsSet?.loadResponses[0]?.data) ||
                        []
                      }
                      fileName='payouts'
                      headers={exportHeaders}
                      queryPayload={queryPayload}
                      onClickPDFExport={onClickPDFExport}
                      isActive={
                        payoutDetailsData && payoutDetailsData?.length > 0
                      }
                    />
                  </div>
                </div>
              </div>

              <div className='search-btn-wrapper'>
                <div className='row mb-2'>
                  <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12'>
                    <div className='search-bar-wrapper yk-search-bar table-filter-search'>
                      <SearchComp
                        optionType='change'
                        placeholder='Search'
                        onChangeHandler={onChangeHandler}
                      />
                    </div>
                  </div>
                  <div className='col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12'>
                    <div className='consignment-btn-wrapper consignment-btn-wrapper p-0 YKCH-topSSpacSS YKCH-filterArenas'>
                      <div className='filter-btn-wrapper'>
                        <ClickAwayListener
                          onClickAway={() => {
                            setShowFilters(false);
                          }}
                        >
                          <>
                            <div className='d-flex'>
                              <div className='me-3'>
                                <Sortings
                                  itemKey='payoutDetails'
                                  handleChange={sortHandler}
                                  defaultSelectedValue={selectedSort}
                                />
                              </div>
                              <div className=''>
                                <button
                                  className='btn filter-btn'
                                  onClick={() => setShowFilters(!showFilters)}
                                >
                                  <Image
                                    src={filterIcon}
                                    alt='filter-btn-icon'
                                    className='filter-btn-icon img-fluid'
                                  />
                                  <span className='filter-btn-text yk-badge-h15'>
                                    Filter
                                  </span>
                                </button>
                                {showFilters && (
                                  <ProductFilters
                                    itemKey='payout'
                                    data={commissionNamesList}
                                    onApplyClick={onApplyClick}
                                    checkedSkuValue={selectedCommisonType}
                                    onSkuChange={onCommissionChange}
                                    onClearFilters={onClearFilters}
                                    clearDisable={clearDisable}
                                  />
                                )}
                              </div>
                            </div>
                          </>
                        </ClickAwayListener>
                      </div>
                    </div>
                  </div>
                </div>
                <VirtualTable
                  loading={payoutIsLoading}
                  error={payoutError}
                  headers={columns}
                  rowData={payoutDetailsData}
                />
                {paginationCount > 0 && payoutDetailsData.length > 0 && (
                  <div className='center-pagination'>
                    <Pagination
                      lengthOfData={paginationCount}
                      itemsPerPage={limit}
                      currentOffset={offset}
                      setOffset={setOffset}
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default PayoutDetails;
