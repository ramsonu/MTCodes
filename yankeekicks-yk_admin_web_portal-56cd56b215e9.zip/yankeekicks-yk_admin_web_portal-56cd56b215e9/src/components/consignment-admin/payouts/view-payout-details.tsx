import React from 'react';
import Image from 'next/image';
import Modal from '@mui/material/Modal';
import { useRouter } from 'next/router';
import format from 'date-fns/format';
import { convertPriceToUSFormat, getBasePath } from 'utils/util';
import { PAYOUT_DETAILS_FORMAT } from 'utils/constants';
import ModalCloseIcon from 'assets/images/modal-close-icon.svg';

const ViewPayoutDetailsModal = (props: any) => {
  const { showModal, handleClose, payoutDetailsData } = props;
  const router = useRouter();

  return (
    <div className='modal-wrapper'>
      <Modal
        open={showModal}
        onClose={handleClose}
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'
        className='yk-product-details-modal'>
        <div className='modal-outer-wrapper payout-details-pop-wrap'>
          <div className='modal-inner-wrapper container'>
            <div className='modal-heading-wrapper row'>
              <div className='heading-wrapper'>
                <div className='d-flex align-items-center'>
                  <h3 className='heading d-inline-block mb-0'>
                    Payout details
                  </h3>
                </div>
                <button
                  className='btn btn-modal-close'
                  onClick={() => handleClose(false)}>
                  <Image
                    src={ModalCloseIcon}
                    className='img-fluid'
                    alt=''></Image>
                </button>
              </div>
            </div>

            <div className='container-fluid ps-0 pe-0'>
              <div className='row'>
                <div className='col-lg-6 col-md-6 col-sm-12 col-12 payout-details-wrap'>
                  <div className='yk-order-title'>
                    <h4>
                      Payout ID:{' '}
                      <span className='yk-order-details'>
                        {payoutDetailsData?.[
                          'PayoutHistory.consigneePayoutId'
                        ] || '--'}
                      </span>
                    </h4>
                  </div>
                  <div className='yk-order-title'>
                    <h4>
                      Transfer Mode:{' '}
                      <span className='yk-order-details'>
                        {payoutDetailsData?.['PayoutHistory.transferMode'] ||
                          '--'}
                      </span>
                    </h4>
                  </div>
                  <div className='yk-order-title'>
                    <h4>
                      Date & Time:{' '}
                      <span className='yk-order-details'>
                        {payoutDetailsData?.['PayoutHistory.payoutDate']
                          ? format(
                              new Date(
                                payoutDetailsData?.['PayoutHistory.payoutDate']
                              ),
                              PAYOUT_DETAILS_FORMAT
                            )
                          : '--'}
                      </span>
                    </h4>
                  </div>

                  <div className='yk-order-title'>
                    <h4>
                      Transaction Trace ID:{' '}
                      <span className='yk-order-details'>
                        {payoutDetailsData?.[
                          'PayoutHistory.transactionTraceId'
                        ] || '--'}
                      </span>
                    </h4>
                  </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-12 payout-details-wrap payout-amount'>
                  <div className='yk-order-title'>
                    <h4>
                      Amount:{' '}
                      <span className='yk-order-details payout-currency'>
                        {payoutDetailsData?.['PayoutHistory.payoutAmount']
                          ? convertPriceToUSFormat(
                              parseFloat(
                                payoutDetailsData?.[
                                  'PayoutHistory.payoutAmount'
                                ] || 0
                              )?.toFixed(2)
                            )
                          : '--'}
                      </span>
                    </h4>
                  </div>
                </div>
              </div>
              <div className='row'>
                <div
                  className='col-lg-12 text-center'
                  onClick={() =>
                    router.push(
                      getBasePath(
                        `orders/${payoutDetailsData?.['PayoutHistory.orderId']}`
                      )
                    )
                  }>
                  <button className='yk-payout-view-details'>
                    View Order Details
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default ViewPayoutDetailsModal;
