import React, { useState, useEffect, useMemo } from 'react';
import type { NextPage } from 'next';
import Image from 'next/image';
import { useCubeQuery } from '@cubejs-client/react';
import format from 'date-fns/format';
import { useRouter } from 'next/router';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import {
  getPayoutHistoryQuery,
  getPaginationCountForPayoutHistory,
  getPayoutTotalAmountQuery,
} from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import { FNS_DATE_FORMAT, KPI_DATE_FORMAT } from 'utils/constants';
import { convertPriceToUSFormat, getBasePath } from 'utils/util';
import VirtualTable from 'components/common/table';
import Sortings from 'components/common/sortings';
import ProductFilters from 'components/common/filters/product-filter';
import ExportsTypes from 'components/common/exports-types';
import ViewPayoutDetailsModal from './view-payout-details';
import Pagination from 'components/common/pagination';
import SearchComp from 'components/common/search';
import filterIcon from 'assets/images/filter-icon.png';
import dollarIcon from 'assets/images/dollar-icon.svg';

const ViewPayoutHistory: NextPage = () => {
  const router = useRouter();
  const [payoutHistoryData, setPayoutHistoryData] = useState<any>([]);
  const [userInput, setUserInput] = useState<any>('');
  const [searchOffset, setSearchOffset] = useState<any>(0);
  const [countForPagination, setCountForPagination] = useState(0);
  const [selectedSort, setSelectedSort] = useState('dateNew');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedStartDate, setSelectedStartDate] = useState<any>('');
  const [selectedEndDate, setSelectedEndDate] = useState<any>('');
  const [selectedPayoutStatus, setSelectedPayoutStatus] = useState<any>([]);
  const [checked, setChecked] = useState({ Pending: false, Paid: false });
  const [filterInput, setFilterInput] = useState<any>({});
  const [showDetailsModal, setShowDetailsModal] = useState<any>(false);
  const [payoutDetails, setPayoutDetails] = useState<string>('');
  const [clearDisable, setClearDisable] = useState(true);
  const consignorId: any = router.query.consignorId;
  const userDetails = { user_id: consignorId };
  const [isPDFExport, setIsPDFExport] = useState(true);

  const queryPayload = {
    userInput,
    selectedSort,
    filterInput,
    userDetails,
  };

  const viewButtonHandler = (data: any) => {
    setShowDetailsModal(true);
    setPayoutDetails(data);
  };
  const columns = useMemo(
    () => [
      {
        title: 'Payout ID',
        value: 'PayoutHistory.consigneePayoutId',
        prefix: '#',
      },
      {
        title: 'Amount',
        value: 'PayoutHistory.payoutAmount',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Transfer Mode',
        value: 'PayoutHistory.transferMode',
      },
      {
        title: 'Date',
        type: 'date',
        format: FNS_DATE_FORMAT,
        value: 'PayoutHistory.payoutDate',
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          viewButtonHandler(data);
        },
        value: 'View',
      },
    ],
    []
  );
  const limitForQuery = 10;
  const payoutHistoryQuery: any = getPayoutHistoryQuery(
    userDetails,
    userInput,
    selectedSort,
    filterInput,
    searchOffset,
    limitForQuery
  );
  const payoutHistoryPaginationCountQuery: any =
    getPaginationCountForPayoutHistory(userDetails, userInput, filterInput);

  const payoutTotalAmountQuery: any = getPayoutTotalAmountQuery(
    userDetails,
    userInput,
    limitForQuery,
    searchOffset,
    selectedSort,
    filterInput
  );
  const exportsPayoutHistoryQuery: any = getPayoutHistoryQuery(
    userDetails,
    userInput,
    selectedSort,
    filterInput
  );
  const { resultSet: exportsResultsSet }: any = useCubeQuery(
    exportsPayoutHistoryQuery,
    { skip: isPDFExport }
  );
  const { resultSet: payoutTotalAmountResultsSet }: any = useCubeQuery(
    payoutTotalAmountQuery
  );
  const {
    resultSet: payoutHistoryResultSet,
    isLoading: payoutIsLoading,
    error: payoutError,
  }: any = useCubeQuery(payoutHistoryQuery);

  const { resultSet: pageCountResultSet }: any = useCubeQuery(
    payoutHistoryPaginationCountQuery
  );

  useEffect(() => {
    const data = payoutHistoryResultSet?.loadResponses[0]?.data;
    if (data?.length > 0) {
      setPayoutHistoryData(data);
    } else if (!payoutIsLoading) {
      setPayoutHistoryData([]);
    }
  }, [payoutHistoryResultSet, payoutIsLoading]);

  useEffect(() => {
    if (pageCountResultSet) {
      let countData =
        +pageCountResultSet?.loadResponses[0]?.data[0]?.[
          'PayoutHistory.count'
        ] || 0;
      setCountForPagination(countData);
    }
  }, [pageCountResultSet]);

  const onClickPDFExport = () => {
    setIsPDFExport(false);
    setTimeout(() => {
      setIsPDFExport(true);
    }, 100);
  };

  const onChangeHandler = (event: any) => {
    setUserInput(event.target.value);
  };

  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
  };

  const onDateChange = (dates: any) => {
    const [start, end] = dates;
    setSelectedStartDate(start);
    setSelectedEndDate(end);
    setClearDisable(false);
  };

  const onApplyClick = () => {
    const filterPayload = {
      startDate:
        selectedStartDate !== '' &&
        format(new Date(selectedStartDate), KPI_DATE_FORMAT),
      endDate:
        selectedEndDate !== '' &&
        format(new Date(selectedEndDate), KPI_DATE_FORMAT),
      status: selectedPayoutStatus,
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setShowFilters(false);
  };
  const onPayoutChange = (event: any) => {
    setChecked({ ...checked, [event?.target?.name]: event?.target?.checked });
    var updatedList = [...selectedPayoutStatus];
    if (event.target.checked) {
      updatedList = [...selectedPayoutStatus, event.target.name];
    } else {
      updatedList.splice(selectedPayoutStatus.indexOf(event.target.name), 1);
    }
    setSelectedPayoutStatus(updatedList);
  };
  const onClearFilters = () => {
    setSelectedStartDate('');
    setSelectedEndDate('');
    setSelectedPayoutStatus([]);
    setChecked({ Pending: false, Paid: false });
    setFilterInput({});
    setShowFilters(false);
    setClearDisable(true);
  };

  const exportHeaders = [
    { label: 'Payout Id', key: 'PayoutHistory.consigneePayoutId' },
    { label: 'Transfer Mode', key: 'PayoutHistory.transferMode' },
    { label: 'Date', key: 'PayoutHistory.payoutDate' },
    { label: 'Amount', key: 'PayoutHistory.payoutAmount' },
  ];

  const totalPayoutAmount =
    convertPriceToUSFormat(
      parseFloat(
        payoutTotalAmountResultsSet?.loadResponses[0]?.data[0]?.[
          'PayoutHistory.payoutAmount'
        ] || 0
      )?.toFixed(2),
      false
    ) || '--';

  return (
    <>
      <div className='app-wrapper w-100 orders-page-wrapper view-payout-history-page-wrapper'>
        <div className='payout-history-page-inner-wrapper'>
          <div className='container-fluid'>
            <div className='row'>
              <div className='col-lg-12 col-md-12 col-sm-12'>
                <div className='breadcrumbs-wrapper'>
                  <ul className='breadcrumbs-list'>
                    <li className='yk-heading yk-title-h19'>
                      <a
                        role='button'
                        className='yk-orders-heading'
                        onClick={() => router?.push(getBasePath('orders'))}>
                        Orders
                      </a>
                    </li>
                    <li className='yk-sub-heading'>Payouts History</li>
                  </ul>
                </div>
                <div className='order-payouts-heading-wrapper'>
                  <h6 className='yk-heading yk-badge-h11'>Payout History</h6>
                  <p className='yk-heading-info-wrapper'>
                    <span className='dollar-img-wrapper'>
                      <Image
                        src={dollarIcon}
                        alt='dollar-icon'
                        className='img-fluid'
                      />
                    </span>
                    <h3 className='yk-sub-heading yk-badge-h16'>Amount :</h3>
                    <h3 className='yk-amount-text yk-badge-h14'>
                      {totalPayoutAmount}
                    </h3>
                  </p>
                </div>
              </div>
              <div className='search-btn-wrapper'>
                <div className='row'>
                  <div className='col-xl-6 col-lg-4 col-md-12 col-sm-12 col-12'>
                    <div className='search-bar-wrapper yk-search-bar table-filter-search'>
                      <SearchComp
                        optionType='change'
                        placeholder='Search'
                        onChangeHandler={onChangeHandler}
                      />
                    </div>
                  </div>
                  <div className='col-xl-6 col-lg-8 col-md-12 col-sm-12 col-12'>
                    <div className='consignment-btn-wrapper'>
                      <Sortings
                        itemKey='payout'
                        handleChange={sortHandler}
                        defaultSelectedValue={selectedSort}></Sortings>

                      <div className='filter-btn-wrapper ykch-filter-wrapper-box'>
                        <ClickAwayListener
                          onClickAway={() => {
                            setShowFilters(false);
                          }}>
                          <div className='YKCH-onSameLine'>
                            <button
                              className='btn filter-btn'
                              onClick={() => setShowFilters(!showFilters)}>
                              <Image
                                src={filterIcon}
                                alt='filter-btn-icon'
                                className='filter-btn-icon img-fluid'
                              />
                              <span className='filter-btn-text yk-badge-h15'>
                                Filter
                              </span>
                            </button>

                            {showFilters && (
                              <ProductFilters
                                itemKey='payoutHistory'
                                onDateChange={onDateChange}
                                startDate={selectedStartDate}
                                endDate={selectedEndDate}
                                onApplyClick={onApplyClick}
                                onPayoutChange={onPayoutChange}
                                checkedValue={checked}
                                onClearFilters={onClearFilters}
                                clearDisable={clearDisable}
                              />
                            )}
                          </div>
                        </ClickAwayListener>
                      </div>
                      <div className='sort-product-wrapper export-btn d-none'>
                        <ExportsTypes
                          data={
                            (exportsResultsSet?.loadResponses &&
                              exportsResultsSet?.loadResponses[0]?.data) ||
                            []
                          }
                          fileName='payouthistory'
                          queryPayload={queryPayload}
                          onClickPDFExport={onClickPDFExport}
                          headers={exportHeaders}
                          isActive={
                            payoutHistoryData && payoutHistoryData?.length > 0
                          }
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <VirtualTable
              loading={payoutIsLoading}
              error={payoutError}
              headers={columns}
              rowData={payoutHistoryData}
            />
          </div>
          {countForPagination > 0 && payoutHistoryData?.length > 0 && (
            <div className='center-pagination'>
              <Pagination
                lengthOfData={countForPagination}
                itemsPerPage={limitForQuery}
                currentOffset={searchOffset}
                setOffset={setSearchOffset}
              />
            </div>
          )}
        </div>
      </div>
      {showDetailsModal && (
        <ViewPayoutDetailsModal
          showModal={showDetailsModal}
          handleClose={setShowDetailsModal}
          payoutDetailsData={payoutDetails}
        />
      )}
    </>
  );
};
export default ViewPayoutHistory;
