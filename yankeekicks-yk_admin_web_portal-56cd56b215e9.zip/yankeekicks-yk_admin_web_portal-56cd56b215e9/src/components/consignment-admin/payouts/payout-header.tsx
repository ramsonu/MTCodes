import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import { getPayoutDetailsForHeader } from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import { convertPriceToUSFormat } from 'utils/util';

const PayoutDetailsHeader = (props: any) => {
  const { setWithdrawalAmount } = props;
  const router = useRouter();
  const consignorId: any = router.query.consignorId;
  const [consignorPayoutDetails, setConsignorPayoutDetails] = useState<any>([]);
  const payoutDetailsByIdQuery: any = getPayoutDetailsForHeader(consignorId);

  const {
    resultSet: payoutResultSet,
    isLoading: payoutIsLoading,
    error: payoutError,
  }: any = useCubeQuery(payoutDetailsByIdQuery);

  useEffect(() => {
    const data = payoutResultSet?.loadResponses[0]?.data;
    if (data) {
      setConsignorPayoutDetails(data[0]);
      setWithdrawalAmount(data[0]['Payout.requestAmount']);
    } else {
      setConsignorPayoutDetails([]);
    }
  }, [payoutResultSet]);

  return (
    <div className='container-fluid'>
      <div className='ConsignmentsWrap mb-4 d-flex justify-content-between order-details-card-mobile'>
        <div className='row'>
          <div className='col-lg-12 col-md-12 col-sm-12'>
            <div className='heading-wrapper orders-heading-wrapper '>
              <h2 className='yk-badge-h5 heading'>
                {consignorPayoutDetails?.['Payout.Name']}
              </h2>
            </div>
          </div>
        </div>
        <div className='row yk-con-detail-wrap YKCH-noShadeShadow'>
          <div className='col yk-con-lable-wrap'>
            <div className='yk-con-detail-lable'>Total Payout Amount</div>
            <div className='yk-con-detail-status'>
              {convertPriceToUSFormat(
                parseFloat(
                  consignorPayoutDetails?.['Payout.totalPayoutAmount'] || 0
                )?.toFixed(2)
              )}
            </div>
          </div>
          <div className='col yk-con-lable-wrap'>
            <div className='yk-con-detail-lable'>Total Paid Amount</div>
            <div className='yk-con-detail-status'>
              {convertPriceToUSFormat(
                parseFloat(
                  consignorPayoutDetails?.['Payout.totalWithdrawalAmount'] || 0
                )?.toFixed(2)
              )}
            </div>
          </div>
          <div className='col yk-con-lable-wrap'>
            <div className='yk-con-detail-lable'>Current Balance</div>
            <div className='yk-con-detail-status'>
              {convertPriceToUSFormat(
                parseFloat(
                  consignorPayoutDetails?.['Payout.balanceAmount'] || 0
                )?.toFixed(2)
              )}
            </div>
          </div>
          <div className='col yk-con-lable-wrap'>
            <div className='yk-con-detail-lable'>Requested Amount</div>
            <div className='yk-con-detail-status'>
              {convertPriceToUSFormat(
                parseFloat(
                  consignorPayoutDetails?.['Payout.requestAmount'] || 0
                )?.toFixed(2)
              )}
            </div>
          </div>
          <div className='col yk-con-lable-wrap'>
            <div className='yk-con-detail-lable'>Payable Amount</div>
            <div className='yk-con-detail-status'>
              {convertPriceToUSFormat(
                parseFloat(
                  (parseFloat(
                    consignorPayoutDetails?.['Payout.balanceAmount'] || 0
                  ) >
                  parseFloat(
                    consignorPayoutDetails?.['Payout.requestAmount'] || 0
                  )
                    ? consignorPayoutDetails?.['Payout.requestAmount']
                    : consignorPayoutDetails?.['Payout.balanceAmount']) || 0
                )?.toFixed(2)
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PayoutDetailsHeader;
