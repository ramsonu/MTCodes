import React, { useState, useEffect, useRef } from 'react';
import groupConsignee from 'assets/images/consignee/group-consignee.svg';
import userConsignee from 'assets/images/consignee/user-Info.svg';
import addressConsignee from 'assets/images/consignee/address-Book.svg';
import mapConsignee from 'assets/images/consignee/map-triFold.svg';
import countriesStateData from 'utils/countries-states.json';
import uploadConsignee from 'assets/images/consignee/upload-consignee.svg';
import identityDetails from 'assets/images/consignee/identity-Details.svg';
import browseConsignee from 'assets/images/consignee/browse-consinee.svg';
import Image from 'next/image';
import { useForm } from 'react-hook-form';
import {
  ValidationFullName,
  ValidationRequired,
  ValidationMaxLength14,
  ValidationMinLength14,
  ValidationOnlyPhoneNumber,
  ValidationEmail,
  ValidationMinLength6,
  ValidationMaxLength250,
  ValidationMaxLength10,
  ValidationMaxLength5,
  ValidationMinLength5,
  ValidationOnlyNumbers,
  PLEASE_FILL_THIS_FIELD,
} from 'utils/validators';
import { getBase64, getBasePath, updatePhoneNumber } from 'utils/util';
import {
  consignorType,
  getConsignorDetails,
  putUpdateUser,
  putUpdateUserUpload,
} from 'services/consignor';
import { useRouter } from 'next/router';
import EditConsignorLeftSideBar from './edit-consignor-left-side-bar';
import {
  FILE_UPLOAD_ACCEPT_FORMATS,
  USER_REGISTRATION_FILE_SIZE_ERROR,
  USER_REGISTRATION_FILE_TYPE_ERROR,
  USER_UPDATE_SUCCESS,
} from 'utils/constants';
import Notification from 'components/common/notification';
import uploadSuccess from 'assets/images/success-icon.svg';
import CloseIcon from 'assets/images/close-black.svg';
import { DragandDrop } from 'components/common/bulk-upload/DragandDrop';

const EditConsignorIdentityDetails = ({ setStep }: any) => {
  const router = useRouter();
  const { consignorId } = router.query;
  const [sendFile, setSendFile] = useState<any>([]);
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [message, setMessage] = useState<string>('');
  const [severityType, setSeverityType] = useState<string>('');
  const [userData, setUserData] = useState<any>();
  const [stateList, setSateList] = useState<any>([]);
  const [uploadFileError, setUploadFileError] = useState<any>();
  const {
    handleSubmit,
    setValue,
    register,
    formState: { errors },
  } = useForm<consignorType>();

  useEffect(() => {
    consignorTableInit();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    setUploadFileError('');
    if (sendFile?.length) {
      let fileType = sendFile && sendFile[0].type.split('/')[1];
      if (FILE_UPLOAD_ACCEPT_FORMATS.includes(fileType)) {
        //file size limit 5 Mb
        if (sendFile && sendFile[0].size > 5 * 1000 * 1000)
          setUploadFileError(USER_REGISTRATION_FILE_SIZE_ERROR);
        else {
          setUserData({
            ...userData,
            documentImage: sendFile && sendFile[0],
            documentName:
              sendFile && sendFile[0]?.name?.replace(/^.*[\\\/]/, ''),
            documentAdded: true,
          });
        }
      } else {
        setUploadFileError(USER_REGISTRATION_FILE_TYPE_ERROR);
      }
    }
  }, [sendFile]);
  const consignorTableInit = async () => {
    let getConsignorsData = await getConsignorDetails(consignorId);
    setUserData(getConsignorsData.data);
    let stateFilterList = countriesStateData.filter(
      (ctry) => ctry.name == getConsignorsData?.data?.address?.country
    )[0]?.states;
    if (!!stateFilterList) setSateList(stateFilterList);
    if (getConsignorsData?.data?.documentType != 'undefined')
      setValue('documentType', getConsignorsData?.data?.documentType);
    setValue('documentName', getConsignorsData?.data?.documentName);
    setValue('documentImage', getConsignorsData?.data?.documentImage);
  };

  const onSubmit = async (data: any) => {
    setUploadFileError('');
    try {
      if (sendFile?.length) {
        const response: any = await putUpdateUserUpload(userData, consignorId);
        if (response.status == 200) {
          setTimeout(() => {
            router.push(getBasePath(`consignors/${consignorId}`));
          }, 1000);
          setIsVisibleMessage(true);
          setSeverityType('success');
          setMessage(USER_UPDATE_SUCCESS);
        }
      } else {
        setUploadFileError(PLEASE_FILL_THIS_FIELD);
      }
    } catch (e: any) {
      setIsVisibleMessage(true);
      setSeverityType('error');
      setMessage(e?.response?.data?.message);
    }
  };
  const handleClearUploadedFile = () => {
    setSendFile('');
    setUploadFileError('');
    setUserData({
      ...userData,
      documentImage: '',
      documentName: '',
      documentAdded: false,
    });
  };
  const handleChange = (e: any) => {
    setUserData({
      ...userData,
      [e.target.name]: e.target.value,
    });
  };
  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)} className='row'>
        <Notification
          showSuccessPopup={isVisibleMessage}
          handleSnackbarClose={() => setIsVisibleMessage(false)}
          severityType={severityType}
          message={message}
          className='yk-shoesize-alert-wrapper YKCH-TostifyMsg'
        />
        <EditConsignorLeftSideBar step={2}></EditConsignorLeftSideBar>

        <div className='col-xl-9 col-lg-6 col-md-12 col-sm-12 col-12 YKEE-columns'>
          <div className='card YKEE-cardCover'>
            <>
              <div className='YKEE-coverArea YKEE-topAreas'>
                <div className='row'>
                  {' '}
                  <div className='YKEE-headerStrip'>
                    <h4 className='YKEE-personalInfo'>Identity Details</h4>
                    <Image
                      src={identityDetails}
                      alt='Consinee Group'
                      className='Image-fluid'
                    />{' '}
                  </div>
                  <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 YKEE-columns'>
                    <div className='YKEE-formArea'>
                      <label className='YKEE-lable'>Document</label>
                      <div className='YKEE-arrowDownns'>
                        <select
                          className='form-control YKEE-field'
                          {...register('documentType', {
                            ...ValidationRequired,
                            onChange: (e) => handleChange(e),
                          })}
                        >
                          <option value=''>Select Document</option>
                          <option value='driverLicense'>
                            Driver`s License
                          </option>
                          <option value='stateId'>State Id</option>
                          <option value='passport'>Pass port</option>
                        </select>
                      </div>
                      {errors?.documentType && (
                        <div className='invalid-feedback'>
                          {errors?.documentType?.message}
                        </div>
                      )}
                      <input type='hidden' {...register('documentName')} />
                      <input type='hidden' {...register('documentImage')} />
                    </div>
                  </div>
                </div>
              </div>
              {!userData?.documentAdded ? (
                <label htmlFor='documentImageInput'>
                  <div className='YKEE-uploadFiles'>
                    <div className='YKEE-wrapFiles text-center'>
                      <DragandDrop
                        setSendFile={setSendFile}
                        sendFile={sendFile}
                        accept={{
                          'image/*': ['.jpeg', '.jpg', '.png'],
                        }}
                        supporttext={'Supported formats: PNG, JEPG up to 2 MB'}
                      ></DragandDrop>
                    </div>
                  </div>
                </label>
              ) : (
                <>
                  <div className='YKEE-uploadFiles'>
                    <div className='YKEE-wrapFiles text-center'>
                      <div
                        className={`after-document-upload-wrapper ${
                          !!userData?.documentAdded ? '' : 'd-none'
                        }`}
                      >
                        <div className='img-upload-wrapper'>
                          <Image src={uploadSuccess} alt='' className='fluid' />
                        </div>
                      </div>
                      <div>
                        <p className='uploaded-file-name'>
                          <span
                            onClick={() => handleClearUploadedFile()}
                            className='imgUploadCloseBtn'
                            title='Remove file'
                          >
                            <Image src={CloseIcon} alt='' className='fluid' />{' '}
                          </span>
                          {sendFile && sendFile[0]?.path}
                        </p>
                      </div>
                    </div>
                  </div>
                </>
              )}
              <div className='invalid-feedback'>
                <p>{uploadFileError}</p>
              </div>
            </>
          </div>
        </div>

        <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
          <div className='YKEE-submitDicard'>
            <div className='YKEE-twoBTNS'>
              <button
                className='btn YKEE-noOverlay'
                onClick={() =>
                  router.push(getBasePath(`consignors/${consignorId}`))
                }
              >
                Cancel
              </button>
              <button type='submit' className='btn YKEE-Default'>
                Save
              </button>
            </div>
          </div>
        </div>
      </form>
    </>
  );
};
export default EditConsignorIdentityDetails;
