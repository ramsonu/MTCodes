const EditConsignorLeftSideBar = ({ step }: any) => {
  return (
    <>
      <div className='col-xl-3 col-lg-6 col-md-12 col-sm-12 col-12 YKEE-columns'>
        <div className='card YKEE-cardCover YKEE-extraArea'>
          <div className='YKEE-flexBoxing'>
            <div className='YKEE-porcessFlow'>
              <div className='YKEE-coverFlowing'>
                <div className='YKEE-boxArea text-center'>
                  {step > 1 ? (
                    <h4 className='YKEE-filledFile'></h4>
                  ) : (
                    <h4>1</h4>
                  )}
                  <p>Consignor Details</p>
                </div>

                <div
                  className={`${
                    step > 1 ? 'YKEE-filledLine' : 'YKEE-flowLine'
                  }`}
                ></div>
              </div>
              <div className='stepper-arrow-mobile'>
                <div className='stepper-border'></div>
              </div>
              <div className='YKEE-coverFlowing'>
                <div className='YKEE-boxArea text-center'>
                  {step != 2 ? <h4 className='YKEE-Disable'>2</h4> : <h4>2</h4>}
                  <p>Identity Document</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default EditConsignorLeftSideBar;
