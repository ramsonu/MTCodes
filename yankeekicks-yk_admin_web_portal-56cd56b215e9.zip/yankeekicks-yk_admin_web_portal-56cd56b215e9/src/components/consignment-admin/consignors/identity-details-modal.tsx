/* eslint-disable @next/next/no-img-element */
import React from 'react';
import type, { NextPage } from 'next';
import Modal from '@mui/material/Modal';
import Image from 'next/image';
import ModalCloseIcon from 'assets/images/modal-close-icon.svg';

interface Props {
  showIdentityDetails?: any;
  setShowIdentityDetails?: any;
  documentToShow?: any;
}

const IdentityDetailsModal: NextPage<Props> = ({
  showIdentityDetails,
  setShowIdentityDetails,
  documentToShow,
}) => {
  const handleModalClose = () => {
    setShowIdentityDetails(false);
  };
  return (
    <>
      <div className='app-wrapper w-100 landing-page-wrapper'>
        <Modal
          open={showIdentityDetails}
          className='yk-identity-details-modal-wrapper'
          aria-labelledby='modal-modal-title'
          aria-describedby='modal-modal-description'>
          <div className='app-wrapper identity-details-modal-wrapper'>
            <div className='yk-modal-body'>
              <div className='modal-heading-wrapper'>
                <h3 className='modal-title yk-badge-h11'>
                  Identity Document
                  <span className='close-icon-wrapper'>
                    <button
                      className='btn btn-modal-close'
                      onClick={handleModalClose}>
                      <Image
                        src={ModalCloseIcon}
                        className='img-fluid'
                        alt='close-icon'></Image>
                    </button>
                  </span>
                </h3>
                <p className='modal-sub-title yk-badge-h8'>
                  Document uploaded during consignor registration
                </p>
              </div>
              <div className='yk-identityImgWrapper'>
                <div className='img-wrapper '>
                  <img
                    src={documentToShow}
                    alt='identity-img'
                    className='identity-img img-fluid'
                  />
                </div>
              </div>
              <div className='close-button-wrapper'>
                <button
                  className='btn btn-close YKCH-closeBBTN'
                  onClick={handleModalClose}>
                  Close
                </button>
              </div>
            </div>
          </div>
        </Modal>
      </div>
    </>
  );
};
export default IdentityDetailsModal;
