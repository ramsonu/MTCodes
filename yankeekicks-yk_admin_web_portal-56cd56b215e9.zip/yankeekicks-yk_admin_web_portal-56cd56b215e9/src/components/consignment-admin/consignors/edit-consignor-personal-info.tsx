import React, { useState, useEffect } from 'react';
import groupConsignee from 'assets/images/consignee/group-consignee.svg';
import userConsignee from 'assets/images/consignee/user-Info.svg';
import addressConsignee from 'assets/images/consignee/address-Book.svg';
import mapConsignee from 'assets/images/consignee/map-triFold.svg';
import countriesStateData from 'utils/countries-states.json';
import Image from 'next/image';
import { useForm } from 'react-hook-form';
import {
  ValidationFullName,
  ValidationRequired,
  ValidationMaxLength14,
  ValidationMinLength14,
  ValidationOnlyPhoneNumber,
  ValidationEmail,
  ValidationMinLength6,
  ValidationMaxLength250,
  ValidationMaxLength10,
  ValidationMaxLength5,
  ValidationMinLength5,
  ValidationOnlyNumbers,
  ValidationMaxLength20,
  ValidationBusinessName,
  ValidationOnlyEINNumber,
  ValidationMinLength11,
} from 'utils/validators';
import { getBasePath, updateEINNumber, updatePhoneNumber } from 'utils/util';
import {
  consignorType,
  getConsignorDetails,
  putUpdateUser,
} from 'services/consignor';
import { useRouter } from 'next/router';
import EditConsignorLeftSideBar from './edit-consignor-left-side-bar';
import { USER_UPDATE_SUCCESS, US_COUNTRY_INDEX } from 'utils/constants';
import Notification from 'components/common/notification';
import stateCitiesData from 'utils/states-cities.json';

const EditConsignorPersonalDetails = ({ setStep }: any) => {
  const router = useRouter();
  const { consignorId } = router.query;
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [message, setMessage] = useState<string>('');
  const [severityType, setSeverityType] = useState<string>('');
  const [saveButtonDisabled, setSaveButtonDisabled] = useState<Boolean>(true);
  const [userData, setUserData] = useState<any>();
  const [stateList, setSateList] = useState<any>(countriesStateData[0]?.states);
  const [cityList, setCityList] = useState<any>([]);
  const {
    handleSubmit,
    watch,
    setValue,
    register,
    formState: { errors, isValid },
  } = useForm<consignorType>({
    mode: 'onChange',
  });

  useEffect(() => {
    consignorTableInit();
  }, [consignorId]); // eslint-disable-line react-hooks/exhaustive-deps

  const consignorTableInit = async () => {
    let getConsignorsData = await getConsignorDetails(consignorId);
    setUserData(getConsignorsData?.data);
    /* Currently we are using one country only
    let stateFilterList = countriesStateData.filter(
      (ctry) => ctry.name == getConsignorsData?.data?.address?.country
    )[0]?.states;
     if (!!stateFilterList) setSateList(stateFilterList); */
    setValue('fullName', getConsignorsData?.data?.fullName);
    setValue(
      'businessName',
      getConsignorsData?.data?.businessDetails?.businessName
    );
    setValue('ein', getConsignorsData?.data?.businessDetails?.businessEIN);
    setValue('address.country', getConsignorsData?.data?.address?.country);
    setValue(
      'address.apartmentNumber',
      getConsignorsData?.data?.address?.apartmentNumber
    );
    setValue('address.city', getConsignorsData?.data?.address?.city);
    setValue('address.address', getConsignorsData?.data?.address?.address);
    setValue('email', getConsignorsData?.data?.email);
    setValue('address.state', getConsignorsData?.data?.address?.state);
    setValue('address.zipCode', getConsignorsData?.data?.address?.zipCode);
    setValue(
      'phoneNumber',
      updatePhoneNumber(getConsignorsData?.data?.phoneNumber)
    );
    setCityDropdownListFromState(getConsignorsData?.data?.address?.state);
  };

  const setCityDropdownListFromState = (state: string) => {
    const tempCityList = stateCitiesData[US_COUNTRY_INDEX].states.filter(
      (stateRow: any) => {
        return stateRow.name == state;
      }
    );
    setCityList(tempCityList[0]?.cities);
  };

  const handlePhoneNumberChange = (e: any) => {
    setUserData({
      ...userData,
      phoneNumber: updatePhoneNumber(e.target.value),
    });

    setValue('phoneNumber', updatePhoneNumber(e.target.value));
  };

  const handleCountryChange = (e: any) => {
    let selectedIndex = e.target.options.selectedIndex;
    if (selectedIndex > 0)
      setSateList(countriesStateData[selectedIndex - 1].states);
    else setSateList([]);
  };
  const onSubmit = async (data: any) => {
    try {
      const response = await putUpdateUser(data, consignorId);
      if (response.status) {
        setIsVisibleMessage(true);
        setSeverityType('success');
        setMessage(USER_UPDATE_SUCCESS);
        setTimeout(() => {
          setStep(2);
        }, 2000);
      } else {
        setIsVisibleMessage(true);
        setSeverityType('error');
        setMessage(response.error);
      }
    } catch (e: any) {
      setIsVisibleMessage(true);
      setSeverityType('error');
      setMessage(e?.response?.data?.error);
    }
  };

  const handleEINNumberChange = (e: any) => {
    setValue('ein', updateEINNumber(e.target.value));
  };

  return (
    <>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className='row edit-form-for-mobile'>
        <EditConsignorLeftSideBar step={1}></EditConsignorLeftSideBar>

        <div className='col-xl-9 col-lg-9 col-md-9 col-sm-9 col-12 YKEE-columns'>
          <Notification
            showSuccessPopup={isVisibleMessage}
            handleSnackbarClose={() => setIsVisibleMessage(false)}
            severityType={severityType}
            message={message}
            className='yk-shoesize-alert-wrapper'
          />
          <div className='card YKEE-cardCover'>
            <div className='YKEE-coverArea'>
              <div className='row'>
                <div className='YKEE-headerStrip'>
                  <h4 className='YKEE-personalInfo'>Personal Information</h4>
                  <Image
                    src={userConsignee}
                    alt='Consinee Group'
                    className='Image-fluid'
                  />{' '}
                </div>
                <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>Full Name*</label>
                    <input
                      type='text'
                      placeholder='Enter Full Name'
                      className='form-control YKEE-field'
                      {...register('fullName', {
                        ...ValidationFullName,
                      })}
                    />
                    {errors.fullName && (
                      <div className='invalid-feedback'>
                        {errors.fullName.message}
                      </div>
                    )}
                  </div>
                </div>
                {userData?.businessDetails?.businessName && (
                  <>
                    <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 YKEE-columns'>
                      <div className='YKEE-formArea'>
                        <label className='YKEE-lable'>Business Name*</label>
                        <input
                          type='text'
                          placeholder='Enter Business Name'
                          className='form-control YKEE-field'
                          {...register('businessName', {
                            ...ValidationBusinessName,
                          })}
                        />
                        {errors.businessName && (
                          <div className='invalid-feedback'>
                            {errors.businessName.message}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 YKEE-columns'>
                      <div className='YKEE-formArea'>
                        <label className='YKEE-lable'>{`Employer Identification Number (EIN)*`}</label>
                        <input
                          type='text'
                          placeholder='Enter EIN'
                          className='form-control YKEE-field'
                          {...register('ein', {
                            ...ValidationRequired,
                            ...ValidationMinLength11,
                            ...ValidationOnlyEINNumber,
                            onChange: (e) => handleEINNumberChange(e),
                          })}
                        />
                        {errors.ein && (
                          <div className='invalid-feedback'>
                            {errors.ein.message}
                          </div>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
            <div className='YKEE-coverArea YKEE-topAreas'>
              <div className='row'>
                <div className='YKEE-headerStrip'>
                  <h4 className='YKEE-personalInfo'>Contact</h4>
                  <Image
                    src={addressConsignee}
                    alt='Consinee Group'
                    className='Image-fluid'
                  />
                </div>

                <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>Mobile Number*</label>
                    <input
                      type='text'
                      className='form-control YKEE-field'
                      {...register('phoneNumber', {
                        ...ValidationRequired,
                        ...ValidationMaxLength14,
                        ...ValidationMinLength14,
                        ...ValidationOnlyPhoneNumber,
                        onChange: (e) => handlePhoneNumberChange(e),
                      })}
                      placeholder='Enter Contact Number'
                    />
                    {errors.phoneNumber && (
                      <div className='invalid-feedback'>
                        {errors.phoneNumber.message}
                      </div>
                    )}
                  </div>
                </div>

                <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>Email*</label>
                    <input
                      type='readonly'
                      placeholder='Enter Email'
                      className='form-control YKEE-field'
                      {...register('email', {
                        ...ValidationEmail,
                      })}
                    />
                    {errors.email && (
                      <div className='invalid-feedback'>
                        {errors.email.message}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
            <div className='YKEE-coverArea YKEE-topAreas'>
              <div className='row'>
                {' '}
                <div className='YKEE-headerStrip'>
                  <h4 className='YKEE-personalInfo'>Address</h4>
                  <Image
                    src={mapConsignee}
                    alt='Consinee Group'
                    className='Image-fluid'
                  />{' '}
                </div>
                <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>Country/Region</label>
                    <div className='YKEE-arrowDownns '>
                      <select
                        className='form-control YKEE-field'
                        {...register('address.country', {
                          ...ValidationRequired,
                          onChange: (e) => {
                            handleCountryChange(e);
                          },
                        })}>
                        <option value=''>Select Country</option>
                        {countriesStateData.map((item, index) => {
                          return (
                            <option key={index} value={item.name}>
                              {item.name}
                            </option>
                          );
                        })}
                      </select>
                    </div>
                    {errors?.address?.country && (
                      <div className='invalid-feedback'>
                        {errors?.address?.country.message}
                      </div>
                    )}
                  </div>
                </div>
                <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>Street Address</label>
                    <input
                      type='text'
                      className='form-control YKEE-field'
                      id='address'
                      {...register('address.address', {
                        ...ValidationRequired,
                        ...ValidationMinLength6,
                        ...ValidationMaxLength250,
                      })}
                      placeholder='Address'
                    />
                    {errors?.address?.address && (
                      <div className='invalid-feedback'>
                        {errors?.address?.address.message}
                      </div>
                    )}
                  </div>
                </div>
                <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>Apartment number</label>
                    <input
                      type='text'
                      className='form-control YKEE-field'
                      id='apartment-number'
                      {...register('address.apartmentNumber', {
                        ...ValidationMaxLength20,
                      })}
                      placeholder='Enter Apartment Number'
                    />
                    {errors?.address?.apartmentNumber && (
                      <div className='invalid-feedback'>
                        {errors?.address?.apartmentNumber.message}
                      </div>
                    )}
                  </div>
                </div>
                <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>State</label>
                    <div className='YKEE-arrowDownns'>
                      <select
                        className='form-control custom-select YKEE-field'
                        id='State'
                        {...register('address.state', {
                          ...ValidationRequired,
                        })}>
                        <option value=''>Select State</option>
                        {stateList.map((item: any, index: number) => {
                          return (
                            <option key={index} value={item.name}>
                              {item.name}
                            </option>
                          );
                        })}
                      </select>
                    </div>
                    {errors?.address?.state && (
                      <div className='invalid-feedback'>
                        {errors?.address?.state.message}
                      </div>
                    )}
                  </div>
                </div>
                <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>Zip/Postal Code</label>
                    <input
                      type='text'
                      placeholder='Enter Zip/Postal Code'
                      className='form-control YKEE-field'
                      {...register('address.zipCode', {
                        ...ValidationRequired,
                        ...ValidationMaxLength5,
                        ...ValidationMinLength5,
                        ...ValidationOnlyNumbers,
                      })}
                    />
                    {errors?.address?.zipCode && (
                      <div className='invalid-feedback'>
                        {errors?.address?.zipCode.message}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
          <div className='YKEE-submitDicard'>
            <div className='YKEE-twoBTNS'>
              <button
                type='button'
                onClick={() => router.push(getBasePath('consignors'))}
                className='btn YKEE-noOverlay'>
                Discard and Close
              </button>
              {/* YKEE-disableDefault */}
              <button
                type='submit'
                //disabled={!isValid}
                className='btn YKEE-Default'>
                Save and Continue
              </button>
            </div>
          </div>
        </div>
      </form>
    </>
  );
};
export default EditConsignorPersonalDetails;
