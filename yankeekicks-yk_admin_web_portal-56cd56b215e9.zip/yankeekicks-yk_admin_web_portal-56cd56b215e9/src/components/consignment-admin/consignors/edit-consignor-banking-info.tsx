import React, { useState, useEffect } from 'react';
import countriesStateData from 'utils/countries-states.json';
import bankConsinee from 'assets/images/consignee/bank-consinee.svg';
import Image from 'next/image';
import { useForm } from 'react-hook-form';
import {
  ValidationRequired,
  ValidationMinLength5,
  ValidationOnlyNumbers,
  ValidationMaxLength35,
  ValidationOnlyAlpha,
  ValidationMaxLength9,
  ValidationMinLength9,
  ValidationMaxLength17,
} from 'utils/validators';
import {
  consignorType,
  getConsignorDetails,
  putUpdateUser,
} from 'services/consignor';
import EditConsignorLeftSideBar from './edit-consignor-left-side-bar';
import { USER_UPDATE_SUCCESS } from 'utils/constants';
import Notification from 'components/common/notification';

const EditConsignorBankDetails = ({ consignorId, setStep }: any) => {
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [message, setMessage] = useState<string>('');
  const [severityType, setSeverityType] = useState<string>('');
  const {
    handleSubmit,
    watch,
    setValue,
    register,
    formState: { errors },
  } = useForm<consignorType>();

  useEffect(() => {
    consignorTableInit();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const consignorTableInit = async () => {
    let getConsignorsData = await getConsignorDetails(consignorId);
    setValue(
      'bankdetail.bankName',
      getConsignorsData?.data?.bankdetail?.bankName
    );
    setValue(
      'bankdetail.routingNum',
      getConsignorsData?.data?.bankdetail?.routingNum
    );
    setValue(
      'bankdetail.accountNo',
      getConsignorsData?.data?.bankdetail?.accountNo
    );
    setValue(
      'bankdetail.accountNo2',
      getConsignorsData?.data?.bankdetail?.accountNo2
    );
    setValue(
      'bankdetail.typeOfTransfer',
      getConsignorsData?.data?.bankdetail?.typeOfTransfer
    );
    setValue(
      'bankdetail.accountType',
      getConsignorsData?.data?.bankdetail?.accountType
    );
    setValue(
      'bankdetail.cardHolderName',
      getConsignorsData?.data?.bankdetail?.cardHolderName
    );
    setValue(
      'bankdetail.cardNumber',
      getConsignorsData?.data?.bankdetail?.cardNumber
    );
    setValue(
      'bankdetail.cardExpDate',
      getConsignorsData?.data?.bankdetail?.cardExpDate
    );
    setValue(
      'bankdetail.cardCvv',
      getConsignorsData?.data?.bankdetail?.cardCvv
    );
  };

  const onSubmit = async (data: any) => {
    const response = await putUpdateUser(data, consignorId);
    if (response.status) {
      setTimeout(() => {
        setStep(3);
      });
      setIsVisibleMessage(true);
      setSeverityType('success');
      setMessage(USER_UPDATE_SUCCESS);
    } else {
      setIsVisibleMessage(true);
      setSeverityType('error');
      setMessage(response.error);
    }
  };
  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)} className='row'>
        <Notification
          showSuccessPopup={isVisibleMessage}
          handleSnackbarClose={() => setIsVisibleMessage(false)}
          severityType={severityType}
          message={message}
          className='yk-shoesize-alert-wrapper'
        />
        <EditConsignorLeftSideBar step={2}></EditConsignorLeftSideBar>

        <div className='col-xl-9 col-lg-6 col-md-12 col-sm-12 col-12 YKEE-columns'>
          <div className='card YKEE-cardCover'>
            <div className='YKEE-coverArea YKEE-topAreas'>
              <div className='row'>
                {' '}
                <div className='YKEE-headerStrip'>
                  <h4 className='YKEE-personalInfo'>Banking Information</h4>
                  <Image
                    src={bankConsinee}
                    alt='Consinee Group'
                    className='Image-fluid'
                  />{' '}
                </div>
                <div className='col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>Account Holder’s Name</label>
                    <input
                      type='text'
                      placeholder='Account Holder Name'
                      className='form-control YKEE-field'
                      {...register('bankdetail.bankName', {
                        ...ValidationRequired,
                        ...ValidationMaxLength35,
                        ...ValidationOnlyAlpha,
                      })}
                    />
                    {errors?.bankdetail?.bankName && (
                      <div className='invalid-feedback'>
                        {errors?.bankdetail?.bankName?.message}
                      </div>
                    )}
                  </div>
                </div>
                <div className='col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>Routing/ABA Number</label>
                    <input
                      type='text'
                      placeholder='Routing/ABA Number'
                      className='form-control YKEE-field'
                      {...register('bankdetail.routingNum', {
                        ...ValidationRequired,
                        ...ValidationOnlyNumbers,
                        ...ValidationMaxLength9,
                        ...ValidationMinLength9,
                      })}
                    />
                    {errors?.bankdetail?.routingNum && (
                      <div className='invalid-feedback'>
                        {errors?.bankdetail?.routingNum?.message}
                      </div>
                    )}
                  </div>
                </div>
                <div className='col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 YKEE-columns'>
                  <div className='YKEE-formArea'>
                    <label className='YKEE-lable'>Account Number</label>
                    <input
                      type='text'
                      placeholder='Account Number'
                      className='form-control YKEE-field'
                      {...register('bankdetail.accountNo', {
                        ...ValidationRequired,
                        ...ValidationOnlyNumbers,
                        ...ValidationMaxLength17,
                        ...ValidationMinLength5,
                      })}
                    />
                    {errors?.bankdetail?.accountNo && (
                      <div className='invalid-feedback'>
                        {errors?.bankdetail?.accountNo?.message}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
          <div className='YKEE-submitDicard'>
            <div className='YKEE-twoBTNS'>
              <button className='btn YKEE-noOverlay'>Cancel</button>
              <button type='submit' className='btn YKEE-Default'>
                Save and Continue
              </button>
            </div>
          </div>
        </div>
      </form>
    </>
  );
};
export default EditConsignorBankDetails;
