import React, { useEffect, useState } from 'react';
import type, { NextPage } from 'next';
import Modal from '@mui/material/Modal';
import {
  postCommissionRequest,
  getAllCommissionTypes,
} from 'services/consignor';
import Notification from 'components/common/notification';
import { CHANGE_COMMISSION_REQUEST } from '../constants';
import { useDispatch } from 'react-redux';
import { DISABLE_LOADER, ENABLE_LOADER } from 'actions/loader';
import { USER_ROLES } from 'utils/constants';
interface Props {
  showChangeCommission?: any;
  setShowChangeCommission?: any;
  consignorData?: any;
  reloadConsignorData?: any;
}

const ChangeCommissionModal: NextPage<Props> = ({
  showChangeCommission,
  setShowChangeCommission,
  consignorData,
  reloadConsignorData,
}) => {
  const dispatch = useDispatch();
  const [commissionTypes, setCommissionTypes] = useState<any>([]);
  const [selectedCommission, setSelectedCommission] = useState<any>(0);
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);
  const [showWarningPopup, setShowWarningPopup] = useState(false);
  const [warningMessage, setWarningMessage] = useState('');
  const [showErrorMessage, setShowErrorMessage] = useState('');

  useEffect(() => {
    (async () => {
      const getCommissionTypes = await getAllCommissionTypes();
      const result: any = Object.values(getCommissionTypes?.data);
      setCommissionTypes(result);
    })();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleModalClose = () => {
    setShowChangeCommission(false);
  };

  const changeCommission = async () => {
    dispatch({ type: ENABLE_LOADER });
    let payload = {
      consigneeId: consignorData?.id,
      description: 'commission change',
      fromTypeId: consignorData?.consigneeTypeDTO?.consigneeTypeId,
      requestedByUserId: localStorage.getItem('userId'),
      toTypeId: selectedCommission,
    };
    let result: any = [];

    try {
      result = await postCommissionRequest(payload);
      if (result?.status === 201 || result?.status === 200) {
        reloadConsignorData();
        dispatch({ type: DISABLE_LOADER });
        setShowSuccessPopup(true);
        handleModalClose();
      } else {
        dispatch({ type: DISABLE_LOADER });
        setShowWarningPopup(true);
        setWarningMessage(
          result?.response?.data?.message || result?.response?.data?.error
        );
        handleModalClose();
      }
    } catch (e: any) {
      dispatch({ type: DISABLE_LOADER });
      setShowWarningPopup(true);
      setWarningMessage(e?.response?.data?.message || e?.response?.data?.error);
      handleModalClose();
    }
  };

  const onCommissionChange = (event: any) => {
    if (
      consignorData?.consigneeTypeDTO?.consigneeTypeId === event.target.value
    ) {
      setShowErrorMessage('please select different commission type');
    } else {
      setShowErrorMessage('')
      setSelectedCommission(event.target.value);
    }
  };

  const handleSnackbarClose = () => {
    setShowSuccessPopup(false);
    setShowWarningPopup(false);
  };

  const message = (
    <h3 className='notification-heading'>{CHANGE_COMMISSION_REQUEST}</h3>
  );
  const warningMessages = (
    <h3 className='notification-heading'>{warningMessage}</h3>
  );
  return (
    <>
      <div className='app-wrapper w-100 landing-page-wrapper'>
        <Modal
          open={showChangeCommission}
          onClose={handleModalClose}
          className='yk-change-commission-modal-wrapper'
          aria-labelledby='modal-modal-title'
          aria-describedby='modal-modal-description'
        >
          <div className='app-wrapper change-commission-modal-wrapper'>
            <div className='yk-modal-body'>
              <div className='modal-heading-wrapper'>
                <h3 className='modal-title yk-badge-h11'>Change commission</h3>
                <p className='modal-sub-title'>
                  Please select new commission to request change
                </p>
              </div>
              <form>
                <div className='yk-form-field'>
                  <label className='col-form-label form-field-title'>
                    Current Commission
                  </label>
                  <input
                    type='text'
                    className='form-control yk-form-field-input'
                    id='recipient-name'
                    placeholder='Default (20%)'
                    value={consignorData?.consigneeTypeDTO?.commissionName}
                    disabled
                  />
                </div>
                <div className='yk-form-field'>
                  <label className='col-form-label form-field-title'>
                    New Commission
                  </label>
                  <div className='YKEE-arrowDownns'>
                    <select
                      className='form-control yk-form-field-input'
                      id='message-text'
                      placeholder='Select New Commission'
                      onChange={onCommissionChange}
                    >
                      <option value=''>
                        Please select new commission type
                      </option>
                      ;
                      {commissionTypes?.length &&
                        commissionTypes?.map((item: any) => {
                          return (
                            <>
                              {consignorData?.consigneeTypeDTO
                                ?.consigneeTypeId != item?.consigneeTypeId && (
                                <option
                                  key={item?.consigneeTypeId}
                                  value={item?.consigneeTypeId}
                                >
                                  {item?.commissionName}
                                </option>
                              )}
                            </>
                          );
                        })}
                    </select>
                  </div>
                  {showErrorMessage && (
                    <div className='invalid-feedback'>{showErrorMessage}</div>
                  )}
                </div>
              </form>
              <div className='yk-modal-btn-wrapper'>
                <button
                  type='button'
                  className='btn modal-btn-cancel'
                  data-bs-dismiss='modal'
                  onClick={handleModalClose}
                >
                  Cancel
                </button>
                <button
                  type='button'
                  className='btn modal-btn-submit'
                  onClick={changeCommission}
                  disabled={selectedCommission > 0 ? false : true}
                >
                  {localStorage?.getItem('user-role') === USER_ROLES.YK_ADMIN
                    ? 'Submit' : 'Submit Request'}
                </button>
              </div>
            </div>
          </div>
        </Modal>
      </div>
      <Notification
        showSuccessPopup={showSuccessPopup}
        handleSnackbarClose={handleSnackbarClose}
        severityType='success'
        message={message}
        className='yk-shoesize-alert-wrapper'
      />
      <Notification
        showSuccessPopup={showWarningPopup}
        handleSnackbarClose={handleSnackbarClose}
        severityType='warning'
        message={warningMessages}
        className='yk-shoesize-alert-wrapper'
      />
    </>
  );
};
export default ChangeCommissionModal;
