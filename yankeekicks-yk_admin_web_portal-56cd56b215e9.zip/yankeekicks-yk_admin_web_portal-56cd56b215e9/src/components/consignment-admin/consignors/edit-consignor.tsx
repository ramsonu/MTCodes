import React, { useState } from 'react';
import groupConsignee from 'assets/images/consignee/group-consignee.svg';
import { useRouter } from 'next/router';
import EditConsignorPersonalDetails from './edit-consignor-personal-info';
import EditConsignorIdentityDetails from './edit-consignor-Identity-info';
import EditConsignorBankDetails from './edit-consignor-banking-info';
import { getBasePath } from 'utils/util';
import Breadcrumbs from 'components/common/breadcrumbs';

const EditConsignor = () => {
  const [step, setStep] = useState(1);
  const router = useRouter();
  const { consignorId } = router.query;
  const headers = {
    title: 'Consignors',
    titleImage: groupConsignee,
    subTitle: consignorId,
    nextSubTitle: 'Edit Consignor',
    onClick: () => {
      router?.push(`${getBasePath('consignors')}`);
    },
    onNextClick: () => {
      router?.push(`${getBasePath(`consignors/${consignorId}`)}`);
    },
  };
  return (
    <>
      <div className='row m-auto YKEE-additional'>
        {/* breadCrumb */}
        <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
          <div className='YKEE-breadCrumb'>
            <Breadcrumbs data={headers} />
          </div>
        </div>

        <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
          <h2 className='YKEE-headlines'>Edit Consignor</h2>
          <p className='YKEE-overviews'>
            Please change the details below to update consignor information
          </p>
        </div>

        {/* card sections */}
        {step == 1 && <EditConsignorPersonalDetails setStep={setStep} />}
        {/* For Future reference */}
        {/*         {step == 2 && (
          <EditConsignorBankDetails
            consignorId={consignorId}
            setStep={setStep}
          />
        )} */}
        {step == 2 && <EditConsignorIdentityDetails setStep={setStep} />}
      </div>
    </>
  );
};
export default EditConsignor;
