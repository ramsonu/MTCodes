import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/router';
import { FNS_DATE_FORMAT } from 'utils/constants';
import VirtualTable from 'components/common/table';
import { useCubeQuery } from '@cubejs-client/react';
import Pagination from 'components/common/pagination';
import SearchComp from 'components/common/search';
import Sortings from 'components/common/sortings';
import filterIcon from 'assets/images/filter-icon.png';
import {
  getConsignorList,
  getConsignorListPagination,
} from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import ProductFilters from 'components/common/filters/product-filter';
import ExportsTypes from 'components/common/exports-types';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import { getCommissionNames } from 'middleware/cubejs-wrapper/yk-super-admin-cubejs-query';

const Consignors = () => {
  const router = useRouter();
  const pageLimit = 10;
  const [clearDisable, setClearDisable] = useState(true);
  const [consignorsList, setConsignorsList] = useState([]);
  const [userInput, setUserInput] = useState<any>('');
  const [searchOffset, setSearchOffset] = useState<any>(0);
  const [countForPagination, setCountForPagination] = useState(0);
  const [showFilters, setShowFilters] = useState<boolean>(false);
  const [selectedSort, setSelectedSort] = useState('consignorIdDesc');
  const [filterInput, setFilterInput] = useState([]);
  const [searchInput, setSearchInput] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<any>([]);
  const [checked, setChecked] = useState({
    ACTIVE: false,
    pending: false,
    DISABLED: false,
  });
  const [selectedCommisonType, setSelectedCommisonType] = useState<any>([]);

  const [isPDFExport, setIsPDFExport] = useState(true);
  const [commissionNamesList, setCommissionNamesList] = useState([]);
  const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
  const commissionDetailsByIdQuery: any = getCommissionNames();

  const { resultSet: commissionDetailsResultSet }: any = useCubeQuery(
    commissionDetailsByIdQuery
  );

  const queryPayload = {
    userInput,
    selectedSort,
    filterInput,
    userDetails,
  };

  const consignmentQuery: any = getConsignorList(
    searchInput,
    filterInput,
    selectedSort,
    pageLimit,
    searchOffset
  );
  const paginationCountForConsignment: any = getConsignorListPagination(
    searchInput,
    filterInput,
    selectedSort
  );

  const {
    resultSet: consignorListResultSet,
    isLoading: consignmentIsLoading,
    error: consignmentError,
  }: any = useCubeQuery(consignmentQuery);

  const exportsConsignorsQuery: any = getConsignorList(
    searchInput,
    filterInput,
    selectedSort
  );

  const { resultSet: pageCountResultSet }: any = useCubeQuery(
    paginationCountForConsignment
  );
  const { resultSet: exportsResultsSet }: any = useCubeQuery(
    exportsConsignorsQuery,
    { skip: isPDFExport }
  );

  useEffect(() => {
    const data = consignorListResultSet?.loadResponses[0]?.data;
    if (data) {
      setConsignorsList(data);
    } else {
      setConsignorsList([]);
    }
    if (pageCountResultSet) {
      let countData =
        +pageCountResultSet?.loadResponses[0]?.data[0]?.['Users.count'] || 0;
      setCountForPagination(countData);
    }
  }, [consignorListResultSet, pageCountResultSet]);

  useEffect(() => {
    const data = commissionDetailsResultSet?.loadResponses[0]?.data;
    if (data) {
      setCommissionNamesList(data);
    } else {
      setCommissionNamesList([]);
    }
  }, [commissionDetailsResultSet]);

  const onClickPDFExport = () => {
    setIsPDFExport(false);
    setTimeout(() => {
      setIsPDFExport(true);
    }, 100);
  };
  const onChangeHandler = (event: any) => {
    setSearchInput(event.target.value);
    setSearchOffset(0);
  };

  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
  };
  const onPayoutChange = (event: any) => {
    setChecked({ ...checked, [event?.target?.name]: event?.target?.checked });
    let updatedList = [...selectedStatus];
    if (event.target.checked) {
      updatedList = [...selectedStatus, event.target.name];
    } else {
      updatedList.splice(selectedStatus.indexOf(event.target.name), 1);
    }
    setSelectedStatus(updatedList);
    if (updatedList.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  };

  const onCommissionChange = (event: any) => {
    if (selectedCommisonType.includes(event?.target?.name)) {
      let tempOption = [];
      tempOption = selectedCommisonType.filter(
        (data: any) => data !== event?.target?.name
      );
      setSelectedCommisonType(tempOption);
      if (tempOption.length === 0) {
        setClearDisable(true);
      }
    } else {
      setSelectedCommisonType([...selectedCommisonType, event?.target?.name]);
      setClearDisable(false);
    }
  };
  const onApplyFilters = () => {
    const filterPayload: any = {
      status: selectedStatus,
      commission: selectedCommisonType,
    };
    if (selectedCommisonType?.length > 0 || selectedStatus?.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
    setFilterInput(filterPayload);
    setShowFilters(false);
  };

  const onClearFilters = () => {
    setSelectedStatus([]);
    setSelectedCommisonType([]);
    setChecked({ ACTIVE: false, pending: false, DISABLED: false });
    setFilterInput([]);
    setShowFilters(false);
    setClearDisable(true);
  };

  const columns = React.useMemo(
    () => [
      {
        title: 'ID',
        value: 'Users.userId',
      },
      {
        title: 'Name',
        value: 'Users.userName',
      },
      { title: 'Phone', value: 'Users.PhoneNumber', type: 'phone' },
      {
        title: 'Email',
        value: 'Users.emailId',
      },
      {
        title: 'Date Added',
        type: 'date',
        format: FNS_DATE_FORMAT,
        value: 'Users.createdAt',
      },
      {
        title: 'Commission',
        value: 'ConsigneeType.name',
      },

      {
        title: 'Status',
        type: 'status',
        value: 'Users.status',
        success: 'ACTIVE',
        pending: 'PENDING',
        danger: 'DISABLED',
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          router.push(`consignors/${data['Users.userId']}`);
        },
        value: 'View',
      },
    ],
    []
  );
  const exportHeaders = [
    { label: 'ID', key: 'Users.userId' },
    { label: 'Name', key: 'Users.userName' },
    { label: 'Number', key: 'Users.PhoneNumber', type: 'phoneNumber' },
    { label: 'Email', key: 'Users.emailId' },
    { label: 'Date Added', key: 'Users.createdAt' },
    { label: 'Commission', key: 'ConsigneeType.name' },
    { label: 'Status', key: 'Users.status' },
  ];
  return (
    <>
      <div className='consignment-admin-details'>
        <div className='container-fluid'>
          <div className='d-flex justify-content-between'>
            <h3 className='yk-main-title '>Consignors</h3>{' '}
            <div className='sort-product-wrapper export-btn me-0 p-0'>
              <ExportsTypes
                data={
                  (exportsResultsSet?.loadResponses &&
                    exportsResultsSet?.loadResponses[0]?.data) ||
                  []
                }
                headers={exportHeaders}
                fileName='consignors'
                queryPayload={queryPayload}
                onClickPDFExport={onClickPDFExport}
                isActive={consignorsList && consignorsList?.length > 0}
              />
            </div>
          </div>
          <section className='consignor-details-section'>
            <div className='row'>
              <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                <section className='inventory-details-table-section YKCH-filterSearchComponent'>
                  <div className='yk-card-body YKCH-cardBody'>
                    <div className='row'>
                      <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 YKCH-searchingData'>
                        <SearchComp
                          optionType='change'
                          placeholder='Search'
                          onChangeHandler={onChangeHandler}
                        />
                      </div>
                      <div className='col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12'>
                        <div className='consignment-btn-wrapper'>
                          <div className='me-3'>
                            <Sortings
                              itemKey='consignors'
                              handleChange={sortHandler}
                              defaultSelectedValue={selectedSort}
                            />
                          </div>
                          <div className='filter-btn-wrapper YKCH-filterWrapperr'>
                            <ClickAwayListener
                              onClickAway={() => {
                                setShowFilters(false);
                              }}
                            >
                              <div className='YKCH-filterBTNWrapp'>
                                <button
                                  className='btn filter-btn YKCH-filterBTNN me-0'
                                  onClick={() => setShowFilters(!showFilters)}
                                >
                                  <Image
                                    src={filterIcon}
                                    alt='filter-btn-icon'
                                    className='filter-btn-icon YKCH-filterIcon img-fluid'
                                  />
                                  <span className='filter-btn-text yk-badge-h15 YKCH-filterText'>
                                    Filter
                                  </span>
                                </button>
                                {showFilters && (
                                  <ProductFilters
                                    itemKey='consignorFilter'
                                    data={commissionNamesList}
                                    onApplyClick={onApplyFilters}
                                    checkedValue={checked}
                                    checkedSkuValue={selectedCommisonType}
                                    onSkuChange={onCommissionChange}
                                    onClearFilters={onClearFilters}
                                    onPayoutChange={onPayoutChange}
                                    clearDisable={clearDisable}
                                  />
                                )}
                              </div>
                            </ClickAwayListener>
                          </div>
                        </div>
                      </div>
                    </div>
                    <VirtualTable
                      loading={consignmentIsLoading}
                      error={consignmentError}
                      headers={columns}
                      rowData={consignorsList}
                    />
                    {countForPagination > 0 && (
                      <div className='center-pagination'>
                        <Pagination
                          lengthOfData={countForPagination}
                          itemsPerPage={pageLimit}
                          currentOffset={searchOffset}
                          setOffset={setSearchOffset}
                        />
                      </div>
                    )}
                  </div>
                </section>
              </div>
            </div>
          </section>
        </div>
      </div>
    </>
  );
};
export default Consignors;
