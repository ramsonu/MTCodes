import React, { useEffect, useState } from 'react';
import arrowToggle from 'assets/images/caretArrow.svg';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Typography,
  Button,
} from '@mui/material';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Image from 'next/image';
import { useRouter } from 'next/router';
import ProductsComp from 'components/consignment-admin/products';
import { getConsignorDetails, updateConsignorStatus } from 'services/consignor';
import DotsThreeVertical from 'assets/images/DotsThreeVertical.svg';
import { getConsignorProfileData } from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import { useCubeQuery } from '@cubejs-client/react';
import ChangeCommissionModal from './change-commission-modal';
import IdentityDetailsModal from './identity-details-modal';
import Notification from 'components/common/notification';
import { USER_UPDATE_SUCCESS } from 'utils/constants';
import ConfirmPopup from 'components/common/confirm-popup';
import Breadcrumbs from 'components/common/breadcrumbs';
import { convertPriceToUSFormat, getBasePath } from 'utils/util';
import groupConsignee from 'assets/images/consignee/group-consignee.svg';
import {
  CONFIRM_MESSAGE_ACTIVE_CONSIGNOR,
  CONFIRM_MESSAGE_DISABLE_CONSIGNOR,
} from 'components/yk-admin/constants';
import { useDispatch } from 'react-redux';
import { DISABLE_LOADER, ENABLE_LOADER } from 'actions/loader';
import { updatePhoneNumber } from 'utils/util';

const ViewConsignor = () => {
  const router = useRouter();
  const dispatch = useDispatch();
  const { consignorId } = router.query;
  const [consignorData, SetConsignorData] = useState<any>();
  const [showConfirmModal, setShowConfirmModal] = useState<any>(false);
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const [showChangeCommission, setShowChangeCommission] = useState<any>(false);
  const [showIdentityDetails, setShowIdentityDetails] = useState<any>(false);
  const [isVisibleMessage, setIsVisibleMessage] = useState<any>(false);
  const [severityType, setSeverityType] = useState<any>('');
  const [notificationMessage, setNotificationMessage] = useState<any>('');
  const [consignorPryoutDetails, setConsignorPryoutDetails] = useState<any>({});
  const [documentToShow, setDocumentToShow] = useState<any>('');

  const consignorProfileDataQuery: any = getConsignorProfileData(consignorId);
  const {
    resultSet: consignorProfileData,
    isLoading: consignmentIsLoading,
    error: consignmentError,
  }: any = useCubeQuery(consignorProfileDataQuery);

  useEffect(() => {
    consignorTableInit();
  }, [consignorId]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const data = consignorProfileData?.loadResponses[0]?.data?.[0];
    setConsignorPryoutDetails(data);
  }, [consignorProfileData]);

  const consignorTableInit = async () => {
    let getConsignorsData = await getConsignorDetails(consignorId);
    SetConsignorData(getConsignorsData?.data);
  };

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  const editProfile = () => {
    router.push(`${consignorId}/edit`);
  };

  const identityDetails = (data: any) => {
    setDocumentToShow(data || '');
    setShowIdentityDetails(true);
  };

  const changeCommission = () => {
    setShowChangeCommission(true);
  };
  const handleConsignorActionClick = async () => {
    try {
      dispatch({ type: ENABLE_LOADER });
      let handleCongnorAction = await updateConsignorStatus(consignorData);
      if (handleCongnorAction.status == 200) {
        dispatch({ type: DISABLE_LOADER });
        setIsVisibleMessage(true);
        setSeverityType('success');
        setNotificationMessage(USER_UPDATE_SUCCESS);
        setTimeout(() => {
          router.push('../consignors');
        }, 2000);
      } else {
        dispatch({ type: DISABLE_LOADER });
        setIsVisibleMessage(true);
        setSeverityType('warning');
        setNotificationMessage(handleCongnorAction?.data?.message);
      }
    } catch (e: any) {
      dispatch({ type: DISABLE_LOADER });
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setNotificationMessage(e?.response?.data?.message);
    }
  };
  const headers = {
    title: 'Consignors',
    titleImage: groupConsignee,
    subTitle: consignorId,
    onClick: () => {
      router?.push(`${getBasePath('consignors')}`);
    },
  };

  return (
    <>
      <div className='container-fluid'>
        <div className='row'>
          <Breadcrumbs data={headers} />
        </div>
      </div>

      <div className='consignment-admin-details'>
        <div className='container-fluid'>
          <section className='page-tool-section'>
            <div className='d-flex grid-for-mobile'>
              <div className='left-tool-info'>
                <div className='tool-info-heading'>
                  {consignorData?.fullName} ({consignorId})
                </div>
                <div className='tool-info-subheading'>Consignor details</div>
              </div>
              <div className='right-tool-info'>
                <ConfirmPopup
                  showPopup={showConfirmModal}
                  handleClose={(e: any) => setShowConfirmModal(false)}
                  title={
                    consignorData?.active
                      ? 'Disable Consignor'
                      : 'Activate Consignor'
                  }
                  message={
                    consignorData?.active
                      ? CONFIRM_MESSAGE_DISABLE_CONSIGNOR
                      : CONFIRM_MESSAGE_ACTIVE_CONSIGNOR
                  }
                  handleSave={handleConsignorActionClick}
                />

                <button
                  className='btn tool-action-btn'
                  onClick={(e) => setShowConfirmModal(true)}
                  type='button'>
                  {consignorData?.active
                    ? 'Disable Consignor'
                    : 'Activate Consignor'}
                </button>
              </div>
            </div>
          </section>
          <section className='consignor-details-section YKCH-newGame'>
            <div className='row'>
              <div className='col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12 pe-1 mb-4'>
                <section className='inventory-details-table-section'>
                  <div className='yk-cards YKCH-newCardProp ps-0 pe-0'>
                    <ProductsComp
                      consignorId={consignorId}
                      isLoadedInConsigorModule={true}
                    />
                  </div>
                </section>
              </div>
              <div className='col-xl-4 col-lg-12 col-md-12 col-sm-12 col-12 mb-4'>
                <section className='profile-details-accordion-section'>
                  <div className='profile-details-widgets'>
                    <div className='yk-cards YKCH-newCardProp'>
                      <div className='yk-cards-heading YKCH-detailTitle d-flex justify-content-between align-items-center'>
                        <h4 className='YK-LKEEEE'>Profile</h4>
                        <div className='YKCH-leftBtnOver'>
                          <Button
                            id='basic-button'
                            aria-controls={open ? 'basic-menu' : undefined}
                            aria-haspopup='true'
                            aria-expanded={open ? 'true' : undefined}
                            onClick={handleClick}
                            className='justify-content-end align-items-end yk-nineMini'>
                            <Image src={DotsThreeVertical} alt='' title='' />
                          </Button>
                          <Menu
                            id='basic-menu'
                            anchorEl={anchorEl}
                            open={open}
                            onClose={handleClose}
                            MenuListProps={{
                              'aria-labelledby': 'basic-button',
                            }}>
                            {/* <MenuItem onClick={editProfile}>
                              Edit Profile
                            </MenuItem> */}
                            <MenuItem onClick={changeCommission}>
                              Change commission
                            </MenuItem>
                          </Menu>
                        </div>
                      </div>
                      <div className='yk-card-body'>
                        <div className='c-details-card consignor-profile-info'>
                          <div className='c-name'>
                            {consignorData?.fullName}
                          </div>
                          <div className='c-contact'>
                            <span className='c-email'>
                              {consignorData?.email}
                            </span>
                            .
                            <span className='c-mobile'>
                              {updatePhoneNumber(consignorData?.phoneNumber)}
                            </span>
                          </div>
                        </div>
                        {!!consignorData?.businessDetails &&
                          !!consignorData?.businessDetails?.businessName && (
                            <div className='c-details-card status'>
                              <div className='d-flex'>
                                <div className='flex-fill'>
                                  <div className='c-s-heading'>
                                    Business Name
                                  </div>
                                  <div className='c-s-value '>
                                    <b>
                                      {consignorData?.businessDetails
                                        ?.businessName || '--'}
                                    </b>
                                  </div>
                                </div>
                                <div className='flex-fill'>
                                  <div className='c-s-heading'>EIN</div>
                                  <div className='c-s-value '>
                                    <b>
                                      {consignorData?.businessDetails
                                        ?.businessEIN || '--'}
                                    </b>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                        <div className='c-details-card status'>
                          <div className='d-flex'>
                            <div className='flex-fill'>
                              <div className='c-s-heading'>Total Payout</div>
                              <div className='c-s-value '>
                                <b>
                                  {!!consignorPryoutDetails?.[
                                    'ConsignorProfile.payoutAmount'
                                  ]
                                    ? convertPriceToUSFormat(
                                        parseFloat(
                                          consignorPryoutDetails?.[
                                            'ConsignorProfile.payoutAmount'
                                          ]
                                        ).toFixed(2)
                                      )
                                    : '$0.00'}
                                </b>
                              </div>
                            </div>
                            <div className='flex-fill'>
                              <div className='c-s-heading'>Total Sales</div>
                              <div className='c-s-value '>
                                <b>
                                  {!!consignorPryoutDetails?.[
                                    'ConsignorProfile.totalLineItemsPrice'
                                  ]
                                    ? convertPriceToUSFormat(
                                        parseFloat(
                                          consignorPryoutDetails?.[
                                            'ConsignorProfile.totalLineItemsPrice'
                                          ]
                                        )?.toFixed(2)
                                      )
                                    : '$0.00'}
                                </b>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className='c-details-accordion'>
                          <Accordion defaultExpanded={true}>
                            <AccordionSummary
                              aria-controls='panel1a-content'
                              id='panel1a-header'>
                              <Typography>
                                <div className='d-flex justify-content-between align-items-center h-100'>
                                  <b>Commission Details</b>
                                  <Image
                                    src={arrowToggle}
                                    alt='filter-btn-icon'
                                    className='filter-btn-icon img-fluid'
                                  />
                                </div>
                              </Typography>
                            </AccordionSummary>
                            <AccordionDetails>
                              <div className='c-accordion-info in'>
                                <div className='d-flex'>
                                  <div className='c-profile-info'>Type:</div>
                                  <div className='c-profile-details'>
                                    {consignorData?.commissionDetailsDTO?.type
                                      ? consignorData?.commissionDetailsDTO
                                          ?.type
                                      : '--'}
                                  </div>
                                </div>
                                <div className='d-flex'>
                                  <div className='c-profile-info'>
                                    New Commission:
                                  </div>
                                  <div className='c-profile-details'>
                                    {consignorData?.commissionDetailsDTO
                                      ?.newCommission
                                      ? consignorData?.commissionDetailsDTO
                                          ?.newCommission
                                      : '--'}
                                  </div>
                                </div>
                                <div className='d-flex'>
                                  <div className='c-profile-info'>Status:</div>
                                  <div
                                    className={`c-profile-details ${
                                      consignorData?.commissionDetailsDTO
                                        ?.status === 'Approved'
                                        ? 'completed'
                                        : 'color-pending'
                                    }`}>
                                    {consignorData?.commissionDetailsDTO?.status
                                      ? consignorData?.commissionDetailsDTO
                                          ?.status
                                      : '--'}
                                  </div>
                                </div>
                              </div>
                            </AccordionDetails>
                          </Accordion>
                          <Accordion defaultExpanded={true}>
                            <AccordionSummary
                              aria-controls='panel1a-content'
                              id='panel1a-header'>
                              <Typography>
                                {' '}
                                <div className='d-flex justify-content-between align-items-center h-100'>
                                  <b>Banking Details</b>{' '}
                                  <Image
                                    src={arrowToggle}
                                    alt='filter-btn-icon'
                                    className='filter-btn-icon img-fluid'
                                  />
                                </div>
                              </Typography>
                            </AccordionSummary>
                            <AccordionDetails>
                              <div className='c-accordion-info in'>
                                <div className='d-flex'>
                                  <div className='c-profile-info'>Name:</div>
                                  <div className='c-profile-details'>
                                    {consignorData?.bankdetail?.bankName ||
                                      '--'}
                                  </div>
                                </div>
                                <div className='d-flex'>
                                  <div className='c-profile-info'>
                                    Routing/ABA no:
                                  </div>
                                  <div className='c-profile-details'>
                                    {consignorData?.bankdetail?.routingNum ||
                                      '--'}
                                  </div>
                                </div>
                                <div className='d-flex'>
                                  <div className='c-profile-info'>
                                    Account no:
                                  </div>
                                  <div className='c-profile-details'>
                                    {consignorData?.bankdetail?.accountNo ||
                                      '--'}
                                  </div>
                                </div>
                                <div className='d-none'>
                                  <div className='c-profile-info'>
                                    Account type:
                                  </div>
                                  <div className='c-profile-details'>
                                    {consignorData?.bankdetail?.accountType
                                      ? consignorData?.bankdetail?.accountType
                                      : '--'}
                                  </div>
                                </div>
                              </div>
                            </AccordionDetails>
                          </Accordion>

                          {consignorData?.userDocuments?.length > 0 && (
                            <Accordion defaultExpanded={true}>
                              <AccordionSummary
                                aria-controls='panel1a-content'
                                id='panel1a-header'>
                                <Typography>
                                  {' '}
                                  <div className='d-flex justify-content-between align-items-center h-100'>
                                    <b>Identity Details</b>
                                    <Image
                                      src={arrowToggle}
                                      alt='filter-btn-icon'
                                      className='filter-btn-icon img-fluid'
                                    />
                                  </div>
                                </Typography>
                              </AccordionSummary>

                              <AccordionDetails>
                                <div className='c-accordion-info'>
                                  {consignorData?.userDocuments?.length > 0 &&
                                    consignorData?.userDocuments?.map(
                                      (item: any, index: any) => {
                                        return (
                                          <React.Fragment key={index}>
                                            <div className='d-flex justify-content-between'>
                                              <div className='c-profile-info'>
                                                Document type:
                                              </div>
                                              <div className='c-profile-details yk-documentTypeDetails'>
                                                {!!item?.documentImage && (
                                                  <span>
                                                    {item?.documentType ==
                                                    'driverLicense'
                                                      ? 'Driver`s License'
                                                      : item?.documentType ==
                                                        'stateId'
                                                      ? 'State Id'
                                                      : item?.documentType ==
                                                        'passport'
                                                      ? 'Passport'
                                                      : item?.documentType}
                                                  </span>
                                                )}
                                              </div>
                                            </div>
                                            <div className='d-flex'>
                                              <div className='c-profile-info'>
                                                Document:
                                              </div>
                                              <div className='c-profile-details'>
                                                {!!item?.documentImage && (
                                                  <div
                                                    className='view-link'
                                                    data-doc={
                                                      item?.documentImage
                                                    }
                                                    onClick={() =>
                                                      identityDetails(
                                                        item?.documentImage
                                                      )
                                                    }>
                                                    View
                                                  </div>
                                                )}
                                                {showIdentityDetails && (
                                                  <IdentityDetailsModal
                                                    documentToShow={
                                                      documentToShow
                                                    }
                                                    showIdentityDetails={
                                                      showIdentityDetails
                                                    }
                                                    setShowIdentityDetails={
                                                      setShowIdentityDetails
                                                    }></IdentityDetailsModal>
                                                )}
                                              </div>
                                            </div>
                                          </React.Fragment>
                                        );
                                      }
                                    )}
                                </div>
                              </AccordionDetails>
                            </Accordion>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </section>
              </div>
            </div>
          </section>
        </div>
      </div>

      <Notification
        showSuccessPopup={isVisibleMessage}
        handleSnackbarClose={() => setIsVisibleMessage(false)}
        severityType={severityType}
        message={notificationMessage}
        className='yk-shoesize-alert-wrapper'
      />

      {
        <ChangeCommissionModal
          showChangeCommission={showChangeCommission}
          setShowChangeCommission={setShowChangeCommission}
          consignorData={consignorData}
          reloadConsignorData={consignorTableInit}
        />
      }
    </>
  );
};
export default ViewConsignor;
