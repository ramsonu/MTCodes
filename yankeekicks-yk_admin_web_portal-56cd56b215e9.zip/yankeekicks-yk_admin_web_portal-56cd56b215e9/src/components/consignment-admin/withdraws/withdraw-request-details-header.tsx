import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { getWithdrawDetailsHeaderById } from 'middleware/cubejs-wrapper/cubejs-query';
import { useCubeQuery } from '@cubejs-client/react';

const WithdrawDetailsHeader = (props: any) => {
  const { headerData } = props;

  const router = useRouter();
  let { withdrawReqId } = router.query;

  return (
    <div className='container-fluid'>
      <div className='ConsignmentsWrap mb-4 yk-withdrawConsignmentsWrap'>
        <div className='row d-flex'>
          <div className='col-lg-7 col-md-12 col-sm-12 col-12 pe-0'>
            <div className='yk-con-detail-wrap yk-conDetailWrap mb-0'>
              <div className='col yk-con-lable-wrap text-left'>
                <div className='yk-consignor-title'>
                  <span className='consignorName'>
                    {headerData?.['WithdrawalInventory.consignorName']}
                  </span>
                  <span className='yk-consignor-status pt-0'>
                    ID : {headerData?.['WithdrawalInventory.consigneeId']}
                    &nbsp;&bull;&nbsp;
                    {headerData?.['WithdrawalInventory.emailId']}{' '}
                    &nbsp;&bull;&nbsp;
                    {headerData?.['WithdrawalInventory.phoneNumber']
                      ? `${headerData?.['WithdrawalInventory.phoneNumber']}`
                      : ''}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className='col-lg-5 col-md-12 col-sm-12 col-12'>
            <div className='yk-con-detail-wrap yk-con-detail-status withdrawDetailWrap ms-0'>
              <div className='row'>
                <div className='col yk-con-lable-wrap'>
                  <div className='yk-con-detail-lable mb-0'>
                    Withdrawal Status
                    <span className='yk-con-detail-status pb-0'>
                      {headerData?.['WithdrawalInventory.withdrawalStatus']}
                    </span>
                  </div>
                </div>
                <div className='col yk-con-lable-wrap'>
                  <div className='yk-con-detail-lable mb-0'>
                    Number of Items
                    <span className='yk-con-detail-status pb-0'>
                      {headerData?.['WithdrawalInventory.numberOfItems']}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WithdrawDetailsHeader;
