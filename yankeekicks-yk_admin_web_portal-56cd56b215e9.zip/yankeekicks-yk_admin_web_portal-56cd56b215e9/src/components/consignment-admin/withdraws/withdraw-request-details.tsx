import React, { useState, useEffect, useMemo } from 'react';
import SearchComp from 'components/common/search';
import Image from 'next/image';
import { Button } from '@mui/material';
import Sortings from 'components/common/sortings';
import VirtualTable from 'components/common/table';
import filterIcon from 'assets/images/filter-icon.png';
import { useCubeQuery } from '@cubejs-client/react';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import { NOTIFICATION_SOMETHING_WENT_WRONG } from 'utils/constants';
import { useRouter } from 'next/router';
import { useDispatch, useSelector } from 'react-redux';
import Breadcrumbs from 'components/common/breadcrumbs';
import OrderDetailsModal from '../orders/order-details-modal';
import ProductFilters from 'components/common/filters/product-filter';
import { actions } from 'store/reducers/kiosk';
import { getBasePath } from 'utils/util';
import Notification from 'components/common/notification';
import ConsignmentIcon from 'assets/images/menu-icons/consignment-default.svg';
import {
  getWithdrawDetailsById,
  getWithdrawDetailsByIdPaginationCount,
  getWithdrawDetailsHeaderById,
} from 'middleware/cubejs-wrapper/cubejs-query';
import WithdrawDetailsHeader from './withdraw-request-details-header';
import Pagination from 'components/common/pagination';
import ConfirmPopup from 'components/common/confirm-popup';
import { DISABLE_LOADER, ENABLE_LOADER } from 'actions/loader';
import {
  MoveToYKInv,
  UpdateStatusPaid,
  handleApproveReject,
} from 'services/withdraw';
import { PLEASE_FILL_THIS_FIELD } from 'utils/validators';

const WithdrawDetails = () => {
  const [userInput, setUserInput] = useState('');
  const [consignmentLineItemId, setConsignmentLineItemId] = useState(0);
  const [skuDetailsData, setSkuDetailsData] = useState<any>([]);
  const [selectedSort, setSelectedSort] = useState('status: Asc');
  const [showDetailsModal, setShowDetailsModal] = useState<any>(false);
  const [showFilters, setShowFilters] = useState(false);
  const [filterInput, setFilterInput] = useState<any>({});
  const [selectedStatus, setSelectedStatus] = useState<any>([]);
  const [selectedPriceDetails, setSelectedPriceDetails] = useState<any>([]);
  const [clearDisable, setClearDisable] = useState(true);
  const [checked, setChecked] = useState({
    Pending: false,
    Approved: false,
    Rejected: false,
  });
  const [isVisibleMessage, setIsVisibleMessage] = useState<any>(false);
  const [severityType, setSeverityType] = useState<any>('');
  const [notificationMessage, setNotificationMessage] = useState<any>('');
  const [isAllCheckBoxChecked, setIsAllCheckBoxChecked] = useState(false);
  const [enableBtn, setEnableBtn] = useState(false);
  const [showApproveConfirmModal, setShowApproveConfirmModal] = useState(false);
  const [showMoveToYKInv, setShowMoveToYKInv] = useState(false);
  const [moveToYKInvData, setMoveToYKInvData] = useState<any>({});
  const [showMarkPaid, setShowMarkPaid] = useState(false);
  const [showRejectConfirmModal, setShowRejectConfirmModal] = useState(false);
  const [barCodeList, setBarCodeList] = useState<any>([]);
  const [isShow, setIsShow] = useState(false);
  const [reloadData, setReloadData] = useState<any>(false);
  const [headerData, setHeaderData] = useState<any>([]);
  const [rejectMessage, setRejectMessage] = useState<any>('');
  const [rejectMsgError, setRejectMsgError] = useState<any>('');
  const [shouldFetchDataOfRequestId, setShouldFetchTransfersHeaderData] =
    useState<boolean>(false);
  const router = useRouter();
  const dispatch = useDispatch();
  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const [modalData, setModalData] = React.useState<any>();

  let { withdrawReqId } = router.query;

  const [countForPagination, setCountForPagination] = useState(0);
  const headerQuery: any = getWithdrawDetailsHeaderById(withdrawReqId);
  const { resultSet: resultSet }: any = useCubeQuery(headerQuery, {
    subscribe: reloadData,
  });

  useEffect(() => {
    setHeaderData(resultSet?.loadResponses[0]?.data?.[0]);
  }, [resultSet]);

  useEffect(() => {
    if (!!router.query.withdrawReqId) {
      setShouldFetchTransfersHeaderData(true);
    } else {
      setShouldFetchTransfersHeaderData(false);
    }
  }, [router?.query]);

  const [offset, setOffset] = useState(0);
  const limit = 10;
  const skuDetailsByIdQuery: any = getWithdrawDetailsById(
    withdrawReqId,
    userInput,
    selectedSort,
    filterInput,
    offset,
    limit
  );
  const skuDetailsByIdCountQuery: any = getWithdrawDetailsByIdPaginationCount(
    withdrawReqId,
    userInput,
    filterInput
  );

  const {
    resultSet: skuDetailsResultSet,
    isLoading: skuDetailsIsLoading,
    error: skuDetailsError,
  }: any = useCubeQuery(skuDetailsByIdQuery, {
    subscribe: reloadData,
  });
  const { resultSet: skuDetailsCountResultSet }: any = useCubeQuery(
    skuDetailsByIdCountQuery,
    {
      skip: shouldFetchDataOfRequestId,
    }
  );

  const columns = useMemo(
    () => [
      {
        type: 'checkbox',
        title: '',
        onChange: (e: any, data: any, tableData: any) => {
          handleCheckBoxChecked(e, data, tableData);
        },
        checked: 'isChecked',
        checkAll: (e: any, tableData: any) => handleCheckAll(e, tableData),
        value: 'WithdrawalInventory.barcode',
        isAllChecked: isAllCheckBoxChecked,
        isDisabled: 'checkboxDisabled',
      },
      {
        title: 'Barcode',
        value: 'WithdrawalInventory.barcode',
      },
      {
        title: 'SKU',
        type: 'copyToClipboard',
        value: 'WithdrawalInventory.sku',
      },

      {
        title: 'Picture',
        type: 'image',
        value: 'WithdrawalInventory.stockxUrl',
      },
      {
        title: 'Brand',
        value: 'WithdrawalInventory.brand',
      },
      {
        title: 'Name',
        value: 'WithdrawalInventory.productName',
      },
      {
        title: 'Size',
        value: 'WithdrawalInventory.size',
      },
      {
        title: 'Price',
        value: 'WithdrawalInventory.retailPrice',
      },
      {
        title: 'Status',
        type: 'statusList',
        value: 'WithdrawalInventory.inventoryWithdrawalStatus',
        success: 'Withdrawn',
        danger: 'Fee Pending',
        reject: 'Rejected',
        lightPink: 'Pending WithDraw',
        withdarw: true,
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          viewButtonHandler(data);
        },
        value: 'Details',
      },
    ],
    []
  );
  useEffect(() => {
    const data = skuDetailsResultSet?.loadResponses[0]?.data;
    if (data) {
      setSkuDetailsData(addCheckPropertyToData(data, false));
      setCountForPagination(
        skuDetailsCountResultSet?.loadResponses[0]?.data?.[0]?.[
          'WithdrawalInventory.count'
        ] || 0
      );
    } else {
      setSkuDetailsData([]);
    }
  }, [skuDetailsResultSet, skuDetailsCountResultSet]);

  useEffect(() => {
    if (filterTypes.size.length !== 0 || selectedStatus.length !== 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  });
  useEffect(() => {
    if (barCodeList.length == skuDetailsData.length)
      setIsAllCheckBoxChecked(true);
    else setIsAllCheckBoxChecked(false);
    if (barCodeList.length > 0) setEnableBtn(true);
    else setEnableBtn(false);
  }, [barCodeList]);

  const headers = {
    title: 'Product Withdraw Request',
    titleImage: ConsignmentIcon,
    subTitle: withdrawReqId,
    onClick: () => {
      router?.push(`${getBasePath('withdraws')}`);
    },
    onNextClick: () => {
      router?.push(`${getBasePath(`withdraws/${withdrawReqId}`)}`);
    },
  };

  const onChangeHandler = (event: any) => {
    setOffset(0);
    setUserInput(event.target.value);
  };

  const sortHandler = (event: any) => {
    setOffset(0);
    setSelectedSort(event.target.value);
  };

  const viewButtonHandler = (data: any) => {
    setConsignmentLineItemId(data['WithdrawalInventory.barcode']);
    setShowDetailsModal(true);
    setIsShow(false);
    setModalData(data);
  };

  const onStatusChange = (event: any) => {
    setChecked({ ...checked, [event?.target?.name]: event?.target?.checked });
    let updatedList = [...selectedStatus];
    if (event.target.checked) {
      updatedList = [...selectedStatus, event.target.name];
    } else {
      updatedList.splice(selectedStatus.indexOf(event.target.name), 1);
    }
    setSelectedStatus(updatedList);
    if (updatedList.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  };

  const onPriceChange = (event: any) => {
    if (selectedPriceDetails.includes(event?.target?.name)) {
      let tempOption = [];
      tempOption = selectedPriceDetails.filter(
        (data: any) => data !== event?.target?.name
      );
      setSelectedPriceDetails(tempOption);
      if (tempOption.length > 0) {
        setClearDisable(false);
      }
    } else {
      setSelectedPriceDetails([...selectedPriceDetails, event?.target?.name]);
      setClearDisable(false);
    }
  };

  const onApplyFilters = () => {
    setOffset(0);
    const filterPayload = {
      status: selectedStatus,
      price: selectedPriceDetails,
      size: filterTypes.size,
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setShowFilters(false);
  };

  const onClearFilters = () => {
    setOffset(0);
    setShowFilters(false);
    setSelectedStatus([]);
    setSelectedPriceDetails([]);
    setChecked({ Pending: false, Approved: false, Rejected: false });
    setFilterInput({});
    setClearDisable(true);
    dispatch(actions.clearAllFilters({}));
  };

  const addCheckPropertyToData = (
    tempConsignmentDetailsData: any,
    checkedStatus: boolean,
    dataItem?: any
  ) => {
    if (!!dataItem) {
      tempConsignmentDetailsData = tempConsignmentDetailsData.map(
        (lineItem: any) => {
          if (
            lineItem['WithdrawalInventory.barcode'] ==
            dataItem['WithdrawalInventory.barcode']
          )
            return updateLineItem(lineItem, checkedStatus);
          else return updateLineItem(lineItem, lineItem?.isChecked);
        }
      );
    } else
      tempConsignmentDetailsData = tempConsignmentDetailsData.map(
        (lineItem: any) => {
          return updateLineItem(lineItem, checkedStatus);
        }
      );
    setBarCodeList(
      tempConsignmentDetailsData
        .filter((item: any) => item.isChecked === true)
        .map((item: any) => {
          return item['WithdrawalInventory.barcode'];
        })
    );
    return tempConsignmentDetailsData;
  };
  const updateLineItem = (lineItem: any, checkedStatus: boolean) => {
    const checkboxDisabled = !(
      lineItem['WithdrawalInventory.inventoryWithdrawalStatus'] == 'Pending' ||
      lineItem['WithdrawalInventory.inventoryWithdrawalStatus'] ==
        'Pending Withdraw' ||
      lineItem['WithdrawalInventory.inventoryWithdrawalStatus'] == null
    );
    return {
      ...lineItem,
      isChecked: checkboxDisabled ? false : checkedStatus,
      checkboxDisabled: checkboxDisabled,
    };
  };
  const handleCheckAll = (event: any, tableData: any) => {
    setIsAllCheckBoxChecked(event?.target?.checked);
    setSkuDetailsData(
      addCheckPropertyToData(tableData, event?.target?.checked)
    );
  };

  const handleCheckBoxChecked = (e: any, data: any, tableData: any) => {
    const updatedData = addCheckPropertyToData(
      tableData,
      e?.target?.checked,
      data
    );
    setSkuDetailsData(updatedData);
  };

  const handleShoeApproval = async () => {
    try {
      dispatch({ type: ENABLE_LOADER });
      const barcodes = skuDetailsData
        .filter((item: any) => item.isChecked === true)
        .map((item: any) => {
          return item['WithdrawalInventory.barcode'];
        });
      const payload = {
        barcodes: barcodes,
        reject_message: '',
        status: 'Approved',
        withdraw_id: withdrawReqId,
        filter_statuses: selectedStatus,
        sizes: filterTypes.size,
        search_filter: userInput,
        sorted: selectedSort,
      };
      const handleAction = await handleApproveReject(payload);
      if (handleAction?.status == 200) {
        dispatch({ type: DISABLE_LOADER });
      }
      setReloadData(true);
      setTimeout(() => {
        setReloadData(false);
      }, 500);
      setIsVisibleMessage(true);
      setSeverityType('success');
      setNotificationMessage('Product Withdrawal Approved.!');
      setShowApproveConfirmModal(false);
    } catch (e: any) {
      setShowApproveConfirmModal(false);
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setNotificationMessage(
        e?.response?.data?.message || NOTIFICATION_SOMETHING_WENT_WRONG
      );
      dispatch({ type: DISABLE_LOADER });
    }
  };
  const handleRejectMessage = (value: string) => {
    setRejectMsgError('');
    setRejectMessage(value);
  };
  const handleShoeReject = async () => {
    if (rejectMessage.trim() != '') {
      try {
        dispatch({ type: ENABLE_LOADER });
        const barcodes = skuDetailsData
          .filter((item: any) => item.isChecked === true)
          .map((item: any) => {
            return item['WithdrawalInventory.barcode'];
          });
        const payload = {
          barcodes: barcodes,
          reject_message: rejectMessage,
          status: 'Rejected',
          withdraw_id: withdrawReqId,
          filter_statuses: selectedStatus,
          sizes: filterTypes.size,
          search_filter: userInput,
          sorted: selectedSort,
        };
        setReloadData(true);
        setTimeout(() => {
          setReloadData(false);
        }, 500);
        const handleAction = await handleApproveReject(payload);
        if (handleAction?.status == 200) {
          dispatch({ type: DISABLE_LOADER });
        }
        setIsVisibleMessage(true);
        setSeverityType('success');
        setNotificationMessage('Product Withdrawal Rejected.!');
        setShowRejectConfirmModal(false);
      } catch (e: any) {
        setShowRejectConfirmModal(false);
        setIsVisibleMessage(true);
        setSeverityType('warning');
        setNotificationMessage(
          e?.response?.data?.message || NOTIFICATION_SOMETHING_WENT_WRONG
        );
        dispatch({ type: DISABLE_LOADER });
      }
    } else {
      setRejectMsgError(PLEASE_FILL_THIS_FIELD);
    }
  };
  const handleMoveToYKInvConfirm = async (action: boolean, data?: any) => {
    setShowMoveToYKInv(true);
    setMoveToYKInvData(data?.[0]);
    //handleMoveToYKInv;
  };
  const handleMoveToYKInv = async () => {
    setShowDetailsModal(false);
    try {
      dispatch({ type: ENABLE_LOADER });
      const payload = {
        barcode: consignmentLineItemId,
        withdraw_id: withdrawReqId,
        cost_per_item: moveToYKInvData?.costPerItem,
        selling_price: moveToYKInvData?.sellingPrice,
      };

      const handleAction = await MoveToYKInv(payload);
      if (handleAction?.status == 200) {
        setReloadData(true);
        setTimeout(() => {
          setReloadData(false);
        }, 500);
        setMoveToYKInvData({});
        dispatch({ type: DISABLE_LOADER });
      }
      setIsVisibleMessage(true);
      setSeverityType('success');
      setNotificationMessage('Product Added to YK Inventory.!');
      setShowMoveToYKInv(false);
    } catch (e: any) {
      setShowMoveToYKInv(false);
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setNotificationMessage(
        e?.response?.data?.message || NOTIFICATION_SOMETHING_WENT_WRONG
      );
      dispatch({ type: DISABLE_LOADER });
    }
  };
  const handleMarkPaid = async () => {
    setShowDetailsModal(false);
    try {
      dispatch({ type: ENABLE_LOADER });
      const payload = {
        barcode: consignmentLineItemId,
        withdraw_id: withdrawReqId,
      };
      setReloadData(true);
      setTimeout(() => {
        setReloadData(false);
      }, 500);
      const handleAction = await UpdateStatusPaid(payload);
      if (handleAction?.status == 200) {
        dispatch({ type: DISABLE_LOADER });
      }
      setIsVisibleMessage(true);
      setSeverityType('success');
      setNotificationMessage('Payment Marked Successfully.!');
      setShowMarkPaid(false);
    } catch (e: any) {
      setShowMarkPaid(false);
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setNotificationMessage(
        e?.response?.data?.message || NOTIFICATION_SOMETHING_WENT_WRONG
      );
      dispatch({ type: DISABLE_LOADER });
    }
  };

  return (
    <div className='yk-withdraw-details-page-wrapper'>
      <div className='container-fluid'>
        <div className='row'>
          <Breadcrumbs data={headers} />
        </div>
      </div>
      <div className='container-fluid orders-page-wrapper'>
        <div className='orders-page-inner-wrapper'>
          <div className='row yk-withdraw-heading-wrapper'>
            <div className='col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 consignmentDetailsHeader '>
              <div className='heading-wrapper orders-heading-wrapper'>
                <h2 className='yk-orders-heading'>{withdrawReqId}</h2>
              </div>
              <h5 className='sub-haeding'>Request details</h5>
            </div>
            <div className='col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12'>
              <div className='heading-btn-wrapper'>
                {headerData?.['WithdrawalInventory.withdrawalStatus'] !=
                  'Complete' && (
                  <>
                    {/* {enableBtn == true ? ( */}
                    <div className='YKCH-approveRejectBBTTN'>
                      <Button
                        className='MuiButtonBase-root me-3 YKCH-aprove'
                        disabled={!enableBtn}
                        onClick={() => setShowApproveConfirmModal(true)}>
                        Approve Selected
                      </Button>
                      <Button
                        className='MuiButtonBase-root YKCH-reject'
                        disabled={!enableBtn}
                        onClick={() => setShowRejectConfirmModal(true)}>
                        Reject Selected
                      </Button>
                    </div>
                    {/*  ) : (
                      <div className='YKCH-approveRejectBBTTN'>
                        <Button
                          className='MuiButtonBase-root me-3 YKCH-aprove'
                          disabled={enableBtn}
                          onClick={() => setShowApproveConfirmModal(true)}>
                          Approve All
                        </Button>
                        <Button
                          className='MuiButtonBase-root YKCH-reject'
                          disabled={enableBtn}
                          onClick={() => setShowRejectConfirmModal(true)}>
                          Reject All
                        </Button>
                      </div>
                    )} */}
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      <WithdrawDetailsHeader headerData={headerData} />
      <div className='container-fluid sku-details-page-wrapper'>
        <div className='row'>
          <div className='col-lg-12 col-md-12 col-sm-12'>
            <div className='search-btn-wrapper'>
              <div className='row'>
                <div className='col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12'>
                  <div className='YKCH-searchingData'>
                    <SearchComp
                      optionType='change'
                      placeholder='Search'
                      onChangeHandler={onChangeHandler}
                    />
                  </div>
                </div>
                <div className='col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12'>
                  <div className='consignment-btn-wrapper'>
                    <Sortings
                      itemKey='withdrawDetails'
                      handleChange={sortHandler}
                      defaultSelectedValue={selectedSort}
                    />
                    <div className='filter-btn-wrapper YKCH-filterWrapperr'>
                      <ClickAwayListener
                        onClickAway={() => {
                          setShowFilters(false);
                        }}>
                        <div className='YKCH-filterBTNWrapp me-0'>
                          <button
                            className='btn filter-btn YKCH-filterBTNN'
                            onClick={() => setShowFilters(!showFilters)}>
                            <Image
                              src={filterIcon}
                              alt='filter-btn-icon'
                              className='filter-btn-icon img-fluid'
                            />
                            <span className='filter-btn-text yk-badge-h15'>
                              Filter
                            </span>
                          </button>
                          {showFilters && (
                            <ProductFilters
                              itemKey='withdrawalDetails'
                              data={skuDetailsData}
                              onPayoutChange={onStatusChange}
                              checkedValue={checked}
                              onPriceChange={onPriceChange}
                              selectedPriceDetails={selectedPriceDetails}
                              onApplyClick={onApplyFilters}
                              onClearFilters={onClearFilters}
                              clearDisable={clearDisable}
                            />
                          )}
                        </div>
                      </ClickAwayListener>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <VirtualTable
              headers={columns}
              loading={skuDetailsIsLoading}
              error={skuDetailsError}
              rowData={skuDetailsData}
            />
            {countForPagination > 0 && skuDetailsData?.length > 0 && (
              <div className='center-pagination'>
                <Pagination
                  lengthOfData={countForPagination}
                  itemsPerPage={limit}
                  currentOffset={offset}
                  setOffset={setOffset}
                />
              </div>
            )}
          </div>
        </div>
        {showDetailsModal && (
          <OrderDetailsModal
            showModal={showDetailsModal}
            handleClose={setShowDetailsModal}
            lineItemId={consignmentLineItemId || withdrawReqId}
            orderDetails='withdrawalDetails'
            isShoeCatalog={isShow}
            isSearchWithBarcode={true}
            modalUsedFor='withDrawal'
            // handleMoveToYKInv={setShowMoveToYKInv}
            handleMoveToYKInv={handleMoveToYKInvConfirm}
            handleMarkPaid={setShowMarkPaid}
            skuId={modalData['WithdrawalInventory.sku']}
          />
        )}

        <ConfirmPopup
          showPopup={showApproveConfirmModal}
          handleClose={(e: any) => setShowApproveConfirmModal(false)}
          title='Approve Item Withdrawal'
          message='Are you sure you want to approve withdrawal of selected Items?'
          handleSave={handleShoeApproval}
          className='yk-withdrawModal'
        />

        <ConfirmPopup
          showPopup={showRejectConfirmModal}
          handleClose={(e: any) => setShowRejectConfirmModal(false)}
          title='Reject Withdrawal'
          //message='Are you sure you want to reject withdrawal of selected shoes?'
          message={
            <div>
              <p>Please enter reason for rejection</p>
              <textarea
                className='form-control'
                onChange={(e: any) => handleRejectMessage(e?.target?.value)}
                placeholder='Please type here'
                rows={6}
              />
              <p style={{ color: 'red' }}>{rejectMsgError}</p>
            </div>
          }
          handleSave={handleShoeReject}
          handleSaveDisabled={!rejectMessage || rejectMsgError !== ''}
          className='yk-withdrawModal'
        />

        <ConfirmPopup
          showPopup={showMoveToYKInv}
          handleClose={(e: any) => setShowMoveToYKInv(false)}
          title='Move to YK Inventory'
          message='Are you sure you want to add this to YK Inventory?'
          handleSave={handleMoveToYKInv}
          className='yk-withdrawModal'
        />

        <ConfirmPopup
          showPopup={showMarkPaid}
          handleClose={(e: any) => setShowMarkPaid(false)}
          title='Mark As Paid?'
          message='Are you sure you want to mark this to Paid?'
          handleSave={handleMarkPaid}
          className='yk-withdrawModal'
        />

        <Notification
          showSuccessPopup={isVisibleMessage}
          handleSnackbarClose={() => setIsVisibleMessage(false)}
          severityType={severityType}
          message={notificationMessage}
          className='yk-shoesize-alert-wrapper'
        />
      </div>
    </div>
  );
};
export default WithdrawDetails;
