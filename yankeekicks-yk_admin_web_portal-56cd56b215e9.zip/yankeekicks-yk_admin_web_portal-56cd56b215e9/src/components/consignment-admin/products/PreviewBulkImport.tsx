import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import Button from '@mui/material/Button';
import ProductMenu from 'components/common/product-menu';
import { useSelector, useDispatch } from 'react-redux';
import { actions } from 'store/reducers/consignment';
import SearchComp from 'components/common/search';
import { useRouter } from 'next/router';
import Breadcrumbs from 'components/common/breadcrumbs';
import VirtualTable from 'components/common/table';
import AddToInventoryModal from './AddToInventoryModal';
import ProductFilters from 'components/common/filters/product-filter';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import filterIcon from 'assets/images/filter-icon.png';
import { actions as kioskActions } from 'store/reducers/kiosk';
import Sortings from 'components/common/sortings';
import NoDataFound from 'components/common/no-data-found';
import Pagination from 'components/common/pagination';
import Notification from 'components/common/notification';
import { getBasePath } from 'utils/util';
import modalCloseIcon from 'assets/images/modal-close-btn-icon.svg';

const PreviewBulkImport = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const limitForQuery = 10;
  const { bulkRecord, filteredData } = useSelector(
    (state: any) => state.consignment
  );
  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const [countForPagination, setCountForPagination] = useState(0);
  const [searchOffset, setSearchOffset] = useState<any>(0);
  const [isAddtoInventoryModalVisible, setIsAddtoInventoryModalVisible] =
    useState<boolean>(false);
  const [showFilter, setShowFilter] = useState(false);
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  let profitRatio = localStorage.getItem('profitRatio');
  const [tableData, setTableData] = useState([]);
  const breadCrumHeaders = {
    title: 'My Inventory',
    subTitle: 'Preview Bulk',
    onClick: () => {
      router?.push(getBasePath('inventory'));
    },
  };
  const columns = React.useMemo(
    () => [
      {
        title: 'S.No',
        type: 'sno',
      },
      {
        title: 'SKU',
        value: 'sku',
      },
      {
        title: 'Image',
        value: 'image',
        type: 'image',
      },
      {
        title: 'Brand',
        value: 'brand',
      },
      {
        title: 'Name',
        value: 'name',
      },
      // {
      //   title: 'Store Name',
      //   value: 'storeName',
      // },
      {
        title: 'Size',
        value: 'size',
      },
      {
        title: 'Condition',
        value: 'condition',
      },
      {
        title: 'Cost/Item',
        value: 'costPerItem',
        methodToApply: 'toFix',
      },
      {
        title: 'Price',
        value: 'price',
        methodToApply: 'toFix',
      },
      {
        title: 'Qty',
        value: 'quantity',
      },
      {
        title: 'Total Cost',
        value: 'totalPrice',
        methodToApply: 'toFix',
      },
      {
        title: 'Actions',
        type: 'image',
        onClick: (data: any) => {
          viewButtonHandler(data);
        },
        mode: 'static',
        value: modalCloseIcon,
      },
    ],
    [] // eslint-disable-line react-hooks/exhaustive-deps
  );

  useEffect(() => {
    if (bulkRecord?.length > 0) {
      setCountForPagination(bulkRecord?.length);
    } else
      setTimeout(() => {
        router.push(getBasePath('inventory'));
      }, 2000);
  }, [bulkRecord?.length]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (filteredData?.length)
      setTableData(
        filteredData.slice(searchOffset, searchOffset + limitForQuery)
      );
  }, [searchOffset, filteredData]);

  const handleSearch = (event: any) => {
    dispatch(
      actions.setFilters({
        text: event.target.value?.toLowerCase(),
        size: filterTypes.size,
        brand: filterTypes.brand,
      })
    );
  };
  const handleAddInventory = () => {
    dispatch(actions.setBulkRecord(filteredData));
    setIsAddtoInventoryModalVisible(true);
  };

  const onClick = () => {
    dispatch(
      actions.setFilters({
        size: filterTypes.size,
        brand: filterTypes.brand,
      })
    );
  };
  const onClearFilters = () => {
    setShowFilter(false);
    dispatch(kioskActions.clearAllFilters({}));
  };
  const sortHandler = (event: any) => {
    if (event.target.value === 'storeNameAsc') {
      const sortedByStoreNameInAsc = bulkRecord
        ?.slice()
        ?.sort((a: any, b: any) => (a.storeName > b.storeName ? 1 : -1));
      dispatch(actions.setBulkRecord(sortedByStoreNameInAsc));
    } else if (event.target.value === 'storeNameDesc') {
      const sortedByStoreNameInDesc = bulkRecord
        ?.slice()
        ?.sort((a: any, b: any) => (a.storeName > b.storeName ? -1 : 1));
      dispatch(actions.setBulkRecord(sortedByStoreNameInDesc));
    } else if (event.target.value === 'sizeAsc') {
      const sortedBySizeInAsc = bulkRecord
        ?.slice()
        ?.sort((a: any, b: any) =>
          parseInt(a.size) > parseInt(b.size) ? 1 : -1
        );
      dispatch(actions.setBulkRecord(sortedBySizeInAsc));
    } else if (event.target.value === 'sizeDesc') {
      const sortedBySizeInDesc = bulkRecord
        ?.slice()
        ?.sort((a: any, b: any) =>
          parseInt(a.size) > parseInt(b.size) ? -1 : 1
        );
      dispatch(actions.setBulkRecord(sortedBySizeInDesc));
    } else {
      dispatch(actions.setBulkRecord(bulkRecord));
    }
  };
  const viewButtonHandler = (data: any) => {
    dispatch(actions.removeBulkRecord(data.rowId));
    if (bulkRecord?.length < 1) {
      router.push(getBasePath('inventory'));
    }
  };
  const handleSnackbarClose = () => {
    setIsVisibleMessage(false);
  };
  return (
    <>
      <div className='preview-bulk-import-page-wrapper'>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-lg-12'>
              <div className='breadcrumbs-wrapper'>
                <Breadcrumbs data={breadCrumHeaders} />
              </div>
            </div>
            <div className='col-lg-12'>
              <div className='heading-wrapper'>
                <div className='heading-inner-wrapper'>
                  <h3 className='heading yk-main-title'>
                    Preview - Bulk Import
                    <span className='count-badge'>{bulkRecord?.length}</span>
                    <span className='description ms-2'>Products</span>
                  </h3>
                  <p className='description'>
                    Please preview the information fetched here.
                  </p>
                </div>
              </div>
              <div className='search-btn-wrapper'>
                <div className='row'>
                  <div className='col-lg-4'>
                    <div className='search-bar-wrapper yk-search-bar consignment-dashboard-search table-filter-search'>
                      <SearchComp
                        optionType='change'
                        placeholder='Search'
                        onChangeHandler={handleSearch}
                      />
                    </div>
                  </div>
                  <div className='col-lg-8'>
                    <div className='consignment-btn-wrapper'>
                      <div className='filter-btn-wrapper ykch-filter-wrapper-box'>
                        <ClickAwayListener
                          onClickAway={() => {
                            setShowFilter(false);
                          }}>
                          <div>
                            <button
                              className='btn filter-btn'
                              onClick={() => setShowFilter(!showFilter)}>
                              <Image
                                src={filterIcon}
                                alt='filter-btn-icon'
                                className='filter-btn-icon img-fluid'
                              />
                              <span className='filter-btn-text yk-badge-h15'>
                                Filter
                              </span>
                            </button>
                            {showFilter && (
                              <ProductFilters
                                itemKey='previewBulk'
                                onApplyClick={onClick}
                                onClearFilters={onClearFilters}
                                clearDisable={
                                  !(
                                    filterTypes.size?.length > 0 ||
                                    filterTypes.brand.length > 0
                                  )
                                }
                              />
                            )}
                          </div>
                        </ClickAwayListener>
                      </div>
                      <div className='yk-PreviewSortBtn'>
                        <Sortings
                          handleChange={sortHandler}
                          itemKey='previewBulk'
                        />
                      </div>
                      <div className='sort-product-wrapper add-product-btn yk-inventary-btn'>
                        {/* <ProductMenu></ProductMenu> */}
                        <div>
                          <Button
                            className='add-product-button'
                            disabled={bulkRecord.length === 0}
                            onClick={handleAddInventory}>
                            Add to Inventory
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {filteredData && filteredData.length > 0 ? (
                <VirtualTable
                  headers={columns}
                  rowData={tableData}
                  offSet={searchOffset}
                />
              ) : (
                <NoDataFound />
              )}
              {countForPagination > 0 && tableData?.length > 0 && (
                <div className='center-pagination'>
                  <Pagination
                    lengthOfData={filteredData.length}
                    itemsPerPage={limitForQuery}
                    currentOffset={searchOffset}
                    setOffset={setSearchOffset}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      {isAddtoInventoryModalVisible && (
        <AddToInventoryModal
          isAddtoInventoryModalVisible={isAddtoInventoryModalVisible}
          setIsAddtoInventoryModalVisible={setIsAddtoInventoryModalVisible}
          setIsVisibleMessage={setIsVisibleMessage}
        />
      )}
      <Notification
        showSuccessPopup={isVisibleMessage}
        handleSnackbarClose={handleSnackbarClose}
        severityType='success'
        message='Shoes Added to Inventory'
        className='yk-shoesize-alert-wrapper'
      />
    </>
  );
};
export default PreviewBulkImport;
