import React, { useState, useEffect } from 'react';
import filterIcon from 'assets/images/filter-icon.png';
import inventoryMedia from 'assets/images/inventory.svg';
import Pagination from 'components/common/pagination';
import SearchComp from 'components/common/search';
import Image from 'next/image';
import { useRouter } from 'next/router';
import {
  getMyInventoryQuery,
  getPaginationCountForInventory,
} from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import { useCubeQuery } from '@cubejs-client/react';
import ExportsTypes from 'components/common/exports-types';
import VirtualTable from 'components/common/table';
import ProductMenu from 'components/common/product-menu';
import Sortings from 'components/common/sortings';
import ProductFilters from 'components/common/filters/product-filter';
import { format } from 'date-fns';
import { FNS_DATE_FORMAT } from 'utils/constants';
import { useDispatch, useSelector } from 'react-redux';
import { getBasePath, getDifferenceDate, getFormattedDate } from 'utils/util';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import { actions } from 'store/reducers/kiosk';
import { Button } from '@mui/material';
import Link from 'next/link';

const InventoryDashboard = (props: any) => {
  let { consignorId = '', isLoadedInConsigorModule = false } = props;
  const router = useRouter();
  const onFindHandler = () => {
    router.push('inventory');
  };
  const dispatch = useDispatch();
  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
  const limitForQuery = 10;
  const [myInventoryData, setMyInventoryData] = useState<any>([]);
  const [userInput, setUserInput] = useState<any>('');
  const [searchOffset, setSearchOffset] = useState<any>(0);
  const [countForPagination, setCountForPagination] = useState(0);
  const [totlaMyInventory, setTotalMyInventory] = useState(0);
  const [showFilter, setShowFilter] = useState(false);
  const [ageFilter, setAgeFilter] = useState<any>('');
  const [selectedSort, setSelectedSort] = useState('skuAsc');
  const [createdDate, setCreatedDate] = useState<any>('');
  const [currentDate, setCurrentDate] = useState<any>('');
  const [selectedStartDate, setSelectedStartDate] = useState<any>('');
  const [selectedEndDate, setSelectedEndDate] = useState<any>('');
  const [filterInput, setFilterInput] = useState<any>({});
  const [clearDisable, setClearDisable] = useState(true);
  const [isPDFExport, setIsPDFExport] = useState(true);

  const queryPayload = {
    userInput,
    selectedSort,
    filterInput,
    userDetails,
  };

  const myInventoryQuery: any = getMyInventoryQuery(
    userInput,
    selectedSort,
    filterInput,
    consignorId,
    searchOffset,
    limitForQuery
  );
  const exportInventory: any = getMyInventoryQuery(
    userInput,
    selectedSort,
    filterInput,
    consignorId
  );

  const myInventoryPaginationCountQuery: any = getPaginationCountForInventory(
    userInput,
    filterInput,
    consignorId
  );

  const columns = React.useMemo(
    () => [
      {
        title: 'S.No',
        type: 'sno',
      },
      {
        title: 'SKU',
        value: 'MyInventory.sku',
      },
      {
        title: 'Picture',
        type: 'image',
        value: 'MyInventory.imageUrl',
      },
      {
        title: 'Brand',
        value: 'MyInventory.brand',
      },
      {
        title: 'Name',
        value: 'MyInventory.itemName',
      },
      {
        title: 'Qty',
        value: 'MyInventory.adminskuCount',
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          viewButtonHandler(data);
        },
        value: 'View',
      },
    ],
    []
  );
  const columnsForConsignorInventory = React.useMemo(
    () => [
      {
        title: 'SKU',
        value: 'MyInventory.sku',
        type: 'copyToClipboard',
      },
      {
        title: 'Product',
        value: 'MyInventory.itemName',
      },
      {
        title: 'Quantity',
        value: 'MyInventory.skuCount',
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          viewButtonHandlerForConsignor(data);
        },
        value: 'View',
      },
    ],
    []
  );

  const {
    resultSet: myInventoryResultSet,
    isLoading: inventoryIsLoading,
    error: inventoryError,
  }: any = useCubeQuery(myInventoryQuery);
  const { resultSet: exportInventoryResult }: any = useCubeQuery(
    exportInventory,
    { skip: isPDFExport }
  );

  const { resultSet: pageCountResultSet }: any = useCubeQuery(
    myInventoryPaginationCountQuery
  );

  useEffect(() => {
    onClearFilters(); //clear filters on page load
  }, []);
  useEffect(() => {
    const data = myInventoryResultSet?.loadResponses[0]?.data;
    if (data) {
      setMyInventoryData(data);
    } else {
      setMyInventoryData([]);
    }
    if (pageCountResultSet) {
      let countData =
        +pageCountResultSet?.loadResponses[0]?.data[0]?.[
          'InventoryCount.skuDistinctCount'
        ] || 0;
      setCountForPagination(countData);
      setTotalMyInventory(
        +pageCountResultSet?.loadResponses[0]?.data[0]?.[
          'InventoryCount.skuDistinctCount'
        ] || 0
      );
    }
  }, [myInventoryResultSet, pageCountResultSet]);

  useEffect(() => {
    if (
      filterTypes.brand.length !== 0 ||
      selectedEndDate !== '' ||
      ageFilter !== ''
    ) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  }, [filterTypes, selectedEndDate, ageFilter]);

  const onClickPDFExport = () => {
    setIsPDFExport(false);
    setTimeout(() => {
      setIsPDFExport(true);
    }, 100);
  };
  const onChangeHandler = (event: any) => {
    setUserInput(event.target.value);
  };
  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
  };

  const onDateChange = (dates: any) => {
    const [start, end] = dates;
    setSelectedStartDate(start);
    setSelectedEndDate(end);
    setClearDisable(false);
  };
  const onClick = () => {
    const filterPayload = {
      startDate:
        selectedStartDate !== ''
          ? format(new Date(selectedStartDate), FNS_DATE_FORMAT)
          : '',
      endDate:
        selectedEndDate !== ''
          ? format(new Date(selectedEndDate), FNS_DATE_FORMAT)
          : '',
      currentDate:
        currentDate !== ''
          ? format(new Date(currentDate), FNS_DATE_FORMAT)
          : '',
      createdDate:
        createdDate !== ''
          ? format(new Date(createdDate), FNS_DATE_FORMAT)
          : '',
      brand: filterTypes.brand,
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setShowFilter(false);
  };

  const onClearFilters = () => {
    setSelectedStartDate('');
    setSelectedEndDate('');
    setCurrentDate('');
    setCreatedDate('');
    setFilterInput({});
    setShowFilter(false);
    setClearDisable(true);
    dispatch(actions.clearAllFilters({}));
  };

  const ageChange = (event: any) => {
    setAgeFilter(event.target.value);
    const todaysDate = new Date();
    const endDate = getFormattedDate(todaysDate, FNS_DATE_FORMAT);
    setClearDisable(false);
    setCurrentDate(endDate);
    if (event.target.value === '1week') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 7);
      const startDate = getFormattedDate(sevenDaysPrevious, FNS_DATE_FORMAT);
      setCreatedDate(startDate);
    }
    if (event.target.value === '1month') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 30);
      const startDate = getFormattedDate(sevenDaysPrevious, FNS_DATE_FORMAT);
      setCreatedDate(startDate);
    }
    if (event.target.value === '3months') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 90);
      const startDate = getFormattedDate(sevenDaysPrevious, FNS_DATE_FORMAT);
      setCreatedDate(startDate);
    }

    if (event.target.value === '6months') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 183);
      const startDate = getFormattedDate(sevenDaysPrevious, FNS_DATE_FORMAT);
      setCreatedDate(startDate);
    }
    if (event.target.value === '9months') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 275);
      const startDate = getFormattedDate(sevenDaysPrevious, FNS_DATE_FORMAT);
      setCreatedDate(startDate);
    }
    if (event.target.value === '1year') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 365);
      const startDate = getFormattedDate(sevenDaysPrevious, FNS_DATE_FORMAT);
      setCreatedDate(startDate);
    }
  };

  const viewButtonHandler = (data: any) => {
    router?.push({
      pathname: 'inventory/skudetails',
      query: {
        id: data?.['MyInventory.sku'],
        quantity: data?.['MyInventory.skuCount'],
      },
    });
  };
  const viewButtonHandlerForConsignor = (data: any) => {
    router?.push({
      pathname: '../inventory/skudetails',
      query: {
        id: data?.['MyInventory.sku'],
        quantity: data?.['MyInventory.skuCount'],
        userId: consignorId,
      },
    });
  };

  const exportHeaders = [
    { label: 'SKU', key: 'MyInventory.sku' },
    { label: 'Brand', key: 'MyInventory.brand' },
    { label: 'Name', key: 'MyInventory.itemName' },
    { label: 'Qty', key: 'MyInventory.adminskuCount' },
  ];

  const viewMissingProducts = () => {
    router.push(getBasePath('/inventory/missing-products'));
  };

  return (
    <>
      <div className='app-wrapper w-100 my-inventory-page-wrapper'>
        <div className='consignment-inventory-wrapper'>
          <div className='consignment-inventory-inner-wrapper'>
            <div className='container-fluid'>
              <div className='row mb-3'>
                <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                  <div className='yk-inventoryHeadingWrapper'>
                    <div className='row'>
                      <div className='col-xl-6 col-lg-4 col-md-12 col-sm-12 col-12'>
                        <h3 className='yk-main-title'>
                          {isLoadedInConsigorModule && <>Inventory</>}
                          {!isLoadedInConsigorModule && (
                            <>
                              My Inventory
                              <span className='count-badge'>
                                {totlaMyInventory}
                              </span>
                            </>
                          )}
                        </h3>
                        {isLoadedInConsigorModule && (
                          <Image
                            src={inventoryMedia}
                            alt='filter-btn-icon'
                            className='filter-btn-icon img-fluid me-1'
                          />
                        )}
                      </div>
                      <div className='col-xl-6 col-lg-8 col-md-12 col-sm-12 col-12'>
                        <div
                          className={`yk-topBtnWrapper yk-displayFlexEnd me-0 pe-0 ${
                            isLoadedInConsigorModule ? 'd-none' : ''
                          }`}>
                          <Link
                            className='yk-printLabelBtn'
                            href={`${getBasePath('inventory/print-labels')}`}>
                            Print Labels
                          </Link>
                          <button
                            id='shoe-catalog'
                            onClick={() =>
                              router.push(getBasePath('inventory/shoe-catalog'))
                            }
                            className='yk-showCatalogBtn'>
                            Show Catalog
                          </button>
                          <div className='sort-product-wrapper me-0 add-product-btn'>
                            <ProductMenu />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className='YKCH-filterSearchComponent'>
                    <div className='row'>
                      <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12'>
                        <div className='YKCH-searchingData'>
                          <SearchComp
                            optionType='change'
                            placeholder='Search'
                            onChangeHandler={onChangeHandler}
                          />
                        </div>
                      </div>

                      <div className='col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12'>
                        <div className='YKCH-topSSpacSS d-sm-block d-lg-block'>
                          <div className='consignment-btn-wrapper YKCH-noFllexy yk-productsBtnWrapper'>
                            <Sortings
                              handleChange={sortHandler}
                              itemKey='inventory'
                              defaultSelectedValue={selectedSort}
                            />

                            <div className='filter-btn-wrapper ms-3'>
                              <ClickAwayListener
                                onClickAway={() => {
                                  setShowFilter(false);
                                }}>
                                <div>
                                  <button
                                    className='btn filter-btn ms-0'
                                    onClick={() => setShowFilter(!showFilter)}>
                                    <Image
                                      src={filterIcon}
                                      alt='filter-btn-icon'
                                      className='filter-btn-icon img-fluid'
                                    />
                                    <span className='filter-btn-text yk-badge-h15'>
                                      Filter
                                    </span>
                                  </button>

                                  {showFilter && (
                                    <ProductFilters
                                      itemKey={
                                        isLoadedInConsigorModule
                                          ? 'consignorInventory'
                                          : 'inventory'
                                      }
                                      onDateChange={onDateChange}
                                      onAgeChange={ageChange}
                                      startDate={selectedStartDate}
                                      endDate={selectedEndDate}
                                      onApplyClick={onClick}
                                      onClearFilters={onClearFilters}
                                      clearDisable={clearDisable}
                                    />
                                  )}
                                </div>
                              </ClickAwayListener>
                            </div>
                            <div
                              className={`sort-product-wrapper export-btn bg-transparent me-3 pe-0 ${
                                isLoadedInConsigorModule ? 'd-none' : ''
                              }`}>
                              <ExportsTypes
                                data={
                                  (exportInventoryResult?.loadResponses &&
                                    exportInventoryResult?.loadResponses[0]
                                      ?.data) ||
                                  []
                                }
                                headers={exportHeaders}
                                fileName='inventory'
                                queryPayload={queryPayload}
                                onClickPDFExport={onClickPDFExport}
                                isActive={
                                  myInventoryData && myInventoryData?.length > 0
                                }
                              />
                            </div>
                            {!isLoadedInConsigorModule && (
                              <div>
                                <button
                                  className='btn yk-viewMissingBtn'
                                  onClick={viewMissingProducts}>
                                  View Missing Product
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <VirtualTable
                loading={inventoryIsLoading}
                headers={
                  isLoadedInConsigorModule
                    ? columnsForConsignorInventory
                    : columns
                }
                rowData={myInventoryData}
                offSet={searchOffset}
                error={inventoryError}
              />
              {countForPagination > 0 && myInventoryData?.length > 0 && (
                <div className='center-pagination'>
                  <Pagination
                    lengthOfData={countForPagination}
                    itemsPerPage={limitForQuery}
                    currentOffset={searchOffset}
                    setOffset={setSearchOffset}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default InventoryDashboard;
