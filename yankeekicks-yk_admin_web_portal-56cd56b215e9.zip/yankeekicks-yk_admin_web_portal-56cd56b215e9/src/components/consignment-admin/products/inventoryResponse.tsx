import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import Button from '@mui/material/Button';
import ProductMenu from 'components/common/product-menu';
import { useSelector, useDispatch } from 'react-redux';
import { actions } from 'store/reducers/consignment';
import SearchComp from 'components/common/search';
import { useRouter } from 'next/router';
import Breadcrumbs from 'components/common/breadcrumbs';
import VirtualTable from 'components/common/table';
import AddToInventoryModal from './AddToInventoryModal';
import ProductFilters from 'components/common/filters/product-filter';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import filterIcon from 'assets/images/filter-icon.png';
import { actions as kioskActions } from 'store/reducers/kiosk';
import Sortings from 'components/common/sortings';
import NoDataFound from 'components/common/no-data-found';
import Pagination from 'components/common/pagination';
import Notification from 'components/common/notification';
import { getBasePath } from 'utils/util';
import modalCloseIcon from 'assets/images/modal-close-btn-icon.svg';
import { Box, Tab, Tabs } from '@mui/material';
import { TabContext, TabPanel } from '@mui/lab';
import { addBulFilekUpload, bulkuploadResponse } from 'services/consignment';
import { ENABLE_LOADER } from 'actions/loader';

const InventoryResponse = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const limitForQuery = 10;
  const { bulkRecordRes, filteredDataRes, bulkRecord, uploadFile } =
    useSelector((state: any) => state.consignment);
  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const [countForPagination, setCountForPagination] = useState(0);
  const [searchOffset, setSearchOffset] = useState<any>(0);
  const [successOffset, setSuccessOffset] = useState<any>(0);
  const [failOffset, setFailOffset] = useState<any>(0);
  const [isAddtoInventoryModalVisible, setIsAddtoInventoryModalVisible] =
    useState<boolean>(false);
  const [showFilter, setShowFilter] = useState(false);
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  let profitRatio = localStorage.getItem('profitRatio');
  const [tableData, setTableData] = useState<bulkuploadResponse>(bulkRecordRes);
  const [tableSuccessData, setTableSuccessData] = useState<any>([]);
  const [tableFailData, setTableFailData] = useState<any>([]);
  const [selectedTab, setSelectedTab] = React.useState('Success');

  const breadCrumHeaders = {
    title: 'My Inventory',
    subTitle: 'New Inventory',
    onClick: () => {
      router?.push(getBasePath('inventory'));
    },
  };
  const columns = React.useMemo(
    () => [
      {
        title: 'S.No',
        type: 'sno',
      },
      {
        title: 'SKU',
        value: 'sku',
      },
      {
        title: 'Image',
        value: 'image',
        type: 'image',
        mode: 'staticData',
      },
      {
        title: 'Brand',
        value: 'brand',
      },
      {
        title: 'Name',
        value: 'name',
      },
      // {
      //   title: 'Store Name',
      //   value: 'storeName',
      // },
      {
        title: 'Size',
        value: 'size',
      },
      {
        title: 'Condition',
        value: 'condition',
      },
      {
        title: 'Cost/Item',
        value: 'costPerItem',
        methodToApply: 'toFix',
      },
      {
        title: 'Price',
        value: 'price',
        methodToApply: 'toFix',
      },
      {
        title: 'Qty',
        value: 'quantity',
      },
      {
        title: 'Total Cost',
        value: 'totalPrice',
        methodToApply: 'toFix',
      },
      {
        type: 'status',
        title: 'Status',
        value: 'status',
        success: 'Approved',
        warning: 'Pending',
        danger: 'Shopify Error',
      },
    ],
    [] // eslint-disable-line react-hooks/exhaustive-deps
  );
  const columnsFail = React.useMemo(
    () => [
      {
        title: 'S.No',
        type: 'sno',
      },
      {
        title: 'SKU',
        value: 'sku',
      },
      {
        title: 'Size',
        value: 'size',
      },
      {
        title: 'Condition',
        value: 'condition',
      },
      {
        title: 'Cost/Item',
        value: 'costPerItem',
        methodToApply: 'toFix',
      },
      {
        title: 'Price',
        value: 'price',
        methodToApply: 'toFix',
      },
      {
        title: 'Qty',
        value: 'quantity',
      },
      {
        title: 'Total Cost',
        value: 'totalPrice',
        methodToApply: 'toFix',
      },
      {
        title: 'Remarks',
        value: 'cause',
        className: 'text-danger',
      },
    ],
    [] // eslint-disable-line react-hooks/exhaustive-deps
  );

  useEffect(() => {
    if (tableData?.Success?.length)
      setTableSuccessData(
        tableData?.Success?.slice(successOffset, successOffset + limitForQuery)
      );
    else setTableSuccessData([]);
  }, [successOffset]);

  useEffect(() => {
    if (tableData?.Failed?.length)
      setTableFailData(
        tableData?.Failed?.slice(failOffset, failOffset + limitForQuery)
      );
    else setTableFailData([]);
  }, [failOffset]);

  const handleSearch = (event: any) => {
    dispatch(
      actions.setFilters({
        text: event.target.value?.toLowerCase(),
        size: filterTypes.size,
        brand: filterTypes.brand,
      })
    );
  };
  const handleAddInventory = async () => {
    router.push(
      getBasePath(`shipments/${tableData?.consignor?.consignmentId}`)
    );
  };

  const onClick = () => {
    dispatch(
      actions.setFilters({
        size: filterTypes.size,
        brand: filterTypes.brand,
      })
    );
  };
  const onClearFilters = () => {
    setShowFilter(false);
    dispatch(kioskActions.clearAllFilters({}));
  };
  const sortHandler = (event: any) => {
    if (event.target.value === 'storeNameAsc') {
      const sortedByStoreNameInAsc = bulkRecord
        ?.slice()
        ?.sort((a: any, b: any) => (a.storeName > b.storeName ? 1 : -1));
      dispatch(actions.setBulkRecord(sortedByStoreNameInAsc));
    } else if (event.target.value === 'storeNameDesc') {
      const sortedByStoreNameInDesc = bulkRecord
        ?.slice()
        ?.sort((a: any, b: any) => (a.storeName > b.storeName ? -1 : 1));
      dispatch(actions.setBulkRecord(sortedByStoreNameInDesc));
    } else if (event.target.value === 'sizeAsc') {
      const sortedBySizeInAsc = bulkRecord
        ?.slice()
        ?.sort((a: any, b: any) =>
          parseInt(a.size) > parseInt(b.size) ? 1 : -1
        );
      dispatch(actions.setBulkRecord(sortedBySizeInAsc));
    } else if (event.target.value === 'sizeDesc') {
      const sortedBySizeInDesc = bulkRecord
        ?.slice()
        ?.sort((a: any, b: any) =>
          parseInt(a.size) > parseInt(b.size) ? -1 : 1
        );
      dispatch(actions.setBulkRecord(sortedBySizeInDesc));
    } else {
      dispatch(actions.setBulkRecord(bulkRecord));
    }
  };
  const viewButtonHandler = (data: any) => {
    dispatch(actions.removeBulkRecord(data.rowId));
    if (bulkRecord?.length < 1) {
      //router.push(getBasePath('inventory'));
    }
  };
  const handleSnackbarClose = () => {
    setIsVisibleMessage(false);
  };

  const handleTabChange = (event: React.SyntheticEvent, newValue: string) => {
    setSelectedTab(newValue);
  };

  return (
    <>
      <div className='preview-bulk-import-page-wrapper'>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
              <div className='breadcrumbs-wrapper'>
                <Breadcrumbs data={breadCrumHeaders} />
              </div>
            </div>
            <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 YKCH-noSpacer'>
              <div className='heading-wrapper'>
                <div className='heading-inner-wrapper'>
                  <h3 className='heading yk-main-title '>Inventory Products</h3>
                  <p className='description'>
                    Below Products added to Inventory.
                  </p>
                </div>
                <div className='sort-product-wrapper add-product-btn yk-inventary-btn'>
                  <div>
                    <Button
                      className='add-product-button'
                      onClick={handleAddInventory}
                      disabled={!tableData?.consignor?.consignmentId}>
                      Go to Shipment
                    </Button>
                  </div>
                </div>
              </div>
              <div className='search-btn-wrapper d-none'>
                <div className='row'>
                  <div className='col-lg-4'>
                    <div className='search-bar-wrapper yk-search-bar consignment-dashboard-search table-filter-search'>
                      <SearchComp
                        optionType='change'
                        placeholder='Search'
                        onChangeHandler={handleSearch}
                      />
                    </div>
                  </div>
                  <div className='col-lg-8'>
                    <div className='consignment-btn-wrapper'>
                      <div className='d-none'>
                        <div className='filter-btn-wrapper ykch-filter-wrapper-box'>
                          <ClickAwayListener
                            onClickAway={() => {
                              setShowFilter(false);
                            }}>
                            <div>
                              <button
                                className='btn filter-btn'
                                onClick={() => setShowFilter(!showFilter)}>
                                <Image
                                  src={filterIcon}
                                  alt='filter-btn-icon'
                                  className='filter-btn-icon img-fluid'
                                />
                                <span className='filter-btn-text yk-badge-h15'>
                                  Filter
                                </span>
                              </button>
                              {showFilter && (
                                <ProductFilters
                                  itemKey='previewBulk'
                                  onApplyClick={onClick}
                                  onClearFilters={onClearFilters}
                                  clearDisable={
                                    !(
                                      filterTypes.size?.length > 0 ||
                                      filterTypes.brand.length > 0
                                    )
                                  }
                                />
                              )}
                            </div>
                          </ClickAwayListener>
                        </div>
                        <div className='yk-PreviewSortBtn'>
                          <Sortings
                            handleChange={sortHandler}
                            itemKey='previewBulk'
                          />
                        </div>
                      </div>
                      <div className='sort-product-wrapper add-product-btn yk-inventary-btn d-none'>
                        {/* <ProductMenu></ProductMenu> */}
                        <div>
                          <Button
                            className='add-product-button'
                            disabled={!tableData?.consignor?.consignmentId}
                            onClick={handleAddInventory}>
                            Go to Shipment
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <TabContext value={selectedTab}>
                <Box sx={{ width: '100%' }}>
                  <Tabs
                    value={selectedTab}
                    onChange={handleTabChange}
                    textColor='secondary'
                    indicatorColor='secondary'
                    aria-label='secondary tabs example'
                    className='BulkUPloadTabs'>
                    <Tab
                      value='Success'
                      className={`${
                        selectedTab == 'Success' ? 'tabActive' : ''
                      }`}
                      label={
                        <div>
                          Success{' '}
                          <span className='count-badge'>
                            {tableData?.Success?.length || 0}
                          </span>
                        </div>
                      }
                    />
                    <Tab
                      value='Failed'
                      className={`${
                        selectedTab == 'Failed' ? 'tabActive' : ''
                      }`}
                      label={
                        <div>
                          Failed
                          <span className='count-badge'>
                            {tableData?.Failed?.length || 0}
                          </span>
                        </div>
                      }
                    />
                  </Tabs>
                  <TabPanel value='Success'>
                    <VirtualTable
                      headers={columns}
                      rowData={tableSuccessData}
                      offSet={successOffset}
                    />
                    {tableData?.Success?.length && (
                      <Pagination
                        lengthOfData={tableData?.Success?.length}
                        itemsPerPage={limitForQuery}
                        currentOffset={successOffset}
                        setOffset={setSuccessOffset}
                      />
                    )}
                  </TabPanel>
                  <TabPanel value='Failed'>
                    <VirtualTable
                      headers={columnsFail}
                      rowData={tableFailData}
                      offSet={failOffset}
                    />
                    {tableData?.Failed?.length && (
                      <Pagination
                        lengthOfData={tableData?.Failed?.length}
                        itemsPerPage={limitForQuery}
                        currentOffset={failOffset}
                        setOffset={setFailOffset}
                      />
                    )}
                  </TabPanel>
                </Box>
              </TabContext>
            </div>
          </div>
        </div>
      </div>
      {isAddtoInventoryModalVisible && (
        <AddToInventoryModal
          isAddtoInventoryModalVisible={isAddtoInventoryModalVisible}
          setIsAddtoInventoryModalVisible={setIsAddtoInventoryModalVisible}
          setIsVisibleMessage={setIsVisibleMessage}
        />
      )}
      <Notification
        showSuccessPopup={isVisibleMessage}
        handleSnackbarClose={handleSnackbarClose}
        severityType='success'
        message='Shoes Added to Inventory'
        className='yk-shoesize-alert-wrapper'
      />
    </>
  );
};
export default InventoryResponse;
