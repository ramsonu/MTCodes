export const NOTIFY_MSG = {
  msg: 'Shoes added to the queue',
};
export const MIN_SELLING_PRICE = 0;
export const ADD_INVENTORY_SUCCESS = 'Product Created Successfully';
export const SELLING_PRICE_ERROR_MSG =
  'Selling Price should be greater than Cost Price';
