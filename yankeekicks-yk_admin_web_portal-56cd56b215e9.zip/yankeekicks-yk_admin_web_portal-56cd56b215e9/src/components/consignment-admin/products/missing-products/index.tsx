import React, { useState, useMemo, useEffect } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import { useDispatch, useSelector } from 'react-redux';
import { ClickAwayListener } from '@mui/material';
import { getBasePath } from 'utils/util';
import { actions } from 'store/reducers/kiosk';
import {
  getMissingProducts,
  getMissingProductsTotalCount,
} from 'middleware/cubejs-wrapper/missing-products-query';
import Sortings from 'components/common/sortings';
import SearchComp from 'components/common/search';
import VirtualTable from 'components/common/table';
import Pagination from 'components/common/pagination';
import Breadcrumbs from 'components/common/breadcrumbs';
import ProductFilters from 'components/common/filters/product-filter';
import MissingProductsModal from './missing-products-modal';
import filterIcon from 'assets/images/filter-icon.png';
import productIcon from 'assets/images/menu-icons/product-breadcumb-icon.svg';
import Notification from 'components/common/notification';

const MissingProducts = () => {
  const missingProductsLimitForQuery = 10;

  const router = useRouter();
  const dispatch = useDispatch();

  const { filterTypes } = useSelector((state: any) => state.kiosk);

  const [showMissingProductModal, setShowMissingProductModal] =
    useState<boolean>(false);
  const [shouldFetchMissingProducts, setShouldFetchMissingProducts] =
    useState<boolean>(false);
  const [missingProductsData, setMissingProductsData] = useState<any>([]);
  const [missingProductsTotalCount, setMissingProductsTotalCount] =
    useState<any>(0);
  const [missingProductsSearch, setMissingProductsSearch] = useState<any>('');
  const [missingProductsSelectedSort, setMissingProductsSelectedSort] =
    useState<string>('dateNew');
  const [missingProductsFilter, setMissingProductsFilter] = useState<any>({});
  const [showMissingProductsFilters, setShowMissingProductsFilters] =
    useState<boolean>(false);
  const [clearDisable, setClearDisable] = useState<boolean>(true);
  const [missingProductsOffset, setMissingProductsOffset] = useState<any>(0);
  const [selectedBarcode, setSelectedBarcode] = useState<any>('');
  const [showNotification, setShowNotification] = useState<boolean>(false);
  const [notificationMessage, setNotificationMessage] = useState<any>('');
  const [severityType, setSeverityType] = useState<string>('');

  const missingProductsQuery: any = getMissingProducts(
    missingProductsSearch,
    missingProductsSelectedSort,
    missingProductsFilter,
    missingProductsLimitForQuery,
    missingProductsOffset
  );
  const missingProductsTotalCountQuery: any = getMissingProductsTotalCount(
    missingProductsSearch,
    missingProductsSelectedSort,
    missingProductsFilter
  );

  useEffect(() => {
    setShouldFetchMissingProducts(true);
  }, []);

  const {
    resultSet: missingProductsResultSet,
    isLoading: missingProductsLoading,
    error: missingProductsError,
  }: any = useCubeQuery(missingProductsQuery, {
    skip: !shouldFetchMissingProducts,
  });
  const {
    resultSet: missingProductsCountResultSet,
    isLoading: missingProductsCountLoading,
    error: missingProductsCountError,
  }: any = useCubeQuery(missingProductsTotalCountQuery, {
    skip: !shouldFetchMissingProducts,
  });

  useEffect(() => {
    if (
      missingProductsError?.status === 401 ||
      missingProductsError?.status === 403
    ) {
      // todo: logout the user
    } else {
      const data: any = missingProductsResultSet?.loadResponses[0]?.data;
      if (data) {
        setMissingProductsData(data);
        setShouldFetchMissingProducts(false);
      } else {
        setMissingProductsData(data);
      }
    }
  }, [missingProductsResultSet, missingProductsError]);

  useEffect(() => {
    if (
      missingProductsCountError?.status === 401 ||
      missingProductsCountError?.status === 403
    ) {
      // todo: logout the user
    } else {
      const pageCountData =
        missingProductsCountResultSet?.loadResponses[0]?.data[0]?.[
          'InventorySkuDetails.count'
        ];
      if (pageCountData) {
        const pageCount = +pageCountData || 0;
        setMissingProductsTotalCount(pageCount);
      } else {
        setMissingProductsTotalCount(0);
      }
    }
  }, [missingProductsCountResultSet, missingProductsCountError]);

  useEffect(() => {
    if (filterTypes?.brand?.length > 0 || filterTypes?.size?.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  }, [filterTypes]);

  const userInputHandler = (event: any) => {
    setMissingProductsSearch(event.target.value || '');
    setShouldFetchMissingProducts(true);
    setMissingProductsOffset(0);
  };

  const sortHandler = (event: any) => {
    setMissingProductsSelectedSort(event.target.value);
    setShouldFetchMissingProducts(true);
    setMissingProductsOffset(0);
  };

  const applyFilters = () => {
    const filterPayload = {
      brand: filterTypes.brand,
      size: filterTypes.size,
    };
    setMissingProductsFilter(filterPayload);
    setMissingProductsSearch('');
    setMissingProductsOffset(0);
    setShowMissingProductsFilters(false);
    setShouldFetchMissingProducts(true);
  };

  const clearAllFilters = () => {
    setMissingProductsFilter({});
    setMissingProductsOffset(0);
    setShowMissingProductsFilters(false);
    setClearDisable(true);
    dispatch(actions.clearAllFilters({}));
    setShouldFetchMissingProducts(true);
  };

  const breadCrumbHeaders = {
    title: 'My Inventory',
    titleImage: productIcon,
    subTitle: 'Missing Products',

    onClick: () => {
      router?.push(`${getBasePath('inventory')}`);
    },
  };

  const missingProductsColumns = useMemo(
    () => [
      {
        title: 'S.No',
        type: 'sno',
      },
      {
        title: 'Barcode',
        value: 'InventorySkuDetails.barcode',
        type: 'copyToClipboard',
      },
      {
        title: 'SKU',
        value: 'InventorySkuDetails.style',
      },
      {
        title: 'Warehouse',
        value: 'InventorySkuDetails.locationName',
      },
      {
        title: 'Picture',
        type: 'image',
        value: 'InventorySkuDetails.imageUrl',
      },
      {
        title: 'Brand',
        value: 'InventorySkuDetails.brand',
      },
      {
        title: 'Name',
        value: 'InventorySkuDetails.itemName',
      },
      {
        title: 'Size',
        value: 'InventorySkuDetails.Size',
      },
      {
        title: 'Status',
        type: 'status',
        value: 'InventorySkuDetails.status',
        success: 'Approved',
        danger: 'Pending',
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          setShowMissingProductModal(true);
          setSelectedBarcode(data?.['InventorySkuDetails.barcode'] || '');
        },
        value: 'Clear',
      },
    ],
    []
  );

  return (
    <div className='yk-missing-products-page-wrapper'>
      <div className='container-fluid'>
        <div className='row'>
          <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
            <Breadcrumbs data={breadCrumbHeaders} />
          </div>
          <div className='col-lg-12 col-md-12 col-sm-12'>
            <h3 className='yk-main-title'>
              Missing Products{' '}
              <span className='count-badge'>{missingProductsTotalCount}</span>
            </h3>

            <p className='yk-gray-text'>Shows all Missing Products</p>
          </div>
        </div>
        <div className='row'>
          <div className='YKCH-filterSearchComponent'>
            <div className='row'>
              <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12'>
                <div className='YKCH-searchingData'>
                  <SearchComp
                    optionType='no suggestions'
                    placeholder='Search Inventory'
                    onChangeHandler={userInputHandler}
                  />
                </div>
              </div>

              <div className='col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12'>
                <div className='YKCH-topSSpacSS d-sm-block d-lg-block'>
                  <div className='consignment-btn-wrapper YKCH-noFllexy yk-productsBtnWrapper'>
                    <Sortings
                      itemKey='missingProducts'
                      defaultSelectedValue={missingProductsSelectedSort}
                      handleChange={sortHandler}
                    />

                    <div className='filter-btn-wrapper ms-3'>
                      <ClickAwayListener
                        onClickAway={() => {
                          setShowMissingProductsFilters(false);
                        }}>
                        <div>
                          <button
                            className='btn filter-btn ms-0'
                            onClick={() =>
                              setShowMissingProductsFilters(
                                !showMissingProductsFilters
                              )
                            }>
                            <Image
                              src={filterIcon}
                              alt='filter-btn-icon'
                              className='filter-btn-icon img-fluid'
                            />
                            <span className='filter-btn-text yk-badge-h15'>
                              Filter
                            </span>
                          </button>

                          {showMissingProductsFilters && (
                            <ProductFilters
                              itemKey={'missingProducts'}
                              onApplyClick={applyFilters}
                              onClearFilters={clearAllFilters}
                              clearDisable={clearDisable}
                            />
                          )}
                        </div>
                      </ClickAwayListener>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12'>
            <VirtualTable
              loading={missingProductsLoading}
              headers={missingProductsColumns}
              rowData={missingProductsData}
              offSet={missingProductsOffset}
              error={missingProductsError}
            />
            {missingProductsTotalCount > 0 &&
              missingProductsData?.length > 0 && (
                <div className='center-pagination'>
                  <Pagination
                    lengthOfData={missingProductsTotalCount}
                    itemsPerPage={missingProductsLimitForQuery}
                    currentOffset={missingProductsOffset}
                    setOffset={setMissingProductsOffset}
                    setShouldFetchApi={setShouldFetchMissingProducts}
                  />
                </div>
              )}
          </div>
        </div>
      </div>

      {showMissingProductModal && (
        <MissingProductsModal
          showModal={showMissingProductModal}
          setShowModal={setShowMissingProductModal}
          selectedBarcode={selectedBarcode}
          setShowNotification={setShowNotification}
          setSeverityType={setSeverityType}
          setNotificationMessage={setNotificationMessage}
          setShouldFetchMissingProducts={setShouldFetchMissingProducts}
        />
      )}

      <Notification
        showSuccessPopup={showNotification}
        handleSnackbarClose={() => setShowNotification(false)}
        severityType={severityType}
        message={notificationMessage}
        className='yk-shoesize-alert-wrapper'
      />
    </div>
  );
};

export default MissingProducts;
