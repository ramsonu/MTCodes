import React from 'react';
import Image from 'next/image';
import { Modal } from '@mui/material';
import { doRequest } from 'utils/request';
import { MISSING_PRODUCT_URL } from 'services/apiUrl';
import ModalCloseIcon from 'assets/images/modal-close-icon.svg';
import {
  MISSING_PRODUCT_SUCCESS,
  SOMETHING_WENT_WRONG,
} from 'components/yk-admin/constants';

const MissingProductsModal = (props: any) => {
  const {
    showModal = false,
    setShowModal = () => {},
    selectedBarcode = '',
    setShowNotification = () => {},
    setSeverityType = () => {},
    setNotificationMessage = () => {},
    setShouldFetchMissingProducts = () => {},
  } = props;

  const clearMissingProduct = async () => {
    if (selectedBarcode) {
      const url = `${MISSING_PRODUCT_URL}/${selectedBarcode}`;
      try {
        const response: any = await doRequest(url, 'post');
        if (response && response?.status === 200) {
          setShouldFetchMissingProducts(true);
          setShowNotification(true);
          setSeverityType('success');
          setNotificationMessage(MISSING_PRODUCT_SUCCESS);
          setShowModal(false);
        }
      } catch (error: any) {
        console.log('missing product error: ', error);
        setShowNotification(true);
        setSeverityType('warning');
        setNotificationMessage(SOMETHING_WENT_WRONG);
        setShowModal(false);
      }
    }
  };

  return (
    <>
      <div className='app-wrapper w-100 landing-page-wrapper'>
        <Modal
          open={showModal}
          onClose={() => setShowModal(false)}
          className='yk-change-commission-modal-wrapper YKCH-ConfirmTransferModel yk-missingProductsModalWrapper'
          aria-labelledby='modal-modal-title'
          aria-describedby='modal-modal-description'>
          <div className='app-wrapper change-commission-modal-wrapper'>
            <div className='yk-modal-body'>
              <div className='modal-heading-wrapper'>
                <h3 className='modal-title yk-badge-h11 mb-0'>
                  Missing Product
                </h3>
                <div className='close-btn-wrapper'>
                  <button
                    className='btn prod-close'
                    onClick={() => setShowModal(false)}>
                    <Image
                      src={ModalCloseIcon}
                      alt='table-close-icon'
                      className='table-close-icon'
                    />
                  </button>
                </div>
              </div>
              <p className='yk-para-p6'>
                Are you sure want to clear the missing product.
              </p>

              <div className='yk-modal-btn-wrapper'>
                <button
                  type='button'
                  className='btn modal-btn-cancel'
                  data-bs-dismiss='modal'
                  onClick={() => setShowModal(false)}>
                  Cancel
                </button>
                <button
                  type='button'
                  className='btn modal-btn-submit'
                  onClick={clearMissingProduct}>
                  Clear
                </button>
              </div>
            </div>
          </div>
        </Modal>
      </div>
    </>
  );
};

export default MissingProductsModal;
