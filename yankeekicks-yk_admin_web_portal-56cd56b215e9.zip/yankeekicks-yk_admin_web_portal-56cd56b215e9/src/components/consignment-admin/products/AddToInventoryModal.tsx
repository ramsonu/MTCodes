import React, { useState, useRef, useEffect } from 'react';
import Modal from '@mui/material/Modal';
import Image from 'next/image';
import modalCloseIcon from 'assets/images/modal-close-btn-icon.svg';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import PrintSummary from './PrintSummary';
import {
  addBulFilekUpload,
  addToInventory,
  getLocationDetails,
} from 'services/consignment';
import {
  NOTIFICATION_INVALID_DATA,
  NOTIFICATION_SOMETHING_WENT_WRONG,
} from 'utils/constants';
import Notification from 'components/common/notification';
import { DISABLE_LOADER, ENABLE_LOADER } from 'actions/loader';
import { actions } from 'store/reducers/consignment';
import Loader from 'components/common/loader';
import { ADD_INVENTORY_SUCCESS } from './constant';
import { getBasePath } from 'utils/util';
const AddToInventoryModal = ({
  isAddtoInventoryModalVisible,
  setIsAddtoInventoryModalVisible,
  setIsVisibleMessage,
}: any) => {
  const dispatch = useDispatch();
  const router = useRouter();
  const { bulkRecord, uploadFile } = useSelector(
    (state: any) => state.consignment
  );
  const [isPrintSummaryVisible, setIsPrintSummaryVisible] =
    useState<boolean>(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isNotificationVisibleMessage, setIsNotificationVisibleMessage] =
    useState(false);
  const [message, setMessage] = useState('');
  const [severityType, setSeverityType] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [consignorData, setConsignorData] = useState();
  const [locationList, setLocationList] = useState<any>([]);
  const [selectedLocation, setSelectedLocation] = useState<any>(false);
  const [confirmClicked, setConfirmClicked] = useState<any>(false);
  const [selectedStore, setSelectedStore] = useState<any>(false);

  const [addShoeInventoryResponse, setAddShoeInventoryResponse] = useState<any>(
    []
  );
  const handleCancle = () => {
    setIsAddtoInventoryModalVisible();
  };
  const hideConfirmModal = () => {
    setShowModal(false);
  };

  useEffect(() => {
    if (!isAddtoInventoryModalVisible) setShowModal(false);
    else setShowModal(true);
  }, [isAddtoInventoryModalVisible]);

  const handleConfirm = async () => {
    const sendFile = uploadFile;
    setConfirmClicked(true);
    dispatch({ type: ENABLE_LOADER });
    try {
      if (sendFile?.length) {
        const response: any = await addBulFilekUpload(
          sendFile[0],
          true,
          selectedLocation
        );
        if (response.status == 200) {
          setIsLoading(false);
          dispatch({ type: DISABLE_LOADER });
          dispatch(actions.setBulkRecordRes(response.data));
          setIsPrintSummaryVisible(false);
          setIsNotificationVisibleMessage(true);
          setMessage(ADD_INVENTORY_SUCCESS);
          setSeverityType('success');
          setConfirmClicked(false);
          setTimeout(() => {
            router.push(getBasePath('inventory/add-inventory-response'));
          }, 1000);
        } else {
          setConfirmClicked(false);
          dispatch({ type: DISABLE_LOADER });
          setIsLoading(false);
          setIsNotificationVisibleMessage(true);
          setMessage(response?.data?.message || NOTIFICATION_INVALID_DATA);
          setSeverityType('warning');
          setTimeout(() => {
            handleCancle();
          }, 1000);
        }
      } else {
        setConfirmClicked(false);
        dispatch({ type: DISABLE_LOADER });
        setIsLoading(false);
        setIsNotificationVisibleMessage(true);
        setMessage(NOTIFICATION_INVALID_DATA);
        setSeverityType('warning');
        setTimeout(() => {
          handleCancle();
        }, 1000);
      }
    } catch (e: any) {
      setConfirmClicked(false);
      dispatch({ type: DISABLE_LOADER });
      setIsLoading(false);
      setIsNotificationVisibleMessage(true);
      setMessage(e?.response?.data?.message || NOTIFICATION_INVALID_DATA);
      setSeverityType('warning');
      setTimeout(() => {
        handleCancle();
      }, 1000);
    }
  };
  const handleConfirmV1 = async () => {
    dispatch({ type: ENABLE_LOADER });
    setShowModal(false);
    const updatedPayload = bulkRecord?.map(({ image, ...rest }: any) => ({
      ...rest,
      locationId: selectedLocation,
      //store: selectedStore,
    }));
    const requestPayload: any = updatedPayload;

    setIsLoading(true);
    addToInventory(requestPayload)
      .then((response) => {
        if (response) {
          setIsLoading(false);
          const failedResponseData = response?.data?.Failed?.map(
            (product: any) => ({
              ...product,
              status: 'Failed',
            })
          );
          const successResponseData = response?.data?.Success?.map(
            (product: any) => ({
              ...product,
              status: 'Success',
            })
          );
          setAddShoeInventoryResponse([
            ...failedResponseData,
            ...successResponseData,
          ]);
          setConsignorData(response?.data?.consignor);
          dispatch({ type: DISABLE_LOADER });
          setIsPrintSummaryVisible(false);
          dispatch(actions.setQueue([]));
          setIsNotificationVisibleMessage(true);
          setMessage(ADD_INVENTORY_SUCCESS);
          setSeverityType('success');
          setTimeout(() => {
            router.push(getBasePath('inventory'));
          }, 2000);
        }
      })
      .catch((error: any) => {
        dispatch({ type: DISABLE_LOADER });
        setIsLoading(false);
        setIsNotificationVisibleMessage(true);
        setMessage(NOTIFICATION_SOMETHING_WENT_WRONG);
        setSeverityType('warning');
        setTimeout(() => {
          handleCancle();
        }, 1000);
      });
  };

  const handleLocation = (event: any) => {
    var dataset = event?.target?.options[event?.target?.selectedIndex]?.dataset;
    setSelectedLocation(event?.target?.value);
    setSelectedStore(dataset?.store_id);
  };

  const fetchLocationDetails = async () => {
    try {
      let getLocations = await getLocationDetails();
      let locationListArray = Object.values(getLocations?.data);
      setLocationList(Object.values(locationListArray));
    } catch (e: any) {
      setLocationList([]);
    }
  };
  useEffect(() => {
    fetchLocationDetails();
  }, []);
  return (
    <>
      <Modal
        open={showModal}
        className='yk-clear-queue-modal-wrapper yk-bulk-import-add-inventory-modal'
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'>
        <div className='app-wrapper yk-clear-queue-modal-overlay-wrapper w-100'>
          <div className='yk-modal-body'>
            <div className='yk-modal-title'>Add To Inventory</div>
            <div className='yk-modal-content'>
              <div className='yk-locationSelectWrapper'>
                <p className='yk-locationInputLabel'>
                  Please Select Location :{' '}
                </p>
                <div className='form-group YKEE-arrowDownns'>
                  <select
                    className='yk-locationSelectDropdownBtn form-control custom-select YKEE-field'
                    onChange={handleLocation}>
                    <option selected hidden>
                      Select Location
                    </option>
                    {locationList?.length > 0 &&
                      locationList?.map((location: any, index: number) => {
                        return location?.locations?.map(
                          (store: any, storeindex: number) => {
                            return (
                              <option
                                key={`loc_${index}_${storeindex}`}
                                value={store?.id}
                                data-store_id={store?.storeId}>
                                {store?.name}
                              </option>
                            );
                          }
                        );
                      })}
                  </select>
                </div>
              </div>
              <div>
                {!confirmClicked && (
                  <p className='yk-modalSubTitle mb-0'>
                    Are you sure you want to add these shoes to inventory?
                  </p>
                )}
                {confirmClicked && (
                  <p className='text-danger text-center'>
                    Please do not refresh the page and wait while we are
                    processing, This can take a few minutes.{' '}
                  </p>
                )}
              </div>
            </div>
            <div className='yk-modalBtnWrapper'>
              <button
                className='btn-transparent clear-filter-btn yk-badge-h7'
                type='button'
                onClick={handleCancle}>
                Cancel
              </button>
              <button
                className='btn yk-btn-primary yk-modal-button mb-5'
                type='button'
                onClick={handleConfirm}>
                Confirm
                {isLoading && <Loader />}
              </button>
            </div>
          </div>
        </div>
      </Modal>
      <Notification
        showSuccessPopup={isNotificationVisibleMessage}
        severityType={severityType}
        handleSnackbarClose={() => setIsNotificationVisibleMessage(false)}
        message={message}
        className='yk-shoesize-alert-wrapper'
      />
      {isPrintSummaryVisible && (
        <PrintSummary
          isPrintSummaryVisible={isPrintSummaryVisible}
          setIsPrintSummaryVisible={setIsPrintSummaryVisible}
          setIsAddtoInventoryModalVisible={setIsAddtoInventoryModalVisible}
          setIsVisibleMessage={setIsVisibleMessage}
          tableData={addShoeInventoryResponse}
          consignorData={consignorData}
        />
      )}
    </>
  );
};

export default AddToInventoryModal;
