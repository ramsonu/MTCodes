import { Box, Button, MobileStepper, Paper, useTheme } from '@mui/material';
import React, { useEffect, useState } from 'react';
import { getBrandNameFromSku } from 'services/consignment';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import { getProductDetailsHeader } from 'middleware/cubejs-wrapper/cubejs-page-header-query';
import { FNS_DATE_FORMAT } from 'utils/constants';
import { format } from 'date-fns';
import CopyToClipboardComponent from 'components/common/copyToClipboard';
import { KeyboardArrowLeft, KeyboardArrowRight } from '@mui/icons-material';
import ImageLoader from 'components/common/image-loader';
import productImg from 'assets/images/big-product-img.svg';

const ProductSkuDetailsHeader = () => {
  const [skuDetailsImages, setSkuDetailsImages] = useState<any>([]);
  const router = useRouter();
  const [activeStep, setActiveStep] = React.useState(0);
  const sku: any = router.query.id;
  const [myInventoryDataById, setMyInventoryDataById] = useState<any>([]);
  const consignmentDetailsHeaderData: any = getProductDetailsHeader(sku);
  const [shouldFetchDataOfRequestId, setShouldFetchTransfersHeaderData] =
    useState<boolean>(false);
  const theme = useTheme();

  const { resultSet: consignmentDetailsResultSet }: any = useCubeQuery(
    consignmentDetailsHeaderData,
    {
      skip: !shouldFetchDataOfRequestId,
    }
  );
  const initData = async () => {
    setMyInventoryDataById(consignmentDetailsResultSet?.loadResponses[0]?.data);
    const param = {
      id: consignmentDetailsResultSet?.loadResponses[0]?.data[0]?.[
        'InventorySkuDetails.style'
      ],
    };
    try {
      await getBrandNameFromSku(param).then((response: any) => {
        const imageUrls = response?.data[0]?.catalogueImageList;
        setSkuDetailsImages(imageUrls);
      });
    } catch (e: any) {
      console.log(e);
    }
  };

  useEffect(() => {
    if (!!router.query.id) {
      setShouldFetchTransfersHeaderData(true);
    } else {
      setShouldFetchTransfersHeaderData(false);
    }
  }, [router?.query]);

  useEffect(() => {
    initData();
  }, [consignmentDetailsResultSet]);

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };
  return (
    <div className='yk-sku-topwrap'>
      <div className='row'>
        <div className='col-xl-2 col-lg-2 col-md-3 col-sm-12 col-12 payout-status'>
          <div className='yk-order-title w-50'>
            <Box sx={{ flexGrow: 1 }}>
              <Paper
                square
                elevation={0}
                sx={{
                  display: 'flex',
                  alignItems: 'center',

                  pl: 2,
                  bgcolor: 'background.default',
                }}></Paper>
              <ImageLoader
                src={skuDetailsImages?.[activeStep]}
                fallbackImg={productImg}
                alt='cart-img'
                className='img-fluid m-auto d-block img-product-logo'
              />
              <MobileStepper
                steps={skuDetailsImages?.length}
                position='static'
                activeStep={activeStep}
                nextButton={
                  <Button
                    className='next-arrow'
                    size='small'
                    onClick={handleNext}
                    disabled={activeStep === skuDetailsImages?.length - 1}>
                    {theme.direction === 'rtl' ? (
                      <KeyboardArrowLeft />
                    ) : (
                      <KeyboardArrowRight />
                    )}
                  </Button>
                }
                backButton={
                  <Button
                    className='back-arrow'
                    size='small'
                    onClick={handleBack}
                    disabled={activeStep === 0}>
                    {theme.direction === 'rtl' ? (
                      <KeyboardArrowRight />
                    ) : (
                      <KeyboardArrowLeft />
                    )}
                  </Button>
                }
              />
            </Box>
          </div>
        </div>
        <div className='col-xl-10 col-lg-10 col-md-9 col-sm-12 col-12 order-status ps-lg-0 pe-lg-0'>
          <div className='container-fluid ps-lg-0 ps-lg-0'>
            <div className='row yk-sku-titles'>
              <div className='col-lg-12 pe-0'>
                <div className='yk-prod-title'>
                  {myInventoryDataById?.[0]?.['InventorySkuDetails.brand']}
                </div>
                <div className='yk-prod-main-titles mt-1 mb-3'>
                  {myInventoryDataById?.[0]?.['InventorySkuDetails.itemName']}
                </div>
              </div>
            </div>

            <div className='yk-prod-details-card-wrap row'>
              <div className='col-xl-3 col-lg-6 col-md-12 col-sm-12 col-12'>
                <div className='yk-order-title YKCH-newDetails'>
                  <h4 className='yk-myouwnData'>
                    SKU:
                    <span className='yk-order-details' id='sku'>
                      <span
                        className='YKCH-nowData'
                        title={
                          myInventoryDataById?.[0]?.[
                            'InventorySkuDetails.style'
                          ]
                        }>
                        {
                          myInventoryDataById?.[0]?.[
                            'InventorySkuDetails.style'
                          ]
                        }
                      </span>
                      <CopyToClipboardComponent
                        copyText={
                          myInventoryDataById?.[0]?.[
                            'InventorySkuDetails.style'
                          ]
                        }
                      />
                    </span>
                  </h4>
                </div>
              </div>
              <div className='col-xl-3 col-lg-6 col-md-12 col-sm-12 col-12'>
                <div className='yk-order-title YKCH-newDetails'>
                  <h4 className='yk-myouwnData'>
                    Style Code:
                    <span className='yk-order-details' id='styleCode'>
                      <span
                        className='YKCH-nowData'
                        title={
                          myInventoryDataById?.[0]?.[
                            'InventorySkuDetails.style'
                          ]
                        }>
                        {
                          myInventoryDataById?.[0]?.[
                            'InventorySkuDetails.style'
                          ]
                        }
                      </span>
                      <CopyToClipboardComponent
                        copyText={
                          myInventoryDataById?.[0]?.[
                            'InventorySkuDetails.style'
                          ]
                        }
                      />
                    </span>
                  </h4>
                </div>
              </div>
              <div className='col-xl-3 col-lg-6 col-md-12 col-sm-12 col-12'>
                <div className='yk-order-title YKCH-newDetails'>
                  <h4 className='yk-myouwnData'>
                    Release Date:&nbsp;
                    <span className='yk-order-details'>
                      {myInventoryDataById?.[0]?.[
                        'InventorySkuDetails.actualReleaseDate'
                      ]
                        ? format(
                            new Date(
                              myInventoryDataById?.[0]?.[
                                'InventorySkuDetails.actualReleaseDate'
                              ]
                            ),
                            FNS_DATE_FORMAT
                          )
                        : ''}
                    </span>
                  </h4>
                </div>
              </div>
              <div className='col-xl-3 col-lg-6 col-md-12 col-sm-12 col-12'>
                <div className='yk-order-title YKCH-newDetails'>
                  <h4 className='yk-myouwnData'>
                    Colorway:
                    <span className='yk-order-details'>
                      <span className='YKCH-nowData'>
                        <span
                          className='YKCH-nowData'
                          title={
                            myInventoryDataById?.[0]?.[
                              'InventorySkuDetails.colorway'
                            ]
                          }>
                          {
                            myInventoryDataById?.[0]?.[
                              'InventorySkuDetails.colorway'
                            ]
                          }
                        </span>
                      </span>
                    </span>
                  </h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default ProductSkuDetailsHeader;
