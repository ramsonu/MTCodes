import React, { useState, useEffect, useMemo } from 'react';
import type { NextPage } from 'next';
import SearchComp from 'components/common/search';
import Image from 'next/image';
import inventoryMedia from 'assets/images/inventory.svg';
import { ClickAwayListener } from '@mui/material';
import Sortings from 'components/common/sortings';
import VirtualTable from 'components/common/table';
import filterIcon from 'assets/images/filter-icon.png';
import { format } from 'date-fns';
import groupConsignee from 'assets/images/consignee/group-consignee.svg';
import {
  getInvetoryDetailsById,
  getPaginationCountForSKU,
} from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import { useCubeQuery } from '@cubejs-client/react';
import {
  getDifferenceDate,
  getFormattedDate,
  getMyId,
  getBasePath,
} from 'utils/util';
import OrderDetailsModal from '../../orders/order-details-modal';
import { useRouter } from 'next/router';
import Breadcrumbs from 'components/common/breadcrumbs';
import {
  downloadPrintQRPDF,
  getProfitRatio,
  intiateWithdraw,
} from 'services/consignment';
import ProductFilters from 'components/common/filters/product-filter';
import {
  FNS_DATE_FORMAT,
  NOTIFICATION_SOMETHING_WENT_WRONG,
} from 'utils/constants';
import Notification from 'components/common/notification';
import Pagination from 'components/common/pagination';
import { useDispatch, useSelector } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import ProductSkuDetailsHeader from './product-sku-details-header';
import ExportsTypes from 'components/common/exports-types';
import { DISABLE_LOADER, ENABLE_LOADER } from 'actions/loader';
import ConfirmPopup from 'components/common/confirm-popup';

const InventorySkuDetails: NextPage = (props: any) => {
  const limitForQuery = 10;
  const dispatch = useDispatch();
  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const [userInput, setUserInput] = useState('');
  const [showDetailsModal, setShowDetailsModal] = useState<any>(false);
  const [myInventoryDataById, setMyInventoryDataById] = useState([]);
  const [countForPagination, setCountForPagination] = useState(0);
  const router = useRouter();
  const [searchOffset, setSearchOffset] = useState<any>(0);
  const [selectedOrderId, setSelectedOrderId] = useState<any>(router.query.id);
  const userId = !!router.query.userId ? router.query.userId : getMyId();
  const isConsignorFlag = !!router.query.userId;
  const [skuId, setSkuId] = useState<any>('');
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [message, setMessage] = useState<string>('');
  const [severityType, setSeverityType] = useState<string>('');
  const [modalData, setModalData] = React.useState<any>();
  const [selectedSort, setSelectedSort] = useState('sellingPriceAsc');
  const [profitRatio, setProfitRatio] = useState('');
  const [showFilters, setShowFilters] = useState<boolean>(false);
  const [filterInput, setFilterInput] = useState<any>({});
  const [selectedStatus, setSelectedStatus] = useState<any>([]);
  const [createdDate, setCreatedDate] = useState<any>('');
  const [currentDate, setCurrentDate] = useState<any>('');
  const [clearDisable, setClearDisable] = useState(true);
  const [selectedStartDate, setSelectedStartDate] = useState<any>('');
  const [selectedEndDate, setSelectedEndDate] = useState<any>('');
  const [lineItemId, setLineItemId] = useState('');
  const [reloadData, setReloadData] = React.useState<any>(false);
  const [totlaMyInventory, setTotalMyInventory] = useState(0);
  const [isAllCheckBoxChecked, setIsAllCheckBoxChecked] = useState<any>(false);
  const [enableWithdrawBtn, setEnableWithdrawBtn] = useState(false);

  const [showConfirmDetailsModal, setShowConfirmDetailsModal] =
    React.useState<any>(false);
  const [checked, setChecked] = useState({
    Pending: false,
    Active: false,
    Sold: false,
    Withdrawn: false,
  });
  const [shouldFetchDataOfRequestId, setShouldFetchTransfersHeaderData] =
    useState<boolean>(false);
  const [isPDFExport, setIsPDFExport] = useState(true);
  const handleCheckBoxChecked = (e: any, data: any, tableData: any) => {
    const updatedData = addCheckPropertyToData(
      tableData,
      e?.target?.checked,
      data
    );
    setMyInventoryDataById(updatedData);
    if (e?.target?.checked) {
      setEnableWithdrawBtn(e?.target?.checked);
    } else {
      setEnableWithdrawBtn(
        updatedData?.filter((item: any) => item.isChecked == true).length
          ? true
          : false
      );
    }
  };
  const handleCheckAll = (event: any, tableData: any) => {
    setIsAllCheckBoxChecked(event?.target?.checked);
    const updatedData = addCheckPropertyToData(
      tableData,
      event?.target?.checked
    );
    setMyInventoryDataById(updatedData);
    setEnableWithdrawBtn(
      updatedData?.filter((item: any) => item.isChecked == true).length
        ? true
        : false
    );
  };
  const checkboxDisabledItemCheck = (status: any): boolean => {
    if (status == 'Pending' || status == 'Active') return false;
    else return true;
  };
  const addCheckPropertyToData = (
    tempData: any,
    checkedStatus: boolean,
    dataItem?: any
  ) => {
    if (!!dataItem) {
      return tempData.map((lineItem: any) => {
        if (
          lineItem['InventorySkuDetails.barcode'] ==
          dataItem['InventorySkuDetails.barcode']
        ) {
          let checkboxDisabledCheck = checkboxDisabledItemCheck(
            lineItem['InventorySkuDetails.status']
          );
          return {
            ...lineItem,
            isChecked: checkedStatus,
            checkboxDisabled: checkboxDisabledCheck,
          };
        } else return lineItem;
      });
    } else
      return tempData.map((lineItem: any) => {
        let checkboxDisabledCheck = checkboxDisabledItemCheck(
          lineItem['InventorySkuDetails.status']
        );
        return {
          ...lineItem,
          isChecked: checkboxDisabledCheck ? false : checkedStatus,
          checkboxDisabled: checkboxDisabledCheck,
        };
      });
  };

  const handleWithdrawal = async () => {
    dispatch({ type: ENABLE_LOADER });
    try {
      const checkedBarcodes = myInventoryDataById
        .filter((item: any) => item.isChecked == true)
        .map((item: any) => {
          return item['InventorySkuDetails.barcode'];
        });
      const handleAction = await intiateWithdraw({ barcodes: checkedBarcodes });
      if (handleAction?.status == 200) {
        if (handleAction?.data?.status == 'Complete') {
          setShowConfirmDetailsModal(false);
          setIsVisibleMessage(true);
          setSeverityType('success');
          setMessage('Withdrawal requested successfully');
          setReloadData(true);
          setTimeout(() => {
            setReloadData(false);
          }, 500);
        } else {
          setShowConfirmDetailsModal(false);
          setIsVisibleMessage(true);
          setSeverityType('warning');
          setMessage(
            handleAction?.data?.message || NOTIFICATION_SOMETHING_WENT_WRONG
          );
        }
        dispatch({ type: DISABLE_LOADER });
      } else {
        setShowConfirmDetailsModal(false);
        setIsVisibleMessage(true);
        setSeverityType('warning');
        setMessage(
          handleAction?.data?.message || NOTIFICATION_SOMETHING_WENT_WRONG
        );
      }
    } catch (e: any) {
      setShowConfirmDetailsModal(false);
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setMessage(
        e?.response?.data?.message || NOTIFICATION_SOMETHING_WENT_WRONG
      );
      dispatch({ type: DISABLE_LOADER });
    }
  };

  const columns = useMemo(
    () => [
      {
        type: 'checkbox',
        ref: 'withdrawal',
        title: '',
        checked: 'isChecked',
        costPerItem: 'InventorySkuDetails.costperItem',
        value: 'InventorySkuDetails.barcode',
        isDisabled: 'checkboxDisabled',
        onChange: (e: any, data: any, tableData: any) => {
          handleCheckBoxChecked(e, data, tableData);
        },
        checkAll: (e: any, tableData: any) => handleCheckAll(e, tableData),
        isAllChecked: isAllCheckBoxChecked,
      },
      {
        title: 'S.No',
        type: !isConsignorFlag ? 'sno' : 'hidden',
      },
      {
        title: 'Barcode',
        value: 'InventorySkuDetails.barcode',
      },
      {
        title: 'Size',
        value: 'InventorySkuDetails.Size',
      },
      {
        title: 'Condition',
        value: 'InventorySkuDetails.conditionName',
      },

      {
        title: 'Selling Price',
        value: 'InventorySkuDetails.retailPrice_D',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Payout Amount',
        value: 'InventorySkuDetails.payoutAmount',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Cost/Item',
        value: 'InventorySkuDetails.costperItem',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Age',
        type: !isConsignorFlag ? 'age' : 'hidden',
        value: 'InventorySkuDetails.releaseDate',
      },
      {
        title: 'Location',
        value: 'InventorySkuDetails.locationName',
      },
      {
        title: 'Status',
        value: 'InventorySkuDetails.status',
        type: 'statusList',
        success: 'Active',
        greensuccess: 'Sold',
        danger: 'Pending',
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          viewButtonHandler(data);
        },
        value: isConsignorFlag ? 'Show Details' : 'View',
      },
      {
        title: 'Display QR Code',
        type: 'printQRButton',
        onClick: (data: any, mobileCheck: boolean) => {
          printQRButtonHandler(data, mobileCheck);
        },
        value: 'InventorySkuDetails.status',
        additionalCheck: 'InventorySkuDetails.productId',
        locationCheck: 'InventorySkuDetails.locationId',
      },
    ],
    []
  );
  const exportHeaders = [
    { label: 'Barcode', key: 'InventorySkuDetails.barcode' },
    {
      label: 'Size',
      key: 'InventorySkuDetails.Size',
    },
    {
      label: 'Condition',
      key: 'InventorySkuDetails.conditionName',
    },

    {
      label: 'Selling Price',
      key: 'InventorySkuDetails.retailPrice_D',
      type: 'amount',
    },
    {
      label: 'Payout Amount',
      key: 'InventorySkuDetails.payoutAmount',
      type: 'amount',
    },
    {
      label: 'Cost/Item',
      key: 'InventorySkuDetails.costperItem',
      type: 'amount',
    },
    {
      label: 'Created Date',
      key: 'InventorySkuDetails.releaseDate',
      type: 'date',
    },
    {
      label: 'Location',
      key: 'InventorySkuDetails.locationName',
    },
    {
      label: 'Status',
      key: 'InventorySkuDetails.status',
    },
  ];
  const breadCrumbHeaders = !isConsignorFlag
    ? {
        title: 'My Inventory',
        subTitle: 'SKU Details',

        onClick: () => {
          router?.push(`${getBasePath('inventory')}`);
        },
      }
    : {
        title: 'Consignors',
        titleImage: groupConsignee,
        subTitle: router.query.userId,
        nextSubTitle: router.query.id,
        onClick: () => {
          router?.push(`${getBasePath('consignors')}`);
        },
        onNextClick: () => {
          router?.push(`${getBasePath(`consignors/${router.query.userId}`)}`);
        },
      };
  const queryPayload = {
    userInput,
    selectedSort,
    filterInput,
    sku: selectedOrderId,
    consigneeId: isConsignorFlag ? userId : null,
  };
  const viewInventory: any = getInvetoryDetailsById(
    selectedOrderId,
    userInput,
    selectedSort,
    filterInput,
    searchOffset,
    limitForQuery,
    isConsignorFlag ? userId : null
  );

  const sKUPaginationCountQuery: any = getPaginationCountForSKU(
    userInput,
    filterInput,
    selectedOrderId,
    isConsignorFlag ? userId : null
  );
  const exportInventory: any = getInvetoryDetailsById(
    selectedOrderId,
    userInput,
    selectedSort,
    filterInput,
    null,
    null,
    isConsignorFlag ? userId : null
  );

  const {
    resultSet: myInventoryDataByIdResultSet,
    isLoading,
    error,
  }: any = useCubeQuery(viewInventory, {
    subscribe: reloadData,
    skip: !shouldFetchDataOfRequestId,
  });

  const { resultSet: pageCountResultSet }: any = useCubeQuery(
    sKUPaginationCountQuery,
    { skip: !shouldFetchDataOfRequestId }
  );
  const { resultSet: exportInventoryResult }: any = useCubeQuery(
    exportInventory,
    { skip: isPDFExport }
  );
  useEffect(() => {
    onClearFilters(); //clear filters on page load
  }, []);
  useEffect(() => {
    const data = myInventoryDataByIdResultSet?.loadResponses[0]?.data;
    if (data) {
      setMyInventoryDataById(addCheckPropertyToData(data, false));
    } else {
      setMyInventoryDataById([]);
    }
    if (pageCountResultSet) {
      let countData =
        (isConsignorFlag
          ? pageCountResultSet?.loadResponses[0]?.data[0]?.[
              'InventoryCount.countBySku'
            ]
          : pageCountResultSet?.loadResponses[0]?.data[0]?.[
              'InventoryCount.countbyskuAdmin'
            ]) || 0;
      let rowCount =
        pageCountResultSet?.loadResponses[0]?.data[0]?.[
          'InventoryCount.count'
        ] || 0;

      setCountForPagination(+rowCount);
      setTotalMyInventory(+countData);
    }
  }, [myInventoryDataByIdResultSet, pageCountResultSet]);

  useEffect(() => {
    setSelectedOrderId(router?.query?.id);
    if (!!router.query.id) {
      setShouldFetchTransfersHeaderData(true);
    } else {
      setShouldFetchTransfersHeaderData(false);
    }
  }, [router?.query]);

  const onChangeHandler = (event: any) => {
    setSearchOffset(0);
    setUserInput(event.target.value);
  };

  const viewButtonHandler = (data: any) => {
    getProfit(data?.['InventorySkuDetails.consigneeId']);
    setSkuId(data?.['InventorySkuDetails.style']);
    setLineItemId(data['InventorySkuDetails.consignmentlineitemId_D']);
    setModalData(data);
    setShowDetailsModal(true);
  };

  const printQRButtonHandler = async (data: any, mobileCheck: boolean) => {
    //const locations = localStorage?.getItem('storeLocationId');
    const locations = data['InventorySkuDetails.locationId'];
    const productId = data['InventorySkuDetails.productId'];
    const barcode = data['InventorySkuDetails.barcode'];
    try {
      await downloadPrintQRPDF(locations, productId, barcode, mobileCheck);
    } catch (e: any) {
      setIsVisibleMessage(true);
      setSeverityType('error');
      setMessage(NOTIFICATION_SOMETHING_WENT_WRONG);
    }
  };

  const sortHandler = (event: any) => {
    setSearchOffset(0);
    setSelectedSort(event.target.value);
  };

  const getProfit = async (consigneeId: any) => {
    const param = { id: consigneeId };
    try {
      await getProfitRatio(param).then((response) => {
        setProfitRatio(response?.data?.profitRatio);
      });
    } catch (e: any) {
      console.log(e);
    }
  };

  const onPayoutChange = (event: any) => {
    setChecked({ ...checked, [event?.target?.name]: event?.target?.checked });
    let updatedList = [...selectedStatus];
    if (event.target.checked) {
      updatedList = [...selectedStatus, event.target.name];
    } else {
      updatedList.splice(selectedStatus.indexOf(event.target.name), 1);
    }
    setSelectedStatus(updatedList);
    if (updatedList.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  };

  const onDateChange = (dates: any) => {
    const [start, end] = dates;
    setSelectedStartDate(start);
    setSelectedEndDate(end);
    setClearDisable(false);
  };
  const onClickPDFExport = () => {
    setIsPDFExport(false);
    setTimeout(() => {
      setIsPDFExport(true);
    }, 100);
  };

  const ageChange = (event: any) => {
    const todaysDate = new Date();
    const endDate = getFormattedDate(todaysDate, FNS_DATE_FORMAT);
    setClearDisable(false);
    setCurrentDate(endDate);
    if (event.target.value === '1week') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 7);
      const startDate = getFormattedDate(sevenDaysPrevious, FNS_DATE_FORMAT);
      setCreatedDate(startDate);
    }

    if (event.target.value === '1month') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 30);
      const startDate = getFormattedDate(sevenDaysPrevious, FNS_DATE_FORMAT);
      setCreatedDate(startDate);
    }
    if (event.target.value === '3months') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 90);
      const startDate = getFormattedDate(sevenDaysPrevious, FNS_DATE_FORMAT);
      setCreatedDate(startDate);
    }

    if (event.target.value === '6months') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 183);
      const startDate = getFormattedDate(sevenDaysPrevious, FNS_DATE_FORMAT);
      setCreatedDate(startDate);
    }
    if (event.target.value === '9months') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 275);
      const startDate = getFormattedDate(sevenDaysPrevious, FNS_DATE_FORMAT);
      setCreatedDate(startDate);
    }
    if (event.target.value === '1year') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 365);
      const startDate = getFormattedDate(sevenDaysPrevious, FNS_DATE_FORMAT);
      setCreatedDate(startDate);
    }
  };
  const onApplyFilters = () => {
    setSearchOffset(0);
    const viewFilterValue = {
      startDate:
        selectedStartDate !== ''
          ? format(new Date(selectedStartDate), FNS_DATE_FORMAT)
          : '',
      endDate:
        selectedEndDate !== ''
          ? format(new Date(selectedEndDate), FNS_DATE_FORMAT)
          : '',
      currentDate:
        currentDate !== ''
          ? format(new Date(currentDate), FNS_DATE_FORMAT)
          : '',
      createdDate:
        createdDate !== ''
          ? format(new Date(createdDate), FNS_DATE_FORMAT)
          : '',
      size: filterTypes.size,
      status: selectedStatus,
    };

    setFilterInput(viewFilterValue);
    setUserInput('');
    setShowFilters(false);
  };
  // this use effect is not required , commented for future ref.
  /*  useEffect(() => {
    if (
      filterTypes.size.length !== 0 ||
      selectedStatus.length !== 0 ||
      currentDate !== '' ||
      selectedStartDate !== ''
    ) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  }); */
  const onClearFilters = () => {
    setSearchOffset(0);
    setSelectedStartDate('');
    setSelectedEndDate('');
    setCurrentDate('');
    setCreatedDate('');
    setSelectedStatus([]);
    dispatch(actions.clearAllFilters({}));
    setChecked({
      Pending: false,
      Active: false,
      Sold: false,
      Withdrawn: false,
    });
    setFilterInput({});
    setShowFilters(false);
    setClearDisable(true);
  };

  const handleClose = (isRefresh: boolean = false) => {
    setReloadData(isRefresh);
    setShowDetailsModal(false);
    setTimeout(() => {
      setReloadData(false);
    }, 500);
  };

  return (
    <div className='yk-inventory-sku-details-page-wrapper'>
      <div className='container-fluid'>
        <Notification
          showSuccessPopup={isVisibleMessage}
          handleSnackbarClose={() => setIsVisibleMessage(false)}
          severityType={severityType}
          message={message}
          className='yk-shoesize-alert-wrapper YKCH-TostifyMsg'
        />
        <div className='row'>
          <Breadcrumbs data={breadCrumbHeaders} />
          <div className='col-lg-12 col-md-12 col-sm-12'>
            {!isConsignorFlag && <ProductSkuDetailsHeader />}
          </div>
        </div>
      </div>

      <div className='app-wrapper w-100 orders-page-wrapper yk-inventory-sku-details-page-wrapper'>
        <div className='orders-page-inner-wrapper YKCH-newSubLisggin'>
          <div className='container-fluid'>
            <div className='row'>
              <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                <div className='heading-wrapper orders-heading-wrapper'>
                  <h2 className='heading'>
                    {router.query.id}

                    <span className='count-badge'>{totlaMyInventory}</span>
                  </h2>
                  <div
                    className={`sort-product-wrapper export-btn bg-transparent me-0 pe-0`}>
                    <ExportsTypes
                      data={
                        (exportInventoryResult?.loadResponses &&
                          exportInventoryResult?.loadResponses[0]?.data) ||
                        []
                      }
                      headers={exportHeaders}
                      fileName='inventoryDetails'
                      queryPayload={queryPayload}
                      onClickPDFExport={onClickPDFExport}
                      isActive={
                        myInventoryDataById && myInventoryDataById?.length > 0
                      }
                    />
                  </div>
                </div>
                {isConsignorFlag && (
                  <h5 className='sub-haeding'>SKU details</h5>
                )}
              </div>
              <div className='col-lg-12 col-md-12 col-sm-12'>
                <div className='yk-sku-topwrap'>
                  {isConsignorFlag && (
                    <div className='yk-sku-titles d-flex justify-content-between'>
                      <h2 className='yk-prod-main-titles mt-1 mb-3'>
                        Inventory
                      </h2>
                      <Image
                        src={inventoryMedia}
                        alt='filter-btn-icon'
                        className='filter-btn-icon img-fluid'
                      />
                    </div>
                  )}
                  <div className='search-btn-wrapper'>
                    <div className='row'>
                      <div className='col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12'>
                        <div className='YKCH-searchingData'>
                          <SearchComp
                            onChangeHandler={onChangeHandler}
                            userInput={userInput}
                            optionType='no suggestions'
                            placeholder='Search'
                          />
                        </div>
                      </div>
                      <div className='col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12'>
                        <div className='consignment-btn-wrapper dFlexCenter'>
                          <div
                            className={`yk-inventory-sku-details-page-wrapper me-0 pe-0`}>
                            <button
                              className='yk-withdraw-btn yk-title-h19'
                              onClick={() => setShowConfirmDetailsModal(true)}
                              disabled={!enableWithdrawBtn}>
                              Withdraw
                            </button>
                          </div>
                          <Sortings
                            handleChange={sortHandler}
                            itemKey='skuDetails'
                            defaultSelectedValue={selectedSort}
                          />

                          <div className='filter-btn-wrapper'>
                            <ClickAwayListener
                              onClickAway={() => {
                                setShowFilters(false);
                              }}>
                              <div>
                                <button
                                  className='btn filter-btn '
                                  onClick={() => setShowFilters(!showFilters)}>
                                  <Image
                                    src={filterIcon}
                                    alt='filter-btn-icon'
                                    className='filter-btn-icon img-fluid'
                                  />
                                  <span className='filter-btn-text yk-badge-h15'>
                                    Filter
                                  </span>
                                </button>
                                {showFilters && (
                                  <ProductFilters
                                    itemKey={
                                      isConsignorFlag
                                        ? 'consignorInventoryDetails'
                                        : 'inventoryDetails'
                                    }
                                    onDateChange={onDateChange}
                                    onAgeChange={ageChange}
                                    startDate={selectedStartDate}
                                    endDate={selectedEndDate}
                                    onApplyClick={onApplyFilters}
                                    onPayoutChange={onPayoutChange}
                                    checkedValue={checked}
                                    onClearFilters={onClearFilters}
                                    clearDisable={clearDisable}
                                  />
                                )}
                              </div>
                            </ClickAwayListener>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className='row'>
                    <div className='col-lg-12 col-md-12 col-sm-12'>
                      <VirtualTable
                        headers={columns}
                        rowData={myInventoryDataById}
                        offSet={searchOffset}
                        loading={isLoading}
                        error={error}
                      />
                    </div>
                    {myInventoryDataById?.length > 0 && (
                      <div className='center-pagination'>
                        <Pagination
                          lengthOfData={countForPagination}
                          itemsPerPage={limitForQuery}
                          currentOffset={searchOffset}
                          setOffset={setSearchOffset}
                        />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {showDetailsModal && (
        <OrderDetailsModal
          showModal={showDetailsModal}
          handleClose={handleClose}
          modalData={modalData}
          orderDetails={'Inventory'}
          quantity={router.query.quantity}
          skuId={skuId}
          profitRatio={profitRatio}
          lineItemId={lineItemId}
          isConsignorFlag={isConsignorFlag}
          modalClassName='yk-inventoryShoeDetailsModal'
        />
      )}

      <ConfirmPopup
        className='withdraw-modal-wrapper'
        showPopup={showConfirmDetailsModal}
        handleClose={(e: any) => setShowConfirmDetailsModal(false)}
        title='Withdraw Shoes'
        message={
          'Are you sure you want to request withdrawal of selected Items?'
        }
        handleSave={handleWithdrawal}
      />
    </div>
  );
};
export default InventorySkuDetails;
