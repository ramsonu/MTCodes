import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import downloadRed from 'assets/images/download-red.svg';
import {
  addBulFilekUpload,
  downloadTemplate,
  downloadTemplateSheSizeData,
  getBrandNameFromSku,
  getConditionTypeList,
  getProfitRatio,
} from 'services/consignment';
import { useDispatch } from 'react-redux';
import { useRouter } from 'next/router';
import { actions } from 'store/reducers/consignment';
import Breadcrumbs from 'components/common/breadcrumbs';
import { BulkUpload } from 'components/common/bulk-upload';
import { DISABLE_LOADER, ENABLE_LOADER } from 'actions/loader';
import Notification from 'components/common/notification';
import { getBasePath, getProfitRatioAmt } from 'utils/util';
import {
  MINIMUM_FEE,
  NOTIFICATION_INVALID_DATA,
  NOTIFICATION_SOMETHING_WENT_WRONG,
} from 'utils/constants';

const Imports = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const [sendFile, setSendFile] = useState<any>([]);
  const sendFileModified = new Blob(sendFile);
  const [isVisibleMessage, setIsVisibleMessage] = useState(false);
  const [notificationMsg, setNotificationMsg] = useState('File is empty');
  const [profitRatio, setProfitRatio] = useState('');
  const [conditionList, setConditionList] = useState<any>([]);
  const [csvData, setCsvData] = useState([]);
  const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');

  const breadCrumHeaders = {
    title: 'My Inventory',
    subTitle: 'Bulk Import',

    onClick: () => {
      router?.push(getBasePath('inventory'));
    },
  };
  const getConditionList = async () => {
    const listData = await getConditionTypeList();
    let dorpDownData: any = [];
    listData?.forEach((item: any, index: number) => {
      dorpDownData[item?.name] = item?.conditionId;
    });
    setConditionList(dorpDownData);
  };
  useEffect(() => {
    getConditionList();
    const param = { id: userDetails?.user_id };
    getProfitRatio(param).then((response) => {
      const { profitRatio, minimumFee } = response?.data;
      localStorage?.setItem('profitRatio', profitRatio);
      localStorage?.setItem('minimumFee', minimumFee || MINIMUM_FEE);
      setProfitRatio(profitRatio);
    });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const handleDownload = async (ee: any) => {
    ee.preventDefault();
    try {
      await downloadTemplate().then((response) => {
        let binaryData = '';

        binaryData = response?.data;
        const link = document.createElement('a');
        link.href = window.URL.createObjectURL(new Blob([binaryData]));

        link.setAttribute('download', 'BulkImportTemplate.csv');
        document.body.appendChild(link);
        link.click();
      });
    } catch (e: any) {
      console.log(e);
    }
  };
  const handleDownloadShoeSizeData = async (ee: any) => {
    ee.preventDefault();
    try {
      await downloadTemplateSheSizeData().then((response) => {
        let binaryData = '';

        binaryData = response?.data;
        const link = document.createElement('a');
        link.href = window.URL.createObjectURL(new Blob([binaryData]));

        link.setAttribute('download', 'Shoe-Size-List.csv');
        document.body.appendChild(link);
        link.click();
      });
    } catch (e: any) {
      console.log(e);
    }
  };

  const handleChange = async () => {
    dispatch({ type: ENABLE_LOADER });
    const reader = new FileReader();
    reader.onload = async (e) => {
      const text: any = e?.target?.result;
      const allTextLines = text.split(/\r\n|\n/);
      const headers = allTextLines[0].split(',');
      const lines: any = [];
      const skus: any = [];
      for (let i = 1; i < allTextLines.length; i++) {
        const data = allTextLines[i].split(',');
        if (data.length == headers.length) {
          const bulkObj: any = {
            sku: '',
            costPerItem: '',
            price: '',
            //storeName: '',
            size: '',
            quantity: '',
            condition: '',
            oldBarcode: '',
            rowId: '',
            payout: 0,
            totalPrice: 0,
          };
          for (let j = 0; j < headers.length; j++) {
            Object.keys(bulkObj).forEach(function (key: any, index) {
              //bulkObj[key] = data[index]; // comment it for csv conditon column
              bulkObj[key] = index == 4 ? data[index].trim() : data[index]; //index4 will be condition
            });
            bulkObj['rowId'] = i;
            if (!skus[bulkObj?.sku]) {
              skus[bulkObj?.sku] = await getBrand(bulkObj?.sku);
            }
            const minimum = getProfitRatioAmt(parseInt(bulkObj.price));
            /* const payCalculated: any = bulkObj.price
              ? (parseInt(bulkObj.price) - minimum)?.toFixed(2)
              : 0;
            bulkObj['payout'] = payCalculated; */
            //bulkObj['condition'] = 'New'; // comment it for csv conditon column
            //bulkObj['conditionId'] = conditionList['New']; // comment it for csv conditon column
            bulkObj['conditionId'] = conditionList[bulkObj['condition']];
            bulkObj['oldBarcode'] = !!bulkObj['oldBarcode']
              ? bulkObj['oldBarcode']
              : '';
            //bulkObj['totalPrice'] = bulkObj['quantity'] * payCalculated;
            bulkObj['totalPrice'] =
              bulkObj['quantity'] * bulkObj['costPerItem'];
            //            console.log('bulk', bulkObj);
          }
          lines.push(bulkObj);
        }
      }
      if (lines && lines.length > 0) {
        lines.map((line: any) => {
          line.brand = skus[line.sku]?.brand;
          line.image = skus[line.sku]?.image;
          line.name = skus[line.sku]?.name;
        });
        dispatch({ type: DISABLE_LOADER });
        dispatch(actions.setBulkRecord(lines));
        setCsvData(lines);
        setSendFile([]);
        //  router.push('/inventory/previewbulk');
      } else {
        dispatch(actions.setBulkRecord([]));
        setCsvData([]);
        setSendFile([]);
        setIsVisibleMessage(true); //when file is empty
        setNotificationMsg('File is empty');
        dispatch({ type: DISABLE_LOADER });
      }
    };
    reader.readAsText(sendFileModified);
  };

  const getBrand = async (id: any) => {
    const param = { id: id };
    try {
      let response = await getBrandNameFromSku(param);
      if (response?.data) {
        return {
          brand: response?.data[0]?.brand,
          name: response?.data[0]?.name,
          image: response?.data[0]?.catalogueImageList[0],
          sku: id,
        };
      }
    } catch (e: any) {
      console.log(e);
    }
  };
  const upload = () => {
    if (
      csvData.length !=
      csvData.filter((row: any, index: number) => !!row?.conditionId).length
    ) {
      setIsVisibleMessage(true); //when file is empty
      setNotificationMsg('Condition type is not availble!');
    } else {
      router.push(getBasePath('inventory/previewbulk'));
    }
  };

  const uploadCsvFile = async () => {
    dispatch({ type: ENABLE_LOADER });
    try {
      if (sendFile?.length) {
        const response: any = await addBulFilekUpload(sendFile[0]);

        if (response.status == 200) {
          dispatch(actions.setBulkRecord(response.data));
          dispatch(actions.setBulkFile(sendFile));
          dispatch({ type: DISABLE_LOADER });
          setTimeout(() => {
            router.push(getBasePath(`inventory/previewbulk`));
          }, 1000);
        } else {
          dispatch({ type: DISABLE_LOADER });
          dispatch(actions.setBulkRecord([]));
          setSendFile([]);
          setIsVisibleMessage(true); //when file is empty
          setNotificationMsg(
            response?.data?.message || NOTIFICATION_INVALID_DATA
          );
        }
      } else {
        dispatch({ type: DISABLE_LOADER });
        dispatch(actions.setBulkRecord([]));
        setSendFile([]);
        setIsVisibleMessage(true); //when file is empty
        setNotificationMsg(NOTIFICATION_INVALID_DATA);
        //        setNotificationMsg(NOTIFICATION_SOMETHING_WENT_WRONG);
      }
    } catch (e: any) {
      dispatch({ type: DISABLE_LOADER });
      dispatch(actions.setBulkRecord([]));
      setSendFile([]);
      setIsVisibleMessage(true); //when file is empty
      setNotificationMsg(
        e?.response?.data?.message || NOTIFICATION_INVALID_DATA
      );
      console.log('error', e);
    }
  };
  return (
    <div className='bulk-import-page-wrapper'>
      <div className='container-fluid bulk-import-page-wrapper'>
        <div className='row'>
          <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
            <Breadcrumbs data={breadCrumHeaders} />
            <div className='heading-wrapper'>
              <div className='heading-inner-wrapper'>
                <h3 className='heading'>Add Product Using Bulk Import</h3>
                <p className='description'>
                  Please fill the relevant information in the sheet and upload.
                </p>
              </div>
            </div>
            <div className='bulk-import-upload-wrapper'>
              <div className='upload-wrapper'>
                <div className='upload-inner-wrapper'>
                  <form action='' className='import-form'>
                    <div className='form-group upload-group'>
                      <div className='documents-upload-wrapper'>
                        <BulkUpload
                          setSendFile={setSendFile}
                          isFileEmpty={isVisibleMessage}
                          upload={uploadCsvFile}></BulkUpload>
                      </div>
                      <div className='download-btn-wrapper'>
                        <button
                          className='btn btn-download yk-btn-outline'
                          onClick={(e) => handleDownload(e)}>
                          <Image
                            src={downloadRed}
                            className='img-fluid'
                            alt=''
                          />
                          Download Template
                        </button>
                      </div>
                      <div className='download-btn-wrapper-shoe-size'>
                        <button
                          className='download-btn-shoe-size'
                          onClick={(e) => handleDownloadShoeSizeData(e)}>
                          {/*  <Image
                            src={downloadRed}
                            className='img-fluid'
                            alt=''
                          /> */}
                          Download Shoe Size & Shoe Condition Information
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <Notification
              showSuccessPopup={isVisibleMessage}
              handleSnackbarClose={() =>
                setTimeout(() => setIsVisibleMessage(false), 1000)
              }
              severityType={'error'}
              message={notificationMsg}
              className='yk-shoesize-alert-wrapper'
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Imports;
