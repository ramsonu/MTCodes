import React, { useState, useRef, useEffect } from 'react';
import Modal from '@mui/material/Modal';
import Image from 'next/image';
import modalCloseIcon from 'assets/images/modal-close-btn-icon.svg';
import { useDispatch, useSelector } from 'react-redux';
import { useCubeQuery } from '@cubejs-client/react';
import { getShoeSize } from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import VirtualTable from 'components/common/table';
import { actions } from 'store/reducers/consignment';
import { getConditionTypeList, getProfitRatio } from 'services/consignment';
import { MIN_SELLING_PRICE } from './constant';
import Loader from 'components/common/loader';
import sizeMatrix from 'utils/sizeMatrix.json';
import {
  MINIMUM_FEE,
  SIZE_MATRIX_GRADESCHOOL,
  SIZE_MATRIX_MENWOMEN,
  SIZE_MATRIX_PRESCHOOL,
  SIZE_MATRIX_TODDLER,
} from 'utils/constants';
import { amIadminUser } from 'utils/util';
const AddQueueModal = ({
  showModal,
  setShowModal,
  selectedProductId,
  setShowSuccessPopup,
  showSuccessPopup,
  selectedSku,
  selectedBrand,
  selectedImage,
  productInfo,
}: any) => {
  const { queue } = useSelector((state: any) => state.consignment);
  const dispatch = useDispatch();
  const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
  const [profitRatio, setProfitRatio] = useState('');
  const [shoesizes, setShoeSizes] = useState<any>([]);
  const [selectedSizeType, setSelectedSizeType] = useState<any>(null);
  const [selectedShoeSize, setSelectedShoeSize] = useState<any>([]);
  const [conditionList, setConditionList] = useState<any>([]);
  const [queueItem, setQueueItem] = useState<any>([]);
  const [newConditionId, setNewConditionId] = useState<any>(0);
  const applyRef = useRef<HTMLButtonElement>(null);

  const handleClose = (event: Event | React.SyntheticEvent) => {
    if (
      applyRef.current &&
      applyRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }
    setShowModal(false);
  };
  const getConditionList = async () => {
    const listData = await getConditionTypeList();
    let dorpDownData = listData?.map((item: any, index: number) => {
      if (item?.name == 'new') setNewConditionId(item?.conditionId);
      return { title: item?.name, value: item?.conditionId };
    });
    setConditionList(dorpDownData);
  };
  useEffect(() => {
    getConditionList();
    const param = { id: userDetails?.user_id };
    getProfitRatio(param).then((response) => {
      const { profitRatio, minimumFee } = response?.data;
      localStorage?.setItem('profitRatio', profitRatio);
      localStorage?.setItem('minimumFee', minimumFee || MINIMUM_FEE);
      setProfitRatio(response?.data?.profitRatio);
    });
    let shoeSizeTemp: any = [];
    if (productInfo['Catalogue.men'] || productInfo['Catalogue.women'])
      shoeSizeTemp = shoeSizeTemp.concat(
        sizeMatrix[SIZE_MATRIX_MENWOMEN].sizeList
      );
    if (productInfo['Catalogue.child'])
      shoeSizeTemp = shoeSizeTemp.concat(
        sizeMatrix[SIZE_MATRIX_GRADESCHOOL].sizeList
      );
    if (productInfo['Catalogue.preschool'])
      shoeSizeTemp = shoeSizeTemp.concat(
        sizeMatrix[SIZE_MATRIX_PRESCHOOL].sizeList
      );
    if (productInfo['Catalogue.infant'] || productInfo['Catalogue.toddler'])
      shoeSizeTemp = shoeSizeTemp.concat(
        sizeMatrix[SIZE_MATRIX_TODDLER].sizeList
      );
    setShoeSizes(shoeSizeTemp);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const isLoading = false;
  const error = false;
  const sizeLabel = sizeMatrix.map((size: any, index: number) => {
    return { label: size?.name, index: index };
  });

  const [addQueue, setQueue] = useState([]);
  const [queueEnable, setQueueEnable] = useState(false);
  const columns = [
    {
      title: 'S.No',
      type: 'sno',
    },
    {
      title: 'Size',
      value: 'size',
    },
    {
      title: 'Condition',
      type: 'select',
      dropdown: conditionList,
      value: newConditionId,
      onChange: (data: any, i: any) => {
        handleonChange(data, 'condition', i);
      },
    },
    {
      title: 'Quantity',
      type: 'textbox',
      value: 'quantity',
      onChange: (data: any, i: any) => {
        handleonChange(data, 'quantity', i);
      },
    },
    {
      title: 'Cost/item',
      type: 'textbox',
      disabled: false,
      //isAddCostModal: true,
      value: 'costPerItem',
      onChange: (data: any, i: any) => {
        handleonChange(data, 'costPerItem', i);
      },
    },
    {
      title: 'Selling Price',
      type: 'textbox',
      value: 'sellingPrice',
      onChange: (data: any, i: any) => {
        handleonChange(data, 'sellingPrice', i);
      },
    },

    {
      title: 'Total Cost',
      prefix: '$',
      value: 'totalCost',
      methodToApply: 'toFix',
      type: 'previewTotalCost',
    },
    {
      title: 'Actions',
      type: 'image',
      mode: 'static',
      onClick: (data: any) => {
        handleOnSizeClick(data?.size, 'actionButton');
      },
      value: modalCloseIcon,
    },
  ];

  const handleOnSizeClick = (val: any, type: any) => {
    let value = '';
    if (type === 'sizeButton') {
      value = val.target.innerText;
    }
    if (type === 'actionButton') {
      value = val;
    }
    if (selectedShoeSize.includes(value)) {
      let tempOption = [];
      tempOption = selectedShoeSize.filter((data: any) => data !== value);
      setSelectedShoeSize(tempOption);
    } else {
      setSelectedShoeSize([...selectedShoeSize, value]);
      enableQueue([...selectedShoeSize, value]);
    }
  };

  useEffect(() => {
    if (selectedShoeSize) {
      const finalPayload = {
        name: selectedProductId,
        size: '',
        quantity: '',
        price: 0,
        payout: 0,
        costPerItem: '',
        totalCost: 0,
        totalPay: 0.0,
        brand: selectedBrand,
        sku: selectedSku,
        image: selectedImage,
        conditionId: newConditionId,
        conditionName: '',
      };
      let tempArray: any = [];
      selectedShoeSize.map((item: any, index: any) => {
        const currentItem = addQueue.filter((row: any) => row.size == item);
        const payload = currentItem.length ? currentItem[0] : finalPayload;
        tempArray.push({ ...payload, size: item });
      });
      setQueueItem(tempArray);
      setQueue(tempArray);
    }
  }, [selectedShoeSize]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleonChange = (data: any, type: string, i: any) => {
    const value = data?.target?.value;
    const inputValueRegex = /^[1-9]\d*\.?\d*$/;
    const qtyRegex = /^-?\d+?\d*$/;
    let tempArray: any = [...queueItem];
    if (type === 'quantity') {
      if (value.match(qtyRegex) || value === '') {
        queueItem.map((item: any, ind: any) => {
          if (i === ind) {
            tempArray[ind].quantity = data.currentTarget.value;
            tempArray[ind].totalPay =
              tempArray[ind].quantity * tempArray[ind].sellingPrice;
            tempArray[ind].totalCost =
              tempArray[ind].quantity * tempArray[ind].costPerItem;
          }
        });
      }
    }
    if (type === 'sellingPrice') {
      if (value.match(inputValueRegex) || value === '') {
        queueItem.map((item: any, ind: any) => {
          if (i === ind) {
            tempArray[ind].sellingPrice = data.currentTarget.value;
            tempArray[ind].totalPay =
              tempArray[ind].quantity * tempArray[ind].sellingPrice;
            tempArray[ind].totalCost =
              tempArray[ind].quantity * tempArray[ind].costPerItem;
          }
        });
      }
    }
    if (type === 'costPerItem') {
      if (value.match(inputValueRegex) || value === '') {
        queueItem.map((item: any, ind: any) => {
          if (i === ind) {
            tempArray[ind].costPerItem = data.currentTarget.value;
            tempArray[ind].totalCost =
              tempArray[ind].quantity * tempArray[ind].costPerItem;
          }
        });
      }
    }
    if (type === 'condition') {
      queueItem.map((item: any, ind: any) => {
        if (i === ind) {
          tempArray[ind].conditionId = parseInt(data.currentTarget.value);
          tempArray[ind].conditionName =
            data.currentTarget?.selectedOptions[0]?.dataset?.title;
        }
      });
    }
    enableQueue(tempArray);
    setQueueItem(tempArray);
  };
  const enableQueue = (tempArray: any) => {
    let tempVal = tempArray.every(
      (x: any) =>
        parseInt(x.quantity) > 0 &&
        parseInt(x.sellingPrice) > parseInt(x.costPerItem) &&
        parseInt(x.conditionId)
    );
    setQueueEnable(tempVal > 0 ? true : false);
  };
  const buttonClickHandler = () => {
    let temp = [...queue];
    temp.push(...queueItem);
    dispatch(actions.setQueue(temp));
    setShowModal(false);
    setShowSuccessPopup(!showSuccessPopup);
  };

  return (
    <>
      <Modal
        open={showModal}
        // onClose={handleClose}
        className='yk-add-queue-modal-wrapper yk-add-product-queue-modal-wrapper'
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'>
        <div className='app-wrapper yk-add-queue-modal-overlay-wrapper w-100'>
          <div className='yk-modal-body'>
            <div className='d-flex justify-content-between'>
              <div className='yk-modal-title'>
                {/*  {selectedBrand} */} {selectedProductId}
              </div>
              <div className='close-btn-wrapper'>
                <button
                  className='btn prod-close'
                  onClick={() => setShowModal(false)}>
                  <Image
                    src={modalCloseIcon}
                    alt='table-close-icon'
                    className='table-close-icon'
                  />
                </button>
              </div>
            </div>
            <div className='yk-modalScroll'>
              <div className='yk-modal-subtitle'>Select size</div>
              {isLoading ? (
                <Loader />
              ) : (
                <div className='yk-modal-content'>
                  {shoesizes.map((item: any, index: any) => {
                    return (
                      <button
                        className={`queue-size-btn ${
                          selectedShoeSize.includes(item['key'].trim())
                            ? 'selected'
                            : ''
                        }`}
                        type='button'
                        key={`size_${index}`}
                        value={item['key']}
                        onClick={(e) => handleOnSizeClick(e, 'sizeButton')}>
                        {item['value']}
                      </button>
                    );
                  })}
                </div>
              )}
              <div className='yk-sizeTableWrapper'>
                {shoesizes.length > 0 && (
                  <VirtualTable
                    loading={isLoading}
                    error={error}
                    noData={true}
                    headers={columns}
                    rowData={addQueue}
                  />
                )}
              </div>
            </div>

            <div className='text-center'>
              <button
                className='btn yk-btn-primary yk-modal-button mb-5'
                type='button'
                onClick={buttonClickHandler}
                disabled={!queueEnable || addQueue?.length === 0}>
                Add to queue
              </button>
            </div>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default AddQueueModal;
