import React, { useState, useEffect } from 'react';
import type { NextPage } from 'next';

import filterIcon from 'assets/images/filter-icon.png';
import {
  Button,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
} from '@mui/material';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
} from '@mui/material';
import tableCloseIcon from 'assets/images/modal-table-close-icon.svg';
import tableImg from 'assets/images/table-product-img.png';
import {
  Checkbox,
  InputAdornment,
  MenuItem,
  Select,
  Link as MuiLink,
} from '@mui/material';
import Box from '@mui/material/Box';
import { FormControl, NativeSelect } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import SearchComp from 'components/common/search';
import Image from 'next/image';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import noRecordImg from 'assets/images/no-table-record-img.png';
import VirtualTable from 'components/common/table';
import modalCloseIcon from 'assets/images/modal-close-btn-icon.svg';
import { useDispatch, useSelector } from 'react-redux';
import { addToInventory, getLocationDetails } from 'services/consignment';
import { actions } from 'store/reducers/consignment';
import CatalogPrintSummary from './catalog-printSummary';
import Notification from 'components/common/notification';
import {
  INVENTORY_ADD,
  NOTIFICATION_SOMETHING_WENT_WRONG,
} from 'utils/constants';
import { DISABLE_LOADER, ENABLE_LOADER } from 'actions/loader';
import Link from 'next/link';
import { PREFIX } from '../constants';
import Modal from '@mui/material/Modal';
import Terms from '../terms';
import ModalCloseIcon from 'assets/images/modal-close-icon.svg';
import Loader from 'components/common/loader';
import { getBasePath } from 'utils/util';
import ConfirmPopup from 'components/common/confirm-popup';
import { ADD_INVENTORY_SUCCESS } from './constant';

const AddShoesToMyInventory = () => {
  const router = useRouter();
  const onFindHandler = () => {
    router.push(getBasePath('inventory'));
  };
  const dispatch = useDispatch();
  const { queue } = useSelector((state: any) => state.consignment);

  const limitForQuery = 10;
  const headers = ['#', 'Sku', 'Pictures', 'Brand', 'Name', 'Qty', 'Actions'];
  const [userInput, setUserInput] = useState<any>('');
  const [isPrintSummaryVisible, setIsPrintSummaryVisible] =
    useState<boolean>(false);
  const [searchOffset, setSearchOffset] = useState<any>(0);
  const [selectedSort, setSelectedSort] = useState('');
  const [checked, setChecked] = useState(false);
  const [addShoeInventoryResponse, setAddShoeInventoryResponse] = useState<any>(
    []
  );
  const [isAddtoInventoryModalVisible, setIsAddtoInventoryModalVisible] =
    useState<boolean>(false);
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [isNotificationVisibleMessage, setIsNotificationVisibleMessage] =
    useState<boolean>(false);
  const [message, setMessage] = useState<string>('');
  const [severityType, setSeverityType] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [isVisibleTerms, setIsVisibleTerms] = useState(false);
  const [consignorData, setConsignorData] = useState();
  const [showConfirmPopup, setShowConfirmPopup] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<any>(false);
  const [selectedStore, setSelectedStore] = useState<any>(false);
  const [locationList, setLocationList] = useState<any>([]);
  const columns = React.useMemo(
    () => [
      {
        title: 'S.No',
        type: 'sno',
      },
      {
        title: 'SKU',
        value: 'sku',
      },
      {
        title: 'Image',
        value: 'image',
        type: 'image',
      },
      {
        title: 'Brand',
        value: 'brand',
      },
      {
        title: 'Name',
        value: 'name',
      },
      {
        title: 'Size',
        value: 'size',
      },
      {
        title: 'Condition',
        value: 'conditionName',
      },
      {
        title: 'Qty',
        value: 'quantity',
      },

      {
        title: 'Total Cost',
        value: 'totalCost',
        methodToApply: 'toFix',
        prefix: PREFIX,
      },
      {
        title: 'Actions',
        type: 'image',
        onClick: (data: any) => {
          viewButtonHandler(data);
        },
        mode: 'static',
        value: modalCloseIcon,
      },
    ],
    [] // eslint-disable-line react-hooks/exhaustive-deps
  );

  const viewButtonHandler = (data: any) => {
    dispatch(actions.removeQueue(data.size));
  };

  const addShoesToInventory = async () => {
    dispatch({ type: ENABLE_LOADER });
    let payload = {};
    let arrayData: any = [];
    queue?.map((x: any) => {
      payload = {
        brand: x.brand,
        name: x.name,
        price: x.sellingPrice,
        costPerItem: x.costPerItem,
        quantity: x.quantity,
        size: x.size,
        sku: x.sku,
        image: x.image,
        conditionId: parseInt(x.conditionId),
        conditionName: x.conditionName,
        locationId: selectedLocation,
        // store: selectedStore,
        // storeName: 'Miami',
      };
      arrayData.push(payload);
    });
    setIsLoading(true);
    setShowConfirmPopup(false);
    addToInventory(arrayData)
      .then((response) => {
        const failedResponseData = response.data.Failed.map((product: any) => ({
          ...product,
          status: 'Failed',
        }));
        const successResponseData = response.data.Success.map(
          (product: any) => ({
            ...product,
            status: 'Success',
          })
        );
        setAddShoeInventoryResponse([
          ...failedResponseData,
          ...successResponseData,
        ]);
        setConsignorData(response?.data?.consignor);
        setIsLoading(false);
        setIsPrintSummaryVisible(false);
        setIsVisibleMessage(false);
        setShowConfirmPopup(false);
        dispatch({ type: DISABLE_LOADER });
        setIsNotificationVisibleMessage(true);
        setMessage(ADD_INVENTORY_SUCCESS);
        setSeverityType('success');
        dispatch(actions.setQueue([]));
        dispatch(actions.setBulkRecordRes(response.data));
        setTimeout(() => {
          router.push(getBasePath('inventory/add-inventory-response'));
        }, 1000);
      })
      .catch((e: any) => {
        setIsLoading(false);
        setIsNotificationVisibleMessage(true);
        setMessage(
          e?.response?.data?.message || NOTIFICATION_SOMETHING_WENT_WRONG
        );
        setSeverityType('warning');
        dispatch({ type: DISABLE_LOADER });
        setShowConfirmPopup(false);
      });
  };

  const onChangeHandler = (event: any) => {
    setUserInput(event.target.value);
  };

  const onTermsChange = (event: any) => {
    setChecked(event.target.checked);
  };

  const handleLocation = (event: any) => {
    var dataset = event.target.options[event.target.selectedIndex].dataset;
    setSelectedLocation(event?.target?.value);
    setSelectedStore(dataset.store_id);
  };

  const fetchLocationDetails = async () => {
    try {
      let getLocations = await getLocationDetails();
      let locationListArray = Object.values(getLocations?.data);
      setLocationList(Object.values(locationListArray));
    } catch (e: any) {
      setLocationList([]);
    }
  };
  useEffect(() => {
    fetchLocationDetails();
  }, []);
  return (
    <>
      <div className='app-wrapper w-100 '>
        <div className='add-shoes-inventory-wrapper'>
          <div className='add-shoes-inventory-inner-wrapper'>
            <div className='container-fluid'>
              <div className='row'>
                <div className='col-lg-12'>
                  <div className='breadcrumbs-wrapper'>
                    <ul className='breadcrumbs-list'>
                      <li className='yk-heading yk-title-h19'>
                        <a
                          role='button'
                          className='yk-orders-heading'
                          onClick={() =>
                            router?.push(getBasePath('inventory'))
                          }>
                          My Inventory
                        </a>
                      </li>
                      <li className='yk-heading yk-title-h19'>
                        <a
                          role='button'
                          className='yk-orders-heading'
                          onClick={() =>
                            router?.push(
                              getBasePath('inventory/AddShoesCatalog')
                            )
                          }>
                          Catalog
                        </a>
                      </li>
                      <li className='yk-sub-heading'>Preview Catalog</li>
                    </ul>
                  </div>
                </div>
                <div className='col-lg-12'>
                  <h3 className='yk-main-title'>
                    Add shoes to My Inventory
                    <span className='count-badge'>{queue?.length}</span>
                    <span className='yk-para-p4'>
                      {queue?.length === 1 ? 'Product' : 'Products'}
                    </span>
                  </h3>
                  <p className='yk-para-p2'>
                    Please preview the items before adding to the inventory
                  </p>
                </div>
              </div>

              <VirtualTable headers={columns} rowData={queue} />
              <div className='agreement-wrapper text-center mt-5'>
                <h3 className='yk-section-subtitle-2'>
                  <Checkbox
                    className='filter-sidebar-checkbox'
                    onChange={(event: any) => onTermsChange(event)}
                    checked={queue?.length > 0 ? checked : false}
                    disabled={queue?.length === 0}
                  />
                  I agree to the{' '}
                  <MuiLink
                    component='button'
                    variant='body2'
                    className='text-decoration-underline'
                    onClick={() => setIsVisibleTerms(true)}>
                    Terms and Conditions
                  </MuiLink>{' '}
                  for adding the shoes to inventory
                </h3>
                <div className='button-action-wrapper'>
                  <button
                    className={
                      checked || queue?.length > 0
                        ? 'btn btn-place-request'
                        : 'btn btn-place-request disabled'
                    }
                    type='button'
                    // onClick={addShoesToInventory}
                    onClick={() => setShowConfirmPopup(true)}
                    disabled={!checked || queue?.length === 0}>
                    Add to my inventory
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <ConfirmPopup
          className='yk-add-to-inventory-modal-wrapper'
          showPopup={showConfirmPopup}
          handleClose={(e: any) => {
            setShowConfirmPopup(false);
          }}
          title='Add To Inventory'
          message={
            <div>
              <div className='yk-locationSelectWrapper'>
                <p className='yk-locationInputLabel'>
                  Please Select Location :{' '}
                </p>
                <div className='form-group YKEE-arrowDownns'>
                  <select
                    className='yk-locationSelectDropdownBtn form-control custom-select YKEE-field'
                    onChange={handleLocation}>
                    <option selected disabled hidden>
                      Select Location
                    </option>
                    {locationList &&
                      locationList.map((location: any, index: number) => {
                        return location?.locations.map(
                          (store: any, storeindex: number) => {
                            return (
                              <option
                                key={`loc_${index}_${storeindex}`}
                                value={store?.id}
                                data-store_id={store?.storeId}>
                                {store?.name}
                              </option>
                            );
                          }
                        );
                      })}
                  </select>
                </div>
              </div>
              <div className='yk-modalContentWrapper'>
                <p className='mb-0'>
                  Are you sure you want to add these shoes to inventory?
                </p>
              </div>
            </div>
          }
          handleSave={addShoesToInventory}
          handleSaveDisabled={!selectedStore || !selectedLocation}
        />

        {isPrintSummaryVisible && (
          <CatalogPrintSummary
            isPrintSummaryVisible={isPrintSummaryVisible}
            setIsPrintSummaryVisible={setIsPrintSummaryVisible}
            setIsAddtoInventoryModalVisible={setIsAddtoInventoryModalVisible}
            setIsVisibleMessage={setIsVisibleMessage}
            addInventoryResponse={addShoeInventoryResponse}
            consignorData={consignorData}
          />
        )}
        <Notification
          showSuccessPopup={isNotificationVisibleMessage}
          handleSnackbarClose={() => setIsNotificationVisibleMessage(false)}
          severityType={severityType}
          message={message}
          className='yk-shoesize-alert-wrapper'
        />
      </div>
      <Modal
        open={isVisibleTerms}
        onClose={() => setIsVisibleTerms(false)}
        className='yk-terms-conditions-modal-wrapper'
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'>
        <div className='app-wrapper terms-conditions-modal-wrapper'>
          <div className='yk-modal-body'>
            <div className='terms-heading-wrapper'>
              <div className='heading-inner-wrapper'>
                <h3 className='terms-modal-title'>Terms of service</h3>
                <p className='modal-sub-title mb-0'>
                  Last Updated on January 2023
                </p>
              </div>
              <button
                className='btn btn-modal-close'
                onClick={() => setIsVisibleTerms(false)}>
                <Image
                  src={ModalCloseIcon}
                  className='img-fluid'
                  alt=''></Image>
              </button>
            </div>
            <hr />
            <Terms />
          </div>
        </div>
      </Modal>
    </>
  );
};

export default AddShoesToMyInventory;
