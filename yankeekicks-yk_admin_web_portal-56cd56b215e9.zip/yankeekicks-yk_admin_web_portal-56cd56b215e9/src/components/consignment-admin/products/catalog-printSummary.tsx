import React, { useRef } from 'react';
import { Modal } from '@mui/material';
import { useSelector, useDispatch } from 'react-redux';
import { actions } from 'store/reducers/consignment';
import VirtualTable from 'components/common/table';
import ReactToPrint from 'react-to-print';
import { useRouter } from 'next/router';
import { PREFIX } from '../constants';
import StaticText from 'components/common/static-text';
import { getBasePath } from 'utils/util';

const CatalogPrintSummary = ({
  isPrintSummaryVisible,
  setIsPrintSummaryVisible,
  setIsAddtoInventoryModalVisible,
  setIsVisibleMessage,
  addInventoryResponse = false,
  consignorData,
}: any) => {
  const { queue } = useSelector((state: any) => state.consignment);
  const tableData = addInventoryResponse ? addInventoryResponse : queue;
  const componentRef: any = useRef(null);
  const router = useRouter();
  const dispatch = useDispatch();

  const columns = React.useMemo(
    () => [
      {
        title: 'S.No',
        type: 'sno',
      },
      {
        title: 'SKU',
        value: 'sku',
      },
      {
        title: 'Image',
        value: 'image',
        type: 'image',
      },
      {
        title: 'Brand',
        value: 'brand',
      },
      {
        title: 'Name',
        value: 'name',
      },
      {
        title: 'Size',
        value: 'size',
      },
      {
        title: 'Condition',
        value: 'condition',
      },
      {
        title: 'Qty',
        value: 'quantity',
      },
      {
        title: 'Status',
        value: 'status',
        type: 'status',
        success: 'Success',
        danger: 'Failed',
      },

      {
        title: 'Total Cost',
        value: 'totalCost',
        prefix: PREFIX,
        methodToApply: 'toFix',
      },
    ],
    []
  );

  const handlePrintLater = () => {
    setIsVisibleMessage(true);
    setIsAddtoInventoryModalVisible(false);
    setIsPrintSummaryVisible(false);
    dispatch(actions.setQueue([]));
    setTimeout(() => {
      router.push(getBasePath('inventory'));
    }, 2000);
  };

  return (
    <>
      <h1>Summary</h1>
      <Modal
        open={isPrintSummaryVisible}
        className='yk-clear-queue-modal-wrapper'
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'>
        <div className='app-wrapper yk-clear-queue-modal-overlay-wrapper yk-print-summary-wrap w-100'>
          <div className='yk-modal-body'>
            <div className='yk-modal-title'>Summary</div>
            <div className='yk-modal-content yk-modal-subtitle'>
              Please print the summary of the items, and place it within the
              shipment.
            </div>

            <div className='yk-print-summary-data-wrap' ref={componentRef}>
              <div className='yk-print-summary-data-view'>
                <div className='yk-consignor-details'>
                  <p>
                    <span className='fw-bold'>Consignee Name : </span>
                    {consignorData?.name}
                  </p>
                  <p>
                    <span className='fw-bold'>Shipment ID : </span>
                    {consignorData?.consignmentId}
                  </p>
                  <p>
                    <span className='fw-bold'>Email : </span>{' '}
                    {consignorData?.email}
                  </p>
                  <p>
                    <span className='fw-bold'>Phone Number : </span>
                    {consignorData?.phoneNumber}
                  </p>
                </div>

                <VirtualTable headers={columns} rowData={tableData} />
                <StaticText />
              </div>
            </div>
            <div className='d-flex justify-content-between'>
              <button
                className='btn-transparent clear-filter-btn yk-badge-h7'
                type='button'
                onClick={handlePrintLater}>
                Print Later
              </button>
              <ReactToPrint
                onBeforePrint={() => handlePrintLater()}
                trigger={() => (
                  <button className='btn yk-btn-primary yk-modal-button yk-modal-summary-button mb-5'>
                    Print Summary
                  </button>
                )}
                content={() => componentRef.current}
                documentTitle={`Print Summary of ConsignmentId id  ${consignorData?.consignmentId}`}
              />
            </div>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default CatalogPrintSummary;
