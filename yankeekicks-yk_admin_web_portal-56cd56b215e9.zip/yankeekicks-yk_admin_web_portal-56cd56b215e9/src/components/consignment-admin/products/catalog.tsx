import React, { useState, useEffect, useRef } from 'react';
import type { NextPage } from 'next';
import filterIcon from 'assets/images/filter-icon.png';
import { Button, ClickAwayListener } from '@mui/material';
import Pagination from 'components/common/pagination';
import modalCloseIcon from 'assets/images/modal-close-btn-icon.svg';
import queueIcon from 'assets/images/queue-icon.svg';
import catalogProductImage3 from 'assets/images/big-product-img.svg';
import SearchComp from 'components/common/search';
import Image from 'next/image';
import { useRouter } from 'next/router';
import AddIcon from 'assets/images/add-icon.png';
import AddQueueModal from './AddQueueModal';
import ClearQueueModal from './ClearQueueModal';
import { useCubeQuery } from '@cubejs-client/react';
import {
  getCatlogueTabQuery,
  getPaginationCountForCatlogue,
} from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import { MY_INVENTORY_INNER_PATH } from '../constants';
import { useDispatch, useSelector } from 'react-redux';
import Notification from 'components/common/notification';
import { NOTIFY_MSG } from './constant';
import Sortings from 'components/common/sortings';
import ProductFilters from 'components/common/filters/product-filter';
import { format } from 'date-fns';
import { KPI_DATE_FORMAT } from 'utils/constants';
import { getBasePath, getDifferenceDate, getFormattedDate } from 'utils/util';
import { actions } from 'store/reducers/kiosk';
import VirtualTable from 'components/common/table';
import Breadcrumbs from 'components/common/breadcrumbs';
import NoDataFound from 'components/common/no-data-found';
import ImageLoader from 'components/common/image-loader';
import productImg from 'assets/images/big-product-img.svg';
import Loader from 'components/common/loader';
import OrderDetailsModal from '../orders/order-details-modal';
import CatalogDetailsModal from '../orders/catalog-details-modal';

const AddShoesCatalog = (props: any) => {
  const router = useRouter();
  const { isShoeCatalog = false } = props;
  const dispatch = useDispatch();
  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const [showCard, setShowCard] = useState(false);
  const { queue } = useSelector((state: any) => state.consignment);
  const limitForQuery = 12;
  const applyRef = useRef<HTMLButtonElement>(null);
  const [showModal, setShowModal] = useState<boolean>(false);
  const [catlogueData, setCatlogueData] = useState<any>([]);
  const [userInput, setUserInput] = useState(router?.query?.sku || '');
  const [searchOffset, setSearchOffset] = useState<any>(0);
  const [countForPagination, setCountForPagination] = useState(0);
  const [selectedProductId, setSelectedProductId] = useState<any>('');
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);
  const [selectedSort, setSelectedSort] = useState('skuAsc');
  const [showFilter, setShowFilter] = useState(false);
  const [ageFilter, setAgeFilter] = useState<any>('');
  const [createdDate, setCreatedDate] = useState<any>('');
  const [currentDate, setCurrentDate] = useState<any>('');
  const [selectedStartDate, setSelectedStartDate] = useState<any>('');
  const [selectedEndDate, setSelectedEndDate] = useState<any>('');
  const [filterInput, setFilterInput] = useState<any>({});
  const [view, setView] = useState(!isShoeCatalog);
  const [clearDisable, setClearDisable] = useState(true);
  const { MY_INVENTORY_PATH } = MY_INVENTORY_INNER_PATH;
  const [isClearQueueAvailable, setIsClearQueueAvailable] =
    useState<boolean>(false);
  const [selectedSku, setSelectedSku] = useState<any>('');
  const [selectedBrand, setSelectedBrand] = useState<any>('');
  const [selectedImage, setSelectedImage] = useState<any>('');
  const [productInfo, setProductInfo] = useState<any>(null);
  const [myInventoryData, setMyInventoryData] = useState<any>([]);
  const headers = {
    title: 'My Inventory',
    subTitle: 'Catalog',

    onClick: () => {
      router?.push(MY_INVENTORY_PATH);
    },
  };
  const columns = React.useMemo(
    () => [
      {
        title: 'S.No',
        type: 'sno',
      },
      {
        title: 'SKU',
        value: 'Catalogue.style',
      },
      {
        title: 'Picture',
        type: 'image',
        value: 'Catalogue.stockxUrl',
      },
      {
        title: 'Brand',
        value: 'Catalogue.brand',
      },
      {
        title: 'Name',
        value: 'Catalogue.itemName',
      },

      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          productClickHandler(data);
        },
        value: isShoeCatalog ? 'View' : 'Add',
      },
    ],
    []
  );

  const catlogueTabQuery: any = getCatlogueTabQuery(
    userInput,
    searchOffset,
    selectedSort,
    limitForQuery,
    filterInput
  );

  const catloguePaginationCountQuery: any = getPaginationCountForCatlogue(
    userInput,
    filterInput
  );

  const {
    resultSet: catlogueTabResultSet,
    isLoading,
    error,
  }: any = useCubeQuery(catlogueTabQuery);
  const { resultSet: pageCountResultSet }: any = useCubeQuery(
    catloguePaginationCountQuery
  );
  useEffect(() => {
    if (catlogueTabResultSet?.loadResponses[0]?.data?.length > 0) {
      setCatlogueData(catlogueTabResultSet?.loadResponses[0]?.data);
    } else if (!isLoading) {
      setCatlogueData([]);
    }
  }, [catlogueTabResultSet, isLoading]);

  useEffect(() => {
    if (pageCountResultSet) {
      let countData =
        +pageCountResultSet?.loadResponses[0]?.data[0]?.['Catalogue.count'] ||
        0;
      setCountForPagination(countData);
    }
  }, [pageCountResultSet]);

  const onChangeHandler = (event: any) => {
    setUserInput(event.target.value);
    setSearchOffset(0);
  };
  const productClickHandler = (product: any) => {
    setSelectedProductId(
      `${product['Catalogue.itemName']} ${product['Catalogue.description']}`
    );
    setSelectedSku(product['Catalogue.style']);
    setSelectedBrand(product['Catalogue.brand']);
    setSelectedImage(product['Catalogue.stockxUrl']);
    setProductInfo(product);
    setShowModal(true);
  };

  const handleSnackbarClose = () => {
    setShowSuccessPopup(false);
  };

  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
  };

  const onDateChange = (dates: any) => {
    const [start, end] = dates;
    setSelectedStartDate(start);
    setSelectedEndDate(end);
    setClearDisable(false);
  };

  const onClick = () => {
    const filterPayload = {
      startDate:
        selectedStartDate !== ''
          ? format(new Date(selectedStartDate), KPI_DATE_FORMAT)
          : '',
      endDate:
        selectedEndDate !== ''
          ? format(new Date(selectedEndDate), KPI_DATE_FORMAT)
          : '',
      currentDate:
        currentDate !== ''
          ? format(new Date(currentDate), KPI_DATE_FORMAT)
          : '',
      createdDate:
        createdDate !== ''
          ? format(new Date(createdDate), KPI_DATE_FORMAT)
          : '',
      brand: filterTypes.brand,
    };

    setFilterInput(filterPayload);
    setUserInput('');
    setShowFilter(false);
    setSearchOffset(0);
  };
  const onClearFilters = () => {
    setSelectedStartDate('');
    setSelectedEndDate('');
    setCurrentDate('');
    setCreatedDate('');
    setFilterInput({});
    setSearchOffset(0);

    setClearDisable(true);
    dispatch(actions.clearAllFilters({}));
  };

  useEffect(() => {
    if (
      filterTypes.brand.length !== 0 ||
      selectedEndDate !== '' ||
      ageFilter !== ''
    ) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  }, [filterTypes, ageFilter, selectedEndDate]);

  const ageChange = (event: any) => {
    setAgeFilter(event.target.value);
    const todaysDate = new Date();
    const endDate = getFormattedDate(todaysDate, KPI_DATE_FORMAT);
    setClearDisable(false);
    setCurrentDate(endDate);
    if (event.target.value === '1week') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 7);
      const startDate = getFormattedDate(sevenDaysPrevious, KPI_DATE_FORMAT);
      setCreatedDate(startDate);
    }
    if (event.target.value === '1month') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 30);
      const startDate = getFormattedDate(sevenDaysPrevious, KPI_DATE_FORMAT);
      setCreatedDate(startDate);
    }
    if (event.target.value === '3months') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 90);
      const startDate = getFormattedDate(sevenDaysPrevious, KPI_DATE_FORMAT);
      setCreatedDate(startDate);
    }
    if (event.target.value === '6months') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 183);
      const startDate = getFormattedDate(sevenDaysPrevious, KPI_DATE_FORMAT);
      setCreatedDate(startDate);
    }
    if (event.target.value === '9months') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 275);
      const startDate = getFormattedDate(sevenDaysPrevious, KPI_DATE_FORMAT);
      setCreatedDate(startDate);
    }
    if (event.target.value === '1year') {
      const sevenDaysPrevious = getDifferenceDate(todaysDate, 365);
      const startDate = getFormattedDate(sevenDaysPrevious, KPI_DATE_FORMAT);
      setCreatedDate(startDate);
    }
  };

  const clearQueueHandler = () => {
    setIsClearQueueAvailable(true);
  };

  const addToInventoryRedirect = () => {
    router.push(getBasePath('inventory/previewcatalog'));
  };
  return (
    <>
      <div className='app-wrapper w-100 landing-page-wrapper catalog-page-wrapper'>
        <div className='consignment-catalog-wrapper'>
          <div className='consignment-catalog-inner-wrapper'>
            <div className='container-fluid'>
              <div className='row'>
                <Breadcrumbs data={headers} />
                <div className='col-lg-12'>
                  <div className='heading-wrapper orders-heading-wrapper'>
                    <div className='heading-inner-wrapper'>
                      <h3 className='yk-main-title'>Add Shoes From Catalog</h3>
                      <div className='search-btn-wrapper'>
                        <div className='row'>
                          <div className='col-lg-4'>
                            <div className='search-bar-wrapper yk-search-bar consignment-dashboard-search table-filter-search'>
                              <SearchComp
                                optionType='change'
                                placeholder='Search'
                                onChangeHandler={onChangeHandler}
                                userInput={userInput}
                              />
                            </div>
                          </div>
                          <div className='col-lg-8'>
                            <div className='consignment-btn-wrapper'>
                              <button
                                className={
                                  view
                                    ? 'grid-bullet-icon-active yk-btnSpacing'
                                    : 'grid-bullet-icon yk-btnSpacing'
                                }
                                onClick={() => setView(true)}
                              />

                              <button
                                className={
                                  view
                                    ? 'list-bullet-icon yk-btnSpacing'
                                    : 'list-bullet-icon-active yk-btnSpacing'
                                }
                                onClick={() => setView(false)}
                              />
                              <div className=''>
                                <Sortings
                                  handleChange={sortHandler}
                                  itemKey='catalog'
                                  defaultSelectedValue={selectedSort}
                                />
                              </div>
                              <div className='filter-btn-wrapper ykch-filter-wrapper-box'>
                                <ClickAwayListener
                                  onClickAway={() => {
                                    setShowFilter(false);
                                  }}>
                                  <div>
                                    <button
                                      className='btn filter-btn '
                                      onClick={() =>
                                        setShowFilter(!showFilter)
                                      }>
                                      <Image
                                        src={filterIcon}
                                        alt='filter-btn-icon'
                                        className='filter-btn-icon img-fluid'
                                      />
                                      <span className='filter-btn-text yk-badge-h15'>
                                        Filter
                                      </span>
                                    </button>
                                    {showFilter && (
                                      <ProductFilters
                                        itemKey='catalog'
                                        onDateChange={onDateChange}
                                        onAgeChange={ageChange}
                                        startDate={selectedStartDate}
                                        endDate={selectedEndDate}
                                        onApplyClick={onClick}
                                        onClearFilters={onClearFilters}
                                        clearDisable={clearDisable}
                                      />
                                    )}
                                  </div>
                                </ClickAwayListener>
                              </div>
                              {/* Side nav */}
                              {showCard && (
                                <div className='inventory-queue-sidenav'>
                                  <span
                                    className='closebtn'
                                    onClick={() => setShowCard(false)}>
                                    <Image
                                      src={modalCloseIcon}
                                      alt='table-close-icon'
                                      className='table-close-icon'
                                    />
                                  </span>
                                  <div className='add-shoes-wrapper'>
                                    <div className='clear-queue-wrapper'>
                                      {queue?.length > 0 && (
                                        <button
                                          className='btn clear-queue'
                                          onClick={clearQueueHandler}>
                                          Clear queue
                                        </button>
                                      )}
                                    </div>

                                    <div
                                      className={`heading-wrapper ${
                                        queue?.length === 0 ? 'text-center' : ''
                                      }`}>
                                      <h3 className='yk-queueHeading mb-0'>
                                        Queue
                                      </h3>
                                      {queue?.length > 0 && (
                                        <>
                                          <p className='queue-count'>
                                            {queue?.length}
                                          </p>
                                          <p className='description'>
                                            {queue?.length === 1
                                              ? 'Product'
                                              : 'Products'}
                                          </p>
                                        </>
                                      )}
                                    </div>

                                    {queue?.length === 0 && (
                                      <div className='empty-wrapper'>
                                        <div className='empty-list'>
                                          <Image
                                            src={AddIcon}
                                            alt=''
                                            className='img-fluid'
                                          />
                                          <p>Add products here</p>
                                        </div>
                                      </div>
                                    )}
                                    <ul className='pending-list list-all-consignment queue-list-items-list'>
                                      {queue.map((item: any, indx: any) => {
                                        return (
                                          <li key={indx}>
                                            <ImageLoader
                                              src={item?.image}
                                              alt='cart-img'
                                              fallbackImg={productImg}
                                              className='img-fluid img-product-logo'
                                            />
                                            <div className='product-details'>
                                              <p className='product-name'>
                                                {item.brand} {` `}
                                                {item?.name}
                                              </p>
                                            </div>
                                          </li>
                                        );
                                      })}
                                    </ul>
                                    <div className='button-action-wrapper mb-4'>
                                      <button
                                        className={`btn btn-place-request ${
                                          queue?.length === 0 ? 'disabled' : ''
                                        }`}
                                        onClick={addToInventoryRedirect}
                                        type='button'>
                                        ADD TO INVENTORY
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              )}
                              {!isShoeCatalog && (
                                <div className='queue-wrapper'>
                                  <button
                                    type='submit'
                                    onClick={() => setShowCard(true)}
                                    className='btn btn-scan btn-queue'>
                                    <Image
                                      src={queueIcon}
                                      alt='qr-scan-icon'
                                      className='Image-fluid'
                                    />
                                    Queue
                                    {queue?.length > 0 && (
                                      <span className='count'>
                                        {queue?.length}
                                      </span>
                                    )}
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {view && (
                <div className='row'>
                  {isLoading && <Loader />}
                  {catlogueData?.length > 0 &&
                    catlogueData?.map((item: any, index: any) => {
                      return (
                        <div
                          className='col-sm-6 col-md-4 col-lg-3 col-xl-3'
                          key={index}>
                          <div className='catalog-cards-wrapper'>
                            <div className='card'>
                              <div className='card-body'>
                                <ImageLoader
                                  src={
                                    item['Catalogue.stockxUrl'] ||
                                    catalogProductImage3
                                  }
                                  alt='table-img'
                                  fallbackImg={catalogProductImage3}
                                  width={100}
                                  height={100}
                                  className='img-fluid img-product-logo'
                                />
                                <h4 className='yk-form-title-text'>
                                  {item['Catalogue.itemName']?.length > 16
                                    ? item['Catalogue.itemName']
                                        .substring(0, 16)
                                        .concat('...')
                                    : item['Catalogue.itemName']}
                                </h4>
                                <p className='yk-para-p2'>
                                  {item['Catalogue.description']?.length > 16
                                    ? item['Catalogue.description']
                                        .substring(0, 16)
                                        .concat('...')
                                    : item['Catalogue.description']}
                                </p>
                                <p className='yk-para-p3'>
                                  {item['Catalogue.style']}
                                </p>
                              </div>
                              <div className='card-footer'>
                                <Button
                                  className='btn-transparent clear-filter-btn yk-badge-h7'
                                  onClick={() => productClickHandler(item)}>
                                  {isShoeCatalog ? 'View' : 'Add'}
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  {!catlogueData?.length && !isLoading && <NoDataFound />}
                </div>
              )}
              {!view && (
                <VirtualTable
                  loading={isLoading}
                  error={error}
                  headers={columns}
                  rowData={catlogueData}
                  offSet={searchOffset}></VirtualTable>
              )}

              {countForPagination > 0 && (
                <div className='center-pagination'>
                  <Pagination
                    lengthOfData={countForPagination}
                    itemsPerPage={limitForQuery}
                    currentOffset={searchOffset}
                    setOffset={setSearchOffset}
                    itemKey={'catalog'}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      {showModal &&
        (isShoeCatalog ? (
          <CatalogDetailsModal
            showModal={showModal}
            handleClose={setShowModal}
            orderDetails={'Inventory'}
            skuId={selectedSku}
            productInfo={productInfo}
            //modalData={modalData}
            //quantity={router.query.quantity}
            //profitRatio={profitRatio}
            //lineItemId={lineItemId}
            //isConsignorFlag={isConsignorFlag}
            isShoeCatalog={isShoeCatalog}
          />
        ) : (
          <AddQueueModal
            showModal={showModal}
            setShowModal={setShowModal}
            selectedProductId={selectedProductId}
            showSuccessPopup={showSuccessPopup}
            setShowSuccessPopup={setShowSuccessPopup}
            selectedSku={selectedSku}
            selectedBrand={selectedBrand}
            selectedImage={selectedImage}
            productInfo={productInfo}
          />
        ))}
      <Notification
        showSuccessPopup={showSuccessPopup}
        handleSnackbarClose={handleSnackbarClose}
        severityType='success'
        message={NOTIFY_MSG.msg}
        className='yk-shoesize-alert-wrapper'
      />
      {isClearQueueAvailable && (
        <ClearQueueModal
          isClearQueueAvailable={isClearQueueAvailable}
          setIsClearQueueAvailable={setIsClearQueueAvailable}
        />
      )}
    </>
  );
};
export default AddShoesCatalog;
