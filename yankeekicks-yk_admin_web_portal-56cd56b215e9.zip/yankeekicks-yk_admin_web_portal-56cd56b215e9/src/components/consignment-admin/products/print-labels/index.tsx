import React, { useState, useEffect, useMemo } from 'react';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import Image from 'next/image';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import Pagination from 'components/common/pagination';
import SearchComp from 'components/common/search';
import NoDataFound from 'components/common/no-data-found';
import {
  getLocationsListForConsignmentReviewPopup,
  getPrintLabelsData,
  getPrintLabelsDataPagination,
  getWeeklyOrders,
  getWeeklyOrdersTotalCount,
} from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import {
  FNS_DATE_FORMAT,
  NOTIFICATION_SOMETHING_WENT_WRONG,
  NOTIFICATION_QR_DOWNLOAD_SUCCESS,
} from 'utils/constants';
import { MenuItem, Select } from '@mui/material';
import { ValidationOnlyAlphaNumbers } from 'utils/validators';
import Sortings from 'components/common/sortings';
import VirtualTable from 'components/common/table';
import { Button } from '@mui/material';
import { COMPLETE_PRINT_LABEL_SUCCESS } from 'components/yk-admin/constants';
import Notification from 'components/common/notification';
import { DISABLE_LOADER, ENABLE_LOADER } from 'actions/loader';
import { useDispatch, useSelector } from 'react-redux';
import { getBasePath } from 'utils/util';
import Breadcrumbs from 'components/common/breadcrumbs';
import ProductFilters from 'components/common/filters/product-filter';
import filterIcon from 'assets/images/filter-icon.png';
import {
  downloadPrintLabels,
  downloadPrintQRBarcodeLabels,
  downloadPrintQRBarcodeLabelsAll,
  getLocationDetails,
} from 'services/consignment';
import { actions } from 'store/reducers/kiosk';
import Selectdropdown from 'components/common/select-dropdown';
import { getAllConsignors } from 'services/consignor';
import DateFilters from 'components/common/filters/date';
import dateIcon from 'assets/images/date-icon.svg';
import ConfirmPopup from 'components/common/confirm-popup';

const PrintLabels = (props: any) => {
  const { showConsginorOrders = false } = props;
  const router = useRouter();
  const dispatch = useDispatch();
  const consignorId: any = showConsginorOrders
    ? router.query.consignorId
    : null;
  const [userInput, setUserInput] = useState('');
  const [selectedConsignor, setSelectedConsignor] = useState('');
  const [selectedStore, setSelectedStore] = useState('');
  const [selectedStoreId, setSelectedStoreId] = useState('');
  const [countForPagination, setCountForPagination] = useState(0);
  const [weeklyOrders, setWeeklyOrders] = useState([]);
  const [locationList, setLocationList] = useState<any>([]);
  const [ordersOffset, setOrdersOffset] = useState(0);
  const [ordersLimit, setOrdersLimit] = useState(10);
  const [selectedSort, setSelectedSort] = useState('createAT:DSC');
  const [showFilters, setShowFilters] = useState(false);
  const [filterInput, setFilterInput] = useState<any>({});
  const [isVisibleMessage, setIsVisibleMessage] = useState<any>(false);
  const [isAllCheckBoxChecked, setIsAllCheckBoxChecked] = useState<any>(false);
  const [enablePrintSelection, setEnablePrintSelection] = useState<any>(false);
  const [severityType, setSeverityType] = useState<any>('');
  const [consignorList, setConsignorList] = useState<any>([]);
  const [notificationMessage, setNotificationMessage] = useState<any>('');
  const [tableLoading, setTableLoading] = useState<any>(false);
  const [startDateRange, setSelectedStartDate] = useState<any>('');
  const [endDateRange, setSelectedEndDate] = useState<any>('');
  const [clearDisable, setClearDisable] = useState(true);
  const [showConfirmModal, setShowConfirmModal] = useState<any>(false);
  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const noOfRecordsDropdownList = [10, 20, 50, 100];
  const breadCrumbHeaders = {
    title: 'My Inventory',
    titleImage: '',
    subTitle: 'Print-labels',

    onClick: () => {
      router?.push(`${getBasePath('inventory')}`);
    },
  };

  const pageName = 'print labels';

  const printLabels: any = getPrintLabelsData(
    userInput,
    selectedSort,
    filterInput,
    ordersOffset,
    ordersLimit,
    selectedConsignor,
    selectedStore,
    startDateRange,
    endDateRange
  );
  const printLabelsPagination: any = getPrintLabelsDataPagination(
    userInput,
    selectedSort,
    filterInput,
    selectedConsignor,
    selectedStore,
    startDateRange,
    endDateRange
  );

  const {
    resultSet: printLabelsSet,
    isLoading: ordersIsLoading,
    error: ordersError,
  }: any = useCubeQuery(printLabels, {
    skip: !selectedConsignor && !selectedStore,
  });

  const {
    resultSet: printLabelsPaginationSet,
    isLoading: printtLabelPaginationLoading,
    error: printLabelsPaginationError,
  }: any = useCubeQuery(printLabelsPagination, {
    skip: !selectedConsignor && !selectedStore,
  });

  const tableInit = () => {
    const data = printLabelsSet?.loadResponses[0]?.data;
    //const dataCount = printLabelsPaginationSet?.loadResponses[0]?.data;
    setCountForPagination(
      printLabelsPaginationSet?.loadResponses[0]?.data?.[0]?.[
        'printLabel.count'
      ] || 0
    );
    if (data) {
      const checkBoxAdded = addCheckPropertyToData(data, false);
      setWeeklyOrders(addCheckPropertyToData(data, false));
      setTableLoading(false);
    } else {
      setWeeklyOrders([]);
      setTableLoading(false);
    }
  };

  useEffect(() => {
    tableInit();
  }, [printLabelsSet, printLabelsPaginationSet]);

  const addCheckPropertyToData = (
    tempData: any,
    checkedStatus: boolean,
    dataItem?: any
  ) => {
    if (!!dataItem) {
      return tempData.map((lineItem: any) => {
        if (lineItem['printLabel.Barcode'] == dataItem['printLabel.Barcode'])
          return {
            ...lineItem,
            isChecked: checkedStatus,
            checkboxDisabled: false,
          };
        else return lineItem;
      });
    } else
      return tempData.map((lineItem: any) => {
        return {
          ...lineItem,
          isChecked: checkedStatus,
          checkboxDisabled: false,
        };
      });
  };

  const userInputChangeHandler = (event: any) => {
    setUserInput(event.target.value);
    setOrdersOffset(0);
  };
  const handleCheckBoxChecked = (e: any, data: any, tableData: any) => {
    const updatedData = addCheckPropertyToData(
      tableData,
      e?.target?.checked,
      data
    );
    setWeeklyOrders(updatedData);
    if (e?.target?.checked) {
      setEnablePrintSelection(e?.target?.checked);
    } else {
      setEnablePrintSelection(
        updatedData?.filter((item: any) => item.isChecked == true).length
          ? true
          : false
      );
    }
  };
  const handleCheckAll = (event: any, tableData: any) => {
    setIsAllCheckBoxChecked(event?.target?.checked);
    const updatedData = addCheckPropertyToData(
      tableData,
      event?.target?.checked
    );
    setWeeklyOrders(updatedData);
    setEnablePrintSelection(event?.target?.checked);
  };
  const fetchLocationDetails = async () => {
    try {
      let getLocations = await getLocationDetails();
      let locationListArray = Object.values(getLocations?.data);
      const locationListData = locationListArray.flatMap(
        (location: any) => location?.locations
      );
      setLocationList(locationListData);
    } catch (e: any) {
      setLocationList([]);
    }
  };

  const fetchconsignorDetails = async () => {
    try {
      let getConsignorList = await getAllConsignors();
      let consignorListArray = Object.values(getConsignorList?.data);
      setConsignorList(Object.values(consignorListArray));
    } catch (e: any) {
      setConsignorList([]);
    }
  };
  const handelLimitChange = (e: any) => {
    setOrdersOffset(0);
    setOrdersLimit(e.target.value);
  };

  useEffect(() => {
    fetchLocationDetails();
    fetchconsignorDetails();
  }, []);

  const columns = useMemo(
    () => [
      {
        type: 'checkbox',
        title: '',
        checked: 'isChecked',
        value: 'printLabel.Barcode',
        isDisabled: 'checkboxDisabled',
        onChange: (e: any, data: any, tableData: any) => {
          handleCheckBoxChecked(e, data, tableData);
        },
        checkAll: (e: any, tableData: any) => handleCheckAll(e, tableData),
        isAllChecked: isAllCheckBoxChecked,
      },
      {
        title: 'Bar code',
        value: 'printLabel.Barcode',
      },
      {
        title: 'SKU',
        value: 'printLabel.Sku',
      },
      {
        title: 'Picture',
        value: 'printLabel.imageUrl',
        type: 'image',
      },
      {
        title: 'Brand',
        value: 'printLabel.brand',
      },
      {
        title: 'Name',
        value: 'printLabel.itemName',
      },
      {
        title: 'Date Added',
        type: 'date',
        format: FNS_DATE_FORMAT,
        value: 'printLabel.createdAt',
      },
      {
        title: 'Consignor',
        value: 'printLabel.Consignor',
      },
      {
        title: 'Location',
        value: 'printLabel.Location',
      },
      {
        title: 'Size',
        value: 'printLabel.Size',
      },
      {
        title: 'Price',
        value: 'printLabel.retailPrice_D',
        prefix: '$',
        methodToApply: 'toFix',
      },

      {
        title: 'Status',
        type: 'statusOrder',
        value: 'printLabel.status',
        success: 'Active',
        danger: 'Pending',
        greensuccess: 'Sold',
      },
    ],
    []
  );

  const sortHandler = (event: any) => {
    setOrdersOffset(0);
    setSelectedSort(event.target.value);
  };

  useEffect(() => {
    if (filterTypes.brand.length !== 0 || filterTypes.size.length !== 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  }, [filterTypes]);

  const onApplyClick = () => {
    const filterPayload = {
      brand: filterTypes.brand,
      size: filterTypes.size,
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setOrdersOffset(0);
    setShowFilters(false);
  };

  const onClearFilters = () => {
    setOrdersOffset(0);
    setShowFilters(false);
    dispatch(actions.clearAllFilters({}));
    setFilterInput({});
    setShowFilters(false);
    setClearDisable(true);
  };

  const handleLocationChange = (e: any) => {
    setOrdersOffset(0);
    setSelectedStore(e.target.value.name);
    setSelectedStoreId(e.target.value.id);
    setTableLoading(true);
  };

  const handleConsignorChange = (e: any) => {
    setOrdersOffset(0);
    setSelectedConsignor(e.target.value.id);
  };

  const onDateChange = (dates: any) => {
    const [start, end] = dates;
    setOrdersOffset(0);
    setSelectedStartDate(start);
    setSelectedEndDate(end);
  };

  const handlePrintSelection = async () => {
    try {
      dispatch({ type: ENABLE_LOADER });
      const barcodes = weeklyOrders
        .filter((item: any) => item.isChecked == true)
        .map((item: any) => {
          return item['printLabel.Barcode'];
        });
      const payload = {
        barcodes: barcodes,
        consignor_id: selectedConsignor,
        end_date: endDateRange ? startDateRange.toISOString() : '',
        start_date: startDateRange ? startDateRange.toISOString() : '',
        location_id: selectedStoreId,
      };
      const handleAction = await downloadPrintQRBarcodeLabels(payload);
      if (handleAction?.status == 200) {
        dispatch({ type: DISABLE_LOADER });
      }
      setIsVisibleMessage(true);
      setSeverityType('success');
      setNotificationMessage(NOTIFICATION_QR_DOWNLOAD_SUCCESS);
    } catch (e: any) {
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setNotificationMessage(
        e?.response?.data?.message || NOTIFICATION_SOMETHING_WENT_WRONG
      );
      dispatch({ type: DISABLE_LOADER });
    }
  };
  const handlePrintAll = async () => {
    try {
      setShowConfirmModal(false);
      dispatch({ type: ENABLE_LOADER });
      /*         const barcodes = weeklyOrders
          .filter((item: any) => item.isChecked == true)
          .map((item: any) => {
            return item['printLabel.Barcode'];
          }); */
      const payload = {
        brands: filterInput?.brand,
        location_id: selectedStoreId || undefined,
        consignor_id: selectedConsignor || undefined,
        end_date: endDateRange ? startDateRange.toISOString() : '',
        start_date: startDateRange ? startDateRange.toISOString() : '',
        search_filter: userInput || undefined,
        sizes: filterInput?.size,
        sorted_by: selectedSort || undefined,
      };
      const handleAction = await downloadPrintQRBarcodeLabelsAll(payload);
      if (handleAction?.status == 200) {
        dispatch({ type: DISABLE_LOADER });
      }
      setIsVisibleMessage(true);
      setSeverityType('success');
      setNotificationMessage(NOTIFICATION_QR_DOWNLOAD_SUCCESS);
    } catch (e: any) {
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setNotificationMessage(
        e?.response?.data?.message || NOTIFICATION_SOMETHING_WENT_WRONG
      );
      dispatch({ type: DISABLE_LOADER });
    }
  };

  // eslint-disable-next-line react/display-name
  const CustomInput = React.forwardRef(
    ({ value, onClick, onChange }: any, ref: any) => (
      <div className='yk-datePickerBtn' onClick={onClick}>
        {!value && 'Date Added'}
        <span>
          <input
            value={value}
            className='section-readonly-input p-0'
            onChange={onChange}
            ref={ref}></input>
          <Image
            src={dateIcon}
            alt='date-icon'
            className='dateBtnIcon img-fluid'
          />
        </span>
      </div>
    )
  );

  return (
    <div className='app-wrapper w-100 orders-page-wrapper yk-print-label-page-wrapper'>
      <div className='orders-page-inner-wrapper'>
        <div className='container-fluid'>
          <div className='row'>
            <Breadcrumbs data={breadCrumbHeaders} />
            <div className='col-lg-12 col-md-12 col-sm-12'>
              <div className='yk-printLabelsHeadingWrapper'>
                <h2 className='heading printLabelsHeading'>{pageName}</h2>
                <div className='yk-searchBoxBtnWrapper'>
                  <div className='row'>
                    <div className='col-xl-4 col-lg-12 col-md-12 col-sm-12 col-12'>
                      <div className='YKCH-searchingData mb-0'>
                        <SearchComp
                          onChangeHandler={userInputChangeHandler}
                          userInput={userInput}
                          optionType='no suggestions'
                          placeholder='Search'
                        />
                      </div>
                    </div>
                    <div className='col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12'>
                      <div className='yk-selectBtnWrapper'>
                        <div className='select selectStore'>
                          <Selectdropdown
                            selectType={'Select Store'}
                            dropdownList={locationList}
                            handleChange={handleLocationChange}
                          />
                        </div>
                        <div className='select selectConsignor yk-selectConsignorBtn'>
                          <Selectdropdown
                            selectType={'Select Consignor'}
                            dropdownList={consignorList}
                            handleChange={handleConsignorChange}
                          />
                        </div>
                        <DateFilters
                          onChange={onDateChange}
                          startDate={startDateRange}
                          endDate={endDateRange}
                          inline={false}
                          customInput={<CustomInput />}
                        />
                        <button
                          className='yk-printLabelsBtn'
                          onClick={() => handlePrintSelection()}
                          disabled={!enablePrintSelection}>
                          Print Selection
                        </button>
                        {/*  {enablePrintSelection && (
                          <button
                            className='yk-printLabelsBtn'
                            onClick={() => handlePrintSelection()}
                            disabled={!enablePrintSelection}>
                            Print Selection
                          </button>
                        )}
                        {!enablePrintSelection && (
                          <button
                            className='yk-printAllBtn'
                            // onClick={() => handlePrintAll()}
                            onClick={() => setShowConfirmModal(true)}
                            disabled={
                              !(
                                countForPagination > 0 &&
                                weeklyOrders?.length > 0
                              )
                            }>
                            Print All
                          </button>
                        )} */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className='yk-printLabelHR'>
              <hr className='yk-hr' />
            </div>
            <div className='yk-showResultsBtnWrapper'>
              <div className='row d-flex align-items-center'>
                <div className='col-xl-4 col-lg-12 col-md-12 col-sm-12 col-12'>
                  <h2 className='yk-searchResultsHeading mb-0'>
                    {countForPagination > 0 && (
                      <>
                        Showing{' '}
                        {ordersLimit > countForPagination
                          ? countForPagination
                          : ordersLimit}{' '}
                        of {countForPagination} Results
                      </>
                    )}
                    &nbsp;
                  </h2>
                </div>
                <div className='col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12'>
                  <div className='yk-printLabelBtnWrapper yk-displayFlexEnd'>
                    <h2 className='yk-searchResultsHeading mb-0 me-3'>
                      No. of records
                    </h2>
                    <div className='yk-noBtnWrapper me-3 '>
                      <Selectdropdown
                        dropdownList={noOfRecordsDropdownList}
                        handleChange={handelLimitChange}
                        defaultSelectedValue={ordersLimit}
                      />
                    </div>
                    <div className='me-3 yk-sortBtnWrapper'>
                      <Sortings
                        handleChange={sortHandler}
                        defaultSelectedValue={selectedSort}
                        itemKey='printQRLabels'
                      />
                    </div>
                    <ClickAwayListener
                      onClickAway={() => {
                        setShowFilters(false);
                      }}>
                      <div className='YKCH-filterBTNWrapp'>
                        <button
                          className='btn filter-btn me-0'
                          onClick={() => setShowFilters(!showFilters)}>
                          <Image
                            src={filterIcon}
                            alt='filter-btn-icon'
                            className='filter-btn-icon img-fluid'
                          />
                          <span className='filter-btn-text yk-badge-h15'>
                            Filter
                          </span>
                        </button>

                        {showFilters && (
                          <ProductFilters
                            itemKey='printLabels'
                            onClearFilters={onClearFilters}
                            onApplyClick={onApplyClick}
                            clearDisable={clearDisable}
                          />
                        )}
                      </div>
                    </ClickAwayListener>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className='yk-printLabelsTable'>
            {selectedStore || selectedConsignor ? (
              <>
                <VirtualTable
                  loading={ordersIsLoading || tableLoading ? true : false}
                  error={ordersError}
                  headers={columns}
                  rowData={weeklyOrders}
                />
                {countForPagination > 0 && weeklyOrders?.length > 0 && (
                  <div className='center-pagination'>
                    <Pagination
                      lengthOfData={countForPagination}
                      itemsPerPage={ordersLimit}
                      currentOffset={ordersOffset}
                      setOffset={setOrdersOffset}
                    />
                  </div>
                )}
              </>
            ) : (
              <div className='yk-printLabelNoDataWrapper'>
                <NoDataFound searchData />
              </div>
            )}
          </div>
        </div>

        <Notification
          showSuccessPopup={isVisibleMessage}
          handleSnackbarClose={() => setIsVisibleMessage(false)}
          severityType={severityType}
          message={notificationMessage}
          className='yk-shoesize-alert-wrapper'
        />
        <ConfirmPopup
          showPopup={showConfirmModal}
          handleClose={(e: any) => setShowConfirmModal(false)}
          title='Print All Labels?'
          message='Are you sure you want to print all labels?'
          handleSave={handlePrintAll}
        />
      </div>
    </div>
  );
};
export default PrintLabels;
