import React, { useState, useEffect } from 'react';
import Notification from 'components/common/notification';
import Breadcrumbs from 'components/common/breadcrumbs';
import router from 'next/router';
import { getBasePath } from 'utils/util';
import Image from 'next/image';
import broseIcon from 'assets/images/browse-icon.svg';
import productImg from 'assets/images/product-1.png';
import checkmarkIcon from 'assets/images/green-check-icon.svg';
import { FormControl, MenuItem, Select } from '@mui/material';

const CreateNewProduct = (props: any) => {
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [message, setMessage] = useState<string>('');
  const [severityType, setSeverityType] = useState<string>('');
  const breadCrumbHeaders = {
    title: 'My Inventory',
    subTitle: 'Create New Product',

    onClick: () => {
      router?.push(`${getBasePath('inventory')}`);
    },
  };
  return (
    <div className='yk-create-new-product-page-wrapper'>
      <div className='container-fluid'>
        <Notification
          showSuccessPopup={isVisibleMessage}
          handleSnackbarClose={() => setIsVisibleMessage(false)}
          severityType={severityType}
          message={message}
          className='yk-shoesize-alert-wrapper YKCH-TostifyMsg'
        />
        <div className='row'>
          {/*  <Breadcrumbs data={breadCrumbHeaders} /> */}
          <div className='col-lg-12 col-md-12 col-sm-12'>
            <div className='orders-heading-wrapper'>
              <h2 className='heading'>Create New Product</h2>
              <p className='sub-haeding mb-0'>
                Please fill the relevant information in the sheet and upload
                images.
              </p>
            </div>
          </div>
        </div>
        <div className='yk-card-wrapper'>
          <div className='row'>
            <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12'>
              <div className='yk-formArea'>
                <label className='yk-form-label'>Item</label>
                <div className='yk-selectInputWrapper'>
                  <FormControl sx={{ m: 1, minWidth: '100%' }}>
                    <Select className='yk-input-field' id='report' defaultValue>
                      <MenuItem value={'asc'} disabled>
                        Select Item
                      </MenuItem>
                      <MenuItem className='YKCH-dataInfinite'></MenuItem>
                    </Select>
                  </FormControl>
                </div>
              </div>
            </div>
            <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12'>
              <div className='yk-formArea'>
                <label className='yk-form-label'>Category</label>
                <div className='yk-selectInputWrapper'>
                  <FormControl sx={{ m: 1, minWidth: '100%' }}>
                    <Select
                      className='yk-input-field'
                      defaultValue='Select Category'>
                      <MenuItem value={'asc'} disabled>
                        Select Category
                      </MenuItem>
                      <MenuItem className='YKCH-dataInfinite'></MenuItem>
                    </Select>
                  </FormControl>
                </div>
              </div>
            </div>
          </div>
          <div className='row'>
            <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12'>
              <div className='yk-formArea'>
                <label className='yk-form-label'>Brand</label>
                <input
                  type='text'
                  placeholder='Enter Brand'
                  className='form-control yk-input-field'
                />
              </div>
            </div>
            <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12'>
              <div className='yk-formArea'>
                <label className='yk-form-label'>Model</label>
                <input
                  type='text'
                  placeholder='Enter Model'
                  className='form-control yk-input-field'
                />
              </div>
            </div>
          </div>
          <div className='row'>
            <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
              <div className='yk-formArea'>
                <label className='yk-form-label'>Product Title</label>
                <input
                  type='text'
                  placeholder='Enter Product Title'
                  className='form-control yk-input-field'
                />
              </div>
            </div>
          </div>
          <div className='row'>
            <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12'>
              <div className='yk-formArea'>
                <label className='yk-form-label'>SKU</label>
                <input
                  type='text'
                  placeholder='Enter SKU'
                  className='form-control yk-input-field'
                />
              </div>
            </div>
            <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12'>
              <div className='yk-formArea'>
                <label className='yk-form-label'>Size Type</label>
                <input
                  type='text'
                  placeholder='Enter Size Type'
                  className='form-control yk-input-field'
                />
              </div>
            </div>
          </div>
          <div className='row'>
            <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12'>
              <div className='yk-formArea'>
                <label className='yk-form-label'>Colorway</label>
                <input
                  type='text'
                  placeholder='Enter Colorway'
                  className='form-control yk-input-field'
                />
              </div>
            </div>
          </div>
          <div className='row'>
            <div className='col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12'>
              <div className='yk-formArea'>
                <label className='yk-form-label'>Option 1</label>
                <input
                  type='text'
                  placeholder='Size'
                  className='form-control yk-input-field'
                />
              </div>
            </div>
            <div className='col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12'>
              <div className='yk-formArea'>
                <label className='yk-form-label'>Option 2</label>
                <input
                  type='text'
                  placeholder='Condition'
                  className='form-control yk-input-field'
                />
              </div>
            </div>
            <div className='col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12'>
              <div className='yk-formArea'>
                <label className='yk-form-label'>Option 3</label>
                <input
                  type='text'
                  placeholder='NA'
                  className='form-control yk-input-field'
                />
              </div>
            </div>
          </div>
          <div className='yk-product-details-wrapper'>
            <div className='row'>
              <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                <div className='yk-formArea'>
                  <label className='yk-form-label'>Product Image (Max 5)</label>
                  <div className='yk-browseInputField'>
                    <Image
                      src={broseIcon}
                      alt=''
                      className='browse-icon img-fluid'
                    />
                    <p className='browseTitle yk-badge-h16'>
                      Browse Files to Upload
                    </p>
                    <button
                      type='button'
                      className='btn yk-btn-primary-sm browse-btn'>
                      Upload
                    </button>
                  </div>
                  {/* Kept below commented code for future use */}
                  {/* <div className='yk-browseInputField yk-ImgUploadWrapper'>
                  <div className='yk-ImgDetailsWrapper dFlexAlignCenter'>
                    <div className='yk-ImgInfo'>
                      <div className='productImgWrapper'>
                        <Image
                          src={productImg}
                          alt=''
                          className='productImg img-fluid'
                        />
                        <Image
                          src={productImg}
                          alt=''
                          className='productImg img-fluid'
                        />
                        <Image
                          src={productImg}
                          alt=''
                          className='productImg img-fluid'
                        />
                      </div>
                      <p className='yk-uploadMsg mb-0'>
                        <Image
                          src={checkmarkIcon}
                          alt=''
                          className='checkIcon img-fluid'
                        />
                        3 Product Image Uploaded!
                      </p>
                    </div>
                    <button type='button' className='btn yk-redBorderBtn'>
                      Upload More
                    </button>
                  </div>
                </div> */}
                </div>
              </div>
            </div>
          </div>
          <div className='yk-formBtnWrapper d-flexSpaceBetween'>
            <button type='button' className='btn modal-btn-cancel'>
              Cancel
            </button>
            <button type='button' className='btn yk-primaryBtn'>
              Add
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default CreateNewProduct;
