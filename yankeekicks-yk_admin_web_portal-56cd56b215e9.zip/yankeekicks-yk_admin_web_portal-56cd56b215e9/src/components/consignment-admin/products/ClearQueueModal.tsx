import React  from 'react';
import Modal from '@mui/material/Modal';
import { useDispatch } from 'react-redux';
import { actions } from 'store/reducers/consignment';

const ClearQueueModal = ({
  isClearQueueAvailable,
  setIsClearQueueAvailable,
}: any) => {
  const dispatch = useDispatch();
  const cancelHandler = () => {
    setIsClearQueueAvailable(false);
  };
  const confirmHandler = () => {
    dispatch(actions.setQueue([]));
    setIsClearQueueAvailable(false);
  };
  return (
    <>
      <Modal
        open={isClearQueueAvailable}
        className='yk-clear-queue-modal-wrapper'
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'
      >
        <div className='app-wrapper yk-clear-queue-modal-overlay-wrapper w-100'>
          <div className='yk-modal-body'>
            <div className='yk-modal-title'>Clear The Queue</div>
            <div className='yk-modal-content'>
              Are you sure you want to remove these shoes from the queue?
            </div>
            <div className='d-flex justify-content-between'>
              <button
                className='btn-transparent clear-filter-btn yk-badge-h7'
                type='button'
                onClick={cancelHandler}
              >
                Cancel
              </button>
              <button
                className='btn yk-btn-primary yk-modal-button mb-5'
                type='button'
                onClick={confirmHandler}
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default ClearQueueModal;
