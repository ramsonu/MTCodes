import React, { useEffect, useState } from 'react';
import { Checkbox, InputAdornment, MenuItem, Select } from '@mui/material';
import { getNotification } from 'services/shared';
import { putUpdateNotifications } from 'services/notifications';
import {
  NOTIFICATION_FLAG_NOT_SUCCESS,
  NOTIFICATION_FLAG_SUCCESS,
} from 'utils/constants';
import isEqual from 'lodash.isequal';

const Notifications = (props: any) => {
  const {
    setIsVisibleMessage = false,
    setSeverityType = '',
    setMessage = '',
    userDetails = '',
  } = props;
  const inAppDisabled = true;
  useEffect(() => {
    getNotificationByUser();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const [notificationFlag, setNotificationFlag] = useState({
    onlineSaleFromInventoryEmailFlag: false,
    onlineSaleFromInventoryInAppFlag: false,
    storeSaleFromInventoryEmailFlag: false,
    storeSaleFromInventoryInAppFlag: false,
    consignmentSaleEmailFlag: false,
    consignmentSaleInAppFlag: false,
    consignmentStatusInAppFlag: false,
    consignerRequestEmailFlag: false,
    consignerRequestInAppFlag: false,
    consignmentRequestEmailFlag: false,
    consignmentRequestInAppFlag: false,
  });
  const [notificationFlagOnLoad, setNotificationFlagOnLoad] = useState<any>({
    onlineSaleFromInventoryEmailFlag: false,
    onlineSaleFromInventoryInAppFlag: false,
    storeSaleFromInventoryEmailFlag: false,
    storeSaleFromInventoryInAppFlag: false,
    consignmentSaleEmailFlag: false,
    consignmentSaleInAppFlag: false,
    consignmentStatusInAppFlag: false,
    consignerRequestEmailFlag: false,
    consignerRequestInAppFlag: false,
    consignmentRequestEmailFlag: false,
    consignmentRequestInAppFlag: false,
  });
  const [isDisable, setUpdateDisable] = useState(true);

  useEffect(() => {
    const oldValue = Object.values(notificationFlag);
    const newValue = Object.values(notificationFlagOnLoad);
    const isModify = isEqual(oldValue, newValue);
    if (isModify) setUpdateDisable(false);
    else setUpdateDisable(true);
  }, [notificationFlag]); // eslint-disable-line react-hooks/exhaustive-deps

  const onNotificationChange = (event: any) => {
    setNotificationFlag({
      ...notificationFlag,
      [event?.target?.name]: event?.target?.checked,
    });
  };

  const updateNotifications = async () => {
    let result: any = [];

    try {
      result = await putUpdateNotifications(
        notificationFlag,
        userDetails?.username
      );
      if (result?.status) {
        setIsVisibleMessage(true);
        setSeverityType('success');
        getNotificationByUser();
        setMessage(NOTIFICATION_FLAG_SUCCESS);
      } else {
        setIsVisibleMessage(true);
        setSeverityType('warn');
        getNotificationByUser();
        setMessage(NOTIFICATION_FLAG_NOT_SUCCESS);
      }
    } catch (e: any) {
      setIsVisibleMessage(true);
      setSeverityType('warn');
      setMessage(NOTIFICATION_FLAG_NOT_SUCCESS);
    }
  };

  const getNotificationByUser = async () => {
    let result: any = [];
    try {
      result = await getNotification(userDetails?.username);
      if (result?.status === 201 || result?.status === 200) {
        const obj: any = {
          onlineSaleFromInventoryEmailFlag:
            result?.data?.onlineSaleFromInventoryEmailFlag,
          onlineSaleFromInventoryInAppFlag:
            result?.data?.onlineSaleFromInventoryInAppFlag,
          storeSaleFromInventoryEmailFlag:
            result?.data?.storeSaleFromInventoryEmailFlag,
          storeSaleFromInventoryInAppFlag:
            result?.data?.storeSaleFromInventoryInAppFlag,
          consignmentSaleEmailFlag: result?.data?.consignmentSaleEmailFlag,
          consignmentSaleInAppFlag: result?.data?.consignmentSaleInAppFlag,
          consignmentStatusInAppFlag: result?.data?.consignmentStatusInAppFlag,
          consignerRequestEmailFlag: result?.data?.consignerRequestEmailFlag,
          consignerRequestInAppFlag: result?.data?.consignerRequestInAppFlag,
          consignmentRequestEmailFlag:
            result?.data?.consignmentRequestEmailFlag,
          consignmentRequestInAppFlag:
            result?.data?.consignmentRequestInAppFlag,
        };
        setNotificationFlag(obj);
        setNotificationFlagOnLoad(obj);
      }
    } catch (e: any) {
      console.log('catch error', e);
    }
  };
  return (
    <>
      <div className='form-wrapper'>
        <div className='yk-form-title-text heading-wrapper'>Notifications</div>
        <h3 className='yk-para-p5'>New Consignor Request</h3>
        <div className='row'>
          <div className='col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12'>
            <h3 className='yk-para-p6 d-flex align-items-center'>
              <Checkbox
                className='filter-sidebar-checkbox'
                checked={notificationFlag?.consignerRequestEmailFlag}
                name='consignerRequestEmailFlag'
                onChange={(event: any) => onNotificationChange(event)}
              />
              Email
            </h3>
          </div>
          <div className='col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12'>
            {!inAppDisabled && (
              <h3 className='yk-para-p6'>
                <Checkbox
                  className='filter-sidebar-checkbox'
                  checked={notificationFlag?.consignerRequestInAppFlag}
                  name='consignerRequestInAppFlag'
                  onChange={(event: any) => onNotificationChange(event)}
                />
                In App
              </h3>
            )}
          </div>
        </div>
        <h3 className='yk-para-p5'>New Shipment Request</h3>
        <div className='row'>
          <div className='col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12'>
            <h3 className='yk-para-p6'>
              <Checkbox
                className='filter-sidebar-checkbox'
                checked={notificationFlag?.consignmentRequestEmailFlag}
                name='consignmentRequestEmailFlag'
                onChange={(event: any) => onNotificationChange(event)}
              />
              Email
            </h3>
          </div>
          <div className='col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12'>
            {!inAppDisabled && (
              <h3 className='yk-para-p6'>
                <Checkbox
                  className='filter-sidebar-checkbox'
                  checked={notificationFlag?.consignmentRequestInAppFlag}
                  name='consignmentRequestInAppFlag'
                  onChange={(event: any) => onNotificationChange(event)}
                />
                In App
              </h3>
            )}
          </div>
        </div>
        <h3 className='yk-para-p5'>Online Sale From Inventory</h3>
        <div className='row'>
          <div className='col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12'>
            <h3 className='yk-para-p6'>
              <Checkbox
                className='filter-sidebar-checkbox'
                checked={notificationFlag?.onlineSaleFromInventoryEmailFlag}
                name='onlineSaleFromInventoryEmailFlag'
                onChange={(event: any) => onNotificationChange(event)}
              />
              Email
            </h3>
          </div>
          <div className='col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12'>
            {!inAppDisabled && (
              <h3 className='yk-para-p6'>
                <Checkbox
                  className='filter-sidebar-checkbox'
                  checked={notificationFlag?.onlineSaleFromInventoryInAppFlag}
                  name='onlineSaleFromInventoryInAppFlag'
                  onChange={(event: any) => onNotificationChange(event)}
                />
                In App
              </h3>
            )}
          </div>
        </div>
        <h3 className='yk-para-p5'>Store Sale From Inventory</h3>
        <div className='row'>
          <div className='col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12'>
            <h3 className='yk-para-p6'>
              <Checkbox
                className='filter-sidebar-checkbox'
                checked={notificationFlag?.storeSaleFromInventoryEmailFlag}
                name='storeSaleFromInventoryEmailFlag'
                onChange={(event: any) => onNotificationChange(event)}
              />
              Email
            </h3>
          </div>
          <div className='col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12'>
            {!inAppDisabled && (
              <h3 className='yk-para-p6'>
                <Checkbox
                  className='filter-sidebar-checkbox'
                  checked={notificationFlag?.storeSaleFromInventoryInAppFlag}
                  name='storeSaleFromInventoryInAppFlag'
                  onChange={(event: any) => onNotificationChange(event)}
                />
                In App
              </h3>
            )}
          </div>
        </div>
      </div>

      <div className='action-items-wrapper'>
        {isDisable && (
          <button
            className='btn yk-btn-danger-sm'
            onClick={updateNotifications}
            type='button'>
            Save Changes
          </button>
        )}
      </div>
    </>
  );
};
export default Notifications;
