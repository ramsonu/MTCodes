import React, { useState } from 'react';
import type { NextPage } from 'next';
import Image from 'next/image';
import dummyUserImg from 'assets/images/user.svg';
import bannerImg from 'assets/images/request-details-banner.png';
import Notification from 'components/common/notification';
import Notifications from './notifications';

const SettingsPage: NextPage = () => {
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [message, setMessage] = useState<string>('');
  const [severityType, setSeverityType] = useState<string>('');

  const userDetails = JSON.parse(localStorage.getItem('UserDetails') || '{}');

  return (
    <>
      <div className='app-wrapper w-100 settings-page-wrapper profile-details-page-wrapper'>
        <div className='page-inner-wrapper'>
          <div className='container-fluid'>
            <div className='user-area-wrapper'>
              <div className='request-details-banner-wrapper setting-details-banner'>
                <div className='yk-request-banner-wrapper'>
                  <Image
                    src={bannerImg}
                    alt=''
                    className='w-100 yk-request-banner img-fluid'
                  />
                </div>

                <div className='profile-info-details'>
                  <div className='row g-0'>
                    <div className='YKCH-newSettingERA d-flex justify-content-start align-items-center'>
                      <div className='user-img-wrapper'>
                        <Image
                          src={dummyUserImg}
                          alt=''
                          className='yk-user-img img-fluid'
                        />
                      </div>

                      <div className='profile-heading-wrapper ykch-leftAlignings'>
                        <h3 className='profile-name'>{userDetails?.name}</h3>
                        <p className='profile-request-text '>
                          {userDetails?.username}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='user-area-inner-wrapper'>
                <div className='yk-profile-form'>
                  <div className='form-wrapper ykch-formGroupWraper'>
                    <Notifications
                      setIsVisibleMessage={setIsVisibleMessage}
                      setMessage={setMessage}
                      setSeverityType={setSeverityType}
                      userDetails={userDetails}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Notification
        showSuccessPopup={isVisibleMessage}
        handleSnackbarClose={() => setIsVisibleMessage(false)}
        severityType={severityType}
        message={message}
        className='yk-shoesize-alert-wrapper'
      />
    </>
  );
};
export default SettingsPage;
