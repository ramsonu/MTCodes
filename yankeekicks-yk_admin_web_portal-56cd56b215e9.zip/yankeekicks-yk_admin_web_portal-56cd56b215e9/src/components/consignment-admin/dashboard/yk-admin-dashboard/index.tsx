import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { format } from 'date-fns';
import BestSellers from './best-sellers';
import YKAdminKPIs from './yk-admin-kpis';
import WeeklySales from '../common/weekly-sales';
import BestPerformerSA from './best-performer-sa';
import PendingTasks from '../common/pending-tasks';
import TopConsignors from '../common/top-consignors';
import UserRegistrations from './user-registrations';
import DateRangeFilter from '../common/date-range-filter';
import { FNS_DATE_DMY_FORMAT, KPI_DATE_FORMAT } from 'utils/constants';

const YKAdminDashboard = () => {
  const locationId: any = localStorage?.getItem('selectedLocIds') || '';

  let date = new Date(),
    y = date.getFullYear(),
    m = date.getMonth();
  let firstDay = new Date(y, m, 1);
  // let lastDay = new Date(y, m + 1, 0);

  const todaysDate = format(date, KPI_DATE_FORMAT);
  const monthStartDate = format(firstDay, KPI_DATE_FORMAT) || '';
  // const monthEndDate = format(lastDay, KPI_DATE_FORMAT) || '';

  const { selected, selectedLocation } = useSelector(
    (state: any) => state.shared
  );

  const [locId, setLocId] = useState<any>(''); // It can store one location or multiple location , separated
  const [userInputDate, setUserInputDate] = useState<any>({
    startDate: firstDay, // by default this months first day
    endDate: date, // be default todays date
  });
  // * Few shouldFetch state has been kept outside as it is going to affect by date range filter
  const [shouldFetchKPIWithOrderDate, setShouldFetchKPIWithOrderDate] =
    useState<boolean>(false);
  const [shouldFetchKPIWithCreationDate, setShouldFetchKPIWithCreationDate] =
    useState<boolean>(false);
  const [shouldFetchBestSellers, setShouldFetchBestSellers] =
    useState<boolean>(false);
  const [shouldFetchTopConsignorSales, setShouldFetchTopConsignorSales] =
    useState<boolean>(false);
  const [shouldFetchTopPerformerSA, setShouldFetchTopPerformerSA] =
    useState<boolean>(false);
  const [shouldFetchUserRegistration, setShouldFetchUserRegistration] =
    useState<boolean>(false);
  const [shouldFetchPendingTasks, setShouldFetchPendingTasks] =
    useState<boolean>(false);

  // * Below commented code is for reference. Do not remove it.
  // const locationId: any = localStorage?.getItem('storeLocationId') || '';
  // const totalLocationIds: any = localStorage?.getItem('totalLocationIds') || '';
  // useEffect(() => {
  //   if (isConsignmentAdmin()) {
  //     if (locationId) {
  //       setLocId(locationId);
  //     } else {
  //       setLocId('');
  //     }
  //   } else {
  //     if (selectedLocation === ALL_LOCATIONS) {
  //       setLocId(totalLocationIds || '');
  //     } else {
  //       setLocId(locationId || '');
  //     }
  //   }
  // }, [selected, selectedLocation]);

  useEffect(() => {
    if (locationId) {
      setLocId(locationId);
    } else {
      setLocId('');
    }
  }, [selected, selectedLocation]);

  const fromDate: any = userInputDate?.startDate
    ? format(userInputDate?.startDate, FNS_DATE_DMY_FORMAT)
    : '';
  const toDate: any = userInputDate?.endDate
    ? format(userInputDate?.endDate, FNS_DATE_DMY_FORMAT)
    : '';

  return (
    <div className='consignment-admin-dashboard w-100 yk-super-admin-dashboard-wrapper'>
      <div className='container-fluid'>
        <div className='row yk-dashboardTitleWrapper'>
          <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
            <div className='heading-wrapper orders-heading-wrapper'>
              <h2 className='heading'>Dashboard</h2>
              <div className='yk-dateInfoWrapper dFlexCenter'>
                <div className='invoice-number-text'>
                  {fromDate && toDate ? `${fromDate} - ${toDate}` : ''}
                </div>
                <div className='yk-dateHeading'>
                  <DateRangeFilter
                    userInputDate={userInputDate}
                    defaultStartDate={firstDay}
                    defaultEndDate={date}
                    setUserInputDate={setUserInputDate}
                    setShouldFetchKPIWithOrderDate={
                      setShouldFetchKPIWithOrderDate
                    }
                    setShouldFetchKPIWithCreationDate={
                      setShouldFetchKPIWithCreationDate
                    }
                    setShouldFetchTopConsignorSales={
                      setShouldFetchTopConsignorSales
                    }
                    setShouldFetchUserRegistration={
                      setShouldFetchUserRegistration
                    }
                    setShouldFetchBestSellers={setShouldFetchBestSellers}
                    setShouldFetchTopPerformerSA={setShouldFetchTopPerformerSA}
                    setShouldFetchPendingTasks={setShouldFetchPendingTasks}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <section className='dashboard-widgets-section'>
          <div className='row'>
            <div className='col-lg-8 col-sm-12 col-12'>
              <YKAdminKPIs
                locId={locId}
                userInputDate={userInputDate}
                monthStartDate={monthStartDate}
                todaysDate={todaysDate}
                shouldFetchKPIWithOrderDate={shouldFetchKPIWithOrderDate}
                shouldFetchKPIWithCreationDate={shouldFetchKPIWithCreationDate}
                setShouldFetchKPIWithOrderDate={setShouldFetchKPIWithOrderDate}
                setShouldFetchKPIWithCreationDate={
                  setShouldFetchKPIWithCreationDate
                }
              />
            </div>
            <div className='col-lg-4 col-sm-12 col-12'>
              <BestSellers
                locId={locId}
                userInputDate={userInputDate}
                monthStartDate={monthStartDate}
                todaysDate={todaysDate}
                shouldFetchBestSellers={shouldFetchBestSellers}
                setShouldFetchBestSellers={setShouldFetchBestSellers}
              />
            </div>
          </div>
        </section>
        <section className='dashboard-overview-section'>
          <div className='row'>
            <div className='col-lg-8 col-sm-12 col-12'>
              <div className='col-lg-12 col-md-12 col-sm-12 col-12'>
                <WeeklySales locId={locId} />
              </div>

              <div className='row'>
                <div className='col-lg-6 col-md-12 col-sm-12 col-12'>
                  <BestPerformerSA
                    locId={locId}
                    userInputDate={userInputDate}
                    monthStartDate={monthStartDate}
                    todaysDate={todaysDate}
                    shouldFetchTopPerformerSA={shouldFetchTopPerformerSA}
                    setShouldFetchTopPerformerSA={setShouldFetchTopPerformerSA}
                  />
                </div>
                <div className='col-lg-6 col-md-12 col-sm-12 col-12'>
                  <UserRegistrations
                    userInputDate={userInputDate}
                    monthStartDate={monthStartDate}
                    todaysDate={todaysDate}
                    shouldFetchUserRegistration={shouldFetchUserRegistration}
                    setShouldFetchUserRegistration={
                      setShouldFetchUserRegistration
                    }
                  />
                </div>
              </div>
            </div>
            <div className='col-lg-4 col-sm-12 col-12'>
              <div className='col-lg-12 col-md-12 col-sm-12 col-12'>
                <PendingTasks
                  locId={locId}
                  userInputDate={userInputDate}
                  monthStartDate={monthStartDate}
                  todaysDate={todaysDate}
                  shouldFetchPendingTasks={shouldFetchPendingTasks}
                  setShouldFetchPendingTasks={setShouldFetchPendingTasks}
                />
                <TopConsignors
                  locId={locId}
                  userInputDate={userInputDate}
                  monthStartDate={monthStartDate}
                  todaysDate={todaysDate}
                  shouldFetchTopConsignorSales={shouldFetchTopConsignorSales}
                  setShouldFetchTopConsignorSales={
                    setShouldFetchTopConsignorSales
                  }
                />
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default YKAdminDashboard;
