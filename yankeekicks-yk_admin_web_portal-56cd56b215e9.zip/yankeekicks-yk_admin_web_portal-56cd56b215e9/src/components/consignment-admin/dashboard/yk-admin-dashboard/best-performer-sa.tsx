import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { useCubeQuery } from '@cubejs-client/react';
import { CircularProgress } from '@mui/material';
import { getBestPerformerSalesAssociate } from 'middleware/cubejs-wrapper/dashboard-queries';
import { convertPriceToUSFormat, getTrimmedText } from 'utils/util';
import NoDataFound from 'components/common/no-data-found';
import circleImg from 'assets/images/menu-icons/red-circle-img.svg';

const BestPerformerSA = (props: any) => {
  const {
    locId,
    userInputDate,
    monthStartDate,
    todaysDate,
    shouldFetchTopPerformerSA,
    setShouldFetchTopPerformerSA,
  } = props;

  const [bestPerformers, setBestPerformers] = useState<any>([]);

  const bestPerformerSalesAssociateQuery: any = getBestPerformerSalesAssociate(
    locId,
    userInputDate,
    monthStartDate,
    todaysDate
  );

  useEffect(() => {
    if (locId) {
      setShouldFetchTopPerformerSA(true);
    }
  }, [locId]);

  const {
    resultSet: bestPerformersResultSet,
    isLoading: bestPerformersLoading,
    error: bestPerformersError,
  }: any = useCubeQuery(bestPerformerSalesAssociateQuery, {
    skip: !shouldFetchTopPerformerSA,
  });

  useEffect(() => {
    if (
      bestPerformersError?.status === 401 ||
      bestPerformersError?.status === 403
    ) {
      // todo: logout the user
    } else {
      const data: any = bestPerformersResultSet?.loadResponses[0]?.data;
      if (data) {
        setBestPerformers(data);
        setShouldFetchTopPerformerSA(false);
      } else {
        setBestPerformers([]);
      }
    }
  }, [bestPerformersResultSet, bestPerformersError]);

  return (
    <div className='yk-cards yk-sales-associates-card-wrapper'>
      <div className='heading-wrapper yk-cardHeadingWrapper'>
        <div className='yk-cards-heading mb-0'>Sales Associates</div>
      </div>
      {bestPerformersError ? (
        <NoDataFound />
      ) : bestPerformersLoading ? (
        <div className='YKCH-loader yk-dashboardLoader'>
          <CircularProgress />
        </div>
      ) : bestPerformers?.length > 0 ? (
        <>
          <div className='yk-productDetailsCard '>
            <div className='yk-bestPerformerInfo d-flexSpaceBetween'>
              <div className='productInfoWrapper'>
                <p className='yk-para-p3 mb-0'>Best Performer</p>
                <p className='yk-badge-h11 mb-0 yk-associateNameTitle'>
                  {bestPerformers?.[0]?.['TopSalesAssociate.userName']
                    ? bestPerformers?.[0]?.['TopSalesAssociate.userName']
                        ?.length > 12
                      ? getTrimmedText(
                          bestPerformers?.[0]?.['TopSalesAssociate.userName'],
                          12
                        )
                      : bestPerformers?.[0]?.['TopSalesAssociate.userName']
                    : '--'}
                </p>
              </div>
              <div className='product-img-wrapper'>
                <Image src={circleImg} className='p-0' alt='product-img' />
              </div>
            </div>
            <div className='yk-performerSalesInfo d-flexSpaceBetween'>
              <div className='productInfoWrapper'>
                <p className='yk-para-p3 mb-0'>Num of Sales</p>
                <h6 className='yk-amount-text mb-0'>
                  {bestPerformers?.[0]?.['TopSalesAssociate.count'] || 0}
                </h6>
              </div>
              <div className='productInfoWrapper'>
                <p className='yk-para-p3 mb-0'>Total Value</p>
                <h6 className='yk-amount-text mb-0'>
                  {bestPerformers?.[0]?.['TopSalesAssociate.totalPriceSum']
                    ? convertPriceToUSFormat(
                        bestPerformers?.[0]?.['TopSalesAssociate.totalPriceSum']
                      )
                    : '$0.00'}
                </h6>
              </div>
            </div>
          </div>
          {bestPerformers?.length > 1 && (
            <div className='yk-card-body'>
              {bestPerformers?.map((performer: any, index: any) => {
                if (index > 0) {
                  return (
                    <div
                      className='yk-productInfoCard d-flexSpaceBetween'
                      key={index}>
                      <p
                        className='productName-title yk-badge-h8 mb-0'
                        title={
                          performer?.['TopSalesAssociate.userName'] || '--'
                        }>
                        {performer?.['TopSalesAssociate.userName']
                          ? performer?.['TopSalesAssociate.userName']?.length >
                            16
                            ? getTrimmedText(
                                performer?.['TopSalesAssociate.userName'],
                                16
                              )
                            : performer?.['TopSalesAssociate.userName']
                          : '--'}
                      </p>
                      <div className='yk-productItemInfo dFlexCenter yk-badgeText-14'>
                        <h6 className='yk-badgeText-14 mb-0'>
                          {performer?.['TopSalesAssociate.count'] || 0}{' '}
                          {`${
                            performer?.['TopSalesAssociate.count'] > 1
                              ? 'Sales'
                              : 'Sale'
                          }`}
                        </h6>
                        <h6 className='yk-sales-amount-text mb-0'>
                          {performer?.['TopSalesAssociate.totalPriceSum']
                            ? convertPriceToUSFormat(
                                performer?.['TopSalesAssociate.totalPriceSum']
                              )
                            : '$0.00'}
                        </h6>
                      </div>
                    </div>
                  );
                }
              })}
            </div>
          )}
        </>
      ) : (
        <NoDataFound />
      )}
    </div>
  );
};

export default BestPerformerSA;
