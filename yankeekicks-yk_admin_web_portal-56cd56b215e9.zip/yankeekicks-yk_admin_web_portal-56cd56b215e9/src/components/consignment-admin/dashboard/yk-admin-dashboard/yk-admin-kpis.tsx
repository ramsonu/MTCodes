import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { useCubeQuery } from '@cubejs-client/react';
import {
  getAdminKPIsWithCreationDate,
  getAdminKPIsWithOrderDate,
} from 'middleware/cubejs-wrapper/dashboard-queries';
import { convertPriceToUSFormat } from 'utils/util';
import { CircularProgress } from '@mui/material';
import salesIcon from 'assets/images/menu-icons/sales-icon.svg';
import inventoryValueIcon from 'assets/images/menu-icons/iv-icon.svg';
import pendingPIcon from 'assets/images/menu-icons/pending-p-icon.svg';
import storeIcon from 'assets/images/menu-icons/store-icon.svg';
import onlineIcon from 'assets/images/menu-icons/online-icon.svg';
// import indicatorsUpIcon from 'assets/images/menu-icons/indicators-up-icon.svg';
// import indicatorsDownIcon from 'assets/images/menu-icons/indicators-down-icon.svg';

const YKAdminKPIs = (props: any) => {
  const {
    locId,
    userInputDate,
    monthStartDate = '',
    todaysDate = '',
    shouldFetchKPIWithOrderDate = false,
    shouldFetchKPIWithCreationDate = false,
    setShouldFetchKPIWithOrderDate = () => {},
    setShouldFetchKPIWithCreationDate = () => {},
  } = props;

  const [KPIsWithOrderDate, setKPIsWithOrderDate] = useState<any>({});
  const [KPIsWithCreationDate, setKPIsWithCreationDate] = useState<any>({});

  const YKAdminKPIsOrderDateQuery: any = getAdminKPIsWithOrderDate(
    locId,
    userInputDate,
    monthStartDate,
    todaysDate
  );
  const YKAdminKPIsCreationDateQuery: any = getAdminKPIsWithCreationDate(
    locId,
    userInputDate,
    monthStartDate,
    todaysDate
  );

  useEffect(() => {
    if (locId) {
      setShouldFetchKPIWithOrderDate(true);
      setShouldFetchKPIWithCreationDate(true);
    }
  }, [locId]);

  const {
    resultSet: kpiOrderDateResultSet,
    isLoading: kpiOrderDateLoading,
    error: kpiOrderDateError,
  }: any = useCubeQuery(YKAdminKPIsOrderDateQuery, {
    skip: !shouldFetchKPIWithOrderDate,
  });
  const {
    resultSet: kpiCreationDateResultSet,
    isLoading: kpiCreationDateLoading,
    error: kpiCreationDateError,
  }: any = useCubeQuery(YKAdminKPIsCreationDateQuery, {
    skip: !shouldFetchKPIWithCreationDate,
  });

  useEffect(() => {
    if (
      kpiOrderDateError?.status === 401 ||
      kpiOrderDateError?.status === 403
    ) {
      // todo: logout the user
    } else {
      const data: any = kpiOrderDateResultSet?.loadResponses[0]?.data[0];
      if (data) {
        setKPIsWithOrderDate(data);
        setShouldFetchKPIWithOrderDate(false);
      } else {
        setKPIsWithOrderDate({});
      }
    }
  }, [kpiOrderDateResultSet, kpiOrderDateError]);

  useEffect(() => {
    if (
      kpiCreationDateError?.status === 401 ||
      kpiCreationDateError?.status === 403
    ) {
      // todo: logout the user
    } else {
      const data: any = kpiCreationDateResultSet?.loadResponses[0]?.data[0];
      if (data) {
        setKPIsWithCreationDate(data);
        setShouldFetchKPIWithCreationDate(false);
      } else {
        setKPIsWithCreationDate({});
      }
    }
  }, [kpiCreationDateResultSet, kpiCreationDateError]);

  return (
    <div className='yk-admin-dashboard-kpi-wrapper yk-widgets'>
      <div className='row'>
        <div className='dFlexCenter marginBottom yk-dashboardHeadingWrapper'>
          <div className='col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 me-3'>
            <div className='yk-kpiHeadingWrapper'>
              <h2 className='heading yk-title-h17'>Total Sales</h2>
              <p className='yk-kpiAmountText yk-badge-h12'>
                {!kpiOrderDateLoading &&
                  (KPIsWithOrderDate?.['AdminDashboardKPI.totalSales']
                    ? convertPriceToUSFormat(
                        KPIsWithOrderDate?.['AdminDashboardKPI.totalSales']
                      )
                    : '$0.00')}
              </p>
            </div>
          </div>
          <div className='col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12'>
            <div className='d-flex'>
              <div className='col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6'>
                <div className='dFlexCenter'>
                  <Image
                    src={storeIcon}
                    alt='storeIcon'
                    className='Image-fluid imgIcon'
                  />
                  <div className='yk-infoWrapper'>
                    <h2 className='heading yk-title-h17'>Store</h2>
                    <p className='yk-badge-h16 mb-0'>
                      {!kpiOrderDateLoading &&
                        (KPIsWithOrderDate?.['AdminDashboardKPI.retailSales']
                          ? convertPriceToUSFormat(
                              KPIsWithOrderDate?.[
                                'AdminDashboardKPI.retailSales'
                              ]
                            )
                          : '$0.00')}
                    </p>
                  </div>
                </div>
              </div>
              <div className='col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6'>
                <div className='dFlexCenter'>
                  <Image
                    src={onlineIcon}
                    alt='browserIcon'
                    className='Image-fluid imgIcon'
                  />
                  <div className='yk-infoWrapper'>
                    <h2 className='heading yk-title-h17'>Online</h2>
                    <p className='yk-badge-h16 mb-0'>
                      {!kpiOrderDateLoading &&
                        (KPIsWithOrderDate?.['AdminDashboardKPI.onlineSales']
                          ? convertPriceToUSFormat(
                              KPIsWithOrderDate?.[
                                'AdminDashboardKPI.onlineSales'
                              ]
                            )
                          : '$0.00')}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className='col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 paddingRight-0'>
          <div className='yk-widgets-cards marginBottom'>
            <div className='d-flex'>
              <div className='widgets-icon'>
                <Image
                  src={salesIcon}
                  alt='salesIcon'
                  className='Image-fluid'
                />
              </div>
              <div className='widgets-info flex-fill'>
                <div className='widgets-heading'>Profit</div>
                <div className='widgets-value'>
                  {kpiOrderDateLoading ? (
                    <CircularProgress />
                  ) : KPIsWithOrderDate?.['AdminDashboardKPI.totalProfits'] ? (
                    convertPriceToUSFormat(
                      KPIsWithOrderDate?.['AdminDashboardKPI.totalProfits']
                    )
                  ) : (
                    '$0.00'
                  )}
                </div>
              </div>
              {/* {!kpiOrderDateLoading && (
                <div className='widgets-indicators'>
                  <Image
                    src={indicatorsUpIcon}
                    alt='indicatorsUpIcon'
                    className='Image-fluid'
                  />
                </div>
              )} */}
            </div>
          </div>
        </div>
        <div className='col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12'>
          <div className='yk-widgets-cards marginBottom'>
            <div className='d-flex'>
              <div className='widgets-icon'>
                <Image
                  src={pendingPIcon}
                  alt='pendingPIcon'
                  className='Image-fluid'
                />
              </div>
              <div className='widgets-info flex-fill'>
                <div className='widgets-heading'>Pending Payouts</div>
                <div className='widgets-value'>
                  {kpiOrderDateLoading ? (
                    <CircularProgress />
                  ) : KPIsWithOrderDate?.[
                      'AdminDashboardKPI.pendingPayouts'
                    ] ? (
                    KPIsWithOrderDate?.['AdminDashboardKPI.pendingPayouts']
                  ) : (
                    0
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 paddingRight-0'>
          <div className='yk-widgets-cards'>
            <div className='d-flex '>
              <div className='widgets-icon'>
                <Image
                  src={inventoryValueIcon}
                  alt='inventoryValueIcon'
                  className='Image-fluid'
                />
              </div>
              <div className='widgets-info flex-fill'>
                <div className='widgets-heading'>Inventory Value</div>
                <div className='widgets-value'>
                  {kpiCreationDateLoading ? (
                    <CircularProgress />
                  ) : KPIsWithCreationDate?.[
                      'AdminDashboardKPI.inventoryValues'
                    ] ? (
                    convertPriceToUSFormat(
                      KPIsWithCreationDate?.[
                        'AdminDashboardKPI.inventoryValues'
                      ]
                    )
                  ) : (
                    '$0.00'
                  )}
                </div>
              </div>
              {/* {!kpiCreationDateLoading && (
                <div className='widgets-indicators '>
                  <Image
                    src={indicatorsDownIcon}
                    alt='indicatorsDownIcon'
                    className='Image-fluid'
                  />
                </div>
              )} */}
            </div>
          </div>
        </div>
        <div className='col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12'>
          <div className='yk-widgets-cards'>
            <div className='d-flex'>
              <div className='widgets-icon'>
                <Image
                  src={salesIcon}
                  alt='salesIcon'
                  className='Image-fluid'
                />
              </div>
              <div className='widgets-info flex-fill'>
                <div className='widgets-heading'>Number of Listings</div>
                <div className='widgets-value'>
                  {kpiCreationDateLoading ? (
                    <CircularProgress />
                  ) : (
                    KPIsWithCreationDate?.['AdminDashboardKPI.listingCount'] ||
                    0
                  )}
                </div>
              </div>
              {/* {!kpiCreationDateLoading && (
                <div className='widgets-indicators'>
                  <Image
                    src={indicatorsUpIcon}
                    alt='indicatorsUpIcon'
                    className='Image-fluid'
                  />
                </div>
              )} */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default YKAdminKPIs;
