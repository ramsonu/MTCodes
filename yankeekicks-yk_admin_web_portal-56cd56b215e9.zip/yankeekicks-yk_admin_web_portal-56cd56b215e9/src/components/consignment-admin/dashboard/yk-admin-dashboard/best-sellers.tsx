import React, { useState, useEffect } from 'react';
import { getBestSellers } from 'middleware/cubejs-wrapper/dashboard-queries';
import { useCubeQuery } from '@cubejs-client/react';
import NoDataFound from 'components/common/no-data-found';
import { CircularProgress } from '@mui/material';
import { convertPriceToUSFormat, getTrimmedText } from 'utils/util';
import ImageLoader from 'components/common/image-loader';
import fallBackImg from 'assets/images/big-product-img.svg';

const BestSellers = (props: any) => {
  const {
    locId,
    userInputDate,
    monthStartDate,
    todaysDate,
    shouldFetchBestSellers,
    setShouldFetchBestSellers,
  } = props;

  const [metric, setMetric] = useState<any>('Gross');
  const [bestSellers, setBestSellers] = useState<any>([]);

  const bestSellersQuery: any = getBestSellers(
    locId,
    userInputDate,
    monthStartDate,
    todaysDate,
    metric
  );

  useEffect(() => {
    if (locId) {
      setShouldFetchBestSellers(true);
    }
  }, [locId, metric]);

  const {
    resultSet: bestSellersResultSet,
    isLoading: bestSellersLoading,
    error: bestSellersError,
  }: any = useCubeQuery(bestSellersQuery, { skip: !shouldFetchBestSellers });

  useEffect(() => {
    if (bestSellersError?.status === 401 || bestSellersError?.status === 403) {
      // todo: logout the user
    } else {
      const data: any = bestSellersResultSet?.loadResponses[0]?.data;
      if (data) {
        setBestSellers(data);
        setShouldFetchBestSellers(false);
      } else {
        setBestSellers([]);
      }
    }
  }, [bestSellersResultSet, bestSellersError]);

  const firstSellerItems = Number(bestSellers?.[0]?.['TopSellerItem.count']);
  const firstSellerCostPerItem =
    Number(bestSellers?.[0]?.['TopSellerItem.sellingPriceSum']) /
    firstSellerItems;

  return (
    <div className='yk-cards yk-best-sellers-card-wrapper'>
      <div className='heading-wrapper yk-cardHeadingWrapper'>
        <div className='yk-cards-heading mb-0'>Best Sellers</div>
        {(bestSellers?.length > 0 || bestSellersLoading) && (
          <div className='dFlexCenter'>
            <div className='dFlexCenter'>
              <button
                className={`btn yk-redBadge-btn ${
                  metric === 'Gross' ? 'yk-redBadgeActive' : ''
                }`}
                onClick={() => setMetric('Gross')}>
                Gross
              </button>
              <button
                className={`btn yk-redBadge-btn ${
                  metric === 'Units' ? 'yk-redBadgeActive' : ''
                }`}
                onClick={() => setMetric('Units')}>
                Units
              </button>
            </div>
          </div>
        )}
      </div>
      {bestSellersError ? (
        <NoDataFound />
      ) : bestSellersLoading ? (
        <div className='YKCH-loader yk-dashboardLoader'>
          <CircularProgress />
        </div>
      ) : bestSellers?.length > 0 ? (
        <>
          <div className='yk-productDetailsCard d-flexSpaceBetween'>
            <div className='productInfoWrapper'>
              <p
                className='productName-title yk-badge-h8'
                title={bestSellers?.[0]?.['TopSellerItem.productName'] || '--'}>
                {bestSellers?.[0]?.['TopSellerItem.productName'] &&
                bestSellers?.[0]?.['TopSellerItem.productName']?.length > 40
                  ? getTrimmedText(
                      bestSellers?.[0]?.['TopSellerItem.productName'],
                      40
                    )
                  : bestSellers?.[0]?.['TopSellerItem.productName'] || '--'}
              </p>
              <p className='mb-0'>
                <h6 className='yk-amount-text mb-0'>
                  {bestSellers?.[0]?.['TopSellerItem.sellingPriceSum']
                    ? convertPriceToUSFormat(
                        bestSellers?.[0]?.['TopSellerItem.sellingPriceSum']
                      )
                    : '$0.00'}
                </h6>
                <h6 className='yk-para-p3 mb-0'>
                  {firstSellerItems || 0}{' '}
                  {firstSellerItems > 1 ? 'Items' : 'Item'}.
                  <span className='yk-para-p3'>
                    {firstSellerItems > 0 &&
                    Number(
                      bestSellers?.[0]?.['TopSellerItem.sellingPriceSum']
                    ) > 0 &&
                    firstSellerItems > 1
                      ? ` ${convertPriceToUSFormat(
                          firstSellerCostPerItem
                        )} / Item`
                      : ''}
                  </span>
                </h6>
              </p>
            </div>
            <div className='product-img-wrapper'>
              <ImageLoader
                src={bestSellers?.[0]?.['TopSellerItem.stockxUrl']}
                fallbackImg={fallBackImg}
                className='p-0'
                alt='product-img'
              />
            </div>
          </div>
          {bestSellers?.length > 1 && (
            <div className='yk-card-body'>
              {bestSellers?.map((seller: any, index: any) => {
                if (index > 0) {
                  return (
                    <div
                      className='yk-productInfoCard d-flexSpaceBetween'
                      key={index}>
                      <div className='product-img-wrapper'>
                        <ImageLoader
                          src={seller?.['TopSellerItem.stockxUrl']}
                          fallbackImg={fallBackImg}
                          className='p-0'
                          alt='product-img'
                        />
                      </div>
                      <p
                        className='productName-title yk-badge-h8 mb-0'
                        title={seller?.['TopSellerItem.productName'] || '--'}>
                        {seller?.['TopSellerItem.productName'] &&
                        seller?.['TopSellerItem.productName']?.length > 20
                          ? getTrimmedText(
                              seller?.['TopSellerItem.productName'],
                              20
                            )
                          : seller?.['TopSellerItem.productName'] || '--'}
                      </p>
                      <div className='yk-productItemInfo'>
                        <h6 className='yk-amount-text mb-0'>
                          {seller?.['TopSellerItem.sellingPriceSum']
                            ? convertPriceToUSFormat(
                                seller?.['TopSellerItem.sellingPriceSum']
                              )
                            : '$0.00'}
                        </h6>
                        <h6 className='yk-para-p3 mb-0'>
                          {seller?.['TopSellerItem.count'] || 0} Item
                        </h6>
                      </div>
                    </div>
                  );
                }
              })}
            </div>
          )}
        </>
      ) : (
        <NoDataFound />
      )}
    </div>
  );
};

export default BestSellers;
