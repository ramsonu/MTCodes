import React, { useEffect, useState } from 'react';
import { useCubeQuery } from '@cubejs-client/react';
import { CircularProgress } from '@mui/material';
import { getUserRegistrations } from 'middleware/cubejs-wrapper/dashboard-queries';
import DoughnutChartWithRCJ from '../common/doughnut-chart-with-RCJ';
import NoDataFound from 'components/common/no-data-found';

const UserRegistrations = (props: any) => {
  const {
    userInputDate,
    monthStartDate = '',
    todaysDate = '',
    shouldFetchUserRegistration,
    setShouldFetchUserRegistration,
  } = props;

  const [userRegistrations, setUserRegistrations] = useState<any>({});

  const userRegistrationsQuery: any = getUserRegistrations(
    userInputDate,
    monthStartDate,
    todaysDate
  );

  useEffect(() => {
    setShouldFetchUserRegistration(true);
  }, []);

  const {
    resultSet: userRegistrationsResultSet,
    isLoading: userRegistrationsLoading,
    error: userRegistrationsError,
  }: any = useCubeQuery(userRegistrationsQuery, {
    skip: !shouldFetchUserRegistration,
  });

  useEffect(() => {
    if (
      userRegistrationsError?.status === 401 ||
      userRegistrationsError?.status === 403
    ) {
      // todo: logout the user
    } else {
      const data: any = userRegistrationsResultSet?.loadResponses[0]?.data[0];
      if (data) {
        setUserRegistrations(data);
        setShouldFetchUserRegistration(false);
      } else {
        setUserRegistrations({});
      }
    }
  }, [userRegistrationsResultSet, userRegistrationsError]);

  const buyerReg = Number(userRegistrations?.['Users.buyerRegCount']) || 0;
  const consignorReg = Number(userRegistrations?.['Users.sellerRegCount']) || 0;
  const totalReg = buyerReg + consignorReg;

  return (
    <div className='yk-cards yk-userRegistrationCardWrapper'>
      <div className='heading-wrapper yk-cardHeadingWrapper'>
        <div className='yk-cards-heading mb-0'>User Registration</div>
      </div>
      <div className='registrationDetailsWrapper'>
        {userRegistrationsError ? (
          <NoDataFound />
        ) : userRegistrationsLoading ? (
          <div className='YKCH-loader yk-dashboardLoader'>
            <CircularProgress />
          </div>
        ) : Object.keys(userRegistrations)?.length !== 0 ? (
          <>
            <DoughnutChartWithRCJ
              data={userRegistrations}
              buyerReg={buyerReg}
              consignorReg={consignorReg}
            />
            <div className='yk-userRegistrationInfo d-flexSpaceBetween'>
              <div className='productInfoWrapper'>
                <p className='yk-para-p3 mb-0'>Total Registrations</p>
                <h6 className='yk-amount-text mb-0'>{totalReg || 0}</h6>
              </div>
              <div className='productInfoWrapper'>
                <p className='yk-para-p3 mb-0'>Buyers</p>
                <h6 className='yk-amount-text mb-0'>{buyerReg || 0}</h6>
              </div>
              <div className='productInfoWrapper'>
                <p className='yk-para-p3 mb-0'>Consignors</p>
                <h6 className='yk-amount-text mb-0'>{consignorReg || 0}</h6>
              </div>
            </div>
          </>
        ) : (
          <NoDataFound />
        )}
      </div>
    </div>
  );
};

export default UserRegistrations;
