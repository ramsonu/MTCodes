import React, { useState, useEffect, useRef } from 'react';
import Image from 'next/image';
import { useCubeQuery } from '@cubejs-client/react';
import { Button, Menu, MenuItem, CircularProgress } from '@mui/material';
import { getWeeklySalesQueryOrSalesOverview } from 'middleware/cubejs-wrapper/dashboard-queries';
import BarChartWithRCJ from '../common/bar-chart-with-RCJ';
import { exportCharts, openInFullScreen } from 'utils/util';
import DotsThreeVertical from 'assets/images/DotsThreeVerticalWhite.svg';
import pdfIcon from 'assets/images/menu-icons/pdfIcon.svg';
import csvIcon from 'assets/images/menu-icons/csvIcon.svg';
import jpegIcon from 'assets/images/menu-icons/jpegIcon.svg';
import fullscreenIcon from 'assets/images/menu-icons/fullscreenIcon.svg';
import pngIcon from 'assets/images/menu-icons/pngIcon.svg';

const SalesOverview = (props: any) => {
  const { locId } = props;

  // As download chart section is in component header, therefore moved this ref to parent.
  const chartRef = useRef<any>(null);

  const [shouldFetchSalesOverview, setShouldFetchSalesOverview] =
    useState<boolean>(false);
  const [salesOverviewData, setSalesOverviewData] = useState<any>([]);
  // In order to not move chartData and dataForCsv in parent component this trigger is required.
  const [downloadCSVTrigger, setDownloadCSVTrigger] = useState<any>(false);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const openDropdown = Boolean(anchorEl);

  useEffect(() => {
    setShouldFetchSalesOverview(true);
  }, [locId]);

  const salesOverviewQuery: any = getWeeklySalesQueryOrSalesOverview(
    locId,
    'salesOverview'
  );

  const {
    resultSet: salesOverviewResultSet,
    isLoading: salesOverviewLoading,
    error: salesOverviewError,
  }: any = useCubeQuery(salesOverviewQuery, {
    skip: !shouldFetchSalesOverview,
  });

  useEffect(() => {
    if (
      salesOverviewError?.status === 401 ||
      salesOverviewError?.status === 403
    ) {
      // todo: logout the user
    } else {
      const data: any = salesOverviewResultSet?.loadResponses[0]?.data;
      if (data) {
        setSalesOverviewData(data);
        setShouldFetchSalesOverview(false);
      } else {
        setSalesOverviewData([]);
      }
    }
  }, [salesOverviewResultSet, salesOverviewError]);

  return (
    <div className='yk-cards sales-overview-card'>
      <div className='heading-wrapper yk-cardHeadingWrapper'>
        <div className='yk-cards-heading'>Sales Overview</div>
        <div className='yk-displayFlexEnd yk-threeDotBtn'>
          <Button
            className='p-0 justify-content-end yk-dropdownBtn'
            id='basic-button'
            aria-controls={openDropdown ? 'basic-menu' : undefined}
            aria-haspopup='true'
            aria-expanded={openDropdown ? 'true' : undefined}
            onClick={(event) => setAnchorEl(event.currentTarget)}>
            <Image src={DotsThreeVertical} className='p-0' alt='' title='' />
          </Button>
          <Menu
            className='yk-weeklySalesDropdown'
            id='basic-menu'
            anchorEl={anchorEl}
            open={openDropdown}
            onClose={() => setAnchorEl(null)}
            MenuListProps={{
              'aria-labelledby': 'basic-button',
            }}>
            <MenuItem onClick={() => openInFullScreen('bar-chart-fullscreen')}>
              View in full screen
              <span>
                <Image
                  src={fullscreenIcon}
                  className=''
                  alt='fullscreen-icon'
                />
              </span>
            </MenuItem>
            <MenuItem
              onClick={() =>
                exportCharts(chartRef, 'image/png', 'Sales Overview.png')
              }>
              Download PNG
              <span>
                <Image src={pngIcon} className='' alt='png-icon' />
              </span>
            </MenuItem>
            <MenuItem
              onClick={() =>
                exportCharts(chartRef, 'image/jpeg', 'Sales Overview.jpeg')
              }>
              Download JPEG
              <span>
                <Image src={jpegIcon} className='' alt='jpeg-icon' />
              </span>
            </MenuItem>
            <MenuItem
              onClick={() =>
                exportCharts(chartRef, 'image/png', 'Sales Overview.pdf', true)
              }>
              Download PDF
              <span>
                <Image src={pdfIcon} className='' alt='pdf-icon' />
              </span>
            </MenuItem>
            <MenuItem onClick={() => setDownloadCSVTrigger(true)}>
              Download CSV
              <span>
                <Image src={csvIcon} className='' alt='csv-icon' />
              </span>
            </MenuItem>
          </Menu>
        </div>
      </div>

      <div className='yk-card-body'>
        <div className='sales-chart'>
          <div>
            {salesOverviewLoading ? (
              <div className='YKCH-loader yk-dashboardLoader'>
                <CircularProgress />
              </div>
            ) : (
              <BarChartWithRCJ
                data={salesOverviewData || []}
                chartRef={chartRef}
                trigger={downloadCSVTrigger}
                setTrigger={setDownloadCSVTrigger}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SalesOverview;
