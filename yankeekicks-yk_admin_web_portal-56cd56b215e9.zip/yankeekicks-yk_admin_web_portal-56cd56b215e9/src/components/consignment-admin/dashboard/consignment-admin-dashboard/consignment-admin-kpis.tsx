import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { useCubeQuery } from '@cubejs-client/react';
import { CircularProgress } from '@mui/material';
import {
  getAdminKPIsWithCreationDate,
  getAdminKPIsWithOrderDate,
} from 'middleware/cubejs-wrapper/dashboard-queries';
import { convertPriceToUSFormat } from 'utils/util';
import salesIcon from 'assets/images/menu-icons/sales-icon.svg';
import profitIcon from 'assets/images/menu-icons/profit-icon.svg';
import inventoryValueIcon from 'assets/images/menu-icons/iv-icon.svg';
import pendingPIcon from 'assets/images/menu-icons/pending-p-icon.svg';
// import indicatorsUpIcon from 'assets/images/menu-icons/indicators-up-icon.svg';
// import indicatorsDownIcon from 'assets/images/menu-icons/indicators-down-icon.svg';

const ConsignmentAdminKPIs = (props: any) => {
  const {
    locId,
    userInputDate,
    monthStartDate = '',
    todaysDate = '',
    shouldFetchKPIWithOrderDate = false,
    shouldFetchKPIWithCreationDate = false,
    setShouldFetchKPIWithOrderDate = () => {},
    setShouldFetchKPIWithCreationDate = () => {},
  } = props;

  const [KPIsWithOrderDate, setKPIsWithOrderDate] = useState<any>({});
  const [KPIsWithCreationDate, setKPIsWithCreationDate] = useState<any>({});

  const consignmentAdminKPIsWithOrderDateQuery: any = getAdminKPIsWithOrderDate(
    locId,
    userInputDate,
    monthStartDate,
    todaysDate
  );
  const consignmentAdminKPIsWithCreationDateQuery: any =
    getAdminKPIsWithCreationDate(
      locId,
      userInputDate,
      monthStartDate,
      todaysDate
    );

  useEffect(() => {
    if (locId) {
      setShouldFetchKPIWithOrderDate(true);
      setShouldFetchKPIWithCreationDate(true);
    }
  }, [locId]);

  const {
    resultSet: kpiOrderDateResultSet,
    isLoading: kpiOrderDateLoading,
    error: kpiOrderDateError,
  }: any = useCubeQuery(consignmentAdminKPIsWithOrderDateQuery, {
    skip: !shouldFetchKPIWithOrderDate,
  });
  const {
    resultSet: kpiCreationDateResultSet,
    isLoading: kpiCreationDateLoading,
    error: kpiCreationDateError,
  }: any = useCubeQuery(consignmentAdminKPIsWithCreationDateQuery, {
    skip: !shouldFetchKPIWithCreationDate,
  });

  useEffect(() => {
    if (
      kpiOrderDateError?.status === 401 ||
      kpiOrderDateError?.status === 403
    ) {
      // todo: logout the user
    } else {
      const data: any = kpiOrderDateResultSet?.loadResponses[0]?.data[0];
      if (data) {
        setKPIsWithOrderDate(data);
        setShouldFetchKPIWithOrderDate(false);
      } else {
        setKPIsWithOrderDate(data);
      }
    }
  }, [kpiOrderDateResultSet, kpiOrderDateError]);

  useEffect(() => {
    if (
      kpiCreationDateError?.status === 401 ||
      kpiCreationDateError?.status === 403
    ) {
      // todo: logout the user
    } else {
      const data: any = kpiCreationDateResultSet?.loadResponses[0]?.data[0];
      if (data) {
        setKPIsWithCreationDate(data);
        setShouldFetchKPIWithCreationDate(false);
      } else {
        setKPIsWithCreationDate(data);
      }
    }
  }, [kpiCreationDateResultSet, kpiCreationDateError]);

  return (
    <div className='yk-widgets'>
      <div className='row'>
        <div className='col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12 paddingRight-0'>
          <div className='yk-widgets-cards'>
            <div className='d-flex'>
              <div className='widgets-icon'>
                <Image
                  src={salesIcon}
                  alt='salesIcon'
                  className='Image-fluid'
                />
              </div>
              <div className='widgets-info flex-fill'>
                <div className='widgets-heading'>sales</div>
                <div className='widgets-value'>
                  {kpiOrderDateLoading ? (
                    <CircularProgress />
                  ) : KPIsWithOrderDate?.['AdminDashboardKPI.totalSales'] ? (
                    convertPriceToUSFormat(
                      KPIsWithOrderDate?.['AdminDashboardKPI.totalSales']
                    )
                  ) : (
                    '$0.00'
                  )}
                </div>
              </div>
              {/* {!kpiOrderDateLoading && (
                <div className='widgets-indicators'>
                  <Image
                    src={indicatorsUpIcon}
                    alt='indicatorsUpIcon'
                    className='Image-fluid'
                  />
                </div>
              )} */}
            </div>
          </div>
        </div>
        <div className='col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12 paddingRight-0'>
          <div className='yk-widgets-cards'>
            <div className='d-flex'>
              <div className='widgets-icon'>
                <Image
                  src={profitIcon}
                  alt='profitIcon'
                  className='Image-fluid'
                />
              </div>
              <div className='widgets-info flex-fill'>
                <div className='widgets-heading'>Profit</div>
                <div className='widgets-value'>
                  {kpiOrderDateLoading ? (
                    <CircularProgress />
                  ) : KPIsWithOrderDate?.['AdminDashboardKPI.totalProfits'] ? (
                    convertPriceToUSFormat(
                      KPIsWithOrderDate?.['AdminDashboardKPI.totalProfits']
                    )
                  ) : (
                    '$0.00'
                  )}
                </div>
              </div>
              {/* {!kpiOrderDateLoading && (
                <div className='widgets-indicators'>
                  <Image
                    src={indicatorsUpIcon}
                    alt='indicatorsUpIcon'
                    className='Image-fluid'
                  />
                </div>
              )} */}
            </div>
          </div>
        </div>
        <div className='col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12 paddingRight-0'>
          <div className='yk-widgets-cards'>
            <div className='d-flex '>
              <div className='widgets-icon'>
                <Image
                  src={inventoryValueIcon}
                  alt='inventoryValueIcon'
                  className='Image-fluid'
                />
              </div>
              <div className='widgets-info flex-fill'>
                <div className='widgets-heading'>Inventory Value</div>
                <div className='widgets-value'>
                  {kpiCreationDateLoading ? (
                    <CircularProgress />
                  ) : KPIsWithCreationDate?.[
                      'AdminDashboardKPI.inventoryValues'
                    ] ? (
                    convertPriceToUSFormat(
                      KPIsWithCreationDate?.[
                        'AdminDashboardKPI.inventoryValues'
                      ]
                    )
                  ) : (
                    '$0.00'
                  )}
                </div>
              </div>
              {/* {!kpiOrderDateLoading && (
                <div className='widgets-indicators '>
                  <Image
                    src={indicatorsDownIcon}
                    alt='indicatorsDownIcon'
                    className='Image-fluid'
                  />
                </div>
              )} */}
            </div>
          </div>
        </div>
        <div className='col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12'>
          <div className='yk-widgets-cards'>
            <div className='d-flex '>
              <div className='widgets-icon'>
                <Image
                  src={pendingPIcon}
                  alt='pendingPIcon'
                  className='Image-fluid'
                />
              </div>
              <div className='widgets-info flex-fill'>
                <div className='widgets-heading'>Pending Payouts</div>
                <div className='widgets-value'>
                  {kpiOrderDateLoading ? (
                    <CircularProgress />
                  ) : (
                    KPIsWithOrderDate?.['AdminDashboardKPI.pendingPayouts'] || 0
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConsignmentAdminKPIs;
