import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useRouter } from 'next/router';
import Image from 'next/image';
import { useCubeQuery } from '@cubejs-client/react';
import { Button, Menu, MenuItem, CircularProgress } from '@mui/material';
import {
  getWeeklyOrdersTableQuery,
  getWeeklySalesQueryOrSalesOverview,
} from 'middleware/cubejs-wrapper/dashboard-queries';
import { FNS_DATE_DMY_FORMAT } from 'utils/constants';
import VirtualTable from 'components/common/table';
import NoDataFound from 'components/common/no-data-found';
import LineChartWithRCJ from './line-chart-with-RCJ';
import { exportCharts, getBasePath, openInFullScreen } from 'utils/util';
import DotsThreeVertical from 'assets/images/DotsThreeVerticalWhite.svg';
import pdfIcon from 'assets/images/menu-icons/pdfIcon.svg';
import csvIcon from 'assets/images/menu-icons/csvIcon.svg';
import jpegIcon from 'assets/images/menu-icons/jpegIcon.svg';
import fullscreenIcon from 'assets/images/menu-icons/fullscreenIcon.svg';
import pngIcon from 'assets/images/menu-icons/pngIcon.svg';

const WeeklySales = (props: any) => {
  const { locId } = props;

  const router = useRouter();

  // As download chart section is in component header, therefore moved this ref to parent.
  const chartRef = useRef<any>(null);

  const [shouldFetchWeeklySales, setShouldFetchWeeklySales] =
    useState<boolean>(false);
  const [shouldFetchWeeklyOrders, setShouldFetchWeeklyOrders] =
    useState<boolean>(false);
  const [weeklySalesData, setWeeklySalesData] = useState<any>([]);
  const [weeklyOrdersData, setWeeklyOrdersData] = useState<any>([]);
  // In order to not move chartData and dataForCsv in parent component this trigger is required.
  const [downloadCSVTrigger, setDownloadCSVTrigger] = useState<any>(false);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const openDropdown = Boolean(anchorEl);

  useEffect(() => {
    if (locId) {
      setShouldFetchWeeklySales(true);
      setShouldFetchWeeklyOrders(true);
    }
  }, [locId]);

  const weeklySalesQuery: any = getWeeklySalesQueryOrSalesOverview(
    locId,
    'weeklySales'
  );
  const weeklyOrdersQuery: any = getWeeklyOrdersTableQuery(locId);

  const {
    resultSet: weeklySalesResultSet,
    isLoading: weeklySalesLoading,
    error: weeklySalesError,
  }: any = useCubeQuery(weeklySalesQuery, { skip: !shouldFetchWeeklySales });

  const {
    resultSet: weeklyOrdersResultSet,
    isLoading: weeklyOrdersLoading,
    error: weeklyOrdersError,
  }: any = useCubeQuery(weeklyOrdersQuery, { skip: !shouldFetchWeeklyOrders });

  useEffect(() => {
    if (weeklySalesError?.status === 401 || weeklySalesError?.status === 403) {
      // todo: logout the user
    } else {
      const data: any = weeklySalesResultSet?.loadResponses[0]?.data;
      if (data) {
        setWeeklySalesData(data);
        setShouldFetchWeeklySales(false);
      } else {
        setWeeklySalesData([]);
      }
    }
  }, [weeklySalesResultSet, weeklySalesError]);

  useEffect(() => {
    if (
      weeklyOrdersError?.status === 401 ||
      weeklyOrdersError?.status === 403
    ) {
      // todo: logout the user
    } else {
      const data: any = weeklyOrdersResultSet?.loadResponses[0]?.data;
      if (data) {
        setWeeklyOrdersData(data);
        setShouldFetchWeeklyOrders(false);
      } else {
        setWeeklyOrdersData([]);
      }
    }
  }, [weeklyOrdersResultSet, weeklyOrdersError]);

  const weeklyOrdersColumn = useMemo(
    () => [
      {
        title: 'Order ID',
        value: 'WeeklyOrderData.sellerorderId',
      },
      {
        title: 'SKU',
        value: 'WeeklyOrderData.sku',
        type: 'multiValueColumn',
        firstValue: 'WeeklyOrderData.sku',
        secondValue: 'WeeklyOrderData.countSku',
        whichValueIsBadge: 'Second',
        isFirstValueHasEllipses: true,
        trimAfter: 13,
      },
      {
        title: 'Order Date',
        type: 'date',
        format: FNS_DATE_DMY_FORMAT,
        value: 'WeeklyOrderData.completedAt',
      },
      {
        title: 'Amount',
        value: 'WeeklyOrderData.totalpriceUsd',
        prefix: '$',
        methodToApply: 'toFix',
        defaultValue: '$0.00',
      },
      {
        title: 'Sale source',
        value: 'WeeklyOrderData.saleLocation',
        type: 'saleLocation',
        success: 'Online',
        danger: 'Store',
        onClick: (data: any) => {
          router.push(
            getBasePath(
              `orders/${data?.['WeeklyOrderData.sellerorderId']?.replace(
                '#',
                ''
              )}`
            )
          );
        },
      },
    ],
    []
  );

  return (
    <div className='yk-cards weekly-sales-card'>
      <div className='heading-wrapper yk-cardHeadingWrapper mb-0'>
        <div className='yk-cards-heading mb-0'>Weekly Sales</div>
        <div className='yk-threeDotBtn'>
          <Button
            className='p-0 justify-content-end yk-dropdownBtn'
            id='basic-button'
            aria-controls={openDropdown ? 'basic-menu' : undefined}
            aria-haspopup='true'
            aria-expanded={openDropdown ? 'true' : undefined}
            onClick={(event) => setAnchorEl(event.currentTarget)}>
            <Image src={DotsThreeVertical} className='p-0' alt='' title='' />
          </Button>
          <Menu
            className='yk-weeklySalesDropdown'
            id='basic-menu'
            anchorEl={anchorEl}
            open={openDropdown}
            onClose={() => setAnchorEl(null)}
            MenuListProps={{
              'aria-labelledby': 'basic-button',
            }}>
            <MenuItem onClick={() => openInFullScreen('line-chart-fullscreen')}>
              View in full screen
              <span>
                <Image
                  src={fullscreenIcon}
                  className=''
                  alt='fullscreen-icon'
                />
              </span>
            </MenuItem>
            <MenuItem
              onClick={() =>
                exportCharts(chartRef, 'image/png', 'Weekly Sales.png')
              }>
              Download PNG
              <span>
                <Image src={pngIcon} className='' alt='png-icon' />
              </span>
            </MenuItem>
            <MenuItem
              onClick={() =>
                exportCharts(chartRef, 'image/jpeg', 'Weekly Sales.jpeg')
              }>
              Download JPEG
              <span>
                <Image src={jpegIcon} className='' alt='jpeg-icon' />
              </span>
            </MenuItem>
            <MenuItem
              onClick={() =>
                exportCharts(chartRef, 'image/png', 'Weekly Sales.pdf', true)
              }>
              Download PDF
              <span>
                <Image src={pdfIcon} className='' alt='pdf-icon' />
              </span>
            </MenuItem>
            <MenuItem onClick={() => setDownloadCSVTrigger(true)}>
              Download CSV
              <span>
                <Image src={csvIcon} className='' alt='csv-icon' />
              </span>
            </MenuItem>
            {/* <MenuItem>Download XLS</MenuItem> */}
          </Menu>
        </div>
      </div>

      <div className='yk-card-body'>
        <div className='weekly-sales-chart'>
          <div>
            {weeklySalesError ? (
              <NoDataFound />
            ) : weeklySalesLoading ? (
              <div className='YKCH-loader yk-dashboardLoader'>
                <CircularProgress />
              </div>
            ) : (
              <LineChartWithRCJ
                data={weeklySalesData || []}
                chartRef={chartRef}
                trigger={downloadCSVTrigger}
                setTrigger={setDownloadCSVTrigger}
              />
            )}
          </div>
        </div>
        <div className='weekly-sales-table-wrapper'>
          <VirtualTable
            headers={weeklyOrdersColumn}
            rowData={weeklyOrdersData}
            loading={weeklyOrdersLoading}
            error={weeklyOrdersError}
          />
        </div>
      </div>
    </div>
  );
};

export default WeeklySales;
