import React, { useEffect } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { parseISO, getDay } from 'date-fns';
import { downloadCsv } from 'utils/util';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const LineChartWithRCJ = (props: any) => {
  const {
    data,
    chartRef = null,
    trigger = false,
    setTrigger = () => {},
  } = props;

  useEffect(() => {
    if (trigger) {
      downloadCsv(dataForCsv, 'Weekly Sales');
      setTrigger(false);
    }
  }, [trigger]);

  const formatYAxisLabel = (value: any): any => {
    if (value >= 1000) {
      return `$${(value / 1000)?.toFixed(1)}K`;
    }
    return `$${value?.toString()}`;
  };

  const options: any = {
    responsive: true,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          usePointStyle: true,
          pointStyle: 'line',
          // boxWidth: 40,
          boxHeight: 12,
          padding: 12,
          font: {
            family: 'Inter',
            style: 'normal',
            weight: 400,
            size: 10,
          },
          color: '#949494',
        },
      },
      title: {
        display: false,
        text: 'Chart.js Line Chart',
      },
    },
    elements: {
      line: {
        tension: 0.4, // Adjust the tension value to control the curvature of the line
        borderWidth: 2, // Set the thickness of the line
      },
    },
    scales: {
      x: {
        grid: {
          display: true, // Show the x-axis grid lines
          drawBorder: true, // Hide the x-axis border
          drawOnChartArea: false, // Do not draw the grid lines within the chart area
        },
        ticks: {
          font: {
            family: 'Inter',
            style: 'normal',
            weight: 400,
            size: 10,
          },
          color: '#949494',
        },
        offset: 10,
      },
      y: {
        // min: 0, // Set the minimum value for the y-axis
        beginAtZero: true, // Start the y-axis at zero
        grid: {
          display: true, // Show the y-axis grid lines
          drawBorder: false, // Hide the y-axis border
          drawOnChartArea: false, // Do not draw the grid lines within the chart area
        },
        ticks: {
          font: {
            family: 'Inter',
            style: 'normal',
            weight: 400,
            size: 10,
          },
          color: '#949494',
          // Customize the y-axis values
          callback: (value: any) => {
            return formatYAxisLabel(value); // Prefix/suffix the values with a dollar sign
          },
        },
      },
    },
  };

  const chartData = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        label: 'Sales',
        data: [0, 0, 0, 0, 0, 0, 0],
        borderColor: '#C92626', // Set the hex code for the desired color
        backgroundColor: '#C92626',
      },
    ],
  };

  if (data) {
    data?.forEach((item: any) => {
      const date = parseISO(item?.['WeeklyOrderData.completedAtDate']);
      const dayOfWeek = getDay(date); // Get the day of the week (0 - Sunday, 1 - Monday, ..., 6 - Saturday)
      chartData.datasets[0].data[dayOfWeek - 1] =
        item?.['WeeklyOrderData.totalSellingPrice'];
    });
  }

  const dataForCsv = [chartData?.labels, chartData?.datasets?.[0]?.data];

  return (
    <div>
      <div id='line-chart-fullscreen' ref={chartRef}>
        <Line options={options} data={chartData} />
      </div>
    </div>
  );
};

export default LineChartWithRCJ;
