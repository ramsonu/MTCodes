import React, { useState } from 'react';
import Image from 'next/image';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import ProductFilters from 'components/common/filters/product-filter';
import filterIcon from 'assets/images/filter-icon.png';

const DateRangeFilter = (props: any) => {
  const {
    userInputDate,
    defaultStartDate = '',
    defaultEndDate = '',
    setUserInputDate = () => {},
    setShouldFetchKPIWithOrderDate = () => {},
    setShouldFetchKPIWithCreationDate = () => {},
    setShouldFetchTopConsignorSales = () => {},
    setShouldFetchUserRegistration = () => {},
    setShouldFetchBestSellers = () => {},
    setShouldFetchTopPerformerSA = () => {},
    setShouldFetchPendingTasks = () => {},
  } = props;

  const [showDateRangeFilter, setShowDateRangeFilter] =
    useState<boolean>(false);
  const [isClearButtonDisabled, setIsClearButtonDisabled] =
    useState<boolean>(true);
  const [isApplyButtonDisabled, setIsApplyButtonDisabled] =
    useState<boolean>(true);

  const dateChangeHandler = (dates: any) => {
    const [start, end] = dates;
    setUserInputDate({ startDate: start || '', endDate: end || '' });
    if (start && end) {
      setIsApplyButtonDisabled(false);
    } else {
      setIsApplyButtonDisabled(true);
    }
    setIsClearButtonDisabled(false);
  };

  const onDateRangeApply = () => {
    setShouldFetchKPIWithOrderDate(true);
    setShouldFetchKPIWithCreationDate(true);
    setShouldFetchTopConsignorSales(true);
    setShouldFetchUserRegistration(true);
    setShouldFetchBestSellers(true);
    setShouldFetchTopPerformerSA(true);
    setShouldFetchPendingTasks(true);
    setShowDateRangeFilter(false);
  };

  const onClearFilters = () => {
    setUserInputDate({ startDate: defaultStartDate, endDate: defaultEndDate });
    setShouldFetchKPIWithOrderDate(true);
    setShouldFetchKPIWithCreationDate(true);
    setShouldFetchTopConsignorSales(true);
    setShouldFetchUserRegistration(true);
    setShouldFetchBestSellers(true);
    setShouldFetchTopPerformerSA(true);
    setShouldFetchPendingTasks(true);
    setIsClearButtonDisabled(true);
    setShowDateRangeFilter(false);
  };

  return (
    <div className='filter-btn-wrapper ms-3'>
      <ClickAwayListener
        onClickAway={() => {
          setShowDateRangeFilter(false);
        }}>
        <div>
          <button
            className='btn filter-btn ms-0'
            onClick={() => setShowDateRangeFilter(!showDateRangeFilter)}>
            <Image
              src={filterIcon}
              alt='filter-btn-icon'
              className='filter-btn-icon img-fluid'
            />
            <span className='filter-btn-text yk-badge-h15'>Filter</span>
          </button>
          {showDateRangeFilter && (
            <ProductFilters
              itemKey='dashboardFilters'
              component='dashboardFilters'
              onDateChange={dateChangeHandler}
              startDate={userInputDate?.startDate}
              endDate={userInputDate?.endDate}
              onApplyClick={onDateRangeApply}
              onClearFilters={onClearFilters}
              clearDisable={isClearButtonDisabled}
              isApplyButtonDisabled={isApplyButtonDisabled}
            />
          )}
        </div>
      </ClickAwayListener>
    </div>
  );
};

export default DateRangeFilter;
