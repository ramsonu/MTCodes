import React, { useEffect } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { parseISO, getMonth } from 'date-fns';
import { downloadCsv } from 'utils/util';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const BarChartWithRCJ = (props: any) => {
  const {
    data,
    chartRef = null,
    trigger = false,
    setTrigger = () => {},
  } = props;

  useEffect(() => {
    if (trigger) {
      downloadCsv(dataForCsv, 'Sales Overview');
      setTrigger(false);
    }
  }, [trigger]);

  const formatYAxisLabel = (value: any) => {
    if (value >= 1000) {
      return `$${(value / 1000)?.toFixed(1)}K`;
    }
    return `$${value?.toString()}`;
  };

  const options: any = {
    responsive: true,
    scales: {
      x: {
        grid: {
          display: true, // Show the y-axis grid lines
          drawBorder: false, // Hide the y-axis border
          drawOnChartArea: false, // Do not draw the grid lines within the chart area
        },
        ticks: {
          display: true,
          font: {
            family: 'Inter',
            style: 'normal',
            weight: 400,
            size: 12,
          },
          color: '#949494', // Set x-axis tick color
        },
      },
      y: {
        title: {
          display: false, // Hide y-axis title
        },
        grid: {
          display: true, // Show the y-axis grid lines
          drawBorder: true, // Hide the y-axis border
          drawOnChartArea: false, // Do not draw the grid lines within the chart area
        },
        ticks: {
          display: true,
          font: {
            family: 'Inter',
            style: 'normal',
            weight: 400,
            size: 12,
          },
          color: '#949494', // Set y-axis tick color
          callback: (value: any) => formatYAxisLabel(value), // Format y-axis labels
          // maxTicksLimit: 7, // Increase the number of ticks on the x-axis
        },
      },
    },
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          usePointStyle: true,
          pointStyle: 'circle',
          boxHeight: 5,
          padding: 12,
          font: {
            family: 'Inter',
            style: 'normal',
            weight: 400,
            size: 12,
          },
          color: '#949494',
        },
      },
      title: {
        display: false,
        text: 'Dollar Amount',
      },
    },
    layout: {
      padding: {
        left: 20,
        right: 20,
        top: 0,
        bottom: 0,
      },
    },
    indexAxis: 'x', // Specify the index axis as 'x' for vertical bar chart
    barPercentage: 0.3, // Adjust the width of the bars (0.8 means 80% of available space)
    categoryPercentage: 0.9, // Adjust the width of the categories (0.9 means 90% of available space)
    elements: {
      bar: {
        borderRadius: 10, // Set the border radius to make the ends rounded
      },
    },
  };

  const chartData = {
    labels: [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ],
    datasets: [
      {
        label: 'Dollar Amount',
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        backgroundColor: '#DF5353', // Change the bar color here
      },
    ],
  };

  if (data) {
    data?.forEach((item: any) => {
      const date = parseISO(item?.['WeeklyOrderData.completedAt.month']);
      const month = getMonth(date); // Get the month (0 - January, 1 - February, ..., 11 - December)
      chartData.datasets[0].data[month] =
        item?.['WeeklyOrderData.totalSellingPrice'];
    });
  }

  const dataForCsv = [chartData?.labels, chartData?.datasets?.[0]?.data];

  return (
    <div>
      <div id='bar-chart-fullscreen' ref={chartRef}>
        <Bar data={chartData} options={options} />
      </div>
    </div>
  );
};

export default BarChartWithRCJ;
