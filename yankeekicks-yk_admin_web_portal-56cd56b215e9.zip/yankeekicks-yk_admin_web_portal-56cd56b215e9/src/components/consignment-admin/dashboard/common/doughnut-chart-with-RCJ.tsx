import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Doughnut } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend);

const DoughnutChartWithRCJ = (props: any) => {
  const { data, buyerReg, consignorReg } = props;

  const formatLabel = (label: string) => {
    if (label && !Array.isArray(label)) {
      let words = label?.split(' ');
      if (words?.length > 1) {
        return [words[0], words[1]];
      }
      return label;
    }
  };

  const chartData = {
    labels: [
      formatLabel('Buyer Registrations'),
      formatLabel('Consignors Registrations'),
    ],
    datasets: [
      {
        label: 'Registrations',
        data: [buyerReg, consignorReg],
        backgroundColor: ['#EFA9A9', '#C92626'],
        borderColor: ['#EFA9A9', '#C92626'],
        borderWidth: 1,
      },
    ],
  };

  const chartOptions: any = {
    responsive: true,
    maintainAspectRatio: false, // Disable maintaining aspect ratio
    // Set the desired width and height
    // width: 200,
    // height: 200,
    plugins: {
      legend: {
        position: 'right',
        labels: {
          usePointStyle: true,
          pointStyle: 'circle',
          boxHeight: 5,
          // boxWidth: 10, // Adjust the size of the legend items
          padding: 20, // Increase the padding between items
          font: {
            family: 'Inter',
            style: 'normal',
            weight: 400, // Modify the font weight of the labels
            size: 12, // Modify the font size of the labels
          },
          color: '#4F4F4F',
        },
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            const label = context.label;
            return formatLabel(label);
          },
        },
      },
    },
    // rotation: 125, // Adjust the rotation angle here
  };

  const hasData = buyerReg !== 0 || consignorReg !== 0;

  return (
    <div className='doughnutChartWrapper'>
      {hasData ? (
        <Doughnut data={chartData} options={chartOptions} />
      ) : (
        <p className='yk-main-title mb-0'>No data available.</p>
      )}
    </div>
  );
};

export default DoughnutChartWithRCJ;
