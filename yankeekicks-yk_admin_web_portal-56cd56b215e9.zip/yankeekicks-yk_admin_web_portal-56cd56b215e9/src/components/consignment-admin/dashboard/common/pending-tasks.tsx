import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { CircularProgress } from '@mui/material';
import { PENDING_TASKS_URL } from 'services/apiUrl';
import { doRequest } from 'utils/request';
import { getBasePath } from 'utils/util';
import NoDataFound from 'components/common/no-data-found';

const PendingTasks = (props: any) => {
  const {
    locId,
    userInputDate,
    monthStartDate,
    todaysDate,
    shouldFetchPendingTasks,
    setShouldFetchPendingTasks,
  } = props;

  const router = useRouter();

  const [pendingTasksData, setPendingTasksData] = useState<any>([]);
  const [pendingItems, setPendingItems] = useState<any>([]);
  const [pendingTasksLoading, setPendingTasksLoading] =
    useState<boolean>(false);
  const [pendingTasksHasError, setPendingTasksHasError] =
    useState<boolean>(false);

  useEffect(() => {
    // if (locId) {
    setShouldFetchPendingTasks(true);
    // }
  }, []);
  // }, [locId]);

  useEffect(() => {
    const fetchPendingTask = async () => {
      try {
        setPendingTasksLoading(true);
        const pendingTaskResponse: any = await doRequest(
          PENDING_TASKS_URL,
          'get'
        );
        if (
          pendingTaskResponse?.status === 401 ||
          pendingTaskResponse?.status === 403
        ) {
          // todo: logout the user
          setPendingTasksLoading(false);
          setPendingTasksHasError(true);
        } else {
          if (
            pendingTaskResponse?.data &&
            (pendingTaskResponse?.status === 200 ||
              pendingTaskResponse?.status === 201)
          ) {
            setPendingTasksData(pendingTaskResponse?.data);
            setPendingTasksLoading(false);
          } else {
            setPendingTasksData([]);
            setPendingTasksLoading(false);
          }
        }
      } catch (error: any) {
        console.log('pending task error: ', error);
        setPendingTasksData([]);
        setPendingTasksLoading(false);
        setPendingTasksHasError(true);
      }
    };

    if (shouldFetchPendingTasks) {
      fetchPendingTask();
    }
  }, [shouldFetchPendingTasks]);

  // * Filter out commission request from pending task if it is consignment_admin
  useEffect(() => {
    if (pendingTasksData?.length > 0) {
      const role: any = localStorage?.getItem('user-role');
      if (role?.toLowerCase() === 'consignment_admin') {
        const filteredItems: any = pendingTasksData?.filter(
          (item: any) =>
            !(
              item?.name === 'Commission request' ||
              item?.eventUrl === 'manage-commissions'
            )
        );
        setPendingItems(filteredItems);
      } else {
        setPendingItems(pendingTasksData);
      }
    } else {
      setPendingItems([]);
    }
  }, [pendingTasksData]);

  const taskNavigator = (selectedTask: any) => {
    let pathToNavigate = selectedTask?.eventUrl;
    const isCommissionRequest =
      selectedTask?.eventUrl === 'manage-commissions' ||
      selectedTask?.name === 'Commission request';
    if (selectedTask?.objectId && !isCommissionRequest) {
      pathToNavigate = pathToNavigate?.concat(`/${selectedTask?.objectId}`);
    }
    if (selectedTask?.eventUrl && pathToNavigate) {
      router.push(getBasePath(pathToNavigate));
    }
  };

  return (
    <div className='yk-cards pending-task-card'>
      <div className='yk-cards-heading'>Pending Tasks</div>
      {pendingTasksHasError ? (
        <NoDataFound />
      ) : pendingTasksLoading ? (
        <div className='YKCH-loader yk-dashboardLoader '>
          <CircularProgress />
        </div>
      ) : pendingItems?.length > 0 ? (
        <div className='yk-card-body'>
          <ul className='list-group'>
            {pendingItems?.map((task: any, index: number) => {
              return (
                <li
                  className='list-group-item'
                  key={index}
                  onClick={() => taskNavigator(task)}>
                  {task?.pendingTaskId || ''}{' '}
                  {task?.pendingTaskId && task?.name && '-'}{' '}
                  {task?.name || '--'}
                </li>
              );
            })}
          </ul>
        </div>
      ) : (
        <NoDataFound />
      )}
    </div>
  );
};

export default PendingTasks;
