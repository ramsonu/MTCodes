import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import { CircularProgress } from '@mui/material';
import { getTopConsignorSales } from 'middleware/cubejs-wrapper/dashboard-queries';
import {
  convertPriceToUSFormat,
  getBasePath,
  getTrimmedText,
} from 'utils/util';
import NoDataFound from 'components/common/no-data-found';

const TopConsignors = (props: any) => {
  const {
    locId,
    userInputDate,
    monthStartDate = '',
    todaysDate = '',
    shouldFetchTopConsignorSales,
    setShouldFetchTopConsignorSales,
  } = props;

  const router = useRouter();

  const [topConsignorsSales, setTopConsignorsSales] = useState<any>([]);

  const topConsignorSalesQuery: any = getTopConsignorSales(
    locId,
    userInputDate,
    monthStartDate,
    todaysDate
  );

  useEffect(() => {
    if (locId) {
      setShouldFetchTopConsignorSales(true);
    }
  }, [locId]);

  const {
    resultSet: topConsignorSalesResultSet,
    isLoading: topConsignorSalesLoading,
    error: topConsignorSalesError,
  }: any = useCubeQuery(topConsignorSalesQuery, {
    skip: !shouldFetchTopConsignorSales,
  });

  useEffect(() => {
    if (
      topConsignorSalesError?.status === 401 ||
      topConsignorSalesError?.status === 403
    ) {
      // todo: logout the user
    } else {
      const data: any = topConsignorSalesResultSet?.loadResponses[0]?.data;
      if (data) {
        setTopConsignorsSales(data);
        setShouldFetchTopConsignorSales(false);
      } else {
        setTopConsignorsSales([]);
      }
    }
  }, [topConsignorSalesResultSet, topConsignorSalesError]);

  const consignorNavigationHandler = (consignorId: any) => {
    if (consignorId) {
      router.push(getBasePath(`consignors/${consignorId}`));
    }
  };

  return (
    <div className='yk-cards top-consignor-card'>
      <div className='yk-cards-heading'>Top Consignor Sales</div>
      <div className='yk-card-body'>
        {topConsignorSalesError ? (
          <NoDataFound />
        ) : topConsignorSalesLoading ? (
          <div className='YKCH-loader'>
            <CircularProgress />
          </div>
        ) : topConsignorsSales?.length > 0 ? (
          <ul className='list-group'>
            {topConsignorsSales?.map((sale: any, index: any) => {
              return (
                <li
                  className='list-group-item'
                  key={index}
                  onClick={() =>
                    consignorNavigationHandler(
                      sale?.['TopConsignorSales.consigneeId']
                    )
                  }>
                  <div className='d-flex justify-content-between'>
                    <div
                      className='consignor-name'
                      title={sale?.['TopConsignorSales.fullName'] || '--'}>
                      {sale?.['TopConsignorSales.fullName'] &&
                      sale?.['TopConsignorSales.fullName']?.length > 15
                        ? getTrimmedText(
                            sale?.['TopConsignorSales.fullName'],
                            15
                          )
                        : sale?.['TopConsignorSales.fullName'] || '--'}
                    </div>
                    <div className='consignor-amount'>
                      {sale?.['TopConsignorSales.sellingPriceSum']
                        ? convertPriceToUSFormat(
                            sale?.['TopConsignorSales.sellingPriceSum']
                          )
                        : '$0.00'}
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        ) : (
          <NoDataFound />
        )}
      </div>
    </div>
  );
};

export default TopConsignors;
