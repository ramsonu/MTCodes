import React, { useEffect, useState, useMemo, useRef } from 'react';
import { useRouter } from 'next/router';
import Breadcrumbs from 'components/common/breadcrumbs';
import Image from 'next/image';
import SearchComp from 'components/common/search';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import filterIcon from 'assets/images/filter-icon.png';
import { useCubeQuery } from '@cubejs-client/react';
import {
  getConsignmentDetailsById,
  getConsignmentDetailsByIdPaginationCount,
} from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import {
  CONSIGNMENT_REVIEW_REJECTED,
  CONSIGNMENT_REVIEW_APPROVED,
  CONSIGNMENT_REVIEW_APPROVE_STATUS,
} from 'utils/constants';
import VirtualTable from 'components/common/table';
import Sortings from 'components/common/sortings';
import ProductFilters from 'components/common/filters/product-filter';
import NoDataFound from 'components/common/no-data-found';
import { Button } from '@mui/material';
import ChecklistPopupModal from 'components/common/checklist-popup';
import { getBasePath } from 'utils/util';
import Notification from 'components/common/notification';
import ConsignmentIcon from 'assets/images/menu-icons/consignment-default.svg';
import CircleLoader from 'components/common/loader/circular-loader';
import Pagination from 'components/common/pagination';
import ConsignmentDetailsHeader from './consignment-details-header';

const ConsignmentDetails = () => {
  const router = useRouter();
  const componentRef: any = useRef(null);
  const { consignmentId } = router.query;
  const [selectedSkuDetails, setSelectedSkuDetails] = useState<any>([]);
  const [showDetailsModal, setShowDetailsModal] = useState<any>(false);
  const [selectedProductDetails, setSelectedProductDetails] = useState<any>([]);
  const [consignmentDetailsData, setConsignmentDetailsData] = useState<any>([]);
  const [userInput, setUserInput] = useState<any>('');
  const [selectedSort, setSelectedSort] = useState('skuAsc');
  const [showFilters, setShowFilters] = useState(false);
  const [filterInput, setFilterInput] = useState<any>({});
  const [selectedStatus, setSelectedStatus] = useState<any>([]);
  const [clearDisable, setClearDisable] = useState(true);
  const [checked, setChecked] = useState({
    Pending: false,
    Approved: false,
    Rejected: false,
  });
  const [skuList, setSkuList] = useState<any>([]);
  const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
  const [isVisibleMessage, setIsVisibleMessage] = useState<any>(false);
  const [severityType, setSeverityType] = useState<any>('');
  const [notificationMessage, setNotificationMessage] = useState<any>('');
  const [isAllCheckBoxChecked, setIsAllCheckBoxChecked] = useState(false);
  const [enableReviewConsignmentBtn, setEnableReviewConsignmentBtn] =
    useState(false);
  const [showRejectPopup, setShowRejectPopup] = useState(false);
  const itemsPerPage = 10;
  const [searchOffset, setSearchOffset] = useState<any>(0);
  const [countForPagination, setCountForPagination] = useState(0);
  const columns = useMemo(
    () => [
      {
        type: 'consignmentReviewCheckbox',
        title: '',
        onChange: (e: any, data: any, tableData: any) => {
          handleCheckBoxChecked(e, data, tableData);
        },
        checked: 'isChecked',
        checkAll: (e: any, tableData: any) => handleCheckAll(e, tableData),
        value: 'ConsignmentviewDetails.sku',
        isAllChecked: isAllCheckBoxChecked,
        isDisabled: 'checkboxDisabled',
      },
      {
        title: 'SKU',
        type: 'copyToClipboard',
        value: 'ConsignmentviewDetails.sku',
      },
      {
        title: 'Product',
        value: 'ConsignmentviewDetails.itemName',
      },
      {
        title: 'Quantity',
        value: 'ConsignmentviewDetails.skulevelCount',
      },
      {
        title: 'Status',
        type: 'status',
        value: 'ConsignmentviewDetails.status',
        success: 'Completed',
        danger: 'Pending',
        reject: 'Rejected',
        warning: 'Yet To Start',
        consignment: true,
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          router.push(
            `${getBasePath(
              `shipments/${data?.['ConsignmentviewDetails.consignmentID']}/${data?.['ConsignmentviewDetails.sku']}?consignorName=${data?.['ConsignmentviewDetails.userName']}`
            )}`
          );
        },
        value: 'Review',
      },
    ],
    []
  );
  const consignmentDetailsByIdQuery: any = getConsignmentDetailsById(
    consignmentId,
    userInput,
    selectedSort,
    filterInput,
    userDetails,
    searchOffset,
    itemsPerPage
  );

  const {
    resultSet: consignmentDetailsResultSet,
    isLoading: consignmentDetailsIsLoading,
    error: consignmentDetailsError,
  }: any = useCubeQuery(consignmentDetailsByIdQuery);

  const consignmentDetailsByIdPaginationQuery: any =
    getConsignmentDetailsByIdPaginationCount(
      consignmentId,
      userInput,
      selectedSort,
      filterInput,
      userDetails
    );
  const { resultSet: consignmentDetailsByIdPaginationQueryResultSet }: any =
    useCubeQuery(consignmentDetailsByIdPaginationQuery);

  const headers = {
    title: 'Shipments',
    titleImage: ConsignmentIcon,
    subTitle:
      consignmentDetailsData[0]?.['ConsignmentviewDetails.consignmentID'],
    onClick: () => {
      router?.push(`${getBasePath('shipments')}`);
    },
  };

  useEffect(() => {
    const data = consignmentDetailsResultSet?.loadResponses[0]?.data;
    const paginationCountdata =
      consignmentDetailsByIdPaginationQueryResultSet?.loadResponses[0]
        ?.data[0]?.['ConsignmentviewDetails.count'];
    if (data) {
      setConsignmentDetailsData(addCheckPropertyToData(data, false));
    } else {
      setConsignmentDetailsData([]);
    }
    if (paginationCountdata) {
      let countData = +paginationCountdata || 0;
      setCountForPagination(countData);
    } else {
      setCountForPagination(0);
    }
  }, [
    consignmentDetailsResultSet,
    consignmentDetailsByIdPaginationQueryResultSet,
  ]);

  useEffect(() => {
    if (skuList.length == consignmentDetailsData.length)
      setIsAllCheckBoxChecked(true);
    else setIsAllCheckBoxChecked(false);
    if (skuList.length > 0) setEnableReviewConsignmentBtn(true);
    else setEnableReviewConsignmentBtn(false);
  }, [skuList]);

  const handleShowNotification = (status: string, errorMessage = false) => {
    if (!errorMessage) {
      setIsVisibleMessage(true);
      setSeverityType('success');
      setNotificationMessage(
        status == CONSIGNMENT_REVIEW_APPROVE_STATUS
          ? CONSIGNMENT_REVIEW_APPROVED
          : CONSIGNMENT_REVIEW_REJECTED
      );
      setTimeout(() => {
        router.push(`${getBasePath('shipments')}`);
      }, 1000);
    } else {
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setNotificationMessage(errorMessage);
    }
  };

  const onChangeHandler = (event: any) => {
    setUserInput(event.target.value);
    setSearchOffset(0);
  };

  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
  };

  const onStatusChange = (event: any) => {
    setChecked({ ...checked, [event?.target?.name]: event?.target?.checked });
    let updatedList = [...selectedStatus];
    if (event.target.checked) {
      updatedList = [...selectedStatus, event.target.name];
    } else {
      updatedList.splice(selectedStatus.indexOf(event.target.name), 1);
    }
    setSelectedStatus(updatedList);
    if (updatedList.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  };
  const onSkuChange = (event: any) => {
    if (selectedSkuDetails.includes(event?.target?.name)) {
      let tempOption = [];
      tempOption = selectedSkuDetails.filter(
        (data: any) => data !== event?.target?.name
      );
      setSelectedSkuDetails(tempOption);
      if (tempOption.length === 0) {
        setClearDisable(true);
      }
    } else {
      setSelectedSkuDetails([...selectedSkuDetails, event?.target?.name]);
      setClearDisable(false);
    }
  };
  const onProductChange = (event: any) => {
    if (selectedProductDetails.includes(event?.target?.name)) {
      let tempOption = [];
      tempOption = selectedProductDetails.filter(
        (data: any) => data !== event?.target?.name
      );
      setSelectedProductDetails(tempOption);
      if (tempOption.length === 0) {
        setClearDisable(true);
      }
    } else {
      setSelectedProductDetails([
        ...selectedProductDetails,
        event?.target?.name,
      ]);
      setClearDisable(false);
    }
  };
  const onApplyFilters = () => {
    const filterPayload = {
      status: selectedStatus,
      sku: selectedSkuDetails,
      product: selectedProductDetails,
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setShowFilters(false);
    setSearchOffset(0);
  };

  const onClearFilters = () => {
    setShowFilters(false);
    setSelectedStatus([]);
    setSelectedProductDetails([]);
    setSelectedSkuDetails([]);
    setChecked({ Pending: false, Approved: false, Rejected: false });
    setFilterInput({});
    setClearDisable(true);
    setSearchOffset(0);
  };

  const addCheckPropertyToData = (
    tempConsignmentDetailsData: any,
    checkedStatus: boolean,
    dataItem?: any
  ) => {
    if (!!dataItem) {
      tempConsignmentDetailsData = tempConsignmentDetailsData.map(
        (lineItem: any) => {
          if (
            lineItem['ConsignmentviewDetails.sku'] ==
            dataItem['ConsignmentviewDetails.sku']
          )
            return updateLineItem(lineItem, checkedStatus);
          else return updateLineItem(lineItem, lineItem?.isChecked);
        }
      );
    } else
      tempConsignmentDetailsData = tempConsignmentDetailsData.map(
        (lineItem: any) => {
          return updateLineItem(lineItem, checkedStatus);
        }
      );
    setSkuList(
      tempConsignmentDetailsData
        .filter((item: any) => item.isChecked === true)
        .map((item: any) => {
          return { skuId: item?.['ConsignmentviewDetails.sku'] };
        })
    );
    return tempConsignmentDetailsData;
  };

  const updateLineItem = (lineItem: any, checkedStatus: boolean) => {
    const checkboxDisabled = !(
      lineItem['ConsignmentviewDetails.status'] === 'Yet To Start' ||
      lineItem['ConsignmentviewDetails.status'] === 'Pending' ||
      lineItem['ConsignmentviewDetails.status'] === ''
    );
    return {
      ...lineItem,
      isChecked: checkboxDisabled ? false : checkedStatus,
      checkboxDisabled: checkboxDisabled,
    };
  };
  const handleCheckAll = (event: any, tableData: any) => {
    setIsAllCheckBoxChecked(event?.target?.checked);
    setConsignmentDetailsData(
      addCheckPropertyToData(tableData, event?.target?.checked)
    );
  };

  const handleCheckBoxChecked = (e: any, data: any, tableData: any) => {
    const updatedData = addCheckPropertyToData(
      tableData,
      e?.target?.checked,
      data
    );
    setConsignmentDetailsData(updatedData);
  };

  return (
    <>
      <div className='container-fluid'>
        <div className='row'>
          <Breadcrumbs data={headers} />
        </div>
      </div>

      <div className='app-wrapper w-100 consignment-consignments-details-page-wrapper'>
        <div className='orders-page-inner-wrapper'>
          <div className='container-fluid'>
            <div className='row'>
              <div className='col-lg-12 col-md-12 col-sm-12 consignmentDetailsHeader'>
                <div className='heading-wrapper orders-heading-wrapper'>
                  <h2 className='heading'>
                    {
                      consignmentDetailsData[0]?.[
                        'ConsignmentviewDetails.consignmentID'
                      ]
                    }
                  </h2>
                  <div className='sort-product-wrapper add-product-btn'>
                    <div>
                      <Button
                        className='MuiButtonBase-root'
                        onClick={() => setShowDetailsModal(true)}
                        disabled={
                          consignmentDetailsData[0]?.[
                            'ConsignmentviewDetails.consignmentStatus'
                          ] === 'Approved'
                            ? true
                            : !enableReviewConsignmentBtn
                        }>
                        Review Shipment
                      </Button>
                    </div>
                  </div>
                </div>
                <h5 className='sub-haeding'>Shipment details</h5>
              </div>
            </div>
          </div>
          <ConsignmentDetailsHeader />
          <div className='container-fluid'>
            <div className='row'>
              <div className='col-lg-12 col-md-12 col-sm-12'>
                <div className='ConsignmentsWrap'>
                  <div className='yk-sku-titles YKCH-detailTitle'>
                    <h2 className='yk-prod-main-titles mt-1 mb-3 YK-LKEEEE'>
                      Inventory
                    </h2>
                  </div>
                  <div className='search-btn-wrapper'>
                    <div className='row'>
                      <div className='col-xl-4 col-lg-12 col-md-12 col-sm-12 col-12'>
                        <div className='YKCH-searchingData'>
                          <SearchComp
                            optionType='change'
                            placeholder='Search'
                            onChangeHandler={onChangeHandler}
                          />
                        </div>
                      </div>
                      <div className='col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12'>
                        <div className='consignment-btn-wrapper'>
                          <div>
                            <Sortings
                              itemKey='consignmentDetails'
                              handleChange={sortHandler}
                              defaultSelectedValue={selectedSort}
                            />
                          </div>
                          <div className='filter-btn-wrapper YKCH-filterWrapperr'>
                            <ClickAwayListener
                              onClickAway={() => {
                                setShowFilters(false);
                              }}>
                              <div className='YKCH-filterBTNWrapp me-0'>
                                <button
                                  className='btn filter-btn '
                                  onClick={() => setShowFilters(!showFilters)}>
                                  <Image
                                    src={filterIcon}
                                    alt='filter-btn-icon'
                                    className='filter-btn-icon img-fluid'
                                  />
                                  <span className='filter-btn-text yk-badge-h15'>
                                    Filter
                                  </span>
                                </button>
                                {showFilters && (
                                  <ProductFilters
                                    itemKey='consignmentDetails'
                                    component='consignmentDetails'
                                    data={consignmentDetailsData}
                                    onPayoutChange={onStatusChange}
                                    checkedValue={checked}
                                    checkedSkuValue={selectedSkuDetails}
                                    checkedProductValue={selectedProductDetails}
                                    onSkuChange={onSkuChange}
                                    onProductChange={onProductChange}
                                    onApplyClick={onApplyFilters}
                                    onClearFilters={onClearFilters}
                                    clearDisable={clearDisable}
                                  />
                                )}
                              </div>
                            </ClickAwayListener>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {consignmentDetailsError ? (
                    <p>Something went wrong!</p>
                  ) : consignmentDetailsIsLoading ? (
                    <CircleLoader />
                  ) : consignmentDetailsData &&
                    consignmentDetailsData?.length > 0 ? (
                    <VirtualTable
                      ref={componentRef}
                      headers={columns}
                      rowData={consignmentDetailsData}
                      loading={consignmentDetailsIsLoading}
                      error={consignmentDetailsError}
                    />
                  ) : (
                    <NoDataFound ref={componentRef} />
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
        {
          <ChecklistPopupModal
            showModal={showDetailsModal}
            setShowDetailsModal={setShowDetailsModal}
            consignmentId={consignmentId}
            consignorName={
              consignmentDetailsData[0]?.['ConsignmentviewDetails.userName']
            }
            sku={skuList}
            handleShowNotification={handleShowNotification}
            showRejectPopup={showRejectPopup}
            setShowRejectPopup={setShowRejectPopup}
          />
        }
        <Notification
          showSuccessPopup={isVisibleMessage}
          handleSnackbarClose={() => setIsVisibleMessage(false)}
          severityType={severityType}
          message={notificationMessage}
          className='yk-shoesize-alert-wrapper'
        />
        {countForPagination > 0 && (
          <div className='center-pagination'>
            <Pagination
              lengthOfData={countForPagination}
              itemsPerPage={itemsPerPage}
              currentOffset={searchOffset}
              setOffset={setSearchOffset}
            />
          </div>
        )}
      </div>
    </>
  );
};
export default ConsignmentDetails;
