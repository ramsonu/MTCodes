import {
  Box,
  Button,
  Menu,
  MenuItem,
  MobileStepper,
  Paper,
  useTheme,
} from '@mui/material';
import React, { useEffect, useState } from 'react';
import DotsThreeVertical from 'assets/images/DotsThreeVertical.svg';
import { getBrandNameFromSku } from 'services/consignment';
import { getBasePath } from 'utils/util';
import { useRouter } from 'next/router';
import Image from 'next/image';
import { useCubeQuery } from '@cubejs-client/react';
import { getConsignmentSkuDetailsHeader } from 'middleware/cubejs-wrapper/cubejs-page-header-query';
import { FNS_DATE_FORMAT } from 'utils/constants';
import { format } from 'date-fns';
import CopyToClipboardComponent from 'components/common/copyToClipboard';
import { KeyboardArrowLeft, KeyboardArrowRight } from '@mui/icons-material';
import ImageLoader from 'components/common/image-loader';
import productImg from 'assets/images/big-product-img.svg';
import CatalogDetailsModal from '../orders/catalog-details-modal';

const ConsignmentSkuDetailsHeader = () => {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [skuDetailsImages, setSkuDetailsImages] = useState<any>([]);
  const open = Boolean(anchorEl);
  const router = useRouter();
  const { consignmentId } = router.query;
  const [activeStep, setActiveStep] = React.useState(0);
  let sku: any = Array.isArray(router?.query?.sku)
    ? router?.query?.sku.join('/')
    : router?.query?.sku;
  const [shouldFetchDataOfRequestId, setShouldFetchTransfersHeaderData] =
    useState<boolean>(false);
  const [skuDetailsData, setSkuDetailsData] = useState<any>([]);
  const consignmentDetailsHeaderData: any = getConsignmentSkuDetailsHeader(
    consignmentId,
    sku
  );
  const theme = useTheme();
  const [showModal, setShowModal] = useState<boolean>(false);

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const { resultSet: consignmentDetailsResultSet }: any = useCubeQuery(
    consignmentDetailsHeaderData,
    {
      skip: shouldFetchDataOfRequestId,
    }
  );
  const initData = async () => {
    setSkuDetailsData(consignmentDetailsResultSet?.loadResponses[0]?.data);
    const param = {
      id: consignmentDetailsResultSet?.loadResponses[0]?.data[0]?.[
        'ConsignmentSkuDetails.style'
      ],
    };
    try {
      await getBrandNameFromSku(param).then((response: any) => {
        const imageUrls = response?.data[0]?.catalogueImageList;
        setSkuDetailsImages(imageUrls);
      });
    } catch (e: any) {
      console.log(e);
    }
  };

  useEffect(() => {
    if (!!router.query.consignmentId) {
      setShouldFetchTransfersHeaderData(true);
    } else {
      setShouldFetchTransfersHeaderData(false);
    }
  }, [router?.query]);

  useEffect(() => {
    initData();
  }, [consignmentDetailsResultSet]);

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const viewShowDetails = () => {
    setShowModal(true);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  return (
    <div className='container-fluid'>
      <div className='row'>
        <div className='col-lg-12 col-md-12 col-sm-12'>
          <div className='yk-sku-topwrap yk-sku-custom-topwrapper'>
            <div className='row'>
              <div className='col-lg-12 pe-0'>
                <div className='yk-sku-titles d-flex justify-content-between'>
                  <h2 className='yk-prod-main-titles mt-1 mb-3'>
                    {skuDetailsData?.[0]?.['ConsignmentSkuDetails.itemName']}
                  </h2>
                  <div>
                    <Button
                      id='basic-button'
                      aria-controls={open ? 'basic-menu' : undefined}
                      aria-haspopup='true'
                      aria-expanded={open ? 'true' : undefined}
                      onClick={handleClick}>
                      <Image src={DotsThreeVertical} alt='' title='' />
                    </Button>
                    <Menu
                      id='basic-menu'
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      MenuListProps={{
                        'aria-labelledby': 'basic-button',
                      }}>
                      <MenuItem onClick={() => viewShowDetails()}>
                        SKU Details
                      </MenuItem>

                      <MenuItem
                        onClick={() =>
                          router.push(
                            getBasePath(`inventory/shoe-catalog?sku=${sku}`)
                          )
                        }>
                        Show in Catalog
                      </MenuItem>
                    </Menu>
                  </div>
                </div>
              </div>
            </div>
            <div className='row mb-2'>
              <div className='col-lg-3 col-sm-12 payout-status'>
                <div className='yk-order-title w-50'>
                  <Box sx={{ flexGrow: 1 }}>
                    <Paper
                      square
                      elevation={0}
                      sx={{
                        display: 'flex',
                        alignItems: 'center',

                        pl: 2,
                        bgcolor: 'background.default',
                      }}></Paper>
                    <ImageLoader
                      src={skuDetailsImages?.[activeStep]}
                      fallbackImg={productImg}
                      alt='cart-img'
                      className='img-fluid m-auto d-block img-product-logo'
                    />
                    <MobileStepper
                      steps={skuDetailsImages?.length}
                      position='static'
                      activeStep={activeStep}
                      nextButton={
                        <Button
                          className='next-arrow'
                          size='small'
                          onClick={handleNext}
                          disabled={
                            activeStep === skuDetailsImages?.length - 1
                          }>
                          {theme.direction === 'rtl' ? (
                            <KeyboardArrowLeft />
                          ) : (
                            <KeyboardArrowRight />
                          )}
                        </Button>
                      }
                      backButton={
                        <Button
                          className='back-arrow'
                          size='small'
                          onClick={handleBack}
                          disabled={activeStep === 0}>
                          {theme.direction === 'rtl' ? (
                            <KeyboardArrowRight />
                          ) : (
                            <KeyboardArrowLeft />
                          )}
                        </Button>
                      }
                    />
                  </Box>
                </div>
              </div>
              <div className='col-lg-9  col-sm-12 order-status ps-lg-0'>
                <div className='container-fluid ps-lg-0 pe-lg-0'>
                  <div className='row'>
                    <div className='yk-prod-details-card-wrap row mb-2'>
                      <div className='yk-order-title col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12'>
                        <h4>
                          Quantity:
                          <span className='yk-order-details'>
                            {' '}
                            {
                              skuDetailsData?.[0]?.[
                                'ConsignmentSkuDetails.Quantity'
                              ]
                            }
                          </span>
                        </h4>
                      </div>
                      <div className='yk-order-title col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12'>
                        <h4>
                          SKU:
                          <span className='yk-order-details' id='sku'>
                            {' '}
                            {
                              skuDetailsData?.[0]?.[
                                'ConsignmentSkuDetails.style'
                              ]
                            }
                            <CopyToClipboardComponent
                              copyText={
                                skuDetailsData?.[0]?.[
                                  'ConsignmentSkuDetails.style'
                                ]
                              }
                            />
                          </span>
                        </h4>
                      </div>
                    </div>
                    <div className='yk-prod-details-card-wrap row'>
                      <div className='yk-order-title col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12'>
                        <h4>
                          Colorway:
                          <span className='yk-order-details'>
                            {' '}
                            {
                              skuDetailsData?.[0]?.[
                                'ConsignmentSkuDetails.colorway'
                              ]
                            }
                          </span>
                        </h4>
                      </div>
                      <div className='yk-order-title col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12'>
                        <h4>
                          Size Type:
                          <span className='yk-order-details'>
                            {' '}
                            {
                              skuDetailsData?.[0]?.[
                                'ConsignmentSkuDetails.sizeType'
                              ]
                            }
                          </span>
                        </h4>
                      </div>

                      <div className='yk-order-title col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12'>
                        <h4>
                          Release Date:
                          <span className='yk-order-details'>
                            {skuDetailsData?.[0]?.[
                              'ConsignmentSkuDetails.releaseDate'
                            ]
                              ? format(
                                  new Date(
                                    skuDetailsData?.[0]?.[
                                      'ConsignmentSkuDetails.releaseDate'
                                    ]
                                  ),
                                  FNS_DATE_FORMAT
                                )
                              : '--'}
                          </span>
                        </h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <CatalogDetailsModal
        showModal={showModal}
        handleClose={setShowModal}
        orderDetails={'Inventory'}
        skuId={sku}
        productInfo={skuDetailsData?.[0]}
        showBrand={false}
        isShoeCatalog={true}
        catalogTableName='ConsignmentSkuDetails'
      />
    </div>
  );
};
export default ConsignmentSkuDetailsHeader;
