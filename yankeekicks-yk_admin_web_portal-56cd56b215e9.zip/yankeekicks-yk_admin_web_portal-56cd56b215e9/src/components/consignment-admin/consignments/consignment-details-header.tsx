import { Button, Menu, MenuItem } from '@mui/material';
import React, { useEffect, useState } from 'react';
import DotsThreeVertical from 'assets/images/DotsThreeVertical.svg';
import { downloadPrintApprovedLabelsPDF } from 'services/consignment';
import { convertPriceToUSFormat, getBasePath } from 'utils/util';
import { useRouter } from 'next/router';
import Image from 'next/image';
import { useCubeQuery } from '@cubejs-client/react';
import { getConsignmentDetailsHeader } from 'middleware/cubejs-wrapper/cubejs-page-header-query';
import ConfirmPopup from 'components/common/confirm-popup';
import copyIcon from 'assets/images/grey-copy-icon.svg';
import CopyToClipboardComponent from 'components/common/copyToClipboard';

const ConsignmentDetailsHeader = () => {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const router = useRouter();
  const { consignmentId } = router.query;
  const [consignmentDetailsData, setConsignmentDetailsData] = useState<any>([]);
  const [consignmentTackingFlag, setConsignmentTackingFlag] =
    useState<boolean>(false);
  const [shouldFetchDataOfRequestId, setShouldFetchTransfersHeaderData] =
    useState<boolean>(false);
  const consignmentDetailsHeaderData: any =
    getConsignmentDetailsHeader(consignmentId);
  const { resultSet: consignmentDetailsResultSet }: any = useCubeQuery(
    consignmentDetailsHeaderData,
    {
      skip: shouldFetchDataOfRequestId,
    }
  );
  const initData = () => {
    setConsignmentDetailsData(
      consignmentDetailsResultSet?.loadResponses[0]?.data
    );
  };

  useEffect(() => {
    if (!!router.query.consignmentId) {
      setShouldFetchTransfersHeaderData(true);
    } else {
      setShouldFetchTransfersHeaderData(false);
    }
  }, [router?.query]);

  useEffect(() => {
    initData();
  }, [consignmentDetailsResultSet]);

  const navigateToConignorProfile = () => {
    router.push(
      getBasePath(
        `consignors/${consignmentDetailsData?.[0]?.['ConsignmentviewDetails.consigneeId']}`
      )
    );
  };

  const onHandleClick = async () => {
    await downloadPrintApprovedLabelsPDF(
      'Print Approved labels',
      consignmentId
    );
  };

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  return (
    <div className='container-fluid'>
      <div className='ConsignmentsWrap mb-4'>
        <div className='row'>
          <div className='col-lg-12 col-md-12 col-sm-12'>
            <div className='heading-wrapper orders-heading-wrapper '>
              <h2 className='yk-badge-h5 heading'>Consignor</h2>
              <div>
                <Button
                  id='basic-button'
                  aria-controls={open ? 'basic-menu' : undefined}
                  aria-haspopup='true'
                  aria-expanded={open ? 'true' : undefined}
                  onClick={handleClick}>
                  <Image src={DotsThreeVertical} alt='' title='' />
                </Button>
                <Menu
                  id='basic-menu'
                  anchorEl={anchorEl}
                  open={open}
                  onClose={handleClose}
                  MenuListProps={{
                    'aria-labelledby': 'basic-button',
                  }}>
                  {(consignmentDetailsData?.[0]?.[
                    'ConsignmentviewDetails.consignmentStatus'
                  ] === 'Completed' ||
                    consignmentDetailsData?.[0]?.[
                      'ConsignmentviewDetails.consignmentStatus'
                    ] === 'Approved') && (
                    <MenuItem onClick={onHandleClick}>
                      Print Approved Labels
                    </MenuItem>
                  )}
                  <MenuItem onClick={() => setConsignmentTackingFlag(true)}>
                    View Tracking Number
                  </MenuItem>
                  <MenuItem onClick={navigateToConignorProfile}>
                    View Consignor Profile
                  </MenuItem>
                </Menu>
              </div>
            </div>
          </div>
        </div>
        <div className='row'>
          <div className='col-lg-6'>
            <div className='yk-con-detail-wrap '>
              <div className='col yk-con-lable-wrap text-left'>
                <div className='yk-consignor-title'>
                  {consignmentDetailsData?.[0]?.[
                    'ConsignmentviewDetails.userName'
                  ]
                    ? consignmentDetailsData?.[0]?.[
                        'ConsignmentviewDetails.userName'
                      ]
                    : '--'}
                </div>
                <div className='yk-consignor-status'>
                  {consignmentDetailsData?.[0]?.[
                    'ConsignmentviewDetails.emailId'
                  ]
                    ? consignmentDetailsData?.[0]?.[
                        'ConsignmentviewDetails.emailId'
                      ]
                    : ''}{' '}
                  .
                  {consignmentDetailsData?.[0]?.[
                    'ConsignmentviewDetails.PhoneNumber'
                  ]
                    ? `+${consignmentDetailsData?.[0]?.['ConsignmentviewDetails.PhoneNumber']}`
                    : ''}
                </div>
              </div>
            </div>
          </div>

          <div className='col-lg-6'>
            <div className='yk-con-detail-wrap yk-con-detail-status'>
              <div className='row'>
                <div className='col yk-con-lable-wrap'>
                  <div className='yk-con-detail-lable'>Shipment Status</div>
                  <div
                    className={`yk-con-detail-status ${
                      consignmentDetailsData?.[0]?.[
                        'ConsignmentviewDetails.consignmentStatus'
                      ] === 'Approved' ||
                      consignmentDetailsData?.[0]?.[
                        'ConsignmentviewDetails.consignmentStatus'
                      ] === 'Completed'
                        ? 'completed'
                        : consignmentDetailsData?.[0]?.[
                            'ConsignmentviewDetails.consignmentStatus'
                          ] === 'Yet To Start'
                        ? 'yet-to-start'
                        : 'pending'
                    }`}>
                    {
                      consignmentDetailsData?.[0]?.[
                        'ConsignmentviewDetails.consignmentStatus'
                      ]
                    }
                  </div>
                </div>
                <div className='col yk-con-lable-wrap'>
                  <div className='yk-con-detail-lable'>Number of Items</div>
                  <div className='yk-con-detail-status'>
                    {
                      consignmentDetailsData?.[0]?.[
                        'ConsignmentviewDetails.numberofItems'
                      ]
                    }
                  </div>
                </div>
                <div className='col yk-con-lable-wrap'>
                  <div className='yk-con-detail-lable'>Shipment Value</div>
                  <div className='yk-con-detail-status'>
                    {consignmentDetailsData?.[0]?.[
                      'ConsignmentviewDetails.consignment_value'
                    ]
                      ? convertPriceToUSFormat(
                          parseFloat(
                            consignmentDetailsData?.[0]?.[
                              'ConsignmentviewDetails.consignment_value'
                            ]
                          )?.toFixed(2)
                        )
                      : '--'}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <ConfirmPopup
        className='yk-trackingNumberModal'
        showPopup={consignmentTackingFlag}
        handleClose={(e: any) => setConsignmentTackingFlag(false)}
        title='Tracking Number'
        confirmButtonName='Close'
        showCancle={false}
        message={
          <div>
            <p className='yk-modalSubTitle'>
              Shipment tracking information entered by the consignor
            </p>
            <div className='yk-trackingDetails'>
              <p className='yk-fieldTitle'>Shiping Vendor</p>
              <h3 className='yk-fieldValue'>
                {consignmentDetailsData?.[0]?.[
                  'ConsignmentviewDetails.vendorName'
                ]
                  ? consignmentDetailsData?.[0]?.[
                      'ConsignmentviewDetails.vendorName'
                    ]
                  : 'NA'}
              </h3>
            </div>
            <div className='yk-trackingDetails'>
              <p className='yk-fieldTitle'>Tracking Number</p>
              <h3 className='yk-fieldValue'>
                {consignmentDetailsData?.[0]?.[
                  'ConsignmentviewDetails.trackingId'
                ]
                  ? consignmentDetailsData?.[0]?.[
                      'ConsignmentviewDetails.trackingId'
                    ]
                  : 'NA'}
                <span className='img-wrapper'>
                  <CopyToClipboardComponent
                    copyText={
                      consignmentDetailsData?.[0]?.[
                        'ConsignmentviewDetails.trackingId'
                      ]
                    }
                  />
                </span>
              </h3>
            </div>
          </div>
        }
        handleSave={() => setConsignmentTackingFlag(false)}
      />
    </div>
  );
};
export default ConsignmentDetailsHeader;
