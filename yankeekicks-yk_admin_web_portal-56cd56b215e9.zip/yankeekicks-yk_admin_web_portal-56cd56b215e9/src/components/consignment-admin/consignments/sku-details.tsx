import React, { useState, useEffect, useMemo } from 'react';
import SearchComp from 'components/common/search';
import Image from 'next/image';
import { Button } from '@mui/material';
import Sortings from 'components/common/sortings';
import VirtualTable from 'components/common/table';
import filterIcon from 'assets/images/filter-icon.png';
import { useCubeQuery } from '@cubejs-client/react';
import { getSkuDetailsByIdQuery } from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import {
  CONSIGNMENT_REVIEW_APPROVED,
  CONSIGNMENT_REVIEW_APPROVE_STATUS,
  CONSIGNMENT_REVIEW_REJECTED,
} from 'utils/constants';
import { useRouter } from 'next/router';
import { useDispatch, useSelector } from 'react-redux';
import Breadcrumbs from 'components/common/breadcrumbs';
import OrderDetailsModal from '../orders/order-details-modal';
import ProductFilters from 'components/common/filters/product-filter';
import { actions } from 'store/reducers/kiosk';
import { getBasePath } from 'utils/util';
import ChecklistPopupModal from 'components/common/checklist-popup';
import Notification from 'components/common/notification';
import ConsignmentIcon from 'assets/images/menu-icons/consignment-default.svg';
import ConsignmentSkuDetailsHeader from './consignment-sku-details-header';

const ConsignmentSkuDetails = () => {
  const [userInput, setUserInput] = useState('');
  const [consignmentLineItemId, setConsignmentLineItemId] = useState(0);
  const [skuDetailsData, setSkuDetailsData] = useState<any>([]);
  const [selectedSort, setSelectedSort] = useState('sellingPriceAsc');
  const [showDetailsModal, setShowDetailsModal] = useState<any>(false);
  const [showReviewDetailsModal, setShowReviewDetailsModal] =
    useState<any>(false);
  const [showFilters, setShowFilters] = useState(false);
  const [filterInput, setFilterInput] = useState<any>({});
  const [selectedStatus, setSelectedStatus] = useState<any>([]);
  const [selectedPriceDetails, setSelectedPriceDetails] = useState<any>([]);
  const [clearDisable, setClearDisable] = useState(true);
  const [checked, setChecked] = useState({
    Pending: false,
    Approved: false,
    Rejected: false,
  });
  const [isVisibleMessage, setIsVisibleMessage] = useState<any>(false);
  const [severityType, setSeverityType] = useState<any>('');
  const [notificationMessage, setNotificationMessage] = useState<any>('');
  const [isAllCheckBoxChecked, setIsAllCheckBoxChecked] = useState(false);
  const [showRejectPopup, setShowRejectPopup] = useState(false);
  const [enableReviewConsignmentBtn, setEnableReviewConsignmentBtn] =
    useState(false);
  const [barCodeList, setBarCodeList] = useState<any>([]);
  const [isShow, setIsShow] = useState(false);

  const router = useRouter();
  const dispatch = useDispatch();
  const { filterTypes } = useSelector((state: any) => state.kiosk);
  let { consignmentId, consignorName } = router.query;
  let sku: any = Array.isArray(router?.query?.sku)
    ? router?.query?.sku.join('/')
    : router?.query?.sku;
  const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');

  const skuDetailsByIdQuery: any = getSkuDetailsByIdQuery(
    consignmentId,
    sku,
    userInput,
    selectedSort,
    filterInput,
    userDetails
  );

  const {
    resultSet: skuDetailsResultSet,
    isLoading: skuDetailsIsLoading,
    error: skuDetailsError,
  }: any = useCubeQuery(skuDetailsByIdQuery);

  const columns = useMemo(
    () => [
      {
        type: 'consignmentReviewCheckbox',
        title: '',
        onChange: (e: any, data: any, tableData: any) => {
          handleCheckBoxChecked(e, data, tableData);
        },
        checked: 'isChecked',
        checkAll: (e: any, tableData: any) => handleCheckAll(e, tableData),
        value: 'ConsignmentSkuDetails.Barcode',
        isAllChecked: isAllCheckBoxChecked,
        consignmentReview: true,
        isDisabled: 'checkboxDisabled',
        //sku
      },
      {
        title: 'Barcode',
        value: 'ConsignmentSkuDetails.Barcode',
      },
      {
        title: 'Size',
        value: 'ConsignmentSkuDetails.size',
      },
      {
        title: 'Condition',
        value: 'ConsignmentSkuDetails.conditionName',
      },
      {
        title: 'Selling Price',
        value: 'ConsignmentSkuDetails.retailPrice_D',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Payout Amount',
        value: 'ConsignmentSkuDetails.payoutAmount',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Cost/Item',
        value: 'ConsignmentSkuDetails.costperItem',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Status',
        type: 'statusList',
        value: 'ConsignmentSkuDetails.status',
        success: 'Approved',
        danger: 'Pending',
        warning: 'Yet To Start',
        consignment: true,
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          viewButtonHandler(data);
        },
        value: 'Details',
      },
    ],
    []
  );

  useEffect(() => {
    const data = skuDetailsResultSet?.loadResponses[0]?.data;
    if (data) {
      setSkuDetailsData(addCheckPropertyToData(data, false));
      setConsignmentLineItemId(
        data?.[0]?.['ConsignmentSkuDetails.consignmentlineitemId_D']
      );
    } else {
      setSkuDetailsData([]);
    }
  }, [skuDetailsResultSet]);

  useEffect(() => {
    if (filterTypes.size.length !== 0 || selectedStatus.length !== 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  });
  useEffect(() => {
    if (barCodeList.length == skuDetailsData.length)
      setIsAllCheckBoxChecked(true);
    else setIsAllCheckBoxChecked(false);
    if (barCodeList.length > 0) setEnableReviewConsignmentBtn(true);
    else setEnableReviewConsignmentBtn(false);
  }, [barCodeList]);

  const headers = {
    title: 'Shipments',
    titleImage: ConsignmentIcon,
    subTitle: consignmentId,
    nextSubTitle: sku,
    onClick: () => {
      router?.push(`${getBasePath('shipments')}`);
    },
    onNextClick: () => {
      router?.push(`${getBasePath(`shipments/${consignmentId}`)}`);
    },
  };

  const onChangeHandler = (event: any) => {
    setUserInput(event.target.value);
  };

  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
  };

  const viewButtonHandler = (data: any) => {
    setConsignmentLineItemId(
      data['ConsignmentSkuDetails.consignmentlineitemId_D']
    );
    setShowDetailsModal(true);
    setIsShow(false);
  };
  const onStatusChange = (event: any) => {
    setChecked({ ...checked, [event?.target?.name]: event?.target?.checked });
    let updatedList = [...selectedStatus];
    if (event.target.checked) {
      updatedList = [...selectedStatus, event.target.name];
    } else {
      updatedList.splice(selectedStatus.indexOf(event.target.name), 1);
    }
    setSelectedStatus(updatedList);
    if (updatedList.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  };

  const onPriceChange = (event: any) => {
    if (selectedPriceDetails.includes(event?.target?.name)) {
      let tempOption = [];
      tempOption = selectedPriceDetails.filter(
        (data: any) => data !== event?.target?.name
      );
      setSelectedPriceDetails(tempOption);
      if (tempOption.length > 0) {
        setClearDisable(false);
      }
    } else {
      setSelectedPriceDetails([...selectedPriceDetails, event?.target?.name]);
      setClearDisable(false);
    }
  };

  const onApplyFilters = () => {
    const filterPayload = {
      status: selectedStatus,
      price: selectedPriceDetails,
      size: filterTypes.size,
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setShowFilters(false);
  };

  const onClearFilters = () => {
    setShowFilters(false);
    setSelectedStatus([]);
    setSelectedPriceDetails([]);
    setChecked({ Pending: false, Approved: false, Rejected: false });
    setFilterInput({});
    setClearDisable(true);
    dispatch(actions.clearAllFilters({}));
  };

  const addCheckPropertyToData = (
    tempConsignmentDetailsData: any,
    checkedStatus: boolean,
    dataItem?: any
  ) => {
    if (!!dataItem) {
      tempConsignmentDetailsData = tempConsignmentDetailsData.map(
        (lineItem: any) => {
          if (
            lineItem['ConsignmentSkuDetails.Barcode'] ==
            dataItem['ConsignmentSkuDetails.Barcode']
          )
            return updateLineItem(lineItem, checkedStatus);
          else return updateLineItem(lineItem, lineItem?.isChecked);
        }
      );
    } else
      tempConsignmentDetailsData = tempConsignmentDetailsData.map(
        (lineItem: any) => {
          return updateLineItem(lineItem, checkedStatus);
        }
      );
    setBarCodeList(
      tempConsignmentDetailsData
        .filter((item: any) => item.isChecked === true)
        .map((item: any) => {
          return item['ConsignmentSkuDetails.Barcode'];
        })
    );
    return tempConsignmentDetailsData;
  };
  const updateLineItem = (lineItem: any, checkedStatus: boolean) => {
    const checkboxDisabled = !(
      lineItem['ConsignmentSkuDetails.status'] == 'Pending' ||
      lineItem['ConsignmentSkuDetails.status'] == 'pending' ||
      lineItem['ConsignmentSkuDetails.status'] == null
    );
    return {
      ...lineItem,
      isChecked: checkboxDisabled ? false : checkedStatus,
      checkboxDisabled: checkboxDisabled,
    };
  };
  const handleCheckAll = (event: any, tableData: any) => {
    setIsAllCheckBoxChecked(event?.target?.checked);
    setSkuDetailsData(
      addCheckPropertyToData(tableData, event?.target?.checked)
    );
  };

  const handleCheckBoxChecked = (e: any, data: any, tableData: any) => {
    const updatedData = addCheckPropertyToData(
      tableData,
      e?.target?.checked,
      data
    );
    setSkuDetailsData(updatedData);
  };

  const handleShowNotification = (status: string, errorMessage = false) => {
    if (!errorMessage) {
      setIsVisibleMessage(true);
      setSeverityType('success');
      setTimeout(() => {
        router.push(`${getBasePath('shipments')}`);
      }, 1000);
      setNotificationMessage(
        status == CONSIGNMENT_REVIEW_APPROVE_STATUS
          ? CONSIGNMENT_REVIEW_APPROVED
          : CONSIGNMENT_REVIEW_REJECTED
      );
    } else {
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setNotificationMessage(errorMessage);
    }
  };

  return (
    <>
      <div className='container-fluid'>
        <div className='row'>
          <Breadcrumbs data={headers} />
        </div>
      </div>
      <div className='container-fluid orders-page-wrapper'>
        <div className='row orders-page-inner-wrapper'>
          <div className='col-lg-12 col-md-12 col-sm-12 consignmentDetailsHeader'>
            <div className='heading-wrapper orders-heading-wrapper'>
              <h2 className='yk-orders-heading'>{sku}</h2>
            </div>
            <h5 className='sub-haeding'>SKU details</h5>
          </div>
        </div>
      </div>
      <ConsignmentSkuDetailsHeader />
      <div className='container-fluid sku-details-page-wrapper'>
        <div className='row'>
          <div className='col-lg-12 col-md-12 col-sm-12'>
            <div className='yk-sku-topwrap'>
              <div className='yk-sku-titles d-flex'>
                <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                  <div className='d-flex justify-content-between'>
                    <h2 className='yk-prod-main-titles mt-1 mb-3'>Items</h2>
                    <div className='YKCH-approveRejectBBTTN'>
                      <Button
                        className='MuiButtonBase-root me-3 YKCH-reject'
                        disabled={!enableReviewConsignmentBtn}
                        onClick={() => setShowRejectPopup(true)}>
                        Reject
                      </Button>
                      <Button
                        className='MuiButtonBase-root YKCH-aprove'
                        disabled={!enableReviewConsignmentBtn}
                        onClick={() => setShowReviewDetailsModal(true)}>
                        Approve
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
              <div className='search-btn-wrapper'>
                <div className='row'>
                  <div className='col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12'>
                    <div className='YKCH-searchingData'>
                      <SearchComp
                        optionType='change'
                        placeholder='Search'
                        onChangeHandler={onChangeHandler}
                      />
                    </div>
                  </div>
                  <div className='col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12'>
                    <div className='consignment-btn-wrapper'>
                      <Sortings
                        itemKey='skuDetails'
                        handleChange={sortHandler}
                        defaultSelectedValue={selectedSort}
                      />
                      <div className='filter-btn-wrapper YKCH-filterWrapperr'>
                        <ClickAwayListener
                          onClickAway={() => {
                            setShowFilters(false);
                          }}>
                          <div className='YKCH-filterBTNWrapp me-0'>
                            <button
                              className='btn filter-btn YKCH-filterBTNN'
                              onClick={() => setShowFilters(!showFilters)}>
                              <Image
                                src={filterIcon}
                                alt='filter-btn-icon'
                                className='filter-btn-icon img-fluid'
                              />
                              <span className='filter-btn-text yk-badge-h15'>
                                Filter
                              </span>
                            </button>
                            {showFilters && (
                              <ProductFilters
                                itemKey='skuDetails'
                                data={skuDetailsData}
                                onPayoutChange={onStatusChange}
                                checkedValue={checked}
                                onPriceChange={onPriceChange}
                                selectedPriceDetails={selectedPriceDetails}
                                onApplyClick={onApplyFilters}
                                onClearFilters={onClearFilters}
                                clearDisable={clearDisable}
                              />
                            )}
                          </div>
                        </ClickAwayListener>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <VirtualTable
                headers={columns}
                loading={skuDetailsIsLoading}
                error={skuDetailsError}
                rowData={skuDetailsData}
              />
            </div>
          </div>
        </div>
        {showDetailsModal && (
          <OrderDetailsModal
            showModal={showDetailsModal}
            handleClose={setShowDetailsModal}
            lineItemId={consignmentLineItemId || consignmentId}
            skuId={sku}
            orderDetails='shoeDetails'
            isShoeCatalog={isShow}
          />
        )}

        {
          <ChecklistPopupModal
            showModal={showReviewDetailsModal}
            setShowDetailsModal={setShowReviewDetailsModal}
            consignmentId={consignmentId}
            consignorName={consignorName}
            sku={[{ barcodes: barCodeList, skuId: sku }]}
            handleShowNotification={handleShowNotification}
            showRejectPopup={showRejectPopup}
            setShowRejectPopup={setShowRejectPopup}
          />
        }
        <Notification
          showSuccessPopup={isVisibleMessage}
          handleSnackbarClose={() => setIsVisibleMessage(false)}
          severityType={severityType}
          message={notificationMessage}
          className='yk-shoesize-alert-wrapper'
        />
      </div>
    </>
  );
};
export default ConsignmentSkuDetails;
