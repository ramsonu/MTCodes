import React, { useState, useEffect } from 'react';
import type { NextPage } from 'next';
import Image from 'next/image';
import Pagination from 'components/common/pagination';
import SearchComp from 'components/common/search';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import filterIcon from 'assets/images/filter-icon.png';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import {
  getConsignmentQuery,
  getPaginationCountForConsignment,
} from 'middleware/cubejs-wrapper/consignment-cubejs-query';
import { FNS_DATE_FORMAT } from 'utils/constants';
import VirtualTable from 'components/common/table';
import ProductFilters from 'components/common/filters/product-filter';
import { format } from 'date-fns';
import Sortings from 'components/common/sortings';

const Consignments: NextPage = () => {
  const router = useRouter();
  const [ConsignmentData, setConsignmentData] = useState<any>([]);
  const [userInput, setUserInput] = useState<any>('');
  const itemsPerPage = 10;
  const [searchOffset, setSearchOffset] = useState<any>(0);
  const [countForPagination, setCountForPagination] = useState(0);
  const [showFilters, setShowFilters] = useState<boolean>(false);
  const [selectedStartDate, setSelectedStartDate] = useState<any>('');
  const [selectedEndDate, setSelectedEndDate] = useState<any>('');
  const [filterInput, setFilterInput] = useState<any>({});
  const [selectedStatus, setSelectedStatus] = useState<any>([]);
  const [selectedSort, setSelectedSort] = useState('consignmentIdDesc');
  const [clearDisable, setClearDisable] = useState(true);
  const [checked, setChecked] = useState({
    Pending: false,
    Completed: false,
    'Yet To Start': false,
  });

  const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');

  const consignmentQuery: any = getConsignmentQuery(
    userInput,
    searchOffset,
    selectedSort,
    filterInput,
    userDetails,
    itemsPerPage
  );
  const paginationCountForConsignment: any = getPaginationCountForConsignment(
    userInput,
    filterInput,
    userDetails
  );
  const {
    resultSet: consignmentResultSet,
    isLoading: consignmentIsLoading,
    error: consignmentError,
  }: any = useCubeQuery(consignmentQuery);

  const { resultSet: pageCountResultSet }: any = useCubeQuery(
    paginationCountForConsignment
  );
  useEffect(() => {
    const data = consignmentResultSet?.loadResponses[0]?.data;
    if (data) {
      setConsignmentData(data);
    } else {
      setConsignmentData([]);
    }
    if (pageCountResultSet) {
      let countData =
        +pageCountResultSet?.loadResponses[0]?.data[0]?.[
          'ConsignmentData.count'
        ] || 0;
      setCountForPagination(countData);
    }
  }, [consignmentResultSet, pageCountResultSet]);

  const onChangeHandler = (event: any) => {
    setUserInput(event.target.value);
    setSearchOffset(0);
  };

  const viewButtonHandler = (data: any) => {
    router.push(`shipments/${data?.['ConsignmentData.consignmentId']}`);
  };
  const columns = React.useMemo(
    () => [
      {
        title: 'Shipment ID',
        value: 'ConsignmentData.consignmentId',
      },
      {
        title: 'Consignor Name',
        value: 'ConsignmentData.userName',
      },
      {
        title: 'Quantity',
        value: 'ConsignmentData.Quantity',
      },
      {
        title: 'Date Added',
        type: 'date',
        format: FNS_DATE_FORMAT,
        value: 'ConsignmentData.creationTime',
      },
      {
        title: 'Status',
        type: 'status',
        value: 'ConsignmentData.consignmentStatus',
        success: 'Completed',
        danger: 'Pending',
        warning: 'Yet To Start',
        consignment: true,
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          viewButtonHandler(data);
        },
        value: 'View',
      },
    ],
    []
  );

  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
  };

  const onDateChange = (dates: any) => {
    const [start, end] = dates;
    setSelectedStartDate(start);
    setSelectedEndDate(end);
    setClearDisable(false);
  };

  const onApplyFilters = () => {
    const filterPayload = {
      startDate:
        selectedStartDate !== ''
          ? format(new Date(selectedStartDate), FNS_DATE_FORMAT)
          : '',
      endDate:
        selectedEndDate !== ''
          ? format(new Date(selectedEndDate), FNS_DATE_FORMAT)
          : '',
      status: selectedStatus,
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setShowFilters(false);
  };

  const onPayoutChange = (event: any) => {
    setChecked({ ...checked, [event?.target?.name]: event?.target?.checked });
    let updatedList = [...selectedStatus];
    if (event.target.checked) {
      updatedList = [...selectedStatus, event.target.name];
    } else {
      updatedList.splice(selectedStatus.indexOf(event.target.name), 1);
    }
    setSelectedStatus(updatedList);
    if (updatedList.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  };

  const onClearFilters = () => {
    setSelectedStartDate('');
    setSelectedEndDate('');
    setSelectedStatus([]);
    setChecked({ Pending: false, Completed: false, 'Yet To Start': false });
    setFilterInput({});
    setShowFilters(false);
    setClearDisable(true);
  };

  return (
    <>
      <div className='app-wrapper w-100 consignment-consignments-page-wrapper'>
        <div className='orders-page-inner-wrapper'>
          <div className='container-fluid'>
            <div className='row'>
              <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                <div className='heading-wrapper orders-heading-wrapper'>
                  <h2 className='heading'>Shipments</h2>
                </div>
              </div>
              <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
                <div className=''>
                  <div className='search-btn-wrapper'>
                    <div className='row'>
                      <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 YKCH-searchingData'>
                        <div className='YKCH-searchingData'>
                          <SearchComp
                            optionType='change'
                            placeholder='Search'
                            onChangeHandler={onChangeHandler}
                          />
                        </div>
                      </div>
                      <div className='col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12'>
                        <div className='d-flex justify-content-end YKCH-filterWrapp'>
                          <div className='me-3'>
                            <Sortings
                              itemKey='consignments'
                              handleChange={sortHandler}
                              defaultSelectedValue={selectedSort}
                            />
                          </div>
                          <div className='filter-btn-wrapper'>
                            <ClickAwayListener
                              onClickAway={() => {
                                setShowFilters(false);
                              }}>
                              <div>
                                <button
                                  className='btn filter-btn '
                                  onClick={() => setShowFilters(!showFilters)}>
                                  <Image
                                    src={filterIcon}
                                    alt='filter-btn-icon'
                                    className='filter-btn-icon img-fluid'
                                  />
                                  <span className='filter-btn-text yk-badge-h15'>
                                    Filter
                                  </span>
                                </button>
                                {showFilters && (
                                  <ProductFilters
                                    itemKey='consignment'
                                    onDateChange={onDateChange}
                                    startDate={selectedStartDate}
                                    endDate={selectedEndDate}
                                    onApplyClick={onApplyFilters}
                                    onPayoutChange={onPayoutChange}
                                    checkedValue={checked}
                                    onClearFilters={onClearFilters}
                                    clearDisable={clearDisable}
                                  />
                                )}
                              </div>
                            </ClickAwayListener>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <VirtualTable
                    headers={columns}
                    loading={consignmentIsLoading}
                    error={consignmentError}
                    rowData={ConsignmentData}
                  />
                </div>
              </div>
            </div>
          </div>
          {countForPagination > 0 && (
            <div className='center-pagination'>
              <Pagination
                lengthOfData={countForPagination}
                itemsPerPage={itemsPerPage}
                currentOffset={searchOffset}
                setOffset={setSearchOffset}
              />
            </div>
          )}
        </div>
      </div>
    </>
  );
};
export default Consignments;
