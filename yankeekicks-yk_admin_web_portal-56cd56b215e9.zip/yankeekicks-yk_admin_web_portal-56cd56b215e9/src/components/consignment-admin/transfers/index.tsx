import React, { useState, useEffect, useMemo } from 'react';
import Image from 'next/image';
import { useCubeQuery } from '@cubejs-client/react';
import { useRouter } from 'next/router';
import { useSelector, useDispatch } from 'react-redux';
import { actions } from 'store/reducers/kiosk';
import {
  getTransfersRequestCountQuery,
  getTransfersRequestQuery,
} from 'middleware/cubejs-wrapper/transfers-query';
import { getBasePath } from 'utils/util';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import SearchComp from 'components/common/search';
import Sortings from 'components/common/sortings';
import ProductFilters from 'components/common/filters/product-filter';
import VirtualTable from 'components/common/table';
import Pagination from 'components/common/pagination';
import ExportsTypes from 'components/common/exports-types';
import filterIcon from 'assets/images/filter-icon.png';
import incomingArrowIcon from 'assets/images/incoming-arrow-icon.svg';
import outgoingArrowIcon from 'assets/images/outgoing-arrow-icon.svg';

const Transfers = () => {
  const limitForQuery: any = 10;
  const locationId: any = localStorage?.getItem('storeLocationId');

  const router = useRouter();
  const dispatch = useDispatch();

  const { selected } = useSelector((state: any) => state.shared);
  const { filterTypes } = useSelector((state: any) => state.kiosk);

  const [locId, setLocId] = useState<any>('');
  const [userInput, setUserInput] = useState<any>('');
  const [selectedSort, setSelectedSort] = useState('transferIdDesc');
  const [showFilters, setShowFilters] = useState(false);
  const [filterInput, setFilterInput] = useState<any>({});
  const [transferRequests, setTransferRequests] = useState<any>([]);
  const [countForPagination, setCountForPagination] = useState<number>(0);
  const [transfersOffset, setTransfersOffset] = useState<number>(0);
  const [shouldFetchTransferRequests, setShouldFetchTransferRequests] =
    useState<boolean>(false);
  const [shouldFetchTransferExport, setShouldFetchTransferExport] =
    useState<boolean>(false);
  const [checked, setChecked] = useState({
    Pending: false,
    Complete: false,
  });
  const [selectedTransferStatus, setSelectedTransferStatus] = useState<any>([]);
  const [clearDisable, setClearDisable] = useState(true);

  useEffect(() => {
    if (locationId) {
      setLocId(localStorage?.getItem('storeLocationId'));
      setShouldFetchTransferRequests(true);
    } else {
      setLocId('');
      setShouldFetchTransferRequests(false);
    }
  }, [selected]);

  const transfersRequestQuery: any = getTransfersRequestQuery(
    locId,
    userInput,
    selectedSort,
    filterInput,
    transfersOffset,
    limitForQuery
  );
  const transfersRequestCountQuery: any = getTransfersRequestCountQuery(
    locId,
    userInput,
    filterInput
  );
  const transfersExportQuery: any = getTransfersRequestQuery(
    locId,
    userInput,
    selectedSort,
    filterInput
  );

  const {
    resultSet: transferRequestsResultSet,
    isLoading: transferRequestsLoading,
    error: transferRequestsError,
  }: any = useCubeQuery(transfersRequestQuery, {
    skip: !shouldFetchTransferRequests,
  });

  const {
    resultSet: transferRequestsCountResultSet,
    isLoading: transferRequestsCountLoading,
    error: transferRequestsCountError,
  }: any = useCubeQuery(transfersRequestCountQuery, {
    skip: !shouldFetchTransferRequests,
  });

  const {
    resultSet: transferExportResultSet,
    isLoading: transferExportLoading,
    error: transferExportError,
  }: any = useCubeQuery(transfersExportQuery, {
    skip: !shouldFetchTransferExport,
  });

  useEffect(() => {
    setShouldFetchTransferRequests(true);
  }, []);

  useEffect(() => {
    if (
      transferRequestsError?.status === 401 ||
      transferRequestsError?.status === 403
    ) {
      //todo: Logout the user
    } else {
      const data = transferRequestsResultSet?.loadResponses[0]?.data;
      if (data) {
        setTransferRequests(data);
        setShouldFetchTransferRequests(false);
      } else {
        setTransferRequests([]);
      }
    }
  }, [transferRequestsResultSet, transferRequestsError]);

  useEffect(() => {
    if (
      transferRequestsCountError?.status === 401 ||
      transferRequestsCountError?.status === 403
    ) {
      //todo: Logout the user
    } else {
      const pageCountData =
        transferRequestsCountResultSet?.loadResponses[0]?.data[0]?.[
          'Transfers.count'
        ];
      if (pageCountData) {
        const pageCount = +pageCountData || 0;
        setCountForPagination(pageCount);
      }
    }
  }, [transferRequestsCountResultSet, transferRequestsCountError]);

  // useEffect to disable clear button in filters
  useEffect(() => {
    if (!filterTypes?.transferType?.length && !selectedTransferStatus?.length) {
      setClearDisable(true);
    } else {
      setClearDisable(false);
    }
  }, [filterTypes, selectedTransferStatus]);

  const onStatusChange = (event: any) => {
    setChecked({ ...checked, [event?.target?.name]: event?.target?.checked });
    var updatedList = [...selectedTransferStatus];
    if (event.target.checked) {
      updatedList = [...selectedTransferStatus, event.target.name];
    } else {
      updatedList.splice(selectedTransferStatus.indexOf(event.target.name), 1);
    }
    setSelectedTransferStatus(updatedList);
  };

  // method for search
  const userInputHandler = (event: any) => {
    setUserInput(event.target.value);
    setTransfersOffset(0);
    setShouldFetchTransferRequests(true);
  };

  // method for sorting
  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
    setTransfersOffset(0);
    setShouldFetchTransferRequests(true);
  };

  const onApplyFilters = () => {
    const filterPayload = {
      status: selectedTransferStatus,
      type: filterTypes?.transferType,
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setTransfersOffset(0);
    setShowFilters(false);
    setShouldFetchTransferRequests(true);
  };

  const onClearFilters = () => {
    setSelectedTransferStatus([]);
    setChecked({ Pending: false, Complete: false });
    dispatch(actions.clearAllFilters({}));
    setTransfersOffset(0);
    setFilterInput({});
    setShowFilters(false);
    setClearDisable(true);
    setShouldFetchTransferRequests(true);
  };

  const onExportTransfer = () => {
    setShouldFetchTransferExport(false);
    setTimeout(() => {
      setShouldFetchTransferExport(true);
    }, 100);
  };

  const exportHeaders = [
    { label: 'Transfer ID', key: 'Transfers.transferId' },
    {
      label: 'Type',
      key: 'Transfers Request',
      type: 'Transfers Request',
      fromLocation: 'Transfers.fromlocationId',
      toLocation: 'Transfers.tolocationId',
      currentLocation: locId,
    },
    { label: 'From', key: 'Transfers.fromLocation' },
    { label: 'To', key: 'Transfers.toLocation' },
    { label: 'Quantity', key: 'Transfers.quantity' },
    { label: 'Status', key: 'Transfers.transferStatus' },
  ];

  const pdfExportQueryPayload = {
    userInput,
    selectedSort,
    filterInput,
  };

  const columns = [
    {
      title: 'Transfer ID',
      value: 'Transfers.transferId',
    },
    {
      title: 'Type',
      type: 'transferType',
      outgoingImg: outgoingArrowIcon,
      incomingImg: incomingArrowIcon,
      fromLocation: 'Transfers.fromlocationId',
      toLocation: 'Transfers.tolocationId',
      currentLocation: locId,
    },
    {
      title: 'From',
      value: 'Transfers.fromLocation',
    },
    {
      title: 'To',
      value: 'Transfers.toLocation',
    },
    {
      title: 'Quantity',
      value: 'Transfers.quantity',
    },
    {
      title: 'Status',
      value: 'Transfers.transferStatus',
      type: 'status',
      success: 'Complete',
      warning: 'Pending',
    },
    {
      title: 'Actions',
      type: 'transferDynamicActionButton',
      onClick: (data: any) => {
        let reqType =
          data?.['Transfers.fromlocationId'] === locId
            ? 'Outgoing'
            : data?.['Transfers.tolocationId'] === locId
            ? 'Incoming'
            : '';
        if (
          (data?.['Transfers.transferStatus'] === 'Completed' ||
            data?.['Transfers.transferStatus'] === 'Pending' ||
            data?.['Transfers.transferStatus'] === 'Yet To Start') &&
          data?.['Transfers.fromlocationId'] === locId
        ) {
          router.push({
            pathname: getBasePath('transfers/view-transfer'),
            query: {
              transferId: data?.['Transfers.transferId'],
              requestType: reqType,
            },
          });
        } else {
          router.push({
            pathname: getBasePath('transfers/accept-transfer'),
            query: {
              transferId: data?.['Transfers.transferId'],
              requestType: reqType,
            },
          });
        }
      },
      value: 'Transfers.transferStatus',
      from: 'Transfer',
    },
  ];

  return (
    <>
      <div className='app-wrapper w-100 orders-page-wrapper yk-transfers-page-wrapper'>
        <div className='manage-user-page-inner-wrapper yk-transfers-landing-page-inner-wrapper'>
          <div className='container-fluid'>
            <div className='row'>
              <div className='col-lg-12 col-md-12 col-sm-12'>
                <div className='heading-wrapper orders-heading-wrapper d-flex justify-content-between'>
                  <h2 className='heading'>Transfers</h2>
                  <div className='yk-displayFlexEnd YKCH-topSSpacSS'>
                    <div className='sort-product-wrapper export-btn me-3 p-0'>
                      <ExportsTypes
                        fileName='transfers'
                        headers={exportHeaders}
                        data={
                          (transferExportResultSet?.loadResponses[0]?.data &&
                            transferExportResultSet?.loadResponses[0]?.data) ||
                          []
                        }
                        queryPayload={pdfExportQueryPayload}
                        onClickPDFExport={onExportTransfer}
                        isActive={
                          transferRequests && transferRequests?.length > 0
                        }
                      />
                    </div>
                    <div className='add-user-btn-wrapper'>
                      <button
                        className='btn yk-btn-primary-sm'
                        onClick={() =>
                          router.push(
                            getBasePath('transfers/initiate-transfer')
                          )
                        }>
                        Initiate Transfer
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div className='search-btn-wrapper'>
                <div className='row'>
                  <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12'>
                    <div className='search-bar-wrapper yk-search-bar table-filter-search YKCH-searchingData'>
                      <SearchComp
                        optionType='no suggestions'
                        placeholder='Search'
                        userInput={userInput}
                        onChangeHandler={userInputHandler}
                      />
                    </div>
                  </div>
                  <div className='col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12'>
                    <div className='consignment-btn-wrapper p-0 YKCH-topSSpacSS YKCH-filterArenas ykch-transferSortBtn'>
                      <Sortings
                        itemKey='transfer'
                        handleChange={sortHandler}
                        defaultSelectedValue={selectedSort}
                      />
                      <div className='yk-filter-btn-wrapper'>
                        <ClickAwayListener
                          onClickAway={() => {
                            setShowFilters(false);
                          }}>
                          <div>
                            <button
                              className='btn filter-btn yk-filter-btn'
                              onClick={() => setShowFilters(!showFilters)}>
                              <Image
                                src={filterIcon}
                                alt='filter-btn-icon'
                                className='filter-btn-icon img-fluid'
                              />
                              <span className='filter-btn-text yk-badge-h15'>
                                Filter
                              </span>
                            </button>

                            {showFilters && (
                              <ProductFilters
                                itemKey='transfer'
                                component='transfer'
                                onPayoutChange={onStatusChange}
                                checkedValue={checked}
                                onApplyClick={onApplyFilters}
                                onClearFilters={onClearFilters}
                                clearDisable={clearDisable}
                              />
                            )}
                          </div>
                        </ClickAwayListener>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className='yk-TransferMainTableWrapper'>
              <VirtualTable
                headers={columns}
                rowData={transferRequests}
                loading={transferRequestsLoading}
                error={transferRequestsError}
                offSet={transfersOffset}
              />
            </div>
          </div>

          {transferRequests?.length > 0 && (
            <div className='center-pagination'>
              <Pagination
                lengthOfData={countForPagination}
                itemsPerPage={limitForQuery}
                currentOffset={transfersOffset}
                setOffset={setTransfersOffset}
                setShouldFetchApi={setShouldFetchTransferRequests}
              />
            </div>
          )}
        </div>
      </div>
    </>
  );
};
export default Transfers;
