import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/router';
import { useDispatch, useSelector } from 'react-redux';
import { useCubeQuery } from '@cubejs-client/react';
import { actions } from 'store/reducers/consignment';
import { CircularProgress, Modal } from '@mui/material';
import Box from '@mui/material/Box';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import ModalCloseIcon from 'assets/images/modal-close-icon.svg';
import { getBasePath } from 'utils/util';
import { doRequest } from 'utils/request';
import { getLocationsQuery } from 'middleware/cubejs-wrapper/transfers-query';
import { INITIATE_TRANSFER_URL } from 'services/apiUrl';
import Notification from 'components/common/notification';
import { COMPLETE_INITIATE_TRANSFER_SUCCESS } from 'components/yk-admin/constants';
import { NOTIFICATION_SOMETHING_WENT_WRONG } from 'utils/constants';

const ConfirmTransferModal = (props: any) => {
  const { showConfirmTransferModal, setShowConfirmTransferModal } = props;

  const dispatch = useDispatch();
  const router = useRouter();

  const fromLocationId: any = localStorage?.getItem('storeLocationId');

  const { transfers } = useSelector((state: any) => state.consignment);

  const [allLocationsData, setAllLocationData] = useState<any>([]);
  const [locationsData, setLocationData] = useState<any>([]);
  const [locationToTransfer, setLocationToTransfer] = useState<any>('');
  const [shouldFetchLocations, setShouldFetchLocations] =
    useState<boolean>(false);
  const [isVisibleMessage, setIsVisibleMessage] = useState<boolean>(false);
  const [severityType, setSeverityType] = useState<string>('');
  const [notificationMessage, setNotificationMessage] = useState<any>('');
  const [initiateTransferLoading, setInitiateTransferLoading] =
    useState<boolean>(false);

  const getLocations: any = getLocationsQuery();

  const {
    resultSet: locationsResultSet,
    isLoading: locationsIsLoading,
    error: locationsError,
  }: any = useCubeQuery(getLocations, { skip: !shouldFetchLocations });

  useEffect(() => {
    setShouldFetchLocations(true);
  }, []);

  useEffect(() => {
    if (locationsError?.status === 401 || locationsError?.status === 403) {
      //todo: Logout the user
    } else {
      const data = locationsResultSet?.loadResponses[0]?.data;
      if (data) {
        setAllLocationData(data);
        setShouldFetchLocations(false);
      } else {
        setAllLocationData([]);
      }
    }
  }, [locationsResultSet, locationsError]);

  useEffect(() => {
    if (allLocationsData?.length > 0) {
      const removeCurrentLocation: any = allLocationsData?.filter(
        (loc: any) => loc?.['Locations.locationID_D'] !== fromLocationId
      );
      if (removeCurrentLocation?.length > 0) {
        setLocationData(removeCurrentLocation);
      } else {
        setLocationData([]);
      }
    }
  }, [allLocationsData, fromLocationId]);

  const groupBy = (array: any, property: any) => {
    return array.reduce((result: any, item: any) => {
      const key = item[property];
      if (!result[key]) {
        result[key] = [];
      }
      result[key].push(item);
      return result;
    }, {});
  };

  const grouped = groupBy(transfers, 'sku');

  const locationChangeHandler = (event: any) => {
    setLocationToTransfer(event?.target?.value);
  };

  const onConfirmTransfer = async () => {
    let skuDetails: any = [];

    Object.keys(grouped)?.map((groupedItem: any) => {
      let sizeDetails: any = [];
      grouped?.[groupedItem]?.map((item: any) => {
        sizeDetails?.push({
          size: item?.size,
          condition_name: item?.condition,
          quantity: item?.quantityToTransfer,
        });
      });
      skuDetails?.push({
        from_location_id: fromLocationId,
        to_location_id: locationToTransfer?.['Locations.locationID_D'],
        from_location_name: grouped?.[groupedItem]?.[0]?.from,
        to_location_name: locationToTransfer?.['Locations.name'],
        sku: grouped?.[groupedItem]?.[0]?.sku,
        size_details: sizeDetails,
      });
    });

    try {
      const url = INITIATE_TRANSFER_URL;
      const payload: any = { sku_details: skuDetails };
      setInitiateTransferLoading(true);
      const response = await doRequest(url, 'post', payload);
      if (response) {
        setIsVisibleMessage(true);
        setSeverityType('success');
        setNotificationMessage(COMPLETE_INITIATE_TRANSFER_SUCCESS);
        setTimeout(() => {
          dispatch(actions?.clearAllTransfersData({}));
          setInitiateTransferLoading(false);
          router.push(getBasePath('transfers'));
        }, 1200);
      }
    } catch (error: any) {
      console.log('transfer error: ', error);
      setInitiateTransferLoading(false);
      setIsVisibleMessage(true);
      setSeverityType('warning');
      setNotificationMessage(NOTIFICATION_SOMETHING_WENT_WRONG);
      setTimeout(() => {
        setShowConfirmTransferModal(false);
        router.push(getBasePath('transfers'));
      }, 1200);
    }
  };

  return (
    <>
      <div className='app-wrapper w-100 landing-page-wrapper'>
        <Modal
          open={showConfirmTransferModal}
          onClose={() => setShowConfirmTransferModal(false)}
          className='yk-change-commission-modal-wrapper YKCH-ConfirmTransferModel'
          aria-labelledby='modal-modal-title'
          aria-describedby='modal-modal-description'>
          <div className='app-wrapper change-commission-modal-wrapper'>
            <div className='yk-modal-body'>
              <div className='modal-heading-wrapper'>
                <h3 className='modal-title yk-badge-h11 mb-0'>
                  Select Location to Confirm Transfer
                </h3>
                <div className='close-btn-wrapper'>
                  <button
                    className='btn prod-close'
                    onClick={() => setShowConfirmTransferModal(false)}>
                    <Image
                      src={ModalCloseIcon}
                      alt='table-close-icon'
                      className='table-close-icon'
                    />
                  </button>
                </div>
              </div>
              <p className='yk-para-p6'>
                Shoes added to the queue will be transferred to the selected
                location. Are you sure you want to transfer the shoes?
              </p>

              {initiateTransferLoading ? (
                <CircularProgress />
              ) : (
                <>
                  <div>
                    <p className='yk-inputLabel'>Transfers to</p>
                    <Box sx={{ minWidth: 120 }}>
                      <FormControl fullWidth>
                        <Select
                          labelId='demo-simple-select-label'
                          id='demo-simple-select'
                          displayEmpty
                          value={locationToTransfer}
                          onChange={locationChangeHandler}>
                          <MenuItem
                            className='YKCH-dataInfinite '
                            value=''
                            selected
                            disabled>
                            <em>Select Location</em>
                          </MenuItem>
                          {locationsIsLoading ? (
                            <div className='YKCH-loaderModal'>
                              <CircularProgress />
                            </div>
                          ) : (
                            locationsData?.map((loc: any) => {
                              return (
                                <MenuItem
                                  className='YKCH-dataInfinite'
                                  placeholder='select location'
                                  value={loc}
                                  key={loc?.['Locations.locationID_D']}>
                                  {loc?.['Locations.name']}
                                </MenuItem>
                              );
                            })
                          )}
                        </Select>
                      </FormControl>
                    </Box>
                  </div>

                  <div className='yk-modal-btn-wrapper'>
                    <button
                      type='button'
                      className='btn modal-btn-cancel'
                      data-bs-dismiss='modal'
                      onClick={() => setShowConfirmTransferModal(false)}>
                      Cancel
                    </button>
                    <button
                      type='button'
                      className='btn modal-btn-submit'
                      disabled={!locationToTransfer}
                      onClick={onConfirmTransfer}>
                      Confirm
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </Modal>
      </div>

      <Notification
        showSuccessPopup={isVisibleMessage}
        handleSnackbarClose={() => setIsVisibleMessage(false)}
        severityType={severityType}
        message={notificationMessage}
        className='yk-shoesize-alert-wrapper'
      />
    </>
  );
};

export default ConfirmTransferModal;
