import React, { useState, useEffect, useMemo } from 'react';
import Image from 'next/image';
import { useSelector, useDispatch } from 'react-redux';
import { useRouter } from 'next/router';
import { actions } from 'store/reducers/consignment';
import { actions as kioskActions } from 'store/reducers/kiosk';
import { getBasePath } from 'utils/util';
import SearchComp from 'components/common/search';
import Breadcrumbs from 'components/common/breadcrumbs';
import VirtualTable from 'components/common/table';
import ProductFilters from 'components/common/filters/product-filter';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import Sortings from 'components/common/sortings';
import NoDataFound from 'components/common/no-data-found';
import Pagination from 'components/common/pagination';
import SelectSizesModal from '../Initiate-Transfers/select-sizes-modal';
import filterIcon from 'assets/images/filter-icon.png';
import ConfirmTransferModal from './confirm-transfer-modal';
import TransferDefault from 'assets/images/menu-icons/transfer-gray-img.svg';

const PreviewTransfer = () => {
  const dispatch = useDispatch();
  const router = useRouter();

  const limitForQuery = 10;

  const { transfers, transferFilteredData } = useSelector(
    (state: any) => state.consignment
  );

  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const [previewTableData, setPreviewTableData] = useState<any>([]);
  const [searchOffset, setSearchOffset] = useState<any>(0);
  const [showFilter, setShowFilter] = useState<boolean>(false);
  const [showSizeModal, setShowSizeModal] = useState<boolean>(false);
  const [selectedLineItemData, setSelectedLineItemData] = useState<any>({});
  const [showConfirmTransferModal, setShowConfirmTransferModal] =
    useState<boolean>(false);

  const breadCrumbHeaders = {
    title: 'Transfers',
    titleImage: TransferDefault,
    subTitle: 'Initiate Transfer',
    nextSubTitle: 'Review Transfer',
    onClick: () => {
      router?.push(getBasePath('transfers'));
    },
    onNextClick: () => {
      router?.push(getBasePath('transfers/initiate-transfer'));
    },
  };

  //useEffect for setting local transfer data i.e  transferFilteredData
  useEffect(() => {
    dispatch(actions?.setTransferFilteredData(transfers));
  }, [transfers]);

  useEffect(() => {
    if (transferFilteredData?.length) {
      setPreviewTableData(
        transferFilteredData.slice(searchOffset, searchOffset + limitForQuery)
      );
    }
  }, [searchOffset, transferFilteredData]);

  const handleSearch = (event: any) => {
    dispatch(
      actions.setTransferFilters({
        text: event.target.value?.toLowerCase(),
        brand: filterTypes.brand,
      })
    );
  };

  const onClick = () => {
    dispatch(
      actions.setTransferFilters({
        brand: filterTypes?.brand,
      })
    );
    setShowFilter(false);
  };

  const onClearFilters = () => {
    setShowFilter(false);
    dispatch(kioskActions.clearAllFilters({}));
    dispatch(
      actions.setTransferFilters({
        brand: [],
      })
    );
  };

  const sortHandler = (event: any) => {
    if (event.target.value === 'skuAsc') {
      const sortedBySKUInAsc = transferFilteredData
        ?.slice()
        ?.sort((a: any, b: any) => (a.sku > b.sku ? 1 : -1));
      dispatch(actions.setTransfersData(sortedBySKUInAsc));
    } else if (event.target.value === 'skuDesc') {
      const sortedBySKUInDesc = transferFilteredData
        ?.slice()
        ?.sort((a: any, b: any) => (a.sku > b.sku ? -1 : 1));
      dispatch(actions.setTransfersData(sortedBySKUInDesc));
    } else if (event.target.value === 'brandAsc') {
      const sortedByBrandNameInAsc = transferFilteredData
        ?.slice()
        ?.sort((a: any, b: any) => (a.brandName > b.brandName ? 1 : -1));
      dispatch(actions.setTransfersData(sortedByBrandNameInAsc));
    } else if (event.target.value === 'brandDesc') {
      const sortedByBrandNameInDesc = transferFilteredData
        ?.slice()
        ?.sort((a: any, b: any) => (a.brandName > b.brandName ? -1 : 1));
      dispatch(actions.setTransfersData(sortedByBrandNameInDesc));
    } else if (event.target.value === 'qtyLow') {
      const sortedBYQtyInAsc = transferFilteredData
        ?.slice()
        ?.sort((a: any, b: any) =>
          a.quantityToTransfer > b.quantityToTransfer ? 1 : -1
        );
      dispatch(actions.setTransfersData(sortedBYQtyInAsc));
    } else if (event.target.value === 'qtyHigh') {
      const sortedBYQtyInDesc = transferFilteredData
        ?.slice()
        ?.sort((a: any, b: any) =>
          a.quantityToTransfer > b.quantityToTransfer ? -1 : 1
        );
      dispatch(actions.setTransfersData(sortedBYQtyInDesc));
    } else {
      dispatch(actions.setTransfersData(transferFilteredData));
    }
  };

  const reviewLineItemHandler = (data: any, flag: any) => {
    if (flag === 'Edit') {
      setSelectedLineItemData(data);
      setShowSizeModal(true);
    } else {
      dispatch(actions.removeSelectedItemFromTransfers(data));
    }
  };

  const transferShoesHandler = () => {
    setShowConfirmTransferModal(true);
  };

  const columns = useMemo(
    () => [
      {
        title: 'S.No',
        type: 'sno',
      },
      {
        title: 'SKU',
        value: 'sku',
      },
      {
        title: 'Picture',
        value: 'productImage',
        type: 'image',
      },
      {
        title: 'Brand',
        value: 'brandName',
      },
      {
        title: 'Name',
        value: 'nameOfProduct',
      },
      {
        title: 'Qty',
        value: 'quantityToTransfer',
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any, flag: any) => {
          reviewLineItemHandler(data, flag);
        },
        mode: 'two buttons',
        value: 'Edit',
        value1: 'Remove',
      },
    ],
    [] // eslint-disable-line react-hooks/exhaustive-deps
  );

  return (
    <>
      <div className='app-wrapper orders-page-wrapper yk-transfers-page-wrapper yk-initiate-transfer-page-wrapper'>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-lg-12'>
              <Breadcrumbs data={breadCrumbHeaders} />
            </div>
            <div className='col-lg-12'>
              <div className='heading-wrapper preview-heading-wrapper'>
                <div className='heading-inner-wrapper'>
                  <h3 className='heading yk-main-title'>Preview Transfer</h3>
                  <p className='yk-gray-text'>
                    Please review the products before transferring.
                  </p>
                </div>
                <button
                  type='button'
                  onClick={transferShoesHandler}
                  disabled={!transferFilteredData?.length}
                  className='btn yk-btn-primary-sm yk-transferShoesBtn'>
                  Transfer Shoes
                </button>
              </div>
              <div className='search-btn-wrapper'>
                <div className='row'>
                  <div className='col-lg-4'>
                    <div className='search-bar-wrapper yk-search-bar consignment-dashboard-search table-filter-search'>
                      <SearchComp
                        optionType='change'
                        placeholder='Search Queue'
                        onChangeHandler={handleSearch}
                      />
                    </div>
                  </div>
                  <div className='col-lg-8'>
                    <div className='consignment-btn-wrapper YKCH-topSSpacSS'>
                      <Sortings
                        handleChange={sortHandler}
                        itemKey='initiateTransfer'
                      />
                      <div className='filter-btn-wrapper ykch-filter-wrapper-box ms-3'>
                        <ClickAwayListener
                          onClickAway={() => {
                            setShowFilter(false);
                          }}>
                          <div>
                            <button
                              className='btn filter-btn'
                              onClick={() => setShowFilter(!showFilter)}>
                              <Image
                                src={filterIcon}
                                alt='filter-btn-icon'
                                className='filter-btn-icon img-fluid'
                              />
                              <span className='filter-btn-text yk-badge-h15'>
                                Filter
                              </span>
                            </button>
                            {showFilter && (
                              <ProductFilters
                                itemKey={'initiateTransfer'}
                                onApplyClick={onClick}
                                onClearFilters={onClearFilters}
                                clearDisable={
                                  !(
                                    filterTypes.size?.length > 0 ||
                                    filterTypes.brand.length > 0
                                  )
                                }
                              />
                            )}
                          </div>
                        </ClickAwayListener>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {transferFilteredData && transferFilteredData.length > 0 ? (
                <VirtualTable
                  headers={columns}
                  rowData={previewTableData}
                  offSet={searchOffset}
                />
              ) : (
                <NoDataFound />
              )}
              {transferFilteredData?.length > 0 && (
                <div className='center-pagination'>
                  <Pagination
                    lengthOfData={transferFilteredData?.length}
                    itemsPerPage={limitForQuery}
                    currentOffset={searchOffset}
                    setOffset={setSearchOffset}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {showSizeModal && (
        <SelectSizesModal
          showSizeModal={showSizeModal}
          setShowSizeModal={setShowSizeModal}
          modalType='edit'
          dataForRow={selectedLineItemData}
        />
      )}

      {showConfirmTransferModal && (
        <ConfirmTransferModal
          showConfirmTransferModal={showConfirmTransferModal}
          setShowConfirmTransferModal={setShowConfirmTransferModal}
        />
      )}
    </>
  );
};
export default PreviewTransfer;
