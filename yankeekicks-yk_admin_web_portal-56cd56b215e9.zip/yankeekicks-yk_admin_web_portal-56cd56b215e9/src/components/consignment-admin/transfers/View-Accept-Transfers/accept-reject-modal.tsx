import { Modal } from '@mui/material';
import React from 'react';
import { ACCEPT_REJECT_MODAL } from '../../constants';

const AcceptRejectTransferModal = (props: any) => {
  const { showRejectTransferModal, showAcceptTransferModal } = props;
  
  return (
    <div className='app-wrapper w-100 landing-page-wrapper'>
      <Modal
        open={showRejectTransferModal || showAcceptTransferModal}
        className='yk-identity-details-modal-wrapper'
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'>
        <div className='app-wrapper identity-details-modal-wrapper'>
          <div className='yk-modal-body'>
            <div className='modal-heading-wrapper'>
              <h3 className='modal-title yk-badge-h11'>
                {showRejectTransferModal
                  ? ACCEPT_REJECT_MODAL.REJECT_TITLE
                  : ACCEPT_REJECT_MODAL.ACCEPT_TITLE}
              </h3>
              <p className='modal-sub-title yk-badge-h8'>
                {showRejectTransferModal
                  ? ACCEPT_REJECT_MODAL.REJECT_MSG
                  : ACCEPT_REJECT_MODAL.ACCEPT_MSG}
              </p>
            </div>
            <div className='close-button-wrapper'>
              <button
                className='btn btn-close YKCH-closeBBTN'
                // onClick={handleModalClose}
              >
                Cancel
              </button>
              <button
                className='btn btn-close YKCH-closeBBTN'
                // onClick={handleModalClose}
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default AcceptRejectTransferModal;
