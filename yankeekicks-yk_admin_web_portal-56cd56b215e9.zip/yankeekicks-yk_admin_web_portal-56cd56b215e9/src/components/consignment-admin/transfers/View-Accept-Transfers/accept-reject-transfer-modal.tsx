import React from 'react';
import Image from 'next/image';
import { Modal } from '@mui/material';
import { ACCEPT_REJECT_MODAL } from '../../constants';
import ModalCloseIcon from 'assets/images/modal-close-icon.svg';

const AcceptRejectTransferModal = (props: any) => {
  const {
    showAcceptTransferModal,
    showRejectTransferModal,
    setShowAcceptTransferModal,
    setShowRejectTransferModal,
    handleSubmit,
  } = props;

  const handleCloseModal = () => {
    setShowAcceptTransferModal(false);
    setShowRejectTransferModal(false);
  };

  return (
    <div className='app-wrapper w-100 landing-page-wrapper'>
      <Modal
        open={showAcceptTransferModal || showRejectTransferModal}
        className='yk-change-commission-modal-wrapper yk-remove-all-modal-wrapper'
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'>
        <div className='app-wrapper change-commission-modal-wrapper'>
          <div className='yk-modal-body'>
            <div className='modal-heading-wrapper d-flex justify-content-between align-items-center'>
              <h3 className='modal-title yk-badge-h11 mb-0'>
                {showAcceptTransferModal
                  ? ACCEPT_REJECT_MODAL?.ACCEPT_TITLE
                  : ACCEPT_REJECT_MODAL?.REJECT_TITLE}
              </h3>
              <div className='close-btn-wrapper'>
                <button className='btn prod-close'>
                  <Image
                    src={ModalCloseIcon}
                    alt='table-close-icon'
                    className='table-close-icon'
                    onClick={handleCloseModal}
                  />
                </button>
              </div>
            </div>
            <p className='yk-modalDescription mb-0'>
              {showAcceptTransferModal
                ? ACCEPT_REJECT_MODAL?.ACCEPT_MSG
                : ACCEPT_REJECT_MODAL?.REJECT_MSG}
            </p>

            <div className='yk-modal-btn-wrapper'>
              <button
                type='button'
                className='btn modal-btn-cancel'
                data-bs-dismiss='modal'
                onClick={handleCloseModal}>
                Cancel
              </button>
              <button
                type='button'
                className='btn modal-btn-submit'
                onClick={handleSubmit}>
                Confirm
              </button>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default AcceptRejectTransferModal;
