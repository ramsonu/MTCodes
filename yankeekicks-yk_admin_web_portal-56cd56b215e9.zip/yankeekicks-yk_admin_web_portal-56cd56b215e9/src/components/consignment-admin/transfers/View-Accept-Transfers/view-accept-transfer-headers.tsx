import React, { useState, useEffect } from 'react';
import { useCubeQuery } from '@cubejs-client/react';
import { format } from 'date-fns';
import { getViewAcceptTransfersHeadersQuery } from 'middleware/cubejs-wrapper/transfers-query';
import { FNS_DATE_DMY_FORMAT } from 'utils/constants';

const ViewAcceptTransferHeaders = (props: any) => {
  const { transferId, requestType } = props;
  const [headerData, setHeaderData] = useState<any>([]);
  const [shouldFetchDataOfRequestId, setShouldFetchTransfersHeaderData] =
    useState<boolean>(false);

  useEffect(() => {
    if (transferId) {
      setShouldFetchTransfersHeaderData(true);
    } else {
      setShouldFetchTransfersHeaderData(false);
    }
  }, [transferId]);

  const getTransfersRequestBasedOnTransferId: any =
    getViewAcceptTransfersHeadersQuery(transferId);
  const {
    resultSet: transferIdResultSet,
    isLoading: transferIdLoading,
    error: transferIdError,
  }: any = useCubeQuery(getTransfersRequestBasedOnTransferId, {
    skip: !shouldFetchDataOfRequestId,
  });

  useEffect(() => {
    if (transferIdError?.status === 401 || transferIdError?.status === 403) {
      //todo: Logout the user
    } else {
      const data = transferIdResultSet?.loadResponses[0]?.data;
      if (data) {
        setHeaderData(data);
        setShouldFetchTransfersHeaderData(false);
      } else {
        setHeaderData([]);
      }
    }
  }, [transferIdResultSet, transferIdError]);

  return (
    <div className='container-fluid'>
      <div className='ConsignmentsWrap mb-4'>
        <div className='row'>
          <div className='col-lg-2 col-md-12 col-sm-12'>
            <div className='heading-wrapper orders-heading-wrapper '>
              <h2 className='yk-badge-h5 heading'>Details</h2>
            </div>
          </div>
          <div className='col-lg-10 col-md-12 col-sm-12'>
            <div className='row justify-content-end'>
              <div className='col-lg-2 col-md-6 col-sm-6 details-wrapper'>
                <div className='yk-label'>Request</div>
                <div className='yk-value'>{requestType || '--'}</div>
              </div>
              <div className='col-lg-2 col-md-6 col-sm-6 details-wrapper'>
                <div className='yk-label'>Request Date</div>
                <div className='yk-value'>
                  {headerData[0]?.['Transfers.createdAt']
                    ? format(
                        new Date(headerData[0]?.['Transfers.createdAt']),
                        FNS_DATE_DMY_FORMAT
                      )
                    : '--'}
                </div>
              </div>
              <div className='col-lg-2 col-md-6 col-sm-6 details-wrapper'>
                <div className='yk-label'>Quantity</div>
                <div className='yk-value'>
                  {headerData[0]?.['Transfers.quantity'] || '--'}
                </div>
              </div>
              <div className='col-lg-2 col-md-6 col-sm-6 details-wrapper'>
                <div className='yk-label'>From</div>
                <div className='yk-value'>
                  {headerData[0]?.['Transfers.fromLocation'] || '--'}
                </div>
              </div>
              <div className='col-lg-2 col-md-12 col-sm-12 details-wrapper'>
                <div className='yk-label'>To</div>
                <div className='yk-value'>
                  {headerData[0]?.['Transfers.toLocation'] || '--'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewAcceptTransferHeaders;
