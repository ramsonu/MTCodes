import React, { useEffect, useState, useMemo, useRef } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/router';
import { useSelector, useDispatch } from 'react-redux';
import { useCubeQuery } from '@cubejs-client/react';
import { Button } from '@mui/material';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import Breadcrumbs from 'components/common/breadcrumbs';
import { actions } from 'store/reducers/kiosk';
import { doRequest } from 'utils/request';
import { ACCEPT_REJECT_TRANSFER_URL } from 'services/apiUrl';
import { getBasePath } from 'utils/util';
import { NOTIFICATION_SOMETHING_WENT_WRONG } from 'utils/constants';
import {
  ACCEPT_TRANSFER_MSG,
  REJECT_TRANSFER_MSG,
  TRANSFER_APPROVE_REJECT_STATUS,
} from 'components/yk-admin/constants';
import { getProductsBasedOnRequestIdsQuery } from 'middleware/cubejs-wrapper/transfers-query';
import SearchComp from 'components/common/search';
import VirtualTable from 'components/common/table';
import Sortings from 'components/common/sortings';
import ProductFilters from 'components/common/filters/product-filter';
import Notification from 'components/common/notification';
import OrderDetailsModal from 'components/consignment-admin/orders/order-details-modal';
import NoDataFound from 'components/common/no-data-found';
import CircleLoader from 'components/common/loader/circular-loader';
import TransferDefault from 'assets/images/menu-icons/transfer-gray-img.svg';
import filterIcon from 'assets/images/filter-icon.png';
import AcceptRejectTransferModal from './accept-reject-transfer-modal';
import ViewAcceptTransferHeaders from './view-accept-transfer-headers';

const AcceptTransferComp = () => {
  const dispatch = useDispatch();
  const router = useRouter();

  const { transferId, requestType } = router.query;
  const componentRef: any = useRef(null);

  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const [filterInput, setFilterInput] = useState<any>({});
  const [checked, setChecked] = useState({
    Pending: false,
    Approved: false,
  });
  const [selectedTransferStatus, setSelectedTransferStatus] = useState<any>([]);
  const [clearDisable, setClearDisable] = useState(true);
  const [userInput, setUserInput] = useState<any>('');
  const [selectedSort, setSelectedSort] = useState('skuAsc');
  const [showFilters, setShowFilters] = useState(false);
  const [showRejectTransferModal, setShowRejectTransferModal] = useState(false);
  const [showAcceptTransferModal, setShowAcceptTransferModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState<any>(false);
  const [productsData, setProductsData] = useState<any>([]);
  const [shouldFetchProducts, setShouldFetchProducts] =
    useState<boolean>(false);
  const [isAllCheckBoxChecked, setIsAllCheckBoxChecked] = useState<any>(false);
  const [enableApproveButton, setEnableApproveButton] = useState<any>(false);
  const [isVisibleMessage, setIsVisibleMessage] = useState<any>(false);
  const [severityType, setSeverityType] = useState<any>('');
  const [notificationMessage, setNotificationMessage] = useState<any>('');
  const [selectedSizeDataForModal, setSelectedSizeDataForModal] = useState<any>(
    []
  );
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [enableSelectAllButton, setEnableSelectAllButton] =
    useState<any>(false);

  useEffect(() => {
    if (transferId) {
      setShouldFetchProducts(true);
    } else {
      setShouldFetchProducts(false);
    }
  }, [transferId, router.query]);

  const getProductsBasedOnRequestId: any = getProductsBasedOnRequestIdsQuery(
    transferId,
    userInput,
    selectedSort,
    filterInput
  );

  const {
    resultSet: productsResultSet,
    isLoading: productsLoading,
    error: productsError,
  }: any = useCubeQuery(getProductsBasedOnRequestId, {
    skip: !shouldFetchProducts,
  });

  useEffect(() => {
    if (productsError?.status === 401 || productsError?.status === 403) {
      //todo: Logout the user
    } else {
      const data = addCheckPropertyToData(
        productsResultSet?.loadResponses[0]?.data,
        false
      );
      if (data) {
        setProductsData(data);
        setShouldFetchProducts(false);
      } else {
        setProductsData([]);
      }
    }
  }, [productsResultSet, productsError]);

  //* useEffect for enable / disable clear button
  useEffect(() => {
    if (!filterTypes?.size?.length && !selectedTransferStatus?.length) {
      setClearDisable(true);
    } else {
      setClearDisable(false);
    }
  }, [filterTypes, selectedTransferStatus]);

  //* Method for search
  const onChangeHandler = (event: any) => {
    setUserInput(event.target.value);
    setShouldFetchProducts(true);
  };

  //* Method for sort
  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
    setShouldFetchProducts(true);
  };

  //* Method for apply filter
  const onApplyFilters = () => {
    const filterPayload = {
      size: filterTypes?.size,
      status: selectedTransferStatus,
    };
    setFilterInput(filterPayload);
    setShouldFetchProducts(true);
    setUserInput('');
    setShowFilters(false);
  };

  //* Method for clear filter
  const onClearFilters = () => {
    setSelectedTransferStatus([]);
    setChecked({ Pending: false, Approved: false });
    dispatch(actions.clearAllFilters({}));
    setFilterInput({});
    setShouldFetchProducts(true);
    setShowFilters(false);
    setClearDisable(true);
  };

  const onStatusChange = (event: any) => {
    setChecked({ ...checked, [event?.target?.name]: event?.target?.checked });
    var updatedList = [...selectedTransferStatus];
    if (event.target.checked) {
      updatedList = [...selectedTransferStatus, event.target.name];
    } else {
      updatedList.splice(selectedTransferStatus.indexOf(event.target.name), 1);
    }
    setSelectedTransferStatus(updatedList);
  };

  //* Method to check single checkbox for accept /reject flow
  const handleCheckBoxChecked = (e: any, data: any, tableData: any) => {
    const updatedData = addCheckPropertyToData(
      tableData,
      e?.target?.checked,
      data
    );
    setProductsData(updatedData);
    if (e?.target?.checked) {
      setEnableApproveButton(e?.target?.checked);
    } else {
      const enableDisableButton = toEnableDisableAcceptButtons(updatedData);
      setEnableApproveButton(enableDisableButton);
    }
  };

  //* Method to add extra property for data for accept/reject flow
  const addCheckPropertyToData = (
    tempData: any,
    checkedStatus: boolean,
    dataItem?: any
  ) => {
    if (!!dataItem) {
      return tempData?.map((lineItem: any) => {
        if (
          lineItem['ViewTransfers.barcode'] == dataItem['ViewTransfers.barcode']
        ) {
          const checkboxDisabled = checkWhetherToShowCheckBox(lineItem);
          return {
            ...lineItem,
            isChecked: checkboxDisabled ? false : checkedStatus,
            checkboxDisabled: checkboxDisabled,
          };
        } else {
          return lineItem;
        }
      });
    } else {
      const data = tempData?.map((lineItem: any) => {
        const checkboxDisabled = checkWhetherToShowCheckBox(lineItem);
        return {
          ...lineItem,
          isChecked: checkboxDisabled ? false : checkedStatus,
          checkboxDisabled: checkboxDisabled,
        };
      });
      return data;
    }
  };

  //* Check whether to disable checkbox or not
  const checkWhetherToShowCheckBox = (item: any) => {
    let toShow: boolean = false;
    if (
      item['ViewTransfers.transferStatus'] === 'Approved' ||
      item['ViewTransfers.transferStatus'] === 'Rejected' ||
      item['ViewTransfers.transferStatus'] === ''
    ) {
      toShow = true;
    }
    return toShow;
  };

  //* Method to check all checkbox for accept /reject
  const handleCheckAll = (event: any, tableData: any) => {
    setIsAllCheckBoxChecked(event?.target?.checked);
    const updatedData = addCheckPropertyToData(
      tableData,
      event?.target?.checked
    );
    const enableDisableButton = toEnableDisableAcceptButtons(updatedData);
    setProductsData(updatedData);
    setEnableSelectAllButton(enableDisableButton);
    setEnableApproveButton(enableDisableButton);
  };

  //* Whether to enable /disable accept buttons
  const toEnableDisableAcceptButtons = (data: any) => {
    if (data?.filter((item: any) => item.isChecked == true)?.length) {
      return true;
    } else {
      return false;
    }
  };

  const detailsActionHandler = (selectedRow: any) => {
    setSelectedSizeDataForModal(selectedRow || {});
    setShowDetailsModal(true);
  };

  //* Method to call accept reject api call
  const handleSubmit = async () => {
    const selectedFilteredProducts = productsData?.filter((items: any) => {
      if (items?.isChecked) return items;
    });
    const grouped = groupBy(selectedFilteredProducts, 'ViewTransfers.sku');
    let skuDetailsData: any = [];
    Object.keys(grouped).forEach(function (key, index) {
      skuDetailsData.push({ barcodes: grouped[key], skuId: key });
    });

    try {
      setIsLoading(true);
      const url = ACCEPT_REJECT_TRANSFER_URL;
      const payload: any = showRejectTransferModal
        ? {
            reject_reason: '',
            sku_details: skuDetailsData,
            status: showAcceptTransferModal
              ? TRANSFER_APPROVE_REJECT_STATUS?.APPROVED
              : TRANSFER_APPROVE_REJECT_STATUS?.REJECTED,
            transfer_id: transferId,
          }
        : {
            sku_details: skuDetailsData,
            status: showAcceptTransferModal
              ? TRANSFER_APPROVE_REJECT_STATUS?.APPROVED
              : TRANSFER_APPROVE_REJECT_STATUS?.REJECTED,
            transfer_id: transferId,
          };
      const response = await doRequest(url, 'post', payload);
      if (response) {
        setIsLoading(false);
        setIsVisibleMessage(true);
        setSeverityType('success');
        setNotificationMessage(
          showAcceptTransferModal ? ACCEPT_TRANSFER_MSG : REJECT_TRANSFER_MSG
        );
        setEnableApproveButton(false);
        setEnableSelectAllButton(false);
      }
    } catch (error: any) {
      console.log('transfer error: ', error);
      setIsLoading(false);
      setIsVisibleMessage(true);
      setSeverityType('error');
      setNotificationMessage(NOTIFICATION_SOMETHING_WENT_WRONG);
    }
    setShowAcceptTransferModal(false);
    setShowRejectTransferModal(false);
    setShouldFetchProducts(true);
  };

  //* Method to separate out the data as per the payload required
  const groupBy = (array: any, property: any) => {
    return array.reduce((result: any, item: any) => {
      const key = item[property];
      if (!result[key]) {
        result[key] = [];
      }
      result[key].push(item?.['ViewTransfers.barcode']);
      return result;
    }, {});
  };

  const columns = useMemo(
    () => [
      {
        type: 'checkbox',
        title: '',
        checked: 'isChecked',
        value: 'ViewTransfers.barcode',
        isDisabled: 'checkboxDisabled',
        onChange: (e: any, data: any, tableData: any) => {
          handleCheckBoxChecked(e, data, tableData);
        },
        checkAll: (e: any, tableData: any) => handleCheckAll(e, tableData),
        isAllChecked: isAllCheckBoxChecked,
      },
      {
        title: 'SKU',
        value: 'ViewTransfers.sku',
      },
      {
        title: 'Barcode',
        type: 'copyToClipboard',
        value: 'ViewTransfers.barcode',
      },
      {
        title: 'Condition',
        value: 'ViewTransfers.conditionName',
      },
      {
        title: 'Size',
        value: 'ViewTransfers.size',
      },
      {
        title: 'Selling Price',
        value: 'ViewTransfers.retailPrice_D',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Status',
        type: 'status',
        value: 'ViewTransfers.transferStatus',
        success: 'Approved',
        danger: 'Pending',
        lowdanger: 'Rejected',
        consignment: true,
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          detailsActionHandler(data);
        },
        value: 'Details',
      },
    ],
    []
  );

  const headers = {
    title: 'Transfer',
    titleImage: TransferDefault,
    subTitle: transferId || '--',
    onClick: () => {
      router?.push(getBasePath('transfers'));
    },
  };

  return (
    <>
      <div className='container-fluid'>
        <div className='row'>
          <Breadcrumbs data={headers} />
        </div>
      </div>

      <div className='app-wrapper w-100 consignment-consignments-details-page-wrapper yk-view-transfer-details-page-wrapper'>
        <div className='orders-page-inner-wrapper yk-accept-transfer-details-wrapper'>
          <div className='container-fluid'>
            <div className='yk-accept-details-heading-wrapper'>
              <div className='consignmentDetailsHeader'>
                <h2 className='yk-transferId'>{transferId || '--'}</h2>
                <h5 className='sub-haeding'>Transfer details</h5>
              </div>
              {/* <div className='btn-wrapper'>
                <button
                  className='yk-newNotificationsBtn'
                  disabled={!enableSelectAllButton}
                  onClick={() => setShowAcceptTransferModal(true)}>
                  Accept All
                </button>
              </div> */}
            </div>
          </div>
          <ViewAcceptTransferHeaders
            transferId={transferId}
            requestType={requestType}
          />
          <div className='container-fluid'>
            <div className='row'>
              <div className='col-lg-12 col-md-12 col-sm-12'>
                <div className='ConsignmentsWrap'>
                  <div className='yk-sku-titles YKCH-detailTitle'>
                    <h2 className='yk-prod-main-titles mb-3 YK-LKEEEE'>
                      Items
                    </h2>
                    <div className='YKCH-approveRejectBBTTN'>
                      <Button
                        className='MuiButtonBase-root me-3 YKCH-reject'
                        disabled={!enableApproveButton}
                        onClick={() => setShowRejectTransferModal(true)}>
                        Reject
                      </Button>
                      <Button
                        className='MuiButtonBase-root YKCH-aprove'
                        disabled={!enableApproveButton}
                        onClick={() => setShowAcceptTransferModal(true)}>
                        Accept
                      </Button>
                    </div>
                  </div>
                  <div className='search-btn-wrapper'>
                    <div className='row'>
                      <div className='col-xl-4 col-lg-12 col-md-12 col-sm-12 col-12'>
                        <div className='YKCH-searchingData'>
                          <SearchComp
                            optionType='change'
                            placeholder='Search'
                            onChangeHandler={onChangeHandler}
                          />
                        </div>
                      </div>
                      <div className='col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12'>
                        <div className='consignment-btn-wrapper'>
                          <div>
                            <Sortings
                              itemKey='viewAcceptTransfer'
                              handleChange={sortHandler}
                              defaultSelectedValue={selectedSort}
                            />
                          </div>
                          <div className='filter-btn-wrapper YKCH-filterWrapperr'>
                            <ClickAwayListener
                              onClickAway={() => {
                                setShowFilters(false);
                              }}>
                              <div className='YKCH-filterBTNWrapp me-0'>
                                <button
                                  className='btn filter-btn '
                                  onClick={() => setShowFilters(!showFilters)}>
                                  <Image
                                    src={filterIcon}
                                    alt='filter-btn-icon'
                                    className='filter-btn-icon img-fluid'
                                  />
                                  <span className='filter-btn-text yk-badge-h15'>
                                    Filter
                                  </span>
                                </button>
                                {showFilters && (
                                  <ProductFilters
                                    itemKey='viewAcceptTransfer'
                                    component='viewAcceptTransfer'
                                    onPayoutChange={onStatusChange}
                                    onApplyClick={onApplyFilters}
                                    onClearFilters={onClearFilters}
                                    clearDisable={clearDisable}
                                  />
                                )}
                              </div>
                            </ClickAwayListener>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {productsError ? (
                    <p>Something went wrong!</p>
                  ) : productsLoading ? (
                    <CircleLoader />
                  ) : productsData && productsData?.length > 0 ? (
                    <div className='yk-viewTransferDetailsTable'>
                      <VirtualTable
                        ref={componentRef}
                        headers={columns}
                        rowData={productsData}
                        loading={productsLoading}
                        error={productsError}
                      />
                    </div>
                  ) : (
                    <NoDataFound ref={componentRef} />
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
        <Notification
          showSuccessPopup={isVisibleMessage}
          handleSnackbarClose={() => setIsVisibleMessage(false)}
          severityType={severityType}
          message={notificationMessage}
          className='yk-shoesize-alert-wrapper'
        />
      </div>
      {(showAcceptTransferModal || showRejectTransferModal) && (
        <AcceptRejectTransferModal
          showAcceptTransferModal={showAcceptTransferModal}
          showRejectTransferModal={showRejectTransferModal}
          setShowRejectTransferModal={setShowRejectTransferModal}
          setShowAcceptTransferModal={setShowAcceptTransferModal}
          transferData={productsData}
          setIsVisibleMessage={setIsVisibleMessage}
          setSeverityType={setSeverityType}
          setNotificationMessage={setNotificationMessage}
          handleSubmit={handleSubmit}
        />
      )}
      {showDetailsModal && (
        <OrderDetailsModal
          showModal={showDetailsModal}
          handleClose={setShowDetailsModal}
          skuId={selectedSizeDataForModal?.['ViewTransfers.sku']}
          lineItemId={
            selectedSizeDataForModal?.['ViewTransfers.consignmentLineItemId_D']
          }
          orderDetails='shoeDetails'
          isShoeCatalog={false}
          modalUsedFor='Transfer'
        />
      )}
      {isLoading && <CircleLoader />}
    </>
  );
};

export default AcceptTransferComp;
