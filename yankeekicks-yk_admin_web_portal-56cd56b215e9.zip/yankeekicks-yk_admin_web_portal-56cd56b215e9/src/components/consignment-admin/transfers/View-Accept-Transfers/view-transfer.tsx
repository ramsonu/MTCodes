import React, { useEffect, useState, useMemo, useRef } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/router';
import { useCubeQuery } from '@cubejs-client/react';
import { useSelector, useDispatch } from 'react-redux';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import { actions } from 'store/reducers/kiosk';
import { getBasePath } from 'utils/util';
import { getProductsBasedOnRequestIdsQuery } from 'middleware/cubejs-wrapper/transfers-query';
import Breadcrumbs from 'components/common/breadcrumbs';
import SearchComp from 'components/common/search';
import VirtualTable from 'components/common/table';
import Sortings from 'components/common/sortings';
import ProductFilters from 'components/common/filters/product-filter';
import OrderDetailsModal from 'components/consignment-admin/orders/order-details-modal';
import NoDataFound from 'components/common/no-data-found';
import CircleLoader from 'components/common/loader/circular-loader';
import ViewAcceptTransferHeaders from './view-accept-transfer-headers';
import TransferDefault from 'assets/images/menu-icons/transfer-gray-img.svg';
import filterIcon from 'assets/images/filter-icon.png';

const ViewTransferComp = () => {
  const dispatch = useDispatch();
  const router = useRouter();

  const { transferId, requestType } = router.query;
  const componentRef: any = useRef(null);

  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const [filterInput, setFilterInput] = useState<any>({});
  const [checked, setChecked] = useState({
    Pending: false,
    Approved: false,
  });
  const [selectedTransferStatus, setSelectedTransferStatus] = useState<any>([]);
  const [clearDisable, setClearDisable] = useState(true);
  const [userInput, setUserInput] = useState<any>('');
  const [selectedSort, setSelectedSort] = useState('skuAsc');
  const [showFilters, setShowFilters] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState<any>(false);
  const [productsData, setProductsData] = useState<any>([]);
  const [shouldFetchProducts, setShouldFetchProducts] =
    useState<boolean>(false);
  const [selectedSizeDataForModal, setSelectedSizeDataForModal] = useState<any>(
    []
  );

  useEffect(() => {
    if (transferId) {
      setShouldFetchProducts(true);
    } else {
      setShouldFetchProducts(false);
    }
  }, [transferId, router.query]);

  const getProductsBasedOnRequestId: any = getProductsBasedOnRequestIdsQuery(
    transferId,
    userInput,
    selectedSort,
    filterInput
  );

  const {
    resultSet: productsResultSet,
    isLoading: productsLoading,
    error: productsError,
  }: any = useCubeQuery(getProductsBasedOnRequestId, {
    skip: !shouldFetchProducts,
  });

  useEffect(() => {
    if (productsError?.status === 401 || productsError?.status === 403) {
      //todo: Logout the user
    } else {
      const data = productsResultSet?.loadResponses[0]?.data;
      if (data) {
        setProductsData(data);
        setShouldFetchProducts(false);
      } else {
        setProductsData([]);
      }
    }
  }, [productsResultSet, productsError]);

  useEffect(() => {
    if (!filterTypes?.size?.length && !selectedTransferStatus?.length) {
      setClearDisable(true);
    } else {
      setClearDisable(false);
    }
  }, [filterTypes, selectedTransferStatus]);

  // method for search
  const onChangeHandler = (event: any) => {
    setUserInput(event.target.value);
    setShouldFetchProducts(true);
  };

  // method for sorting
  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
    setShouldFetchProducts(true);
  };

  //method for apply filter
  const onApplyFilters = () => {
    const filterPayload = {
      size: filterTypes?.size,
      status: selectedTransferStatus,
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setShouldFetchProducts(true);
    setShowFilters(false);
  };

  //method for clear filter
  const onClearFilters = () => {
    setSelectedTransferStatus([]);
    setChecked({ Pending: false, Approved: false });
    dispatch(actions.clearAllFilters({}));
    setFilterInput({});
    setShouldFetchProducts(true);
    setShowFilters(false);
    setClearDisable(true);
  };

  const onStatusChange = (event: any) => {
    setChecked({ ...checked, [event?.target?.name]: event?.target?.checked });
    var updatedList = [...selectedTransferStatus];
    if (event.target.checked) {
      updatedList = [...selectedTransferStatus, event.target.name];
    } else {
      updatedList.splice(selectedTransferStatus.indexOf(event.target.name), 1);
    }
    setSelectedTransferStatus(updatedList);
  };

  const detailsActionHandler = (selectedRow: any) => {
    setSelectedSizeDataForModal(selectedRow || {});
    setShowDetailsModal(true);
  };

  const columns = useMemo(
    () => [
      {
        title: 'SKU',
        value: 'ViewTransfers.sku',
      },
      {
        title: 'Barcode',
        type: 'copyToClipboard',
        value: 'ViewTransfers.barcode',
      },
      {
        title: 'Condition',
        value: 'ViewTransfers.conditionName',
      },
      {
        title: 'Size',
        value: 'ViewTransfers.size',
      },
      {
        title: 'Selling Price',
        value: 'ViewTransfers.retailPrice_D',
        prefix: '$',
        methodToApply: 'toFix',
      },
      {
        title: 'Status',
        type: 'status',
        value: 'ViewTransfers.transferStatus',
        success: 'Approved',
        danger: 'Pending',
        lowdanger: 'Rejected',
        consignment: true,
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          detailsActionHandler(data);
        },
        value: 'Details',
      },
    ],
    []
  );

  const headers = {
    title: 'Transfer',
    titleImage: TransferDefault,
    subTitle: transferId || '--',
    onClick: () => {
      router?.push(getBasePath('transfers'));
    },
  };

  return (
    <>
      <div className='container-fluid'>
        <div className='row'>
          <Breadcrumbs data={headers} />
        </div>
      </div>

      <div className='app-wrapper w-100 consignment-consignments-details-page-wrapper yk-view-transfer-details-page-wrapper'>
        <div className='orders-page-inner-wrapper'>
          <div className='container-fluid'>
            <div className='row'>
              <div className='col-lg-12 col-md-12 col-sm-12 consignmentDetailsHeader'>
                <h2 className='yk-transferId'>{transferId || '--'}</h2>
                <h5 className='sub-haeding'>Transfer details</h5>
              </div>
            </div>
          </div>
          <ViewAcceptTransferHeaders
            transferId={transferId}
            requestType={requestType}
          />
          <div className='container-fluid'>
            <div className='row'>
              <div className='col-lg-12 col-md-12 col-sm-12'>
                <div className='ConsignmentsWrap'>
                  <div className='yk-sku-titles YKCH-detailTitle'>
                    <h2 className='yk-prod-main-titles mb-3 YK-LKEEEE'>
                      Items
                    </h2>
                  </div>
                  <div className='search-btn-wrapper'>
                    <div className='row'>
                      <div className='col-xl-4 col-lg-12 col-md-12 col-sm-12 col-12'>
                        <div className='YKCH-searchingData'>
                          <SearchComp
                            optionType='change'
                            placeholder='Search'
                            onChangeHandler={onChangeHandler}
                          />
                        </div>
                      </div>
                      <div className='col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12'>
                        <div className='consignment-btn-wrapper'>
                          <div>
                            <Sortings
                              itemKey='viewAcceptTransfer'
                              handleChange={sortHandler}
                              defaultSelectedValue={selectedSort}
                            />
                          </div>
                          <div className='filter-btn-wrapper YKCH-filterWrapperr'>
                            <ClickAwayListener
                              onClickAway={() => {
                                setShowFilters(false);
                              }}>
                              <div className='YKCH-filterBTNWrapp me-0'>
                                <button
                                  className='btn filter-btn '
                                  onClick={() => setShowFilters(!showFilters)}>
                                  <Image
                                    src={filterIcon}
                                    alt='filter-btn-icon'
                                    className='filter-btn-icon img-fluid'
                                  />
                                  <span className='filter-btn-text yk-badge-h15'>
                                    Filter
                                  </span>
                                </button>
                                {showFilters && (
                                  <ProductFilters
                                    itemKey='viewAcceptTransfer'
                                    component='viewAcceptTransfer'
                                    onPayoutChange={onStatusChange}
                                    checkedValue={checked}
                                    onApplyClick={onApplyFilters}
                                    onClearFilters={onClearFilters}
                                    clearDisable={clearDisable}
                                  />
                                )}
                              </div>
                            </ClickAwayListener>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {productsError ? (
                    <p>Something went wrong!</p>
                  ) : productsLoading ? (
                    <CircleLoader />
                  ) : productsData && productsData?.length > 0 ? (
                    <div className='yk-viewTransferDetailsTable'>
                      <VirtualTable
                        ref={componentRef}
                        headers={columns}
                        rowData={productsData}
                        loading={productsLoading}
                        error={productsError}
                      />
                    </div>
                  ) : (
                    <NoDataFound ref={componentRef} />
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showDetailsModal && (
        <OrderDetailsModal
          showModal={showDetailsModal}
          handleClose={setShowDetailsModal}
          skuId={selectedSizeDataForModal?.['ViewTransfers.sku']}
          lineItemId={
            selectedSizeDataForModal?.['ViewTransfers.consignmentLineItemId_D']
          }
          orderDetails='shoeDetails'
          isShoeCatalog={false}
          modalUsedFor='Transfer'
        />
      )}
    </>
  );
};

export default ViewTransferComp;
