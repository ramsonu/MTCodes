import React from 'react';
import Image from 'next/image';
import { useDispatch } from 'react-redux';
import { actions } from 'store/reducers/consignment';
import { Modal } from '@mui/material';
import ModalCloseIcon from 'assets/images/modal-close-icon.svg';

const RemoveConfirmationModal = (props: any) => {
  const {
    showRemoveConfirmationModal,
    setShowRemoveConfirmationModal,
    setShowQueue,
  } = props;

  const dispatch = useDispatch();

  const removeAllItems = () => {
    dispatch(actions?.clearAllTransfersData({}));
    setShowRemoveConfirmationModal(false);
    setShowQueue(false);
  };

  return (
    <div className='app-wrapper w-100 landing-page-wrapper'>
      <Modal
        open={showRemoveConfirmationModal}
        onClose={() => setShowRemoveConfirmationModal(false)}
        className='yk-change-commission-modal-wrapper yk-remove-all-modal-wrapper'
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'>
        <div className='app-wrapper change-commission-modal-wrapper'>
          <div className='yk-modal-body'>
            <div className='modal-heading-wrapper d-flex justify-content-between align-items-center'>
              <h3 className='modal-title yk-badge-h11 mb-0'>Remove all</h3>
              <div className='close-btn-wrapper'>
                <button
                  className='btn prod-close'
                  onClick={() => setShowRemoveConfirmationModal(false)}>
                  <Image
                    src={ModalCloseIcon}
                    alt='table-close-icon'
                    className='table-close-icon'
                  />
                </button>
              </div>
            </div>
            <p className='yk-modalDescription mb-0'>
              Remove all shoes from queue. This action is irreversible. Are you
              sure you want to clear queue?
            </p>

            <div className='yk-modal-btn-wrapper'>
              <button
                type='button'
                className='btn modal-btn-cancel'
                data-bs-dismiss='modal'
                onClick={() => setShowRemoveConfirmationModal(false)}>
                Cancel
              </button>
              <button
                type='button'
                className='btn modal-btn-submit'
                onClick={removeAllItems}>
                Confirm
              </button>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default RemoveConfirmationModal;
