import React, { useState } from 'react';
import Image from 'next/image';
import { useSelector, useDispatch } from 'react-redux';
import { useRouter } from 'next/router';
import { actions } from 'store/reducers/consignment';
import { getBasePath } from 'utils/util';
import ImageLoader from 'components/common/image-loader';
import productImg from 'assets/images/big-product-img.svg';
import AddIcon from 'assets/images/grey-add-icon.svg';
import modalCloseIcon from 'assets/images/modal-close-btn-icon.svg';
import RemoveConfirmationModal from './remove-confirmation-modal';
import ModalCloseIcon from 'assets/images/modal-close-icon.svg';

const Queue = (props: any) => {
  const { setShowQueue } = props;

  const router = useRouter();
  const dispatch = useDispatch();

  const { transfers } = useSelector((state: any) => state.consignment);
  const [showRemoveConfirmationModal, setShowRemoveConfirmationModal] =
    useState<boolean>(false);

  const addToInventoryRedirect = () => {
    router.push(getBasePath('transfers/initiate-transfer/review-transfer'));
  };

  const removeQueueItem = (value: any) => {
    dispatch(actions?.removeSelectedItemFromTransfers(value));
  };

  return (
    <>
      <div className='consignment-btn-wrapper'>
        <div className='inventory-queue-sidenav yk-admin-sidenav'>
          <h3 className='heading mb-0'>Queue</h3>
          <span className='closebtn' onClick={() => setShowQueue(false)}>
            <Image
              src={modalCloseIcon}
              alt='table-close-icon'
              className='table-close-icon'
            />
          </span>
          <div className='add-shoes-wrapper px-0'>
            <div
              className={`heading-wrapper ${
                transfers?.length === 0 ? 'd-block text-center' : ''
              }`}>
              {transfers?.length > 0 && <h3 className='description'>Shoes</h3>}
              <div className='clear-queue-wrapper'>
                {transfers?.length > 0 && (
                  <button
                    className='btn modal-btn-cancel'
                    onClick={() => setShowRemoveConfirmationModal(true)}>
                    Remove all
                  </button>
                )}
              </div>
            </div>

            {transfers?.length === 0 && (
              <div className='empty-wrapper'>
                <div className='empty-list'>
                  <Image src={AddIcon} alt='' className='img-fluid' />
                  <p>Add products here</p>
                </div>
              </div>
            )}

            <ul className='pending-list list-all-consignment queue-list-items-list'>
              {transfers?.map((item: any, indx: any) => {
                return (
                  <li key={indx}>
                    <button
                      className='btn prod-close'
                      onClick={() => removeQueueItem(item)}>
                      <Image
                        src={ModalCloseIcon}
                        alt='table-close-icon'
                        className='table-close-icon'
                      />
                    </button>
                    <div className='row w-100'>
                      <div className='col-lg-3 col-md-3 col-sm-3 col-3'>
                        <ImageLoader
                          src={item?.productImage}
                          alt='cart-img'
                          fallbackImg={productImg}
                          className='img-fluid img-product-logo'
                        />
                      </div>
                      <div className='col-lg-9 col-md-9 col-sm-9 col-9 ps-0'>
                        <div className='row'>
                          <div className='col-lg-12 d-flex align-items-center'>
                            <p className='product-label'>Name:&nbsp;</p>
                            <p
                              className='product-value yk-custom-ellipse'
                              title={item?.nameOfProduct || '--'}>
                              {item?.nameOfProduct || '--'}
                            </p>
                          </div>
                        </div>

                        <div className='row'>
                          <div className='col-lg-6 d-flex align-items-center'>
                            <p className='product-label'>SKU:&nbsp;</p>
                            <p
                              className='product-value yk-custom-ellipse'
                              title={item?.sku || '--'}>
                              {item?.sku || '--'}
                            </p>
                          </div>
                          {/* <div className='col-lg-6 d-flex align-items-center'>
                            <p className='product-label'>Barcode:&nbsp;</p>
                            <p
                              className='product-value yk-custom-ellipse'
                              title={item?.barcode || '--'}>
                              {item?.barcode || '--'}
                            </p>
                          </div> */}
                          <div className='col-lg-6 d-flex align-items-center'>
                            <p className='product-label'>
                              Transfer Quantity:&nbsp;
                            </p>
                            <p className='product-value'>
                              {item?.quantityToTransfer || '--'}
                            </p>
                          </div>
                        </div>

                        <div className='row'>
                          <div className='col-lg-6 d-flex align-items-center'>
                            <p className='product-label'>Size:&nbsp;</p>
                            <p className='product-value'>
                              {item?.size || '--'}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
            <div className='button-action-wrapper'>
              <button
                className={`btn btn-place-request ${
                  transfers?.length === 0 ? 'disabled' : ''
                }`}
                onClick={addToInventoryRedirect}
                type='button'>
                Review Transfers
              </button>
            </div>
          </div>
        </div>
      </div>

      {showRemoveConfirmationModal && (
        <RemoveConfirmationModal
          showRemoveConfirmationModal={showRemoveConfirmationModal}
          setShowRemoveConfirmationModal={setShowRemoveConfirmationModal}
          setShowQueue={setShowQueue}
        />
      )}
    </>
  );
};

export default Queue;
