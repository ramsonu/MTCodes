import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import { useDispatch, useSelector } from 'react-redux';
import { Modal, CircularProgress } from '@mui/material';
import ModalCloseIcon from 'assets/images/modal-close-icon.svg';
import VirtualTable from 'components/common/table';
import { actions } from 'store/reducers/consignment';
import { sizeBasedOnProductId } from 'middleware/cubejs-wrapper/transfers-query';
import { useCubeQuery } from '@cubejs-client/react';

const SelectSizesModal = (props: any) => {
  const {
    showSizeModal = false,
    setShowSizeModal = () => {},
    productLevelData = {},
    setShowQueue = () => {},
    modalType = 'add',
    dataForRow = {},
  } = props;

  const dispatch = useDispatch();

  const locId: any = localStorage?.getItem('storeLocationId');

  const isAddModal: boolean = modalType === 'add' ? true : false;

  const { transfers } = useSelector((state: any) => state.consignment);
  const [allSizes, setAllSizes] = useState<any>([]);
  const [uniqueSizes, setUniqueSizes] = useState<any>([]);
  const [filteredSizes, setFilteredSizes] = useState<any>([]);
  const [selectedSizesRow, setSelectedSizesRow] = useState<any>([]);
  const [selectedSizes, setSelectedSizes] = useState<any>([]);
  const [conditions, setConditions] = useState<any>([]);
  const [selectedCondition, setSelectedCondition] = useState<string>('');
  const [shouldFetchSizes, setShouldFetchSizes] = useState<boolean>(false);
  const [sizesWhichQuantityIsHigher, setSizesWhichQuantityIsHigher] =
    useState<any>([]);
  const [sizesWhichCannotAddToQueue, setSizesWhichCannotAddToQueue] =
    useState<any>([]);

  const getSizesByProductIdQuery: any = sizeBasedOnProductId(
    productLevelData?.['MyInventory.productId'],
    locId
  );

  const {
    resultSet: sizesResultSet,
    isLoading: sizesIsLoading,
    error: sizesError,
  }: any = useCubeQuery(getSizesByProductIdQuery, { skip: !shouldFetchSizes });

  useEffect(() => {
    if (productLevelData?.['MyInventory.productId'] && modalType === 'add') {
      setShouldFetchSizes(true);
    } else {
      setShouldFetchSizes(false);
    }
  }, [productLevelData]);

  useEffect(() => {
    if (sizesError?.status === 401 || sizesError?.status === 403) {
      //todo: Logout the user
    } else {
      const data = sizesResultSet?.loadResponses[0]?.data;
      if (data) {
        setAllSizes(data);
        setShouldFetchSizes(false);
      } else {
        setAllSizes([]);
      }
    }
  }, [sizesResultSet, sizesError]);

  useEffect(() => {
    // * Added condition check as well because same size name could have different condition
    const removeDuplicateSizes: any = allSizes
      ?.map((item: any) => item)
      ?.filter(
        (item: any, i: any, ar: any) =>
          ar.findIndex(
            (t: any) =>
              t?.['ConsigneeSize.Size'] === item?.['ConsigneeSize.Size'] &&
              t?.['ConsigneeCondition.conditionName'] ===
                item?.['ConsigneeCondition.conditionName']
          ) === i && !!item?.['ConsigneeSize.Size']
      );

    if (removeDuplicateSizes?.length > 0) {
      const uniqueConditions: any = removeDuplicateSizes
        ?.map((item: any) => item?.['ConsigneeCondition.conditionName'])
        ?.filter(
          (conditionName: any, i: any, ar: any) =>
            ar.findIndex((t: any) => t === conditionName) === i &&
            !!conditionName
        );

      const defaultCondition =
        uniqueConditions[0] === 'New' ? 'New' : uniqueConditions[0];

      setUniqueSizes(removeDuplicateSizes);
      setConditions(uniqueConditions || []);
      setSelectedCondition(defaultCondition || '');
    } else {
      setUniqueSizes([]);
      setConditions([]);
      setSelectedCondition('');
    }
  }, [allSizes]);

  useEffect(() => {
    if (selectedCondition) {
      const filterTheSizes: any = uniqueSizes?.filter(
        (item: any) =>
          item?.['ConsigneeCondition.conditionName']?.toLowerCase() ===
          selectedCondition?.toLowerCase()
      );
      setFilteredSizes(filterTheSizes);
    } else {
      setFilteredSizes(uniqueSizes);
    }
  }, [selectedCondition, uniqueSizes]);

  useEffect(() => {
    if (!isAddModal) {
      const itemToAdd: any = {
        size: dataForRow?.size,
        condition: dataForRow?.condition,
        availableQuantity: Number(dataForRow?.availableQuantity),
        barcode: dataForRow?.barcode,
        variantId: dataForRow?.variantId,
        sellingPrice: dataForRow?.sellingPrice,
        quantityToTransferUserInput: dataForRow?.quantityToTransfer,
      };
      setSelectedSizes([itemToAdd]);
    }
  }, [dataForRow, modalType]);

  useEffect(() => {
    // * create payload/row structure based on selected sizes
    /* while creating payload/row structure check whether userInput for quantity to transfer 
    is greater than available quantity of specific size (if it is add modal) */
    const rowForSize = selectedSizes?.map((sizeItem: any) => {
      if (isAddModal) {
        const userInputValue: any = sizeItem?.quantityToTransferUserInput
          ? sizeItem?.quantityToTransferUserInput
          : sizeItem?.quantityToTransferUserInput === 0
          ? 0
          : 1;
        const quantityToCompare: any = Number(
          sizeItem?.['ConsignmentLineItem.availableQuantity']
        );
        checkQtyToTransferFromStateIsHigherThanAvailableQuantity(
          sizeItem,
          userInputValue,
          quantityToCompare
        );
      }

      return {
        size: isAddModal ? sizeItem?.['ConsigneeSize.Size'] : sizeItem?.size,
        availableQuantity: isAddModal
          ? Number(sizeItem?.['ConsignmentLineItem.availableQuantity'])
          : Number(sizeItem?.availableQuantity),
        condition: isAddModal
          ? sizeItem?.['ConsigneeCondition.conditionName']
          : sizeItem?.condition,
        defaultLocationName: localStorage?.getItem('storeLocation') || '',
        barcode: isAddModal
          ? sizeItem?.['ConsignmentLineItem.barcode']
          : sizeItem?.barcode,
        sellingPrice: isAddModal
          ? sizeItem?.['ConsignmentLineItem.retailPrice_D']
          : sizeItem?.sellingPrice,
        variantId: isAddModal
          ? sizeItem?.['ConsignmentLineItem.variantId']
          : sizeItem?.variantId,
        quantityToTransfer: sizeItem?.quantityToTransferUserInput
          ? sizeItem?.quantityToTransferUserInput
          : sizeItem?.quantityToTransferUserInput === 0
          ? 0
          : sizeItem?.quantityToTransferUserInput === ''
          ? ''
          : 1,
      };
    });
    setSelectedSizesRow(rowForSize || []);
  }, [selectedSizes, isAddModal]);

  useEffect(() => {
    // * to show the sizes which transfer quantity is higher than available quantity
    if (sizesWhichQuantityIsHigher?.length > 0) {
      if (selectedSizes?.length > 0) {
        const tempSizes: any = sizesWhichQuantityIsHigher?.filter(
          (QtyItem: any) =>
            selectedSizes?.find(
              (item: any) =>
                item?.['ConsigneeSize.Size'] === QtyItem?.size &&
                item?.['ConsigneeCondition.conditionName'] ===
                  QtyItem?.condition
            )
        );
        setSizesWhichCannotAddToQueue(tempSizes);
      } else {
        setSizesWhichQuantityIsHigher([]);
      }
    } else {
      setSizesWhichCannotAddToQueue([]);
    }
  }, [selectedSizes, sizesWhichQuantityIsHigher]);

  const sizeSelector = (value: any) => {
    // if quantity of shoe is available (greater than zero)
    if (value?.['ConsignmentLineItem.availableQuantity']) {
      // 👇️ if size already selected -> remove it else add it.
      if (
        selectedSizes?.filter(
          (item: any) =>
            item?.['ConsigneeSize.Size'] === value?.['ConsigneeSize.Size'] &&
            item?.['ConsigneeCondition.conditionName'] ===
              value?.['ConsigneeCondition.conditionName']
        )?.length > 0
      ) {
        const sizesExceptCurrent = selectedSizes?.filter(
          (sizeItem: any) =>
            !(
              sizeItem?.['ConsigneeSize.Size'] ===
                value?.['ConsigneeSize.Size'] &&
              sizeItem?.['ConsigneeCondition.conditionName'] ===
                value?.['ConsigneeCondition.conditionName']
            )
        );
        setSelectedSizes(sizesExceptCurrent);
      } else {
        setSelectedSizes([...selectedSizes, value]);
      }
    }
  };

  const isSizePresentInArray = (
    arrayValues: any,
    valueToCheck: any,
    compareDirectly: any = false
  ) => {
    let isPresent: any = false;
    let sizeToCompare: any = compareDirectly
      ? valueToCheck?.size
      : valueToCheck?.['ConsigneeSize.Size'];
    let conditionToCompare: any = compareDirectly
      ? valueToCheck?.condition
      : valueToCheck?.['ConsigneeCondition.conditionName'];
    arrayValues?.map((item: any) => {
      if (
        item?.size === sizeToCompare &&
        item?.condition === conditionToCompare
      ) {
        return (isPresent = true);
      }
    });
    return isPresent;
  };

  const checkQtyToTransferFromStateIsHigherThanAvailableQuantity = (
    obj: any,
    userInputValue: any = 0,
    quantityToCompare: any = 0
  ) => {
    transfers?.map((transObj: any) => {
      if (
        obj?.['ConsigneeSize.Size'] === transObj?.size &&
        obj?.['ConsigneeCondition.conditionName'] === transObj?.condition &&
        obj?.['ConsignmentLineItem.barcode'] === transObj?.barcode &&
        productLevelData?.['MyInventory.itemName'] ===
          transObj?.nameOfProduct &&
        productLevelData?.['MyInventory.sku'] === transObj?.sku
      ) {
        if (
          Number(userInputValue) + Number(transObj?.quantityToTransfer) >
          Number(quantityToCompare)
        ) {
          // * this is the user value which higher than its availableQuantity (user input + redux value)
          if (
            // !sizesWhichQuantityIsHigher?.includes(obj?.['ConsigneeSize.Size'])
            !isSizePresentInArray(sizesWhichQuantityIsHigher, obj)
          ) {
            setSizesWhichQuantityIsHigher([
              ...sizesWhichQuantityIsHigher,
              {
                size: obj?.['ConsigneeSize.Size'],
                condition: obj?.['ConsigneeCondition.conditionName'],
              },
            ]);
          }
        } else {
          if (
            // sizesWhichQuantityIsHigher?.includes(obj?.['ConsigneeSize.Size'])
            isSizePresentInArray(sizesWhichQuantityIsHigher, obj)
          ) {
            let tempSizes = [];
            tempSizes = sizesWhichQuantityIsHigher?.filter(
              (data: any) =>
                !(
                  data?.size === obj?.['ConsigneeSize.Size'] &&
                  data?.condition === obj?.['ConsigneeCondition.conditionName']
                )
            );
            setSizesWhichQuantityIsHigher(tempSizes);
          }
        }
      }
    });
  };

  const transferQuantityInputHandler = (userInput: any, rowIndex: any) => {
    const userInputValue: any = Number(userInput?.currentTarget?.value);
    const quantityToCompare: any = isAddModal
      ? selectedSizes[rowIndex]?.['ConsignmentLineItem.availableQuantity']
      : selectedSizes[rowIndex]?.availableQuantity;

    if (userInputValue <= Number(quantityToCompare)) {
      setSelectedSizes((prevState: any) => {
        const newState = prevState.map((obj: any, index: any) => {
          // 👇️ if selectedSize index is equals to rowIndex, update the country property
          if (index === rowIndex) {
            return {
              ...obj,
              quantityToTransferUserInput: userInputValue,
            };
          }

          // 👇️ otherwise return the object as is
          return obj;
        });

        return newState;
      });
    }
  };

  const removeDataRow = (value: any) => {
    if (modalType === 'add') {
      const removeSelectedRow = selectedSizes?.filter(
        (item: any) =>
          !(
            item?.['ConsigneeSize.Size'] === value?.size &&
            item?.['ConsigneeCondition.conditionName'] === value?.condition
          )
      );
      setSelectedSizes(removeSelectedRow);
    } else if (modalType === 'edit') {
      const removeSelectedItemFromRedux = transfers?.filter(
        (item: any) =>
          item?.size !== value?.size && item?.barcode !== value?.barcode
      );
      dispatch(actions.setTransfersData(removeSelectedItemFromRedux));
      setShowSizeModal(false);
    }
  };

  const updateExistingItemFromState = (updateObj: any) => {
    const newUpdateState: any = transfers?.map((obj: any) => {
      // if below properties match in transfers state
      if (
        obj?.size === updateObj?.[0]?.size &&
        obj?.condition === updateObj?.[0]?.condition &&
        obj?.barcode === updateObj?.[0]?.barcode &&
        obj?.variantId === updateObj?.[0]?.variantId &&
        obj?.sku === updateObj?.[0]?.sku &&
        obj?.nameOfProduct === updateObj?.[0]?.nameOfProduct &&
        obj?.availableQuantity === updateObj?.[0]?.availableQuantity
      ) {
        const objetToUse: any = updateObj?.[0];
        return { ...obj, ...objetToUse };
      }

      // otherwise return the transfers obj as it is
      return obj;
    });
    // update particular item from redux
    dispatch(actions?.setTransfersData(newUpdateState));
  };

  const checkRowItemsExistOrNot = (rowItems: any) => {
    let itemsAlreadyPresent: any = []; // items to be update
    let newItemsToBeAdded: any = []; // items to be add as new
    let itemsWhichAreNotUpdatingNorNew: any = []; // items which are not getting update, neither new

    // store items which are already present in redux
    rowItems?.map((rItem: any) => {
      transfers?.map((tItem: any) => {
        if (
          rItem?.size === tItem?.size &&
          rItem?.condition === tItem?.condition &&
          rItem?.sku === tItem?.sku &&
          rItem?.barcode === tItem?.barcode &&
          rItem?.variantId === tItem?.variantId &&
          rItem?.nameOfProduct === tItem?.nameOfProduct
        ) {
          itemsAlreadyPresent?.push(rItem);
        }
      });
    });

    // store items which are going to be newly added
    rowItems?.map((rItem: any, rIndex: any) => {
      transfers?.filter((tItem: any, tIndex: any) => {
        if (
          !(
            rItem?.size === tItem?.size &&
            rItem?.condition === tItem?.condition &&
            rItem?.sku === tItem?.sku &&
            rItem?.barcode === tItem?.barcode &&
            rItem?.variantId === tItem?.variantId &&
            rItem?.nameOfProduct === tItem?.nameOfProduct
          )
        ) {
          if (
            !itemsAlreadyPresent?.includes(rItem) &&
            !newItemsToBeAdded?.includes(rItem)
          ) {
            newItemsToBeAdded?.push(rItem);
          }
        }
      });
    });

    const isPresent = (arrayToUse: any, itemToCheck: any) => {
      let present = false;
      arrayToUse?.map((aItem: any) => {
        if (
          aItem?.size === itemToCheck?.size &&
          aItem?.condition === itemToCheck?.condition &&
          aItem?.sku === itemToCheck?.sku &&
          aItem?.barcode === itemToCheck?.barcode &&
          aItem?.variantId === itemToCheck?.variantId &&
          aItem?.nameOfProduct === itemToCheck?.nameOfProduct
        ) {
          present = true;
        }
      });
      return present;
    };

    // store items which are not getting updated nor getting add as new
    transfers?.map((item: any) => {
      if (
        !isPresent(itemsAlreadyPresent, item) &&
        !isPresent(newItemsToBeAdded, item)
      ) {
        itemsWhichAreNotUpdatingNorNew?.push(item);
      }
    });

    // combine three arrays and store it in redux
    if (itemsAlreadyPresent?.length > 0 || newItemsToBeAdded?.length > 0) {
      const combineItems: any = [
        ...itemsAlreadyPresent,
        ...itemsWhichAreNotUpdatingNorNew,
        ...newItemsToBeAdded,
      ];
      dispatch(actions?.setTransfersData(combineItems));
    }
  };

  const onAddSizesToQueue = () => {
    let holdOldQuantityToTransfer: any = 0;
    const transfersNewArray = selectedSizesRow?.map((item: any) => {
      holdOldQuantityToTransfer = 0;
      if (isAddModal) {
        transfers?.filter((transferItem: any) => {
          if (
            item?.size === transferItem?.size &&
            item?.condition === transferItem?.condition &&
            item?.barcode === transferItem?.barcode &&
            item?.variantId === transferItem?.variantId &&
            productLevelData?.['MyInventory.sku'] === transferItem?.sku &&
            productLevelData?.['MyInventory.itemName'] ===
              transferItem?.nameOfProduct
          ) {
            holdOldQuantityToTransfer = transferItem?.quantityToTransfer;
          }
        });
      }

      const quantityToAddInTransferState =
        isAddModal && holdOldQuantityToTransfer
          ? Number(item?.quantityToTransfer) + Number(holdOldQuantityToTransfer)
          : item?.quantityToTransfer;

      return {
        from: item?.defaultLocationName,
        to: '',
        size: item?.size,
        condition: item?.condition,
        availableQuantity: item?.availableQuantity,
        barcode: isAddModal ? item?.barcode : dataForRow?.barcode,
        sellingPrice: item?.sellingPrice,
        variantId: item?.variantId,
        quantityToTransfer: quantityToAddInTransferState,
        sku: isAddModal
          ? productLevelData?.['MyInventory.sku']
          : dataForRow?.sku,
        nameOfProduct: isAddModal
          ? productLevelData?.['MyInventory.itemName']
          : dataForRow?.nameOfProduct,
        productImage: isAddModal
          ? productLevelData?.['MyInventory.imageUrl']
          : dataForRow?.productImage,
        brandName: isAddModal
          ? productLevelData?.['MyInventory.brand']
          : dataForRow?.brandName,
      };
    });

    if (isAddModal) {
      // if redux is empty means it is getting added first time so no need for checks
      if (transfers?.length === 0) {
        dispatch(actions?.updateTransfersData(transfersNewArray));
      } else {
        checkRowItemsExistOrNot(transfersNewArray);
      }
    } else {
      updateExistingItemFromState(transfersNewArray);
    }
    setShowSizeModal(false);
    if (isAddModal) {
      setShowQueue(true);
    }
  };

  const isTransferQuantitiesValid = () => {
    return selectedSizesRow?.filter(
      (item: any) => item?.quantityToTransfer === 0
    )?.length > 0
      ? false
      : true;
  };

  const isAnySizeShouldNotAddToQueue = () => {
    const includesAny: any = selectedSizes?.some((size: any) =>
      // sizesWhichCannotAddToQueue?.includes(size?.['ConsigneeSize.Size'])
      isSizePresentInArray(sizesWhichCannotAddToQueue, size)
    );
    return includesAny;
  };

  const columns = [
    {
      title: 'S.No',
      type: 'sno',
    },
    {
      title: 'Size',
      value: 'size',
    },
    {
      title: 'Condition',
      value: 'condition',
    },
    {
      title: 'Quantity Available',
      type: 'textbox',
      disabled: true,
      value: 'availableQuantity',
    },
    {
      title: 'Current Location',
      type: 'textbox',
      disabled: true,
      value: 'defaultLocationName',
    },
    {
      title: 'Transfer Quantity',
      type: 'textbox',
      value: 'quantityToTransfer',
      checkStockAvailability: sizesWhichCannotAddToQueue,
      methodToUseForComparison: isSizePresentInArray,
      onChange: (data: any, index: any) => {
        transferQuantityInputHandler(data, index);
      },
    },
    {
      title: 'Remove',
      type: 'button',
      value: 'Remove',
      onClick: (data: any) => {
        removeDataRow(data);
      },
    },
  ];

  return (
    <>
      <Modal
        open={showSizeModal}
        // onClose={() => setShowSizeModal(false)}
        className='yk-add-queue-modal-wrapper'
        aria-labelledby='modal-modal-title'
        aria-describedby='modal-modal-description'>
        <div className='app-wrapper yk-add-queue-modal-overlay-wrapper w-100'>
          <div className='yk-modal-body'>
            {sizesIsLoading ? (
              <div className='YKCH-loaderModal'>
                <CircularProgress />
              </div>
            ) : (
              <>
                <div className='yk-modalHeadingWrapper'>
                  <div className='yk-modal-title'>Transfer</div>
                  <div className='close-btn-wrapper'>
                    <button
                      className='btn prod-close modal-closeBtn'
                      onClick={() => setShowSizeModal(false)}>
                      <Image
                        src={ModalCloseIcon}
                        alt='table-close-icon'
                        className='table-close-icon'
                      />
                    </button>
                  </div>
                </div>
                <p className='yk-modal-subtitletext'>
                  {modalType === 'add'
                    ? productLevelData?.['MyInventory.itemName'] || '--'
                    : dataForRow?.nameOfProduct || '--'}
                </p>
                <div className='yk-modalScroll'>
                  {modalType === 'add' && !!selectedCondition && (
                    <div className='yk-modal-subtitle'>Select condition</div>
                  )}
                  {modalType === 'add' &&
                    !!selectedCondition &&
                    (sizesIsLoading ? (
                      <div className='YKCH-loaderModal'>
                        <CircularProgress />
                      </div>
                    ) : (
                      <div className='yk-modal-content yk-selectConditionContent'>
                        {conditions?.map((name: any, index: any) => {
                          return (
                            <button
                              className={`btn queue-size-btn available-size ${
                                selectedCondition?.toLowerCase() ===
                                name?.toLowerCase()
                                  ? 'selected'
                                  : ''
                              }`}
                              type='button'
                              key={index}
                              value={name}
                              onClick={() => setSelectedCondition(name)}>
                              {name}
                            </button>
                          );
                        })}
                      </div>
                    ))}

                  {modalType === 'add' && (
                    <div className='yk-modal-subtitle'>Select size</div>
                  )}
                  {modalType === 'add' &&
                    (sizesIsLoading ? (
                      <div className='YKCH-loaderModal'>
                        <CircularProgress />
                      </div>
                    ) : (
                      <div className='yk-modal-content'>
                        {filteredSizes?.map((item: any, index: any) => {
                          return (
                            <button
                              className={`btn queue-size-btn ${
                                item?.['ConsignmentLineItem.availableQuantity']
                                  ? 'available-size'
                                  : 'disabled-size'
                              } ${
                                selectedSizes?.filter(
                                  (sizeItem: any) =>
                                    sizeItem?.['ConsigneeSize.Size'] ===
                                      item?.['ConsigneeSize.Size'] &&
                                    sizeItem?.[
                                      'ConsigneeCondition.conditionName'
                                    ] ===
                                      item?.['ConsigneeCondition.conditionName']
                                )?.length > 0
                                  ? 'selected'
                                  : ''
                              }`}
                              type='button'
                              key={index}
                              value={item?.['ConsigneeSize.Size']}
                              disabled={
                                !Number(item?.['ConsignmentLineItem.availableQuantity'])
                              }
                              onClick={() => sizeSelector(item)}>
                              {item?.['ConsigneeSize.Size']}
                            </button>
                          );
                        })}
                      </div>
                    ))}
                  <div className='yk-transferModalTable'>
                    {/* {selectedSizes?.length > 0 && ( */}
                    <VirtualTable
                      loading={sizesIsLoading}
                      error={sizesError}
                      noData={true}
                      headers={columns}
                      rowData={selectedSizesRow}
                      emptyRow={true}
                    />
                  </div>
                  {/* )} */}
                </div>
                <div className='yk-modalActionWrapper'>
                  <div className='row'>
                    <div className='col-6 text-start'>
                      <button
                        className='btn modal-btn-cancel yk-modalCloseBtn mt-0'
                        type='button'
                        onClick={() => setShowSizeModal(false)}>
                        Close
                      </button>
                    </div>
                    <div className='col-6 text-end'>
                      <button
                        className='btn yk-btn-primary yk-modal-button yk-addToQueueBtn mt-0'
                        type='button'
                        onClick={onAddSizesToQueue}
                        disabled={
                          !selectedSizes?.length ||
                          !isTransferQuantitiesValid() ||
                          isAnySizeShouldNotAddToQueue()
                        }>
                        {modalType === 'add' ? 'Add to Queue' : 'Update'}
                      </button>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </Modal>
    </>
  );
};

export default SelectSizesModal;
