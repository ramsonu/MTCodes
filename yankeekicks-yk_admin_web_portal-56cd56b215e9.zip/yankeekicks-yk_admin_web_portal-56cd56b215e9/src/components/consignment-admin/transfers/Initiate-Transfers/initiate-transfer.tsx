import React, { useState, useEffect, useMemo } from 'react';
import Image from 'next/image';
import { useSelector, useDispatch } from 'react-redux';
import { useCubeQuery } from '@cubejs-client/react';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import { actions } from 'store/reducers/kiosk';
import { getBasePath } from 'utils/util';
import SearchComp from 'components/common/search';
import Sortings from 'components/common/sortings';
import ProductFilters from 'components/common/filters/product-filter';
import VirtualTable from 'components/common/table';
import Pagination from 'components/common/pagination';
import {
  getMyInventoryProductsQuery,
  getPaginationCountForInventoryProducts,
} from 'middleware/cubejs-wrapper/transfers-query';
import filterIcon from 'assets/images/filter-icon.png';
import TransferDefault from 'assets/images/menu-icons/transfer-gray-img.svg';
import whitefilterIcon from 'assets/images/menu-icons/queue-white-icon.svg';
import blackfilterIcon from 'assets/images/menu-icons/queue-black-icon.svg';
import SelectSizesModal from './select-sizes-modal';
import Queue from './queue';
import Breadcrumbs from 'components/common/breadcrumbs';
import { useRouter } from 'next/router';

const InitiateTransfer = () => {
  const limitForQuery = 10;

  const router = useRouter();
  const dispatch = useDispatch();

  const { filterTypes } = useSelector((state: any) => state.kiosk);
  const { transfers } = useSelector((state: any) => state.consignment);

  const [initiateTransferData, setInitiateTransferData] = useState<any>([]);
  const [countForPagination, setCountForPagination] = useState<number>(0);
  const [userInput, setUserInput] = useState<string>('');
  const [selectedSort, setSelectedSort] = useState<any>('skuAsc');
  const [showFilters, setShowFilters] = useState<boolean>(false);
  const [filterInput, setFilterInput] = useState<any>({});
  const [myInventoryOffset, setMyInventoryOffset] = useState<any>(0);
  const [clearDisable, setClearDisable] = useState<boolean>(true);
  const [shouldFetchInventory, setShouldFetchInventory] =
    useState<boolean>(false);
  const [showSizeModal, setShowSizeModal] = useState<boolean>(false);
  const [showQueue, setShowQueue] = useState<boolean>(false);
  const [selectedProduct, setSelectedProduct] = useState<any>([]);

  useEffect(() => {
    setShouldFetchInventory(true);
  }, []);

  const locId: any = localStorage?.getItem('storeLocationId');

  const myInventoryQuery: any = getMyInventoryProductsQuery(
    userInput,
    selectedSort,
    filterInput,
    locId,
    myInventoryOffset,
    limitForQuery
  );
  const myInventoryPaginationCountQuery: any =
    getPaginationCountForInventoryProducts(userInput, filterInput, locId);

  const {
    resultSet: initiateTransferResultSet,
    isLoading: initiateTransferIsLoading,
    error: initiateTransferError,
  }: any = useCubeQuery(myInventoryQuery, { skip: !shouldFetchInventory });

  const { resultSet: pageCountResultSet, error: pageCountError }: any =
    useCubeQuery(myInventoryPaginationCountQuery, {
      skip: !shouldFetchInventory,
    });

  useEffect(() => {
    if (
      initiateTransferError?.status === 401 ||
      initiateTransferError?.status === 403
    ) {
      //todo: Logout the user
    } else {
      const data = initiateTransferResultSet?.loadResponses[0]?.data;
      if (data) {
        setInitiateTransferData(data);
        setShouldFetchInventory(false);
      } else {
        setInitiateTransferData([]);
      }
    }
  }, [initiateTransferResultSet, initiateTransferError]);

  useEffect(() => {
    if (pageCountError?.status === 401 || pageCountError?.status === 403) {
      //todo: Logout the user
    } else {
      const pageCountData =
        pageCountResultSet?.loadResponses[0]?.data[0]?.[
          'InventoryCount.skuDistinctCount'
        ];
      if (pageCountData) {
        const pageCount = +pageCountData || 0;
        setCountForPagination(pageCount);
      }
    }
  }, [pageCountResultSet, pageCountError]);

  useEffect(() => {
    if (filterTypes.brand.length > 0) {
      setClearDisable(false);
    } else {
      setClearDisable(true);
    }
  }, [filterTypes]);

  const userInputHandler = (event: any) => {
    setUserInput(event.target.value);
    setShouldFetchInventory(true);
    setMyInventoryOffset(0);
  };

  const sortHandler = (event: any) => {
    setSelectedSort(event.target.value);
    setShouldFetchInventory(true);
    setMyInventoryOffset(0);
  };

  const applyFilters = () => {
    const filterPayload = {
      brand: filterTypes.brand,
    };
    setFilterInput(filterPayload);
    setUserInput('');
    setMyInventoryOffset(0);
    setShowFilters(false);
    setShouldFetchInventory(true);
  };

  const clearAllFilters = () => {
    setFilterInput({});
    setMyInventoryOffset(0);
    setShowFilters(false);
    setClearDisable(true);
    dispatch(actions.clearAllFilters({}));
    setShouldFetchInventory(true);
  };

  const openSizeModal = (data: any) => {
    setSelectedProduct(data);
    setShowSizeModal(true);
  };

  const columns = useMemo(
    () => [
      {
        title: 'S.No',
        type: 'sno',
      },
      {
        title: 'SKU',
        value: 'MyInventory.sku',
      },
      {
        title: 'Picture',
        type: 'image',
        value: 'MyInventory.imageUrl',
      },
      {
        title: 'Brand',
        value: 'MyInventory.brand',
      },
      {
        title: 'Name',
        value: 'MyInventory.itemName',
      },
      {
        title: 'Qty',
        value: 'MyInventory.nonTransferQuantity',
      },
      {
        title: 'Actions',
        type: 'button',
        onClick: (data: any) => {
          openSizeModal(data);
        },
        value: 'View',
      },
    ],
    []
  );

  const breadCrumbHeaders = {
    title: 'Transfers',
    titleImage: TransferDefault,
    subTitle: 'Initiate Transfer',
    onClick: () => {
      router?.push(getBasePath('transfers'));
    },
  };

  const queueImageToShow =
    transfers?.length > 0 ? whitefilterIcon : blackfilterIcon;

  return (
    <>
      <div className='app-wrapper orders-page-wrapper yk-transfers-page-wrapper yk-initiate-transfer-page-wrapper'>
        <div className='container-fluid'>
          <div className='row mb-3'>
            <div className='col-lg-12'>
              <Breadcrumbs data={breadCrumbHeaders} />
            </div>
            <div className='col-lg-12'>
              <h3 className='yk-main-title'>Initiate Transfer</h3>
              <p className='yk-gray-text'>
                Please add products from inventory to the queue to initiate
                transfer
              </p>
            </div>
          </div>
        </div>
        <div className='container-fluid'>
          <div className='search-btn-wrapper'>
            <div className='row'>
              <div className='col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12'>
                <div className='search-bar-wrapper yk-search-bar table-filter-search'>
                  <SearchComp
                    optionType='no suggestions'
                    placeholder='Search Inventory'
                    onChangeHandler={userInputHandler}
                  />
                </div>
              </div>
              <div className='col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12'>
                <div className='consignment-btn-wrapper p-0 YKCH-topSSpacSS YKCH-filterArenas'>
                  <Sortings
                    handleChange={sortHandler}
                    itemKey='initiateTransfer'
                    defaultSelectedValue={selectedSort}
                  />

                  <div className='filter-btn-wrapper mb-0'>
                    <button
                      className={`btn filter-btn ${
                        transfers?.length > 0 ? 'yk-notify-filter-btn' : ''
                      }`}
                      onClick={() => setShowQueue(!showQueue)}>
                      <Image
                        src={queueImageToShow}
                        alt='filter-btn-icon'
                        className='filter-btn-icon img-fluid'
                      />
                      <span className='filter-btn-text yk-badge-h15'>
                        Queue
                      </span>
                      {transfers?.length > 0 && (
                        <div className='notify-button'>
                          <div className='notify-button-number'>
                            {transfers?.length}
                          </div>
                        </div>
                      )}
                    </button>
                  </div>

                  <div className='filter-btn-wrapper mb-0'>
                    <ClickAwayListener
                      onClickAway={() => {
                        setShowFilters(false);
                      }}>
                      <div>
                        <button
                          className='btn filter-btn'
                          onClick={() => setShowFilters(!showFilters)}>
                          <Image
                            src={filterIcon}
                            alt='filter-btn-icon'
                            className='filter-btn-icon img-fluid'
                          />
                          <span className='filter-btn-text yk-badge-h15'>
                            Filter
                          </span>
                        </button>

                        {showFilters && (
                          <ProductFilters
                            itemKey={'initiateTransfer'}
                            onApplyClick={applyFilters}
                            onClearFilters={clearAllFilters}
                            clearDisable={clearDisable}
                          />
                        )}
                      </div>
                    </ClickAwayListener>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <VirtualTable
            headers={columns}
            rowData={initiateTransferData}
            loading={initiateTransferIsLoading}
            error={initiateTransferError}
            offSet={myInventoryOffset}
          />
        </div>
        <div className='center-pagination'>
          {countForPagination > 0 && initiateTransferData?.length > 0 && (
            <div className='center-pagination'>
              <Pagination
                lengthOfData={countForPagination}
                itemsPerPage={limitForQuery}
                currentOffset={myInventoryOffset}
                setOffset={setMyInventoryOffset}
                setShouldFetchApi={setShouldFetchInventory}
              />
            </div>
          )}
        </div>
      </div>

      {showSizeModal && (
        <SelectSizesModal
          showSizeModal={showSizeModal}
          setShowSizeModal={setShowSizeModal}
          productLevelData={selectedProduct}
          setShowQueue={setShowQueue}
          modalType='add'
        />
      )}

      {showQueue && <Queue setShowQueue={setShowQueue} />}
    </>
  );
};

export default InitiateTransfer;
