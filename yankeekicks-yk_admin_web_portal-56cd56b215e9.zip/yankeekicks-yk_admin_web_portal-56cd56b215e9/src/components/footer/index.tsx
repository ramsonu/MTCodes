import React, { useState } from 'react';
import type { NextPage } from 'next';
import { useSelector } from 'react-redux';

const Footer: NextPage = () => {
  const { cart } = useSelector((state: any) => state.kiosk);
  const [isVisible, setIsVisible] = useState(false);
  return (
    <>
      <footer>
        <div className='btn-wrapper'>
          {cart?.length > 0 && (
            <button
              className='btn yk-btn-primary'
              onClick={() => setIsVisible(true)}
            >
              REQUEST TO TRY
            </button>
          )}
        </div>
      </footer>
    </>
  );
};
export default Footer;
