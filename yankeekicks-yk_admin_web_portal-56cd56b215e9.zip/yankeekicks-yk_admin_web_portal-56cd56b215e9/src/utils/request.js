import axios from 'axios';

export async function doRequest(
  url,
  method = 'get',
  dataOrParams = {},
  contentType = '',
  authorizeFrom = false,
  isConsignment = false,
  responseType = ''
) {
  let headers = {
    Accept: 'application/json',
    'Content-type': contentType || 'application/json',
    Authorization: localStorage.getItem('jwt-token')
      ? `Bearer ${localStorage.getItem('jwt-token')}`
      : '',
    responseType: responseType,
  };

  const params = method === 'get' ? dataOrParams : {};
  const data = method !== 'get' ? dataOrParams : undefined;
  axios.interceptors.response.use(
    async (response) => {
      return response;
    },
    async (error) => {
      const originalRequest = error.config;
      const status = error.response.status;
      if (status === 403 && !originalRequest._retry) {
        originalRequest._retry = true;
        return axios({
          url: `${process.env.NEXT_PUBLIC_APP_API_PORT}/api`,
          method: 'post',
          data: {
            apiUrl: `${process.env.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/authenticate/refreshtoken`,
            apiMethod: `get`,
          },
          headers: {
            Accept: 'application/json',
            'Content-type': contentType || 'application/json',
            Authorization: localStorage.getItem('jwt-token')
              ? `Bearer ${localStorage.getItem('jwt-token')}`
              : '',
            responseType: responseType,
          },
        })
          .then((res) => {
            if (res.status === 201 || res.status === 200) {
              localStorage.setItem('jwt-token', res.data.token);
              axios.defaults.headers.common['Authorization'] =
                'Bearer ' + res.data.token;
              axios.defaults.headers.common['refreshToken'] =
                'Bearer ' + res.data.token;
              //window.location.reload();
              return axios(originalRequest);
            }
          })
          .catch((err) => {
            console.log('refresh token api failed');
            // window.location.reload();
          });
      }
      return Promise.reject(error);
    }
  );

  return await axios({
    url,
    method,
    data,
    params,
    headers,
    responseType,
  });
}
