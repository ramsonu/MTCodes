export const PLEASE_FILL_THIS_FIELD = 'Please fill this field';
export const ValidationRequired = {
  required: PLEASE_FILL_THIS_FIELD,
};

export const ValidationMaxLength20 = {
  maxLength: {
    value: 20,
    message: 'This input exceed max length.',
  },
};

export const ValidationMaxLength30 = {
  maxLength: {
    value: 30,
    message: 'This input exceed max length.',
  },
};

export const ValidationMaxLength35 = {
  maxLength: {
    value: 35,
    message: 'This input exceed max length.',
  },
};

export const ValidationMaxLength250 = {
  maxLength: {
    value: 250,
    message: 'This input exceed max length.',
  },
};
export const ValidationMaxLength10 = {
  maxLength: {
    value: 10,
    message: 'This input exceed max length.',
  },
};

export const ValidationMaxLength9 = {
  maxLength: {
    value: 9,
    message: 'This input exceed max length.',
  },
};

export const ValidationMaxLength5 = {
  maxLength: {
    value: 5,
    message: 'This input exceed max length.',
  },
};

export const ValidationMaxLength6 = {
  maxLength: {
    value: 6,
    message: 'This input exceed max length.',
  },
};

export const ValidationMaxLength14 = {
  maxLength: {
    value: 14,
    message: 'This input exceed max length.',
  },
};
export const ValidationMaxLength17 = {
  maxLength: {
    value: 17,
    message: 'This input exceed max length.',
  },
};
export const ValidationMaxLength12 = {
  maxLength: {
    value: 12,
    message: 'This input exceed max length.',
  },
};

export const ValidationMinLength9 = {
  minLength: {
    value: 9,
    message: 'This input required min 9 char.',
  },
};
export const ValidationMinLength8 = {
  minLength: {
    value: 8,
    message: 'This input required min 8 char.',
  },
};
export const ValidationMinLength5 = {
  minLength: {
    value: 5,
    message: 'This input required min 5 char.',
  },
};

export const ValidationMinLength6 = {
  minLength: {
    value: 6,
    message: 'This input required min 6 char.',
  },
};
export const ValidationMinLength20 = {
  minLength: {
    value: 20,
    message: 'This input required min 20 char.',
  },
};
export const ValidationMinLength14 = {
  minLength: {
    value: 14,
    message: 'This input required min 10 char.',
  },
};
export const ValidationMinLength10 = {
  minLength: {
    value: 10,
    message: 'This input required min 10 char.',
  },
};
export const ValidationMinLength11 = {
  minLength: {
    value: 11,
    message: 'This input required min 11 char.',
  },
};

export const ValidationOnlyNumbers = {
  pattern: {
    value: /^[0-9]*$/,
    message: 'Numbers only allowed',
  },
};

export const ValidationOnlyPhoneNumber = {
  pattern: {
    value: /^[0-9 \)\(-]*$/,
    message: 'Numbers only allowed',
  },
};

export const ValidationOnlyAlpha = {
  pattern: {
    value: /^[a-zA-Z. ]*$/,
    message: 'only characters allowed',
  },
};

export const ValidationOnlyAlphaNumbers = {
  pattern: {
    value: /^[A-Za-z0-9]+$/,
    message: 'Please enter characters and numbers',
  },
};

export const ValidationCommissionName = {
  pattern: {
    value: /^[a-zA-Z0-9.,% -]+$/,
    // value: /^[A-Za-z0-9 *&$()%]+$/,
    message: 'Please enter characters and numbers',
  },
};

export const ValidationOnlyUptoTwoDecimals = {
  pattern: {
    value: /^(?:\d|[1-8]\d|9[0-9])(?:\.\d{1,2})?$|^[0-9][0-9]?$|^99\.99$/,
    message: 'Only Numbers below 100 with 2 decimals are allowed',
  },
};

export const ValidationPassword = {
  ...ValidationRequired,
  ...ValidationMaxLength12,
  ...ValidationMinLength8,
  pattern: {
    value: /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
    message:
      'Your password must be at least 8 characters, contains at least one number, one special character ,one uppercase and one lower case.',
  },
};

export const ValidationEmail = {
  ...ValidationRequired,
  ...ValidationMaxLength35,
  ...ValidationMinLength6,
  pattern: {
    value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9-]+\.[a-zA-Z]{2,4}$/,
    message: 'Invalid email address',
  },
};

export const getDay = () => {
  var days = [
    'Sunday',
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
  ];
  var d = new Date();
  return days[d.getDay()];
};

export const ValidationFullName = {
  ...ValidationRequired,
  ...ValidationOnlyAlpha,
  ...ValidationMaxLength35,
  ...ValidationMinLength6,
};

export const ValidationBusinessName = {
  ...ValidationRequired,
  ...ValidationOnlyAlpha,
  ...ValidationMaxLength35,
  ...ValidationMinLength6,
};

export const ValidationOnlyEINNumber = {
  pattern: {
    value: /^[0-9 \)\(-]*$/,
    message: 'Numbers only allowed',
  },
};
