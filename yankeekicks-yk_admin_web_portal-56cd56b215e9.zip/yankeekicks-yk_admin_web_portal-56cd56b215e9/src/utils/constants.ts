export const FNS_DATE_FORMAT = 'MMM dd, yyyy';
export const FNS_DATE_DMY_FORMAT = 'MMM dd, yyyy';
export const FNS_DATE_NOTIFICATIONS_FORMAT = 'MMMM dd';
export const FNS_TIME_NOTIFICATIONS_FORMAT = 'h:mm';
export const NOTIFICATION_TIME_FORMAT = 'h:mm a';
export const KPI_DATE_FORMAT = 'yyyy-MM-dd';
export const FNS_TIME_FORMAT = 'HH:mm a';
export const COMMISSION_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
export const PAYOUT_DATE_FORMAT = 'MM/dd/yyyy';

export const PERMISSIONS = {
  CONSIGNMENT_ADMIN_PORTAL: ['Consignment_Admin', 'Super_Admin', 'YK_Admin'],
  YK_ADMIN_PORTAL: ['YK_Admin', 'Super_Admin'],
};

export const USER_ROLES = {
  WAREHOUSE_PERSONAL: 'Warehouse_Personal',
  SALES_ASSOCIATE: 'Sales_Associate',
  CONSIGNEE: 'Consignee',
  WAREHOUSE_ADMIN: 'Warehouse_Admin',
  STORE_ADMIN: 'Store_Admin',
  CONSIGNMENT_ADMIN: 'Consignment_Admin',
  YK_ADMIN: 'YK_Admin',
  SUPER_ADMIN: 'Super_Admin',
};

export const ORDER_DATE_FORMAT = 'MM/dd/yyyy';
export const PAYOUT_DETAILS_FORMAT = 'MMM dd, yyyy HH:mm a';
export const NO_HEADER_ROUTES = ['login'];
export const USER_REGISTRATION_FILE_TYPE_ERROR = 'File Type not accepted!';
export const USER_REGISTRATION_FILE_SIZE_ERROR =
  'Document must be less than 2MB!';
export const NOTIFICATION_REGISTER_UPLOAD_FILE =
  'Please Upload at least one document.';
export const NOTIFICATION_LOGIN_SUCCESS = 'Login successful!';
export const NOTIFICATION_REGISTER_SUCCESS = 'User register successfully!';
export const NOTIFICATION_PASSWORD_RESET_SUCCESS =
  'Password reset link sent successfully!';
export const NOTIFICATION_PASSWORD_RESET_FAIl = "User email doesn't exist!";
export const NOTIFICATION_FORGET_PASSWORD_SUCCESS =
  'Forget password requested!';
export const NOTIFICATION_INVALID_EMAIL_PWD = 'Invalid email or password!';
export const NOTIFICATION_INVALID_OLD_PASSWORD = 'Invalid old password!';
export const NOTIFICATION_INVALID_PASSWORD = 'Invalid password!';
export const NOTIFICATION_PASSWORD_UPDATED_SUCCESS =
  'Password updated successfully!';
export const NOTIFICATION_SOMETHING_WENT_WRONG =
  'Somethig went wrong, please try later!';
export const NOTIFICATION_INVALID_DATA = 'Please upload valid template';
export const NOTIFICATION_INVALID_FILE = 'Invalid File';
export const NOTIFICATION_QR_DOWNLOAD_SUCCESS = 'Successfully Downloaded!';
export const NOTIFICATION_CHANGE_PASSWORD_SUCCESS =
  'Password changed, Please login to continue!';
export const NOTIFICATION_OLDPWD_NEWPWD_NOT_MATCHING =
  'New password and confirmation password did not match!';
export const NOTIFICATION_PWD_UPDATED_SUCCESS = 'Password reset successfully!';
export const LINEITEM_ALREDY_EXISTS =
  'This line iteam already exist in the queue';
export const LINEITEM_QUANTITY_UPDATED = 'Item quantity updated.';
export const TRY_OUT_ACCEPTED: any = {
  title: 'Request from Kiosk accepted',
  msg: 'Shoes are added to your request list',
};
export const NO_RESULT_FOUND: any = {
  title: 'No results found',
  msg: "We couldn't find anything for what you are looking.",
};
export const UNAUTHORIZED_USER: any = {
  title: 'You are not authorized to access this page!',
  msg: 'Please contact Administrator.',
};

export const TIME_INTERVAL_NOTIFICATIONS = 30 * 1000; // 30 SECONDS
export const STORE_ID = 1; // 5 minutes
export const NOTIFICATION_FLAG_SUCCESS = 'Notifications updated successfully';
export const NOTIFICATION_FLAG_NOT_SUCCESS =
  'Notifications not updated, Please try agin.!';
export const USER_UPDATE_SUCCESS = 'User details updated successfully';
export const NOTIFICATION_UPDATE_SUCCESS = 'Sent successfully';
export const NOTIFICATION_CANCEL_SUCCESS =
  'Notification cancelled successfully';
export const NOTIFICATION_SCHEDULE_SUCCESS = 'Scheduled successfully';
export const FILE_UPLOAD_ACCEPT_FORMATS = ['png', 'jpg', 'jpeg'];
export const INVENTORY_ADD = 'Inventory Details Added Successfully';

export const CONSIGNMENT_REVIEW_APPROVE_STATUS = 'Approved';
export const CONSIGNMENT_REVIEW_REJECT_STATUS = 'Rejected';
export const CONSIGNMENT_REVIEW_APPROVED = 'Shipment Approved!';
export const CONSIGNMENT_REVIEW_REJECTED = 'Shipment Rejected!';
export const CONSIGNMENT_REVIEW_POPUP_CHECKLIST = [
  'Smell',
  'Structure',
  'Color',
  'Material and stitching',
  'Sole',
  'Label and tag',
  'Quality check',
];

export const US_COUNTRY_INDEX = 0;
export const LOCATIONS_TYPE_LIST = ['Warehouse', 'Store'];
export const APP_TITLE = 'Yankeekicks Admin';
export const APP_KEYWORDS =
  'Yankeekicks Store | Footwear | Apparel | Sneaker Care';
export const MINIMUM_FEE = '0';
export const SIZE_MATRIX_MENWOMEN = 0;
export const SIZE_MATRIX_TODDLER = 1;
export const SIZE_MATRIX_PRESCHOOL = 2;
export const SIZE_MATRIX_GRADESCHOOL = 3;

export const CANNOT_ADD_TO_QUEUE =
  'Quantity to transfer cannot be more than available quantity!';

export const TRANSFER_NOT_ZERO = 'Please enter valid quantity!';
export const DAYS_LIMIT_FOR_MOVE_TO_YK_INV = 30;
export const TIME_TO_DAYS_CONVERSION = 1000 * 60 * 60 * 24;

export const ALL_LOCATIONS = 'All Locations';
