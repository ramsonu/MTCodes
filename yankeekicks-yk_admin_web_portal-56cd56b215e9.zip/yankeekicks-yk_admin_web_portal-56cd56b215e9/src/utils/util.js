import Image from 'next/image';
import { subDays, format } from 'date-fns';
import {
  PERMISSIONS,
  USER_ROLES,
  NO_RESULT_FOUND,
  UNAUTHORIZED_USER,
} from './constants';
import noRecordImg from 'assets/images/no-table-record-img.png';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

export const getPreviousFullYear = (noOfYears) => {
  const date = new Date();
  let years = [];
  for (let i = 0; i < noOfYears; i++) {
    const year = date.getFullYear() - i;
    const yrkey = { key: year, value: year };
    years = [...years, yrkey];
  }
  return years;
};

export const getTime = (date) => {
  let currentTime = new Date(date);
  return currentTime.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });
};

export const get24HoursTime = (date) => {
  let currentTime = new Date(date);
  return currentTime.toLocaleTimeString('en-GB');
};

export const getDate = (date) => {
  let currentDate = new Date(date);
  return currentDate.toLocaleDateString();
};

export const getUTCtoLocaleDate = (date) => {
  const dateString = `${date} UTC`;
  const inputDate = new Date(dateString);

  // Specify the options with the timeZone parameter
  const options = {
    timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
  };
  const localTimeString = inputDate.toLocaleString('en-US', options);

  // Create a new Date object from the local time string
  const localDate = new Date(localTimeString);
  return localDate;
};

export const convertLocalTimeToUTCTime = (dateString, times) => {
  const inputDate = new Date(dateString);
  const inputTime = new Date(times);

  // Create a new date object with the combined date and time
  const combinedDateTime = new Date(
    inputDate.getFullYear(),
    inputDate.getMonth(),
    inputDate.getDate(),
    inputTime.getHours(),
    inputTime.getMinutes(),
    inputTime.getSeconds(),
    inputTime.getMilliseconds()
  );

  // Convert to UTC and get the string representation
  const utcDateTimeStr = combinedDateTime.toISOString();

  const dateTime = `${utcDateTimeStr.slice(0, 10)} ${utcDateTimeStr.slice(
    11,
    19
  )}`;

  return dateTime;
};

export const getTrimmedText = (data, length) => {
  const formattedText = data?.substring(0, length).concat('...');
  return formattedText;
};

export const getAllUpperCase = (data) => {
  const words = data?.split(' ');
  const formattedText = words
    ?.map((word) => {
      return word[0]?.toUpperCase() + word.substring(1);
    })
    .join(' ');
  return formattedText;
};

export const capitalizeFirstLetter = (data) => {
  return data.charAt(0).toUpperCase() + data.slice(1);
};

export const copyContentToClipBoard = (text) => {
  navigator.clipboard.writeText(text);
};

export const getDifferenceDate = (currentDate, numberOfDays) => {
  return subDays(currentDate, numberOfDays);
};

export const getFormattedDate = (dateToFormat, formatToApply) => {
  return format(dateToFormat, formatToApply);
};

export const navigateTo = (role) => {
  const myRole = role?.toString();
  let path = '/';
  switch (myRole) {
    case USER_ROLES.CONSIGNMENT_ADMIN:
      path = '/consignment-admin';
      break;
    case USER_ROLES.YK_ADMIN:
      path = '/yk-admin';
      break;
    case USER_ROLES.SUPER_ADMIN:
      path = '/yk-admin';
      break;
  }
  return path;
};

export const checkPermission = (portal) => {
  return PERMISSIONS?.[portal]?.includes(localStorage.getItem('user-role'));
};

export const checkPermissionForLayout = (pathname) => {
  let portal = '';
  if (pathname?.includes('/consignment-admin'))
    portal = 'CONSIGNMENT_ADMIN_PORTAL';
  if (pathname?.includes('/yk-admin')) portal = 'YK_ADMIN_PORTAL';
  // if (pathname == '/unauthorized') return true;
  return checkPermission(portal);
};

export const getDifferenceFromDates = (currentDate, toDate) => {
  const date1 = new Date(toDate);
  const date2 = new Date(currentDate);
  const diffTime = Math.abs(date2 - date1);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
};

export const getBase64 = (file) => {
  return new Promise((resolve) => {
    let fileInfo;
    let baseURL = '';
    // Make new FileReader
    let reader = new FileReader();

    // Convert the file to base64 text
    reader.readAsDataURL(file);

    // on reader load somthing...
    reader.onload = () => {
      // Make a fileInfo Object
      baseURL = reader.result;
      resolve(baseURL);
    };
  });
};

export const displayNoResultsFound = () => {
  return (
    <div className='no-record-found-wrapper text-center'>
      <Image
        src={noRecordImg}
        alt='filter-btn-icon'
        className='no-result-img img-fluid'
      />
      <h4 className='yk-title'>{NO_RESULT_FOUND.title}</h4>
      <p className='yk-subtitle'>{NO_RESULT_FOUND.msg}</p>
    </div>
  );
};

export const displayUnauthorized = () => {
  return (
    <div className='no-record-found-wrapper text-center'>
      <Image
        src={noRecordImg}
        alt='filter-btn-icon'
        className='no-result-img img-fluid'
      />
      <h4 className='yk-title'>{UNAUTHORIZED_USER.title}</h4>
      <p className='yk-subtitle'>{UNAUTHORIZED_USER.msg}</p>
    </div>
  );
};

export const getMaskedNumber = (number, start, end) => {
  let maskedNumber = number?.toString().substring(start, end);
  maskedNumber = '**********' + maskedNumber;
  return maskedNumber;
};

export const updatePhoneNumber = (value) => {
  if (!value) return value;
  const currentValue = value.replace(/[^\d]/g, '');
  const cvLength = currentValue.length;

  if (value.length > 0) {
    if (cvLength < 4) return currentValue;
    if (cvLength < 7)
      return `(${currentValue.slice(0, 3)}) ${currentValue.slice(3)}`;
    return `(${currentValue.slice(0, 3)}) ${currentValue.slice(
      3,
      6
    )}-${currentValue.slice(6, 10)}`;
  }
};
export function getUserDetails(params) {
  const userId = localStorage?.getItem('userId');
  const locationId = localStorage?.getItem('storeLocationId');
  return { userId: userId, currentLocId: locationId };
}
export function getMyId() {
  return localStorage?.getItem('userId');
}

export function getMyEmail() {
  const userDetails = JSON.parse(localStorage.getItem('UserDetails') || '{}');
  return userDetails?.username;
}

export function amIadminUser() {
  const myRole = localStorage?.getItem('user-role');
  if (PERMISSIONS.CONSIGNMENT_ADMIN_PORTAL.includes(myRole)) return true;
  else return false;
}

export function getBasePath(path = '') {
  const userRole = localStorage.getItem('user-role');
  if (userRole == USER_ROLES.CONSIGNMENT_ADMIN)
    return `/consignment-admin/${path}`;
  else return `/yk-admin/${path}`;
}

export function getProfitRatioAmt(sellPrice) {
  let minAmt = localStorage?.getItem('minimumFee');
  const profitRatio = localStorage?.getItem('profitRatio');
  const calculate = (profitRatio / 100) * sellPrice;
  minAmt = minAmt === null ? 25 : minAmt;
  return Math.max(calculate, minAmt);
}

export const updateEINNumber = (value) => {
  if (!value) return value;
  const currentValue = value?.replace(/[^\d]/g, '');
  if (
    currentValue?.length > 0 &&
    currentValue?.length <= 9 &&
    !value?.includes('-')
  ) {
    if (currentValue?.length < 3) return value;

    return `${currentValue?.slice(0, 2)}-${currentValue?.slice(2, 10)}`;
  } else {
    return value;
  }
};

export const convertPriceToUSFormat = (
  number,
  withDollar = true,
  prefix = '$',
  suffix = ''
) => {
  let instanceToUse = '';

  // format number to US dollar
  if (withDollar) {
    instanceToUse = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  } else {
    instanceToUse = new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }

  let isNum = /^[0-9.]+$/.test(number);
  // To apply the format value must be number/float and either prefix or suffix must be dollar
  if (isNum && instanceToUse && (prefix === '$' || suffix === '$')) {
    return instanceToUse?.format(number) || '';
  } else {
    return number;
  }
};

export const exportCharts = (
  reference,
  typeOfDocument,
  fileName,
  isPdf = false
) => {
  html2canvas(reference?.current)?.then((canvas) => {
    const imgData = canvas?.toDataURL(typeOfDocument);
    if (isPdf) {
      // code for pdf format
      const pdf = new jsPDF();

      // Get the dimensions of the PDF page
      const pageSize = pdf.internal.pageSize;
      const pageWidth = pageSize.width;
      const pageHeight = pageSize.height;

      // Calculate the center position
      const imgWidth = 150; // Width of the image
      const imgHeight = 150; // Height of the image

      const centerX = (pageWidth - imgWidth) / 2;
      const centerY = (pageHeight - imgHeight) / 2;

      // Add the image to the PDF at the center position
      pdf.addImage(imgData, 'JPG', centerX, centerY, imgWidth, imgHeight);
      pdf.save(fileName);
    } else {
      //code for jpeg ,jpg,png formats
      const link = document?.createElement('a');
      link.href = imgData;
      link.download = fileName;
      link.click();
    }
  });
};

export const downloadCsv = (data, documentName) => {
  const csvContent =
    'data:text/csv;charset=utf-8,' +
    data?.map((row) => row.join(',')).join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', documentName + '.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const openInFullScreen = (id) => {
  let element = document.getElementById(id);
  if (element?.requestFullScreen) {
    element?.requestFullscreen(); //Chrome
  } else if (element?.mozRequestFullScreen) {
    element?.mozRequestFullScreen(); // Firefox
  } else if (element?.webkitRequestFullScreen) {
    element?.webkitRequestFullScreen(); // Safari
  } else if (element?.msRequestFullscreen) {
    element?.msRequestFullscreen(); // IE/Edge
  }
};

export const isConsignmentAdmin = () => {
  const userRole = localStorage?.getItem('user-role') || '';

  if (userRole === USER_ROLES?.CONSIGNMENT_ADMIN) {
    return true;
  } else {
    return false;
  }
};
