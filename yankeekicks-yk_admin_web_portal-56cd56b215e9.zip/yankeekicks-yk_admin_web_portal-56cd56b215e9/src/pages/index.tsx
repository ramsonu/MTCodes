import CircleLoader from 'components/common/loader/circular-loader';
import type { NextPage } from 'next';
import { useRouter } from 'next/router';
import { useEffect } from 'react';

const Home: NextPage = () => {
  const router = useRouter();
  useEffect(() => {
    console.log('loading ');
    let role = localStorage.getItem('user-role');
    if (role == 'YK_Admin') {
      router.push('/YK-admin/consignors');
    } else if (role == 'Consignment_Admin') {
      router.push('/consignment-admin/consignors');
    } else {
      router.push('/unauthorized');
    }
  });
  return (
    <>
      <CircleLoader />
    </>
  );
};

export default Home;
