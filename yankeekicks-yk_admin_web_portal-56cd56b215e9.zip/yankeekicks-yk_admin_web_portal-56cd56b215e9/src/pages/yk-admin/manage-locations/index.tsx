import axios from 'axios';
import { NextPage } from 'next';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';
import ManageLocations from 'components/yk-admin/manage-locations';

const ManageLocationsPage: NextPage = () => {
  if (!checkPermission('YK_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <ManageLocations />
      </CubeWrapper>
    </>
  );
};

export default ManageLocationsPage;
