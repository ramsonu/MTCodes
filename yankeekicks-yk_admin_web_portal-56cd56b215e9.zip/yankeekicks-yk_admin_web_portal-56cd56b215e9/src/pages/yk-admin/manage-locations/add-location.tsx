import { NextPage } from 'next';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';
import AddLocation from 'components/yk-admin/manage-locations/add-location';

const AddLocationPage: NextPage = () => {
  if (!checkPermission('YK_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <AddLocation />
      </CubeWrapper>
    </>
  );
};

export default AddLocationPage;
