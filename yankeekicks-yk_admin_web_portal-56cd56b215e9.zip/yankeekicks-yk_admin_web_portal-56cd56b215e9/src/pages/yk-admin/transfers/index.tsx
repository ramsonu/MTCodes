import axios from 'axios';
import { NextPage } from 'next';
import TransfersComp from 'components/consignment-admin/transfers';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const Transfers: NextPage = () => {
  if (!checkPermission('YK_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <TransfersComp />
      </CubeWrapper>
    </>
  );
};

export default Transfers;
