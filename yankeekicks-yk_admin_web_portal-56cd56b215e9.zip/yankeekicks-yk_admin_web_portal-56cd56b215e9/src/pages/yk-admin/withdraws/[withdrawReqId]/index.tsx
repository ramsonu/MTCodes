import { NextPage } from 'next';
import WithdrawDetailsComp from 'components/consignment-admin/withdraws/withdraw-request-details';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const WithdrawsPage: NextPage = () => {
  if (!checkPermission('YK_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <WithdrawDetailsComp />
      </CubeWrapper>
    </>
  );
};

export default WithdrawsPage;
