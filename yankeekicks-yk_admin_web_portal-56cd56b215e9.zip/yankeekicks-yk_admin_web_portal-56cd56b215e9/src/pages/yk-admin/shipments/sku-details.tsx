import { NextPage } from 'next';
import ViewSkuDetails from 'components/consignment-admin/consignments/sku-details';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const SkuDetails: NextPage = () => {
  if (!checkPermission('YK_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <ViewSkuDetails />
      </CubeWrapper>
    </>
  );
};

export default SkuDetails;
