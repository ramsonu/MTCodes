import { NextPage } from 'next';
import { checkPermission, displayNoResultsFound } from 'utils/util';
import NewNotification from 'components/yk-admin/push-notifications/new-notification';

const ViewUserPage: NextPage = () => {
  if (!checkPermission('YK_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
     <NewNotification />
    </>
  );
};

export default ViewUserPage;
