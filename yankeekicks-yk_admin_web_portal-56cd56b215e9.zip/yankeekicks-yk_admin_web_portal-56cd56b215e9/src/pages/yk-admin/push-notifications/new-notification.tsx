import axios from 'axios';
import { NextPage } from 'next';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';
import NewNotification from 'components/yk-admin/push-notifications/new-notification';

const NewNotificationPage: NextPage = () => {
  if (!checkPermission('YK_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <NewNotification />
      </CubeWrapper>
    </>
  );
};

export default NewNotificationPage;
