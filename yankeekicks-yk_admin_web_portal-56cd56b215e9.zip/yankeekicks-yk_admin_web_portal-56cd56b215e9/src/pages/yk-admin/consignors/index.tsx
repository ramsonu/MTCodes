import axios from 'axios';
import { NextPage } from 'next';
import ConsignorsComp from 'components/consignment-admin/consignors';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const Consignors: NextPage = () => {
  if (!checkPermission('YK_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <ConsignorsComp />
      </CubeWrapper>
    </>
  );
};

export default Consignors;
