import axios from 'axios';
import { NextPage } from 'next';
import IdentityConsignorsComp from 'components/consignment-admin/consignors';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const IdentityConsignors: NextPage = () => {
  if (!checkPermission('YK_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <IdentityConsignorsComp />
      </CubeWrapper>
    </>
  );
};

export default IdentityConsignors;
