import Reports from 'components/yk-admin/reports';
const ReportPage = () => {
  return <Reports />;
};

export default ReportPage;
