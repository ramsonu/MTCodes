import axios from 'axios';
import { NextPage } from 'next';
import AddShoesToMyInventory from 'components/consignment-admin/products/AddShoesToMyInventory';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';
const addShoesMyInventory: NextPage = () => {
  if (!checkPermission('CONSIGNMENT_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <AddShoesToMyInventory />
      </CubeWrapper>
    </>
  );
};

export default addShoesMyInventory;
