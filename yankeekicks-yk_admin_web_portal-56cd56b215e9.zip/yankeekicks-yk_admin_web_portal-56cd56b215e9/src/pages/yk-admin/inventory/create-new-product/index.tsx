import axios from 'axios';
import { NextPage } from 'next';
import CreateNewProductComp from 'components/consignment-admin/products/create-new-product';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const Products: NextPage = () => {
  if (!checkPermission('YK_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <CreateNewProductComp />
      </CubeWrapper>
    </>
  );
};

export default Products;
