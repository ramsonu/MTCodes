import axios from 'axios';
import { NextPage } from 'next';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';
import AddUser from 'components/yk-admin/manage-users/add-user';

const AddUserPage: NextPage = () => {
  if (!checkPermission('YK_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <AddUser />
      </CubeWrapper>
    </>
  );
};

export default AddUserPage;
