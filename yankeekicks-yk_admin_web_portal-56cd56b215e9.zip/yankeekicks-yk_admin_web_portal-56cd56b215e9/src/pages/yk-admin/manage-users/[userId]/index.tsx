import { NextPage } from 'next';
import ViewUser from 'components/yk-admin/manage-users/view-user';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const ViewUserPage: NextPage = () => {
  if (!checkPermission('YK_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <ViewUser />
    </>
  );
};

export default ViewUserPage;
