import axios from 'axios';
import { NextPage } from 'next';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';
import ViewCommission from 'components/yk-admin/manage-commissions/view-commission';

const ViewCommissionsPage: NextPage = () => {
  if (!checkPermission('YK_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <ViewCommission />
      </CubeWrapper>
    </>
  );
};

export default ViewCommissionsPage;
