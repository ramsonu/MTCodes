import axios from 'axios';
import { NextPage } from 'next';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';
import AddCommission from 'components/yk-admin/manage-commissions/add-commission';

const AddCommissionsPage: NextPage = () => {
  if (!checkPermission('YK_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <AddCommission />
      </CubeWrapper>
    </>
  );
};

export default AddCommissionsPage;
