import axios from 'axios';
import { NextPage } from 'next';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';
import ManageCommissions from 'components/yk-admin/manage-commissions';

const ManageCommissionsPage: NextPage = () => {
  if (!checkPermission('YK_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <ManageCommissions />
      </CubeWrapper>
    </>
  );
};

export default ManageCommissionsPage;
