// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';
import https from 'https';
import { NOTIFICATION_SOMETHING_WENT_WRONG } from 'utils/constants';
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const data = req.body;
  try {
    const response = await axios({
      method: `${data.apiMethod}`,
      url: `${data.apiUrl}`,
      data: data.apiMethod != 'get' ? data?.data : {},
      headers: req.headers.authorization
        ? {
            Authorization: <string>req.headers.authorization,
            accept: 'application/json',
            'Content-Type': 'application/json',
          }
        : {
            accept: 'application/json',
            'Content-Type': 'application/json',
          },
    });
    res.status(response.status).json({ ...response.data });
  } catch (e: any) {
    res.status(e?.response?.status).json({
      error: NOTIFICATION_SOMETHING_WENT_WRONG,
      ...e.response?.data,
    });
  }
}
