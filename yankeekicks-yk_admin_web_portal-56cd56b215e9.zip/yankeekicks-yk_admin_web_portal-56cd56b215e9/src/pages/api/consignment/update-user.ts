// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  try {
    const { id } = req.query;
    const data = req.body;
    const response = await axios({
      method: 'put',
      url: `${process.env.NEXT_PUBLIC_APP_AUTH_STOREFRONT_REST_API_DOMAIN}/user/update/${id}`,
      data: data,
      headers: {
        Authorization: <string>req.headers.authorization,
        accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    res.status(200).json({ data: response.data, status: true });
  } catch (e: any) {
    switch (e.response.data.status) {
      default:
        res.status(e?.response?.status).json({
          error:
            e?.response?.data?.message ||
            'Somethig went wrong, please try later',
          status: false,
          errorInfo: e?.response?.data,
        });
    }
  }
}
