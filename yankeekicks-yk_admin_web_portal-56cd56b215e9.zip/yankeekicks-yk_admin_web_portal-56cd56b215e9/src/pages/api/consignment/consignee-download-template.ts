// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import axios from 'axios';
import type { NextApiRequest, NextApiResponse } from 'next';
import { NOTIFICATION_SOMETHING_WENT_WRONG } from 'utils/constants';

type Data = {
  name: string;
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  try {
    const response = await axios({
      method: 'get',
      url: `${process.env.NEXT_PUBLIC_APP_CONSIGNEE_REST_API_DOMAIN}/downloadCsvTemplate?isYkInventory=true`,
      headers: {
        Authorization: <string>req.headers.authorization,
        'Content-Type': 'text/csv',
      },
    });
    res.send(response.data);
  } catch (e: any) {
    res.status(e?.response?.status).json({
      error: NOTIFICATION_SOMETHING_WENT_WRONG,
      ...e.response?.data,
    });
  }
}
