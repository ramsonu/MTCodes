import axios from 'axios';
import { NextPage } from 'next';
import EditConsignorComponent from 'components/consignment-admin/consignors/edit-consignor';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const ConsignorDetails: NextPage = () => {
  if (!checkPermission('CONSIGNMENT_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <EditConsignorComponent />
      </CubeWrapper>
    </>
  );
};

export default ConsignorDetails;
