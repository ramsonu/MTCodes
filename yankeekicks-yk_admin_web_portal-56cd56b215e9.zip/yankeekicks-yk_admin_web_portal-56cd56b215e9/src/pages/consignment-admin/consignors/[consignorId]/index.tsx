import axios from 'axios';
import { NextPage } from 'next';
import ViewDetailsComp from 'components/consignment-admin/consignors/view-consignor-details';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const ViewConsignor: NextPage = () => {
  if (!checkPermission('CONSIGNMENT_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <ViewDetailsComp />
      </CubeWrapper>
    </>
  );
};

export default ViewConsignor;
