import axios from 'axios';
import { NextPage } from 'next';
import ViewOrderDetails from 'components/consignment-admin/orders/order-details';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const OrderDetails: NextPage = () => {
  if (!checkPermission('CONSIGNMENT_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <ViewOrderDetails />
      </CubeWrapper>
    </>
  );
};

export default OrderDetails;
