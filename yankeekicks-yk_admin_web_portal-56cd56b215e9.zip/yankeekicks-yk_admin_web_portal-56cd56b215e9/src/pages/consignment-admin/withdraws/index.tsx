import { NextPage } from 'next';
import WithdrawComp from 'components/consignment-admin/withdraws/index';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const WithdrawsPage: NextPage = () => {
  if (!checkPermission('CONSIGNMENT_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <WithdrawComp />
      </CubeWrapper>
    </>
  );
};

export default WithdrawsPage;
