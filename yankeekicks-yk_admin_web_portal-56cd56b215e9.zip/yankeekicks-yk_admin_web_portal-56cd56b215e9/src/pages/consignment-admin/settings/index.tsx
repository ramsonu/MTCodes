import { NextPage } from 'next';
import SettingsPage from 'components/consignment-admin/Settings';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const Settings: NextPage = () => {
  if (!checkPermission('CONSIGNMENT_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <SettingsPage />
    </>
  );
};

export default Settings;
