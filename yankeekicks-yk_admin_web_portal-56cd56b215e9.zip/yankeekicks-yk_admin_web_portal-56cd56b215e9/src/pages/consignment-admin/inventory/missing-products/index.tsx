import { NextPage } from 'next';
import MissingProductsComponent from 'components/consignment-admin/products/missing-products';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const MissingProducts: NextPage = () => {
  if (!checkPermission('CONSIGNMENT_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <MissingProductsComponent />
      </CubeWrapper>
    </>
  );
};

export default MissingProducts;
