import axios from 'axios';
import PreviewBulkImport from 'components/consignment-admin/products/bulk-imports/priviewBulkInTabs';
import { NextPage } from 'next';

const PreviewBulk: NextPage = () => {
  return (
    <>
      <PreviewBulkImport />
    </>
  );
};

export default PreviewBulk;
