import axios from 'axios';
import InventoryResponse from 'components/consignment-admin/products/inventoryResponse';
import { NextPage } from 'next';

const PreviewBulk: NextPage = () => {
  return (
    <>
      <InventoryResponse />
    </>
  );
};

export default PreviewBulk;
