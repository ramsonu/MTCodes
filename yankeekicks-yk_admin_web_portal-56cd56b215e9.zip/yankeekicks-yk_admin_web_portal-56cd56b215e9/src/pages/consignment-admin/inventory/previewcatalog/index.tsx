import axios from 'axios';
import { NextPage } from 'next';
import AddShoesToMyInventory from 'components/consignment-admin/products/AddShoesToMyInventory';
import { checkPermission, displayNoResultsFound } from 'utils/util';
import CubeWrapper from 'middleware/cubejs-wrapper';
const PreviewCatalog: NextPage = () => {
  if (!checkPermission('CONSIGNMENT_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }
  return (
    <CubeWrapper>
      <AddShoesToMyInventory />
    </CubeWrapper>
  );
};

export default PreviewCatalog;
