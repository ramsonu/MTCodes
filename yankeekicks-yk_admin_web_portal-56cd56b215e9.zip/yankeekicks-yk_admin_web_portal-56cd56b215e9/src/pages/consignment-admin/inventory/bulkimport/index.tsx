import axios from 'axios';
import { NextPage } from 'next';
import BulkImportComp from 'components/consignment-admin/products/bulk-imports';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const BulkImports: NextPage = () => {
  if (!checkPermission('CONSIGNMENT_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <BulkImportComp />
    </>
  );
};

export default BulkImports;
