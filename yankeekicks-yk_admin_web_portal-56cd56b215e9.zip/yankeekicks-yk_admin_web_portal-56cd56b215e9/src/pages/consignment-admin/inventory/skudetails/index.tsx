import axios from 'axios';
import InventorySkuDetails from 'components/consignment-admin/products/sku-details';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { NextPage } from 'next';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const SKUDetails: NextPage = () => {
  if (!checkPermission('CONSIGNMENT_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <CubeWrapper>
      <InventorySkuDetails />
    </CubeWrapper>
  );
};

export default SKUDetails;
