import axios from 'axios';
import { NextPage } from 'next';
import PrintLabelsComponent from 'components/consignment-admin/products/print-labels';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const PrintLabels: NextPage = () => {
  if (!checkPermission('CONSIGNMENT_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <PrintLabelsComponent />
      </CubeWrapper>
    </>
  );
};

export default PrintLabels;
