import axios from 'axios';
import { NextPage } from 'next';
import PayoutComp from 'components/consignment-admin/payouts';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const Payout: NextPage = () => {
  if (!checkPermission('YK_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <PayoutComp />
      </CubeWrapper>
    </>
  );
};

export default Payout;
