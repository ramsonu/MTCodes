import axios from 'axios';
import { NextPage } from 'next';
import PayoutHistory from 'components/consignment-admin/payouts/view-payout-history';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const PayoutOrderDetails: NextPage = () => {
  if (!checkPermission('CONSIGNMENT_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <PayoutHistory />
      </CubeWrapper>
    </>
  );
};

export default PayoutOrderDetails;
