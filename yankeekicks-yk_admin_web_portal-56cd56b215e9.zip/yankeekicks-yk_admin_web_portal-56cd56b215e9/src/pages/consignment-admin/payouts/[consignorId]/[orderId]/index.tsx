import axios from 'axios';
import { NextPage } from 'next';
import OrdersComponent from 'components/consignment-admin/orders/order-details';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const PayoutOrderDetails: NextPage = () => {
  if (!checkPermission('CONSIGNMENT_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <OrdersComponent showConsginorOrders={true} />
      </CubeWrapper>
    </>
  );
};

export default PayoutOrderDetails;
