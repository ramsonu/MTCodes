import { NextPage } from 'next';
import ConsignmentComp from 'components/consignment-admin/consignments/index';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const Consignments: NextPage = () => {
  if (!checkPermission('CONSIGNMENT_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <ConsignmentComp />
      </CubeWrapper>
    </>
  );
};

export default Consignments;
