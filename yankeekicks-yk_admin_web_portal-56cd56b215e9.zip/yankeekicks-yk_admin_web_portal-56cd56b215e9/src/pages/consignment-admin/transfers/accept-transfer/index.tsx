import React from 'react';
import CubeWrapper from 'middleware/cubejs-wrapper';
import AcceptTransferComp from 'components/consignment-admin/transfers/View-Accept-Transfers/accept-transfer';

const AcceptTransfer = () => {
  return (
    <CubeWrapper>
      <AcceptTransferComp />
    </CubeWrapper>
  );
};

export default AcceptTransfer;
