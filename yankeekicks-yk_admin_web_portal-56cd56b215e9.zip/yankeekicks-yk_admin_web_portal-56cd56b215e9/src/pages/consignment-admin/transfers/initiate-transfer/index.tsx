import axios from 'axios';
import { NextPage } from 'next';
import InitiateTransferComp from 'components/consignment-admin/transfers/Initiate-Transfers/initiate-transfer';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';

const InitiateTransfers: NextPage = () => {
  if (!checkPermission('CONSIGNMENT_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <>
      <CubeWrapper>
        <InitiateTransferComp />
      </CubeWrapper>
    </>
  );
};

export default InitiateTransfers;
