import { NextPage } from 'next';
import CubeWrapper from 'middleware/cubejs-wrapper';
import { checkPermission, displayNoResultsFound } from 'utils/util';
import PreviewTransfer from 'components/consignment-admin/transfers/Review-Transfers/preview-transfer';

const PreviewTransfers: NextPage = () => {
  if (!checkPermission('CONSIGNMENT_ADMIN_PORTAL')) {
    displayNoResultsFound();
  }

  return (
    <CubeWrapper>
      <PreviewTransfer />
    </CubeWrapper>
  );
};

export default PreviewTransfers;
