import React from 'react';
import CubeWrapper from 'middleware/cubejs-wrapper';
import ViewTransferComp from 'components/consignment-admin/transfers/View-Accept-Transfers/view-transfer';

const ViewTransfer = () => {
  return (
    <CubeWrapper>
      <ViewTransferComp />
    </CubeWrapper>
  );
};

export default ViewTransfer;